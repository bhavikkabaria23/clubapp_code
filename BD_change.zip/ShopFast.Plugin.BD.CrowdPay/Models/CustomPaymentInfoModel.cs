﻿using Nop.Core.Infrastructure;
using Nop.Services.Localization;
using Nop.Web.Models.Checkout;
using System.ComponentModel.DataAnnotations;
using FluentValidation.Attributes;
using ShopFast.Plugin.BD.CrowdPay.Validation;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    [Validator(typeof(CustomPaymentInfoValidation))]
    public class CustomPaymentInfoModel
    {
        public CheckoutPaymentInfoModel CheckoutPaymentInfoModel { get; set; }

        public bool Terms { get; set; }
        public string TermsTest { get; set; }

        public bool IsTermOprion { get; set; }

        public bool? TermOption1 { get; set; }
        public bool? TermOption2 { get; set; }
        public bool? TermOption3 { get; set; }
        public bool? TermOption4 { get; set; }        
        public string TermOption1Temp { get; set; }
        public string TermOption2Temp { get; set; }
        public string TermOption3Temp { get; set; }
        public string TermOption4Temp { get; set; }        
    }
}
