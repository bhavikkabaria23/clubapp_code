﻿using Nop.Core.Infrastructure;
using RestSharp;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class CustomerAddUpdateFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int customerId = 0;
            if (filterContext.ActionDescriptor.ActionName == "Create")
            {
                customerId = int.Parse(HttpContext.Current.Session["BD_Admin_CustomerController_Create_Customer_Id"].ToString());
                HttpContext.Current.Session["BD_Admin_CustomerController_Create_Customer_Id"] = null;
            }
            else
            {
                if (form != null)
                {
                    customerId = int.Parse(form["Id"]);
                }
            }
            if (customerId > 0)
            {
                VerificationTemplateModel model = new VerificationTemplateModel();
                BD_VerificationTemplate verificationTemplate = new BD_VerificationTemplate();
                model.VerificationTemplateId = int.Parse(form["VerificationTemplateId"]);
                model.HTMLTemplateIndividual = form["HTMLTemplateIndividual"];
                model.HTMLTemplateCompany = form["HTMLTemplateCompany"];
                model.PDFIndividualUploadId = int.Parse(form["PDFIndividualUploadId"]);
                model.PDFCompanyUploadId = int.Parse(form["PDFCompanyUploadId"]);
                model.customerId = int.Parse(form["customerId"]);
                var check = form["IsDocusign"];
                if (form["IsDocusign"] == "false")
                {
                    model.IsDocusign = false;
                }
                else
                {
                    model.IsDocusign = true;
                }
                model.DocusignUsername = form["DocusignUsername"];
                model.DocusignPassword = form["DocusignPassword"];
                model.DocuSignIntegratorKey = form["DocuSignIntegratorKey"];
                if (model.VerificationTemplateId > 0)
                {
                    verificationTemplate = EngineContext.Current.Resolve<IBDAddressService>().GetVerificationTemplateById(model.VerificationTemplateId);
                }
                verificationTemplate.customerId = model.customerId;
                verificationTemplate.Id = model.VerificationTemplateId;
                verificationTemplate.HTMLTemplateIndividual = model.HTMLTemplateIndividual;
                verificationTemplate.PDFIndividualUploadId = model.PDFIndividualUploadId;
                verificationTemplate.HTMLTemplateCompany = model.HTMLTemplateCompany;
                verificationTemplate.PDFCompanyUploadId = model.PDFCompanyUploadId;
                verificationTemplate.IsDocusign = model.IsDocusign;
                verificationTemplate.DocusignUsername = model.DocusignUsername;
                verificationTemplate.DocusignPassword = model.DocusignPassword;
                verificationTemplate.DocuSignIntegratorKey = model.DocuSignIntegratorKey;
                verificationTemplate.AuthorizeOfferingsJson = SetAuthorizeOfferingJson(form);
                if (model.VerificationTemplateId > 0)
                {
                    EngineContext.Current.Resolve<IBDAddressService>().UpdateVerificationTemplate(verificationTemplate);
                }
                else
                {
                    EngineContext.Current.Resolve<IBDAddressService>().InsertVerificationTemplate(verificationTemplate);
                }
            }
        }

        private string SetAuthorizeOfferingJson(NameValueCollection form)
        {
            List<AuthorizeOffering> Offerings = new List<AuthorizeOffering>();
            var jsonSerialiser = new JavaScriptSerializer();
            try
            {                
                string[] productIds = form["productIds"].Split(',');
                for (int i = 0; i < productIds.Count(); i++)
                {
                    Offerings.Add(new AuthorizeOffering
                    {
                        ProductId = Convert.ToInt32(productIds[i]),
                        IsAuthorize = Convert.ToBoolean(form["IsAuthorize_"+ productIds[i]].Split(',').Count() > 1 ? form["IsAuthorize_"+ productIds[i]].Split(',')[1] : form["IsAuthorize_"+ productIds[i]])
                    });                    
                }
                
                return jsonSerialiser.Serialize(Offerings);
            }
            catch (Exception ex)
            {
                return jsonSerialiser.Serialize(Offerings);
            }
        }
    }
}
