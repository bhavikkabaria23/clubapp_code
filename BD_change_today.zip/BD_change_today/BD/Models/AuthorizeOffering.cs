﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class AuthorizeOffering
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public bool IsAuthorize { get; set; }
    }
}
