﻿using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public partial interface IBDAddressService
    {
        BD_IndividualBasicInfo GetIndividualBasicInfo(int customerId);
        BD_IndividualJointInfo GetIndividualJointInfo(int customerId);
        BD_CompanyBasicInfo GetCompanyBasicInfo(int customerId);
        void InsertIndividualBasicInfo(BD_IndividualBasicInfo individualBasicInfo);
        void UpdateIndividualBasicInfo(BD_IndividualBasicInfo individualBasicInfo);
        void InsertIndividualJointInfo(BD_IndividualJointInfo individualJointInfo);
        void UpdateIndividualJointInfo(BD_IndividualJointInfo individualJointInfo);
        void InsertCompanyBasicInfo(BD_CompanyBasicInfo companyBasicInfo);
        void UpdateCompanyBasicInfo(BD_CompanyBasicInfo companyBasicInfo);
        void InsertInvestorFormData(BD_investorForm investorForm);
        IEnumerable<BD_investorForm> GetInvestorFormDataByProduct(int productId);
        IEnumerable<BD_investorForm> GetInvestorFormData();
        BD_investorForm GetInvestorFormDataById(int Id);
        BD_SubscriptionTemplate GetSubscriptionTemplateById(int Id);
        BD_SubscriptionTemplate GetSubscriptionTemplateByProduct(int productId);
        void InsertSubscriptionTemplate(BD_SubscriptionTemplate subscriptionTemplate);
        void UpdateSubscriptionTemplate(BD_SubscriptionTemplate subscriptionTemplate);
        BD_VerificationTemplate GetVerificationTemplateById(int Id);
        BD_VerificationTemplate GetVerificationTemplateByCustomer(int customerId);
        void InsertVerificationTemplate(BD_VerificationTemplate verificationTemplate);
        void UpdateVerificationTemplate(BD_VerificationTemplate verificationTemplate);
        BD_Documents GetDocumentsById(int Id);
        IEnumerable<BD_Documents> GetDocumentsByCustomer(int customerId);
        void InsertDocuments(BD_Documents documents);
        void UpdateDocuments(BD_Documents documents);
        void DeleteDocumentById(int Id);
        void DeleteDocumentByCustomer(int customerId);
        void InsertUpdateInvestorOrder(BD_InvestorOrder insertInvestorOrder);
        IEnumerable<BD_InvestorOrder> GetInvestorOrder(int productId, int CustomerId);
        int CheckForTypeAndNumberOfInvestor(int productId, int storeId);
        bool CheckForRequireNDAToSigne(int customerId, int productId);
        void SignNDA(int customerId, int productId);
        byte[] ExportInvestorFormDataToXlsx();
        List<AuthorizeOffering> GetCustomerOffering(int customerId);
        bool IsOfferingAuthorize(int productId);

    }
}
