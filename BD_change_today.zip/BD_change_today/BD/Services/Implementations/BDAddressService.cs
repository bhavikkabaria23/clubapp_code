﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Services.Events;
using Nop.Core.Data;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Common;
using Nop.Services.Configuration;
using Nop.Services.ExportImport.Help;
using ShopFast.Plugin.BD.CrowdPay.Models;
using Nop.Services.Directory;
using System.IO;
using Nop.Core.Domain.Catalog;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Nop.Core.Infrastructure;
using System.Drawing;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using System.Web.Script.Serialization;
using Nop.Core;
using Nop.Core.Domain.Customers;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public partial class BDAddressService : IBDAddressService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<BD_IndividualBasicInfo> _individualBasicInfoRepository;
        private readonly IRepository<BD_IndividualJointInfo> _individualJointInfoRepository;
        private readonly IRepository<BD_CompanyBasicInfo> _companyBasicInfoRepository;
        private readonly IRepository<BD_investorForm> _investorFormRepository;
        private readonly IRepository<BD_SubscriptionTemplate> _subscriptionTemplateRepository;
        private readonly IRepository<BD_VerificationTemplate> _verificationTemplateRepository;
        private readonly IRepository<BD_Documents> _documentsRepository;
        private readonly IRepository<BD_InvestorOrder> _investorOrder;
        private readonly ISettingService _settingsService;
        private readonly IRepository<BD_OfferingNDA> _OfferingNDARepository;
        private readonly IProductService _productService;
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;


        #endregion

        public BDAddressService(IEventPublisher eventPublisher,
           IRepository<BD_IndividualBasicInfo> individualBasicInfoRepository,
            IRepository<BD_IndividualJointInfo> individualJointInfoRepository,
                IRepository<BD_CompanyBasicInfo> companyBasicInfoRepository,
            IRepository<BD_investorForm> investorFormRepository,
            IRepository<BD_SubscriptionTemplate> subscriptionTemplateRepository,
            IRepository<BD_Documents> documentsRepository,
            IRepository<BD_VerificationTemplate> verificationTemplateRepository,
            IRepository<BD_InvestorOrder> investorOrder,
            IRepository<BD_OfferingNDA> OfferingNDARepository,
            ISettingService settingsService,
            IProductService productService,
            IStoreContext storeContext,
            IWorkContext workContext)
        {
            this._eventPublisher = eventPublisher;
            this._individualBasicInfoRepository = individualBasicInfoRepository;
            this._individualJointInfoRepository = individualJointInfoRepository;
            this._companyBasicInfoRepository = companyBasicInfoRepository;
            this._investorFormRepository = investorFormRepository;
            this._subscriptionTemplateRepository = subscriptionTemplateRepository;
            this._documentsRepository = documentsRepository;
            this._verificationTemplateRepository = verificationTemplateRepository;
            this._investorOrder = investorOrder;
            this._settingsService = settingsService;
            this._OfferingNDARepository = OfferingNDARepository;
            this._productService = productService;
            this._storeContext = storeContext;
            this._workContext = workContext;
        }

        public virtual BD_IndividualBasicInfo GetIndividualBasicInfo(int customerId)
        {
            if (customerId == 0)
                return null;

            return _individualBasicInfoRepository.Table.FirstOrDefault(b => b.CustomerId == customerId);
        }

        public virtual BD_IndividualJointInfo GetIndividualJointInfo(int customerId)
        {
            if (customerId == 0)
                return null;

            return _individualJointInfoRepository.Table.FirstOrDefault(b => b.CustomerId == customerId);
        }

        public virtual BD_CompanyBasicInfo GetCompanyBasicInfo(int customerId)
        {
            if (customerId == 0)
                return null;

            return _companyBasicInfoRepository.Table.FirstOrDefault(b => b.CustomerId == customerId);
        }

        public virtual void InsertIndividualBasicInfo(BD_IndividualBasicInfo individualBasicInfo)
        {
            if (individualBasicInfo == null)
                throw new ArgumentNullException("individualBasicInfo");

            _individualBasicInfoRepository.Insert(individualBasicInfo);

            //event notification
            _eventPublisher.EntityInserted(individualBasicInfo);
        }

        public virtual void UpdateIndividualBasicInfo(BD_IndividualBasicInfo individualBasicInfo)
        {
            if (individualBasicInfo == null)
                throw new ArgumentNullException("individualBasicInfo");

            _individualBasicInfoRepository.Update(individualBasicInfo);

            //event notification
            _eventPublisher.EntityUpdated(individualBasicInfo);
        }

        public virtual void InsertIndividualJointInfo(BD_IndividualJointInfo individualJointInfo)
        {
            if (individualJointInfo == null)
                throw new ArgumentNullException("individualJointInfo");

            _individualJointInfoRepository.Insert(individualJointInfo);

            //event notification
            _eventPublisher.EntityInserted(individualJointInfo);
        }

        public virtual void UpdateIndividualJointInfo(BD_IndividualJointInfo individualJointInfo)
        {
            if (individualJointInfo == null)
                throw new ArgumentNullException("individualJointInfo");

            _individualJointInfoRepository.Update(individualJointInfo);

            //event notification
            _eventPublisher.EntityUpdated(individualJointInfo);
        }

        public virtual void InsertCompanyBasicInfo(BD_CompanyBasicInfo companyBasicInfo)
        {
            if (companyBasicInfo == null)
                throw new ArgumentNullException("companyBasicInfo");

            _companyBasicInfoRepository.Insert(companyBasicInfo);

            //event notification
            _eventPublisher.EntityInserted(companyBasicInfo);
        }

        public virtual void UpdateCompanyBasicInfo(BD_CompanyBasicInfo companyBasicInfo)
        {
            if (companyBasicInfo == null)
                throw new ArgumentNullException("companyBasicInfo");

            _companyBasicInfoRepository.Update(companyBasicInfo);

            //event notification
            _eventPublisher.EntityUpdated(companyBasicInfo);
        }

        public virtual void InsertInvestorFormData(BD_investorForm investorForm)
        {
            if (investorForm == null)
                throw new ArgumentNullException("investorForm");

            _investorFormRepository.Insert(investorForm);

            //event notification
            _eventPublisher.EntityInserted(investorForm);
        }
        public virtual IEnumerable<BD_investorForm> GetInvestorFormDataByProduct(int productId)
        {
            return _investorFormRepository.Table.Where(b => b.productId == productId);
        }

        public virtual IEnumerable<BD_investorForm> GetInvestorFormData()
        {
            return _investorFormRepository.Table;
        }
        public virtual BD_investorForm GetInvestorFormDataById(int Id)
        {
            if (Id == 0)
                return null;

            return _investorFormRepository.Table.FirstOrDefault(b => b.Id == Id);
        }

        public virtual BD_SubscriptionTemplate GetSubscriptionTemplateById(int Id)
        {
            if (Id == 0)
                return null;

            return _subscriptionTemplateRepository.Table.FirstOrDefault(b => b.Id == Id);
        }
        public virtual BD_SubscriptionTemplate GetSubscriptionTemplateByProduct(int productId)
        {
            if (productId == 0)
                return null;

            return _subscriptionTemplateRepository.Table.FirstOrDefault(b => b.productId == productId);
        }
        public virtual void InsertSubscriptionTemplate(BD_SubscriptionTemplate subscriptionTemplate)
        {
            if (subscriptionTemplate == null)
                throw new ArgumentNullException("SubscriptionTemplate");

            _subscriptionTemplateRepository.Insert(subscriptionTemplate);

            //event notification
            _eventPublisher.EntityInserted(subscriptionTemplate);
        }

        public virtual void UpdateSubscriptionTemplate(BD_SubscriptionTemplate subscriptionTemplate)
        {
            if (subscriptionTemplate == null)
                throw new ArgumentNullException("SubscriptionTemplate");

            _subscriptionTemplateRepository.Update(subscriptionTemplate);

            //event notification
            _eventPublisher.EntityUpdated(subscriptionTemplate);
        }

        #region Individual / Company Verification
        public virtual BD_VerificationTemplate GetVerificationTemplateById(int Id)
        {
            if (Id == 0)
                return null;

            return _verificationTemplateRepository.Table.FirstOrDefault(b => b.Id == Id);
        }
        public virtual BD_VerificationTemplate GetVerificationTemplateByCustomer(int customerId)
        {
            if (customerId == 0)
                return null;

            return _verificationTemplateRepository.Table.FirstOrDefault(b => b.customerId == customerId);
        }
        public virtual void InsertVerificationTemplate(BD_VerificationTemplate verificationTemplate)
        {
            if (verificationTemplate == null)
                throw new ArgumentNullException("VerificationTemplate");

            _verificationTemplateRepository.Insert(verificationTemplate);

            //event notification
            _eventPublisher.EntityInserted(verificationTemplate);
        }

        public virtual void UpdateVerificationTemplate(BD_VerificationTemplate verificationTemplate)
        {
            if (verificationTemplate == null)
                throw new ArgumentNullException("VerificationTemplate");

            _verificationTemplateRepository.Update(verificationTemplate);

            //event notification
            _eventPublisher.EntityUpdated(verificationTemplate);
        }
        #endregion

        #region Upload Documents - BD_Documents
        public virtual BD_Documents GetDocumentsById(int Id)
        {
            if (Id == 0)
                return null;

            return _documentsRepository.Table.FirstOrDefault(b => b.Id == Id);
        }
        public virtual IEnumerable<BD_Documents> GetDocumentsByCustomer(int customerId)
        {
            if (customerId == 0)
                return null;

            return _documentsRepository.Table.Where(b => b.CustomerId == customerId);
        }
        public virtual void InsertDocuments(BD_Documents documents)
        {
            if (documents == null)
                throw new ArgumentNullException("Documents");

            _documentsRepository.Insert(documents);

            //event notification
            _eventPublisher.EntityInserted(documents);
        }
        public virtual void UpdateDocuments(BD_Documents documents)
        {
            if (documents == null)
                throw new ArgumentNullException("Documents");

            _documentsRepository.Update(documents);

            //event notification
            _eventPublisher.EntityUpdated(documents);
        }

        public virtual void DeleteDocumentById(int Id)
        {
            if (Id > 0)
            {
                var documents = _documentsRepository.Table.FirstOrDefault(d => d.Id == Id);
                _documentsRepository.Delete(documents);

                //event notification
                _eventPublisher.EntityDeleted(documents);
            }
        }
        public virtual void DeleteDocumentByCustomer(int customerId)
        {
            if (customerId > 0)
            {
                var documents = _documentsRepository.Table.Where(d => d.CustomerId == customerId).ToList();
                foreach (var doc in documents)
                {
                    _documentsRepository.Delete(doc);

                    //event notification
                    _eventPublisher.EntityDeleted(doc);
                }
            }
        }
        #endregion

        #region Investor Order
        public virtual void InsertUpdateInvestorOrder(BD_InvestorOrder insertInvestorOrder)
        {
            if (insertInvestorOrder == null)
                throw new ArgumentNullException("InsertInvestorOrder");

            var investorOrder = _investorOrder.Table.FirstOrDefault(b => b.CustomerId == insertInvestorOrder.CustomerId && b.ProductId == insertInvestorOrder.ProductId && b.StoreId == insertInvestorOrder.StoreId);
            if (investorOrder == null)
            {
                _investorOrder.Insert(insertInvestorOrder);
            }
            else
            {
                _investorOrder.Update(insertInvestorOrder);
            }

            //event notification
            _eventPublisher.EntityInserted(insertInvestorOrder);
        }
        public virtual IEnumerable<BD_InvestorOrder> GetInvestorOrder(int productId, int CustomerId)
        {
            return _investorOrder.Table.Where(b => b.CustomerId == CustomerId && b.ProductId == productId);
        }
        #endregion

        #region Offering Type Rules Conditions
        // 0 => Can go to checkout page or Accreditation and invest. All conditions passed
        // 1 -> Do not show Non-Accreditted box , only Allow Accreditted.   
        //      can not go to checkout page if customer is Non-Accreditted. Redirect to Accreditation page to select Investor Type
        // 2 -> Do not show Accreditted box , only Allow Non-Accreditted
        //      can not go to checkout page if customer is Accreditted. Redirect to Accreditation page to select investor type
        // 3 -> Do not Allow for any one. Can not go to my Accreditation or checkout page                
        public virtual int CheckForTypeAndNumberOfInvestor(int productId, int storeId)
        {
            int offeringType = Convert.ToInt32(_subscriptionTemplateRepository.Table.FirstOrDefault(s => s.productId == productId).OfferingType);
            if (offeringType > 0)
            {
                var investorOrder = _investorOrder.Table.Where(o => o.ProductId == productId && o.StoreId == storeId);
                int accredited = 0;
                int non_accredited = 0;
                if (investorOrder.Any())
                {
                    accredited = investorOrder.Count(o => o.InvestorType == ClientConstants.InvestorType.Accreddited);
                    non_accredited = investorOrder.Count(o => o.InvestorType == ClientConstants.InvestorType.NonAccreditted);
                }
                if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_506b))
                {
                    if (accredited >= 2000 && non_accredited >= 35)
                    {
                        return 3;
                    }
                    else if (accredited < 2000 && non_accredited >= 35)
                    {
                        return 1;
                    }
                    else if (accredited >= 2000 && non_accredited < 35)
                    {
                        return 2;
                    }
                }
                else if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_506c))
                {
                    if (accredited >= 2000)
                    {
                        return 3;
                    }
                    else
                    {
                        return 1;
                    }
                }
            }
            return 0;
        }

        // Now Will work for both single offering and multiple offering
        public bool CheckForRequireNDAToSigne(int customerId, int productId)
        {
            // Old code
            //var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            //if (settings.SingleOfferProductId > 0)
            //{
            //    var subscriptionTemplate = _subscriptionTemplateRepository.Table.FirstOrDefault(s => s.productId == settings.SingleOfferProductId);
            //    if (subscriptionTemplate != null)
            //    {
            //        if (subscriptionTemplate.OfferingType == ClientConstants.OfferingType.type_506c && subscriptionTemplate.AllowNDA == true)
            //        {
            //            var verificationTemplate = _verificationTemplateRepository.Table.FirstOrDefault(b => b.customerId == customerId);
            //            // check for NDA signed or not
            //            if (verificationTemplate != null && Convert.ToBoolean(verificationTemplate.IsNDASigned))
            //            {
            //                return false; // NDA is already signed
            //            }
            //            else
            //            {
            //                return true; // NDA is still not signed
            //            }
            //        }
            //    }
            //}
            //return false;
            //----------------------------
            // New code
            if (customerId > 0 && productId > 0)
            {
                var subscriptionTemplate = _subscriptionTemplateRepository.Table.FirstOrDefault(s => s.productId == productId);
                if (subscriptionTemplate != null)
                {
                    if (subscriptionTemplate.AllowNDA == true)
                    {
                        var offeringNda = _OfferingNDARepository.Table.FirstOrDefault(n => n.CustomerId == customerId && n.ProductId == productId);
                        // check for NDA signed or not
                        if (offeringNda != null && offeringNda.IsNDASigned)
                        {
                            return false; // NDA is already signed
                        }
                        else
                        {
                            return true; // NDA is still not signed
                        }
                    }
                }
            }
            return false;
            //-------------------------
        }

        public virtual void SignNDA(int customerId, int productId)
        {
            // Old code
            //var verificationTemplate = _verificationTemplateRepository.Table.FirstOrDefault(b => b.customerId == customerId);
            //if (verificationTemplate == null)
            //{
            //    verificationTemplate = new BD_VerificationTemplate();
            //}
            //verificationTemplate.IsNDASigned = true;
            //if (verificationTemplate.Id > 0)
            //{
            //    _verificationTemplateRepository.Update(verificationTemplate);
            //}
            //else
            //{
            //    verificationTemplate.customerId = customerId;
            //    _verificationTemplateRepository.Insert(verificationTemplate);
            //}

            ////event notification
            //_eventPublisher.EntityUpdated(verificationTemplate);
            //---------------

            // New code
            if (customerId > 0 && productId > 0)
            {
                var offeringNda = new BD_OfferingNDA();
                offeringNda.CustomerId = customerId;
                offeringNda.ProductId = productId;
                offeringNda.IsNDASigned = true;

                _OfferingNDARepository.Insert(offeringNda);

                //event notification
                _eventPublisher.EntityUpdated(offeringNda);

            }
            //--------------
        }
        #endregion

        #region Export ToExcel
        /// <summary>
        /// Export products to XLSX
        /// </summary>
        /// <param name="products">Products</param>
        public virtual byte[] ExportInvestorFormDataToXlsx()
        {
            var investorForm = GetInvestorFormData();

            InvestorFormModel model = new InvestorFormModel();
            var properties = new[]
            {
                new PropertyByName<BD_investorForm>("FormType", p => p.FormType),
                new PropertyByName<BD_investorForm>("productId", p => EngineContext.Current.Resolve<IProductService>().GetProductById(p.productId).Name),
                new PropertyByName<BD_investorForm>("FirstName", p => p.FirstName),
                new PropertyByName<BD_investorForm>("LastName", p => p.LastName),
                new PropertyByName<BD_investorForm>("Phone", p => p.Phone),
                new PropertyByName<BD_investorForm>("Email", p => p.Email),
                new PropertyByName<BD_investorForm>("CountryId", p => EngineContext.Current.Resolve<ICountryService>().GetCountryById(p.CountryId).Name),
                new PropertyByName<BD_investorForm>("StateId", p => EngineContext.Current.Resolve<IStateProvinceService>().GetStateProvinceById(p.StateId).Name),
                new PropertyByName<BD_investorForm>("ZipPostalCode", p => p.ZipPostalCode),
                new PropertyByName<BD_investorForm>("LanguageId", p => (Convert.ToInt32(p.LanguageId) > 0) ? EngineContext.Current.Resolve<ILanguageService>().GetLanguageById(Convert.ToInt32(p.LanguageId)).Name : ""),
                new PropertyByName<BD_investorForm>("LookingToInvest", p => (model.LookingToInvestList.FirstOrDefault(i => i.Value == p.LookingToInvest.ToString()) != null)
                    ?model.LookingToInvestList.FirstOrDefault(i => i.Value == p.LookingToInvest.ToString()).Text
                    :model.LookingToInvestList.FirstOrDefault(i => i.Value == "5").Text),
                new PropertyByName<BD_investorForm>("PreferedContacts", p => p.PreferedContacts),
                new PropertyByName<BD_investorForm>("CreatedOn", p => p.CreatedOn.ToString()),
            };

            var investorFormList = investorForm.ToList();

            return ExportToXlsx(properties, investorFormList);
        }

        protected virtual void SetCaptionStyle(ExcelStyle style)
        {
            style.Fill.PatternType = ExcelFillStyle.Solid;
            style.Fill.BackgroundColor.SetColor(Color.FromArgb(184, 204, 228));
            style.Font.Bold = true;
        }

        protected virtual byte[] ExportToXlsx<T>(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport)
        {
            using (var stream = new MemoryStream())
            {
                // ok, we can run the real code of the sample now
                using (var xlPackage = new ExcelPackage(stream))
                {
                    // uncomment this line if you want the XML written out to the outputDir
                    //xlPackage.DebugMode = true; 

                    // get handles to the worksheets
                    var worksheet = xlPackage.Workbook.Worksheets.Add(typeof(T).Name);
                    var fWorksheet = xlPackage.Workbook.Worksheets.Add("DataForFilters");
                    fWorksheet.Hidden = eWorkSheetHidden.VeryHidden;

                    //create Headers and format them 
                    var manager = new PropertyManager<T>(properties.Where(p => !p.Ignore));
                    manager.WriteCaption(worksheet, SetCaptionStyle);

                    var row = 2;
                    foreach (var items in itemsToExport)
                    {
                        manager.CurrentObject = items;
                        manager.WriteToXlsx(worksheet, row++, EngineContext.Current.Resolve<CatalogSettings>().ExportImportUseDropdownlistsForAssociatedEntities, fWorksheet: fWorksheet);
                    }

                    xlPackage.Save();
                }
                return stream.ToArray();
            }
        }
        #endregion

        #region Customer Offering
        public virtual List<AuthorizeOffering> GetCustomerOffering(int customerId)
        {
            List<AuthorizeOffering> Offerings = new List<AuthorizeOffering>();
            try
            {
                if (customerId > 0)
                {
                    var customerVerification = _verificationTemplateRepository.Table.FirstOrDefault(b => b.customerId == customerId);
                    if (customerVerification != null && !string.IsNullOrEmpty(customerVerification.AuthorizeOfferingsJson))
                    {
                        JavaScriptSerializer js = new JavaScriptSerializer();
                        Offerings = js.Deserialize<List<AuthorizeOffering>>(customerVerification.AuthorizeOfferingsJson);
                        if (Offerings.Any())
                        {
                            var products = _productService.SearchProducts(storeId: _storeContext.CurrentStore.Id).Where(p => Offerings.Any(o => o.ProductId == p.Id))
                                .Select(pro => new AuthorizeOffering()
                                {
                                    ProductId = pro.Id,
                                    ProductName = pro.Name,
                                    IsAuthorize = Offerings.FirstOrDefault(of => of.ProductId == pro.Id).IsAuthorize
                                });
                            return products.ToList();
                        }
                    }
                }
                return Offerings;
            }
            catch
            {
                return Offerings;
            }
        }

        public virtual bool IsOfferingAuthorize(int productId)
        {
            // -> Check "AuthorizeOffering" for product level. 
            // if it is "true" then Allow for all customers, no need to check authorize for customer
            // -> if it is "false" then check authorize for customer level
            try
            {
                if (productId > 0 && _workContext.CurrentCustomer.IsRegistered())
                {
                    var subscription = _subscriptionTemplateRepository.Table.FirstOrDefault(b => b.productId == productId);
                    if (subscription != null)
                    {
                        // if it is "true" then Allow for all customers, no need to check authorize for customer
                        if (subscription.AuthorizeOffering)
                        {
                            return true;
                        }
                        // if it is "false" then check authorize for customer level
                        else
                        {
                            var customerVerification = _verificationTemplateRepository.Table.FirstOrDefault(b => b.customerId == _workContext.CurrentCustomer.Id);
                            if (customerVerification != null && !string.IsNullOrEmpty(customerVerification.AuthorizeOfferingsJson))
                            {
                                JavaScriptSerializer js = new JavaScriptSerializer();
                                var Offerings = js.Deserialize<List<AuthorizeOffering>>(customerVerification.AuthorizeOfferingsJson);
                                if (Offerings.Any(o => o.ProductId == productId && o.IsAuthorize == true))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                return false;
            }

            return false;
        }


        #endregion

    }
}
