﻿using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public class BD_SubscriptionTemplateMap : NopEntityTypeConfiguration<BD_SubscriptionTemplate>
    {
        public BD_SubscriptionTemplateMap()
        {
            this.ToTable("BD_SubscriptionTemplate");
            this.HasKey(tr => tr.Id);            
        }
    }
}
