﻿using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public class BD_investorFormMap : NopEntityTypeConfiguration<BD_investorForm>
    {
        public BD_investorFormMap()
        {
            this.ToTable("BD_investorForm");
            this.HasKey(tr => tr.Id);            
        }
    }
}
