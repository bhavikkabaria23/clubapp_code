using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public partial class BD_CompanyBasicInfoMap : NopEntityTypeConfiguration<BD_CompanyBasicInfo>
    {
        public BD_CompanyBasicInfoMap()
        {
            this.ToTable("BD_CompanyBasicInfo");
            this.HasKey(tr => tr.Id);            
        }
    }
}