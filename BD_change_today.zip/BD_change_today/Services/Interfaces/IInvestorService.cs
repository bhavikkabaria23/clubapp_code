﻿using System;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public partial interface IInvestorService
    {
        IPagedList<Customer> GetAllCustomers(DateTime? createdFromUtc = null,
          DateTime? createdToUtc = null, int affiliateId = 0, int vendorId = 0,
          int[] customerRoleIds = null, string email = null, string username = null,
          string firstName = null, string lastName = null,
          int dayOfBirth = 0, int monthOfBirth = 0,
          string company = null, string phone = null, string zipPostalCode = null,
          string ipAddress = null, bool loadOnlyWithShoppingCart = false, ShoppingCartType? sct = null,
          int pageIndex = 0, int pageSize = int.MaxValue);

        /// <summary>
        /// Get best customers
        /// </summary>
        /// <param name="createdFromUtc">Order created date from (UTC); null to load all records</param>
        /// <param name="createdToUtc">Order created date to (UTC); null to load all records</param>
        /// <param name="os">Order status; null to load all records</param>
        /// <param name="ps">Order payment status; null to load all records</param>
        /// <param name="ss">Order shipment status; null to load all records</param>
        /// <param name="orderBy">1 - order by order total, 2 - order by number of orders</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="vendorId">Vendor identifier; null to load all orders</param>
        /// <param name="pageSize">Page size</param>
        /// <returns>Report</returns>
        IPagedList<BestCustomerReportLine> GetBestCustomersReport(DateTime? createdFromUtc,
            DateTime? createdToUtc, OrderStatus? os, PaymentStatus? ps, ShippingStatus? ss, int orderBy,
            int vendorId = 0, int pageIndex = 0, int pageSize = 214748364);

        /// <summary>
        /// Gets a report of customers registered in the last days
        /// </summary>
        /// <param name="days">Customers registered in the last days</param>
        /// <param name="vendorId">Vendor identifier; null to load all orders</param>
        /// <returns>Number of registered customers</returns>
        int GetRegisteredCustomersReport(int days, int vendorId = 0);
    }
}