﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using Nop.Core;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using RestSharp;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using Nop.Services.Logging;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class BlockScoreService : IBlockScoreService
    {
        private readonly ISettingService _settingService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICountryService _countryService;
        private readonly ICustomerService _customerService;
        private readonly IWorkContext _workContext;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomCustomerAttributeParser _customCustomerAttributeParser;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly ICustomAddressAttributeParser _customAddressAttributeParser;
        private readonly ILogger _logger;

        public BlockScoreService(ISettingService settingService, IStateProvinceService stateProvinceService,
            ICountryService countryService, ICustomerService customerService, IWorkContext workContext,
            IGenericAttributeService genericAttributeService, ICustomCustomerAttributeParser customCustomerAttributeParser,
            IAddressAttributeFormatter addressAttributeFormatter, IAddressAttributeParser addressAttributeParser, ICustomAddressAttributeParser customAddressAttributeParser,
            ILogger logger)
        {
            _settingService = settingService;
            _stateProvinceService = stateProvinceService;
            _countryService = countryService;
            _customerService = customerService;
            _workContext = workContext;
            _genericAttributeService = genericAttributeService;
            _customCustomerAttributeParser = customCustomerAttributeParser;
            _addressAttributeParser = addressAttributeParser;
            _customAddressAttributeParser = customAddressAttributeParser;
            this._logger = logger;
        }

        /// <summary>
        /// Verifies customer by BlockScore API
        /// </summary>
        /// <param name="model">Customer Info</param>
        public void VerifyCustomer(IndividualsModel model)
        {
            var client = new RestClient(String.Format("{0}{1}", ClientConstants.ExternalApi.BlackScoreApi, ClientConstants.BlockScore.VerificationType.Customer));
            var request = new RestRequest(Method.POST);

            //adding request settings: headers, credentials, ect.
            SetRequestSettings(request);

            //adding parameters
            var currentCustomer = _workContext.CurrentCustomer;
            var customAttributesXml = currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            var blockScoreCustomerId = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.BlockScoreObjectId);
            if (!String.IsNullOrEmpty(blockScoreCustomerId))
            {
                request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.CustomerId, blockScoreCustomerId);
            }

            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.FirstName, model.FirstName);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.LastName, model.LastName);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.Street1, model.StreetAddress);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.Street2, model.StreetAddress2);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.DocumentValue, model.SSN);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.City, model.City);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.PostalCode, model.ZipPostalCode);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.Phone, model.Phone);

            var contertedDate = DateTime.Parse(model.DateOfBirth);
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.BirthDay, contertedDate.Day.ToString());
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.BirthMonth, contertedDate.Month.ToString());
            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.BirthYear, contertedDate.Year.ToString());

            var country = _countryService.GetCountryById(model.CountryId);
            if (country != null)
            {
                request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.CountryCode, country.TwoLetterIsoCode);

                if (country.TwoLetterIsoCode.Contains("US"))
                {
                    request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.DocumentType,
                        ClientConstants.BlockScore.PassportTypes.SSN);
                }
                else
                {
                    request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.DocumentType,
                       ClientConstants.BlockScore.PassportTypes.PASSPORT);
                }
            }
            var stateProvince = _stateProvinceService.GetStateProvinceById(model.StateProvinceId);

            request.AddParameter(ClientConstants.BlockScore.CustomerFormAttributes.State, stateProvince != null ? stateProvince.Abbreviation : "None");

            IRestResponse response = client.Execute(request);
            if (response.StatusCode == HttpStatusCode.Created)
            {
                _logger.Information("BlockScoreContent: " + response.Content);
                if (!String.IsNullOrEmpty(response.Content))
                {
                    var blockScoreResponse = GetDesirializedResponse<BlockScoreCustomerResponse>(response.Content);
                    if (blockScoreResponse.Error != null)
                    {
                        throw new Exception(blockScoreResponse.Error.Message);
                    }

                    var blockScoreAttributes = new Dictionary<string, string>
                    {
                        {ClientConstants.CustomAttributes.BlockScoreAdressMatch, blockScoreResponse.Details.Address },
                        {ClientConstants.CustomAttributes.BlockScoreAdressRisk, blockScoreResponse.Details.Address_Risk },
                        {ClientConstants.CustomAttributes.BlockScorePassportMatch, blockScoreResponse.Details.Identification },
                        {ClientConstants.CustomAttributes.BlockScoreDateOfBirthMath, blockScoreResponse.Details.Date_Of_Birth },
                        {ClientConstants.CustomAttributes.BlockScoreOfacMath, blockScoreResponse.Details.Ofac },
                        {ClientConstants.CustomAttributes.BlockScorePepMatch, blockScoreResponse.Details.Pep },
                        {ClientConstants.CustomAttributes.BlockScoreObjectId, blockScoreResponse.Id },
                        {ClientConstants.CustomAttributes.BlockScoreStatus, blockScoreResponse.Status },
                    };
                    InsertOrUpdateBlockScoreAttributes(currentCustomer.Id,
                        ClientConstants.GerenicAttributeKeyGroup.CustomerGroup, blockScoreAttributes);
                }
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                throw new Exception(response.Content);
            }
        }

        /// <summary>
        /// Verifies company by BlockScore API
        /// </summary>
        /// <param name="model">Company Info</param>
        public void VerifyCompany(PersonalInformationModel model)
        {
            var client = new RestClient(String.Format("{0}{1}", ClientConstants.ExternalApi.BlackScoreApi, ClientConstants.BlockScore.VerificationType.Company));
            var request = new RestRequest(Method.POST);

            //adding request settings: headers, credentials, ect.
            SetRequestSettings(request);

            //adding parameters
            var companyAddress = new Address();
            var currentCustomer = _workContext.CurrentCustomer;

            //Company information is stored in special address
            foreach (var address in currentCustomer.Addresses)
            {
                var addressAttributes = _addressAttributeParser.ParseAddressAttributeValues(address.CustomAttributes);
                if (addressAttributes.Any(addressAttribute => addressAttribute.AddressAttribute.Name == ClientConstants.CustomAttributes.CompanyAddress))
                {
                    companyAddress = address;
                }
            }

            var blockScoreCompanyId = _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.BlockScoreObjectId);
            if (!String.IsNullOrEmpty(blockScoreCompanyId))
            {
                request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.CompanyId, blockScoreCompanyId);
            }

            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.CompanyName, model.OtherInfoModel.CompanyInfo.Company);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.Phone, model.OtherInfoModel.CompanyInfo.PhoneNumber);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.Street1, model.OtherInfoModel.CompanyInfo.Address1);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.Street2, model.OtherInfoModel.CompanyInfo.Address2);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.City, model.OtherInfoModel.CompanyInfo.City);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.PostalCode, model.OtherInfoModel.CompanyInfo.ZipPostalCode);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.Phone, model.OtherInfoModel.CompanyInfo.PhoneNumber);
            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.TaxId, model.OtherInfoModel.TaxId);

            string corporationType;
            switch (model.OtherInfoModel.InfoType)
            {
                case ClientConstants.PersonalInfoType.Company:
                    corporationType = ClientConstants.BlockScore.CorporationTypes.Corporation;
                    break;
                default:
                    corporationType = ClientConstants.BlockScore.CorporationTypes.Other;
                    break;
            }

            request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.CorporationType, corporationType);

            if (model.OtherInfoModel.CompanyInfo.CountryId != null)
            {
                var country = _countryService.GetCountryById(model.OtherInfoModel.CompanyInfo.CountryId.Value);
                if (country != null)
                {
                    request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.CountryCode, country.TwoLetterIsoCode);
                    request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.CorporationCountryCode, country.TwoLetterIsoCode);
                }
            }
            if (model.OtherInfoModel.CompanyInfo.StateProvinceId != null)
            {
                var stateProvince = _stateProvinceService.GetStateProvinceById(model.OtherInfoModel.CompanyInfo.StateProvinceId.Value);

                request.AddParameter(ClientConstants.BlockScore.CompanyFormAttributes.State, stateProvince != null ? stateProvince.Abbreviation : "None");
            }

            //parsing API response
            IRestResponse response = client.Execute(request);
            if (response.StatusCode == HttpStatusCode.Created)
            {
                if (!String.IsNullOrEmpty(response.Content))
                {
                    var blockScoreResponse = GetDesirializedResponse<BlockScoreCompanyScoreResponse>(response.Content);
                    if (blockScoreResponse.Error != null)
                    {
                        throw new Exception(blockScoreResponse.Error.Message);
                    }

                    var blockScoreAttributes = new Dictionary<string, string>
                    {
                        {ClientConstants.CustomAttributes.BlockScoreAdressMatch, blockScoreResponse.Details.Address },
                        {ClientConstants.CustomAttributes.BlockScoreCompanyNameMatch, blockScoreResponse.Entity_name },
                        {ClientConstants.CustomAttributes.BlockScoreOfacMath, blockScoreResponse.Details.Ofac },
                        {ClientConstants.CustomAttributes.BlockScoreStateMatch, blockScoreResponse.Details.State },
                        {ClientConstants.CustomAttributes.BlockScoreTaxIdMatch, blockScoreResponse.Details.Tax_Id },
                        {ClientConstants.CustomAttributes.BlockScoreCompanyCountryCodeMatch, blockScoreResponse.Details.Country_code },
                        {ClientConstants.CustomAttributes.BlockScoreObjectId, blockScoreResponse.Id },
                        {ClientConstants.CustomAttributes.BlockScoreStatus, blockScoreResponse.Status },
                    };
                    InsertOrUpdateBlockScoreAttributes(currentCustomer.Id,
                        ClientConstants.GerenicAttributeKeyGroup.CompanyGroup, blockScoreAttributes);
                }
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                throw new Exception(response.Content);
            }
        }

        #region helpers methods
        private T GetDesirializedResponse<T>(string response)
        {
            return JsonConvert.DeserializeObject<T>(response);
        }

        private void SetRequestSettings(RestRequest request)
        {
            var settings = _settingService.LoadSetting<CrowdPaySettings>();

            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Accept", "application/vnd.blockscore+json;version=4");
            request.Credentials = new NetworkCredential(settings.BlockScoreKey, "");
        }

        //blockscore responses are stored in generic attributes, so we need to insert or update their
        private void InsertOrUpdateBlockScoreAttributes(int entityId, string keyGroup,
            Dictionary<string, string> blockScoreAttributes)
        {
            foreach (var attribute in blockScoreAttributes)
            {
                var blockScoreGenericAttribute = _genericAttributeService.GetAttributesForEntity(
                      entityId, keyGroup).
                      FirstOrDefault(x => x.Key == attribute.Key);
                if (blockScoreGenericAttribute != null)
                {
                    blockScoreGenericAttribute.Value = attribute.Value;
                    _genericAttributeService.UpdateAttribute(blockScoreGenericAttribute);
                }
                else
                {
                    blockScoreGenericAttribute = new GenericAttribute()
                    {
                        EntityId = entityId,
                        Key = attribute.Key,
                        KeyGroup = keyGroup,
                        Value = attribute.Value
                    };
                    _genericAttributeService.InsertAttribute(blockScoreGenericAttribute);
                }
            }

        }
    }
    #endregion
}
