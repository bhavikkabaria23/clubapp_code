﻿using System;
using System.Linq;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Logging;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Logging;
using RestSharp;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class VerifyInvestorService : IVerifyInvestorService
    {
        private readonly ISettingService _settingService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly Customer _currentCustomer;
        private readonly IStoreContext _storeContext;
        private readonly IWebHelper _webHelper;
        private readonly ILogger _logger;

        public VerifyInvestorService(ISettingService settingService, IWorkContext workContext, IStoreContext storeContext, IWebHelper webHelper, ICustomGenericAttributeService customGenericAttributeService, ILogger logger)
        {
            _settingService = settingService;
            _storeContext = storeContext;
            _webHelper = webHelper;
            _customGenericAttributeService = customGenericAttributeService;
            _logger = logger;
            _currentCustomer = workContext.CurrentCustomer;
        }

        public void VerifyCustomer(int viUserId, out string redirectUrl)
        {
            var client = new RestClient(String.Format("{0}api/v1/",
                        ClientConstants.ExternalApi.VerifyInvestorTest));
            var request = new RestRequest(Method.GET);
            SetRequestSettings(request);

            IRestResponse response = client.Execute(request);
            redirectUrl = String.Empty;

            if (response.StatusCode == HttpStatusCode.OK)
            {
                client =
                    new RestClient(String.Format("{0}api/v1/users/{1}/verification_requests",
                        ClientConstants.ExternalApi.VerifyInvestorTest, viUserId));

                request = new RestRequest(Method.POST);
                SetRequestSettings(request);

                //adding request params
                request.AddParameter(ClientConstants.VerifyInvestor.CustomerFormAttributes.Email, _currentCustomer.Email);

                var company = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Company);
                if (!String.IsNullOrEmpty(company))
                {
                    request.AddParameter(ClientConstants.VerifyInvestor.CustomerFormAttributes.CompanyName, company);
                }
                request.AddParameter(ClientConstants.VerifyInvestor.CustomerFormAttributes.PortalName,
                    _storeContext.CurrentStore.Name);

                var currentProduct =
                    _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                        ClientConstants.TempCheckOutGenericAttirubutes.ProductId);

                if (currentProduct != null)
                {
                    request.AddParameter(ClientConstants.VerifyInvestor.CustomerFormAttributes.RedirectUrl,
                        String.Format("{0}CrowdPayPage?productId={1}", _webHelper.GetStoreLocation(), currentProduct.Value));
                }

                //get response
                response = client.Execute(request);
                if (response.StatusCode == HttpStatusCode.Created || response.StatusCode.ToString() == ClientConstants.VerifyInvestor.StatusCode.PendingVerification)
                {
                    if (!String.IsNullOrEmpty(response.Content))
                    {
                        var verifyInvestorResponse =
                            GetDesirializedResponse<InvestorVerificationPendingResponse>(response.Content);
                        if (!String.IsNullOrEmpty(verifyInvestorResponse.error))
                        {
                            if (verifyInvestorResponse.error == ClientConstants.VerifyInvestor.ErrorMessages.OkError)
                            {
                                redirectUrl = verifyInvestorResponse.pending_verification_request.investor_url;
                            }
                            _logger.InsertLog(LogLevel.Debug, verifyInvestorResponse.error);
                        }
                        else
                        {
                           var succesullyReponse =
                            GetDesirializedResponse<PendingVerificationResponse>(response.Content);

                            redirectUrl = succesullyReponse.investor_url;
                            _customGenericAttributeService.SaveGenericAttirubteValue(String.Format(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorId, viUserId), succesullyReponse.id.ToString());
                        }
                    }
                }
                else
                {
                    _logger.InsertLog(LogLevel.Error, response.ErrorMessage ?? "", response.Content);
                }
            }
            else
            {
                _logger.InsertLog(LogLevel.Error, response.ErrorMessage ?? "", response.Content);
            }
        }

        public UserVerificationStatus GetUserVerificationStatus(int userId)
        {
            var client = new RestClient(String.Format("{0}/api/v1/users/{1}",
                         ClientConstants.ExternalApi.VerifyInvestorTest,userId));
            var request = new RestRequest(Method.GET);
            SetRequestSettings(request);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                var verifyStatusResponse =
                           GetDesirializedResponse<UserVerificationStatus>(response.Content);

                return verifyStatusResponse;
            }
            else
            {
                _logger.InsertLog(LogLevel.Error, response.StatusCode.ToString(), response.Content);
            }

            return null;
        }

        public byte[] GetVerificationCertificate(int viUserId)
        {
            var client = new RestClient(String.Format("{0}/api/v1/users/{1}/verification_certificate",
                         ClientConstants.ExternalApi.VerifyInvestorTest, viUserId));
            var request = new RestRequest(Method.GET);
            SetRequestSettings(request);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                return response.RawBytes;
            }
            else
            {
                _logger.InsertLog(LogLevel.Error, response.StatusCode.ToString(), response.Content);
            }
            return null;;
        }

        public string GetRedirectUrlForInvestor(int vi_user_id)
        {
            var existingInvestorId =
              _customGenericAttributeService.GetAttributesByName(
                  String.Format(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorId, vi_user_id)).FirstOrDefault();
            if (existingInvestorId != null)
            {
                return String.Format("{0}/investor/verification-requests/{1}/verification-method",
                    ClientConstants.ExternalApi.VerifyInvestorTest,
                    existingInvestorId.Value);
            }

            return String.Empty;
        }

        private void SetRequestSettings(RestRequest request)
        {
            var settings = _settingService.LoadSetting<CrowdPaySettings>();

            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Accept", "application/vnd.blockscore+json;version=4");
            request.AddHeader("Authorization", String.Format("Token {0}", settings.VerifyInvestorApiKey));
        }

        private T GetDesirializedResponse<T>(string response)
        {
            return JsonConvert.DeserializeObject<T>(response);
        }
    }
}
