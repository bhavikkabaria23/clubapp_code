﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class BD_Documents : BaseEntity
    {
        public int CustomerId { get; set; }
        public int DocumentUploadId { get; set; }
        public string description { get; set; }
        //public int DocumentUploadId1 { get; set; }
        //public int DocumentUploadId2 { get; set; }
        //public int DocumentUploadId3 { get; set; }
        //public int DocumentUploadId4 { get; set; }
        //public int DocumentUploadId5 { get; set; }
        //public string description1 { get; set; }
        //public string description2 { get; set; }
        //public string description3 { get; set; }
        //public string description4 { get; set; }
        //public string description5 { get; set; }
        public bool IsApproved { get; set; }
        public int? ApprovedById { get; set; } //ID of approved by which customer
        public string ApprovedByName { get; set; } // Name of customer
        public string ApprovedByEmail { get; set; } // Customer email
        public DateTime? ApproveDate { get; set; }
        public string Comment { get; set; }
        public string InvestorComment { get; set; }
    }
}
