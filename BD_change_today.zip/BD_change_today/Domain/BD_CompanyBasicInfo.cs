﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public partial class BD_CompanyBasicInfo : BaseEntity
    {
        public int CustomerId { get; set; }
        public string Business_City { get; set; }
        public int Business_Country { get; set; }        
        public int Business_State { get; set; }        
        public string Business_Zip { get; set; }        
        public string Business_Website { get; set; }
        public string EIN { get; set; }        
        public bool IsBasicSaved { get; set; }        
    }
}
