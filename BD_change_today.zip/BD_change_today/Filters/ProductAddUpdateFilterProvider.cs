﻿using Nop.Admin.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class ProductAddUpdateFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(ProductController)) &&
                (actionDescriptor.ActionName.Equals("Edit") || actionDescriptor.ActionName.Equals("Create")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                return new[]
                    {
                        new Filter(new ProductAddUpdateFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}
