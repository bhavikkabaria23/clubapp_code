﻿using Nop.Core.Infrastructure;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Core;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class NDAFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (EngineContext.Current.Resolve<IBDAddressService>().CheckForRequireNDAToSigne(EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.Id,0))
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { area = "", action = "LoadNDAForm", Controller = "CrowdPayCheckOut" }));
            }
        }        
    }
}
