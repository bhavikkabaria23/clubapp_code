﻿using ShopFast.Plugin.BD.CrowdPay.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class NDAFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if (((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CrowdPayInvestmentController)) &&
                (actionDescriptor.ActionName.Equals("PublicInfo")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "GET") ||
                ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CrowdPayCheckOutController)) &&
                (actionDescriptor.ActionName.Equals("Accreditation")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "GET")
                )
            {
                return new[]
                    {
                        new Filter(new NDAFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}
