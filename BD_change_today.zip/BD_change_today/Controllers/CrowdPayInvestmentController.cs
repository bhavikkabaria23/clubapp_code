﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Seo;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Web.Controllers;
using Nop.Web.Extensions;
using Nop.Web.Framework.Controllers;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using Newtonsoft.Json;
using iTextSharp.text.pdf;
using System.Drawing;
using System.Drawing.Imaging;
using System.Web.Script.Serialization;
using Nop.Web.Framework.Kendoui;
using Nop.Services.Security;
using Shopfast.Plugin.Custom.Services.Messages;
using System.Text;
using Nop.Services.Topics;
using Nop.Core.Infrastructure;
using Nop.Services.Media;
using Nop.Services.Helpers;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdPayInvestmentController : CheckoutController
    {
        #region Properties
        private readonly IDocusignService _docusignService;
        private readonly ICustomCustomerAttributeService _crowdPayCustomerAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ILocalizationService _localizationService;
        private readonly IWorkContext _workContext;
        private readonly CustomerSettings _customerSettings;
        private readonly Customer _currentCustomer;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;
        private readonly AddressSettings _addressSettings;
        private readonly ICustomAddressAttributeParser _customAddressAttributeParser;
        private readonly ICustomCustomerAttributeParser _customCustomerAttributeParser;
        private readonly ICurrencyService _currencyService;
        private readonly IPaymentService _paymentService;
        private readonly IStoreContext _storeContext;
        private readonly ITaxService _taxService;
        private readonly IWebHelper _webHelper;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IProductService _productService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly PaymentSettings _paymentSettings;
        private readonly IPluginFinder _pluginFinder;
        private readonly HttpContextBase _httpContext;
        private readonly ICustomOrderProccessingService _customOrderProccessingService;
        private readonly ISettingService _settingsService;
        private readonly ILogger _logger;
        private readonly ShippingSettings _shippingSettings;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IShippingService _shippingService;
        private readonly OrderSettings _orderSettings;
        private readonly IOrderService _orderService;
        private readonly IBlockScoreService _blockScoreService;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly IVerifyInvestorService _verifyInvestorService;
        private readonly IBDAddressService _bDAddressService;
        private readonly IPermissionService _permissionService;
        private readonly IWorkflowMessageServiceBD _workflowMessageServiceBD;
        private readonly IDateTimeHelper _dateTimeHelper;

        #endregion

        #region Ctors
        public CrowdPayInvestmentController(IWorkContext workContext,
            IStoreContext storeContext,
            IStoreMappingService storeMappingService,
            IShoppingCartService shoppingCartService,
            ILocalizationService localizationService,
            ITaxService taxService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IOrderProcessingService orderProcessingService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IShippingService shippingService,
            IPaymentService paymentService,
            IPluginFinder pluginFinder,
            IOrderTotalCalculationService orderTotalCalculationService,
            IRewardPointService rewardPointService,
            ILogger logger,
            IOrderService orderService,
            IWebHelper webHelper,
            HttpContextBase httpContext,
            IAddressAttributeParser addressAttributeParser,
            IAddressAttributeService addressAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            OrderSettings orderSettings,
            RewardPointsSettings rewardPointsSettings,
            PaymentSettings paymentSettings,
            ShippingSettings shippingSettings,
            AddressSettings addressSettings,
            CustomerSettings customerSettings, IDocusignService docusignService, ICustomCustomerAttributeService crowdPayCustomerAttributeService, ICustomAddressAttributeParser customAddressAttributeParser,
            ICustomCustomerAttributeParser customCustomerAttributeParser, IAddressService addressService, IProductService productService,
            IPriceCalculationService priceCalculationService, ICustomOrderProccessingService customOrderProccessingService, ISettingService settingsService,
            IBlockScoreService blockScoreService, ICustomGenericAttributeService customGenericAttributeService, IVerifyInvestorService verifyInvestorService,
            IBDAddressService bDAddressService,
            IPermissionService permissionService,
            IWorkflowMessageServiceBD workflowMessageServiceBD,
            IDateTimeHelper dateTimeHelper)
            : base(workContext, storeContext, storeMappingService, shoppingCartService,
                localizationService, taxService, currencyService, priceFormatter, orderProcessingService, customerService, genericAttributeService, countryService,
                stateProvinceService, shippingService, paymentService, pluginFinder, orderTotalCalculationService, rewardPointService, logger, orderService,
                webHelper, httpContext, addressAttributeParser, addressAttributeService, addressAttributeFormatter, orderSettings, rewardPointsSettings, paymentSettings,
                shippingSettings, addressSettings, customerSettings)
        {

            _workContext = workContext;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _taxService = taxService;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _paymentService = paymentService;
            _pluginFinder = pluginFinder;
            _logger = logger;
            _webHelper = webHelper;
            _httpContext = httpContext;
            _addressAttributeParser = addressAttributeParser;
            _addressAttributeService = addressAttributeService;
            _paymentSettings = paymentSettings;
            _shippingSettings = shippingSettings;
            _addressSettings = addressSettings;
            _docusignService = docusignService;
            _crowdPayCustomerAttributeService = crowdPayCustomerAttributeService;
            _customerSettings = customerSettings;
            _currentCustomer = _workContext.CurrentCustomer;
            _customAddressAttributeParser = customAddressAttributeParser;
            _customCustomerAttributeParser = customCustomerAttributeParser;
            _addressService = addressService;
            _productService = productService;
            _priceCalculationService = priceCalculationService;
            _customOrderProccessingService = customOrderProccessingService;
            _settingsService = settingsService;
            _shippingService = shippingService;
            _blockScoreService = blockScoreService;
            _customGenericAttributeService = customGenericAttributeService;
            _verifyInvestorService = verifyInvestorService;
            _orderService = orderService;
            _orderSettings = orderSettings;
            _bDAddressService = bDAddressService;
            _permissionService = permissionService;
            _workflowMessageServiceBD = workflowMessageServiceBD;
            _dateTimeHelper = dateTimeHelper;
        }

        #endregion

        [Authorize]
        public ActionResult PublicInfo(int? productId, int? vi_user_id, bool? goToInformationGatheringSection)
        {
            _logger.Information("PublicInfo_ViUserID:" + vi_user_id);
            if (productId != null)
            {
                Session["productId"] = productId;
                Session["offering"] = "multiple";
            }
            else
            {
                var settings = _settingsService.LoadSetting<CrowdPaySettings>();
                Session["productId"] = settings.SingleOfferProductId;
                Session["offering"] = "single";
            }
            int investProductId;
            int.TryParse(Convert.ToString(Session["productId"]), out investProductId);

            int currentOfferingType = GetOfferingTypeOfProduct(investProductId) ?? 0;

            //Title 3 new layout change
            string redirectionPublicInfoPage = (currentOfferingType == ClientConstants.OfferingType.type_title3) ? "PublicInfoOther" : "PublicInfo";

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            bool resultNetwork1Security = CanAllowNetwork1Security(currentOfferingType);

            if (vi_user_id.HasValue && vi_user_id.Value > 0)
            {
                _genericAttributeService.SaveAttribute(_currentCustomer, ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId, vi_user_id);
            }

            // Check weather to go My account or checkout page  
            _logger.Information("InvestorType: " + investorType);
            _logger.Information("NetworkSecurity: " + resultNetwork1Security);
            _logger.Information("ProductId: " + productId);

            if (CanGoToMyAccountAccreditation(investorType, resultNetwork1Security, productId))
            {
                TempData["goToAccreditation"] = true;
                return RedirectToRoute("Plugin.CrowdPay.Accreditation", new { productId = productId });
            }

            //resetting checkout state 
            _customGenericAttributeService.DeleteAttriutes(ClientConstants.TempCheckOutGenericAttirubutes.ProductId,
                ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity);

            var model = new PublicInfoModel();

            if (investProductId != 0)
            {
                var product = _productService.GetProductById(investProductId);
                if (product != null)
                {
                    // No need to show first step of Investor Information
                    //model.InvestorInformationExists = product.ProductSpecificationAttributes.Any(
                    //x =>
                    //    x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                    //    ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId);
                    model.InvestorInformationExists = false;

                    model.SubscriptionAgreementExists = product.ProductSpecificationAttributes.Any(
                    x =>
                        x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                        ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId);

                    var tempProductIdAttribute = new GenericAttribute()
                    {
                        KeyGroup = ClientConstants.GerenicAttributeKeyGroup.CustomerGroup,
                        EntityId = _currentCustomer.Id,
                        Key = ClientConstants.TempCheckOutGenericAttirubutes.ProductId,
                        Value = investProductId.ToString()
                    };

                    _genericAttributeService.InsertAttribute(tempProductIdAttribute);

                    model.ShippingRequired = product.IsShipEnabled;

                    if (goToInformationGatheringSection.HasValue && CanSkipInvestorInformationStep(product) && CanSkipPersonalInformationStep() && CanSkipVerifyInvestorStep() &&
                        CanSkipInvestorTypeStep())
                    {
                        model.GoToInformationGatheringSection = goToInformationGatheringSection.Value;
                    }

                    if (vi_user_id.HasValue)
                    {
                        var verifyStatus = _verifyInvestorService.GetVerificationStatus(vi_user_id.Value);
                        _logger.Information("PublicInfo_Verification_Status: " + verifyStatus.verification_status);
                        if (verifyStatus != null)
                        {
                            string redirectUrl;

                            switch (verifyStatus.verification_status)
                            {
                                case ClientConstants.VerifyInvestor.InvestorValidationStatus.PendingVerification:
                                    {
                                        return RedirectToAction("PublicInfo", "CrowdPayInvestment", new { productId = investProductId });
                                    }
                                    break;
                                default:
                                    {
                                        return RedirectToAction("PublicInfo", "CrowdPayInvestment", new { productId = investProductId });
                                    }
                            }

                            if (!String.IsNullOrEmpty(redirectUrl))
                            {
                                return Redirect(redirectUrl);
                            }

                            return RedirectToAction("Index", "Home");
                        }

                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
            // s-1 type condition
            if (resultNetwork1Security)
            {
                return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/" + redirectionPublicInfoPage + ".cshtml", model);
            }
            //------------------------
            #region Check For Investor Permitted
            int result = _bDAddressService.CheckForTypeAndNumberOfInvestor(investProductId, _storeContext.CurrentStore.Id);
            if (result == 3)
            {
                TempData["OfferingTypeMessage"] = _localizationService.GetResource("OfferingTypeMessage.InvestorsNotPermitted");
                TempData["goToAccreditation"] = true;
                //TempData["NotAllowToInvest"] = true;
                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
            }
            else if (result == 2 && investorType == ClientConstants.InvestorType.Accreddited)
            {
                TempData["OfferingTypeMessage"] = _localizationService.GetResource("OfferingTypeMessage.InvestorsAccredittedNotPermitted");
                TempData["goToAccreditation"] = true;
                //TempData["NotAllowToInvest"] = true;
                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
            }
            else if (result == 1 && investorType == ClientConstants.InvestorType.NonAccreditted)
            {
                TempData["OfferingTypeMessage"] = _localizationService.GetResource("OfferingTypeMessage.InvestorsNonAccredittedNotPermitted");
                TempData["goToAccreditation"] = true;
                //TempData["NotAllowToInvest"] = true;
                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
            }
            #endregion

            if (AllowToInvest())
            {
                return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/" + redirectionPublicInfoPage + ".cshtml", model);
            }
            else
            {
                TempData["OfferingTypeMessage"] = _localizationService.GetResource("shopfast.fields.NotAllowToInvest");
                TempData["goToAccreditation"] = true;
                //TempData["NotAllowToInvest"] = true;
                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
            }
            //return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/"+redirectionPublicInfoPage+".cshtml", model);
        }

        // Load Share details as subcription at home page
        public ActionResult LoadShareDetail()
        {
            var purchaseModel = new PurchaseModel();
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            PreparePurchaseModel(purchaseModel, settings.SingleOfferProductId);
            TempData["PurchaseModel"] = purchaseModel;
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ShareDetail.cshtml",
                                purchaseModel);
        }

        // Load purchase 
        public ActionResult LoadPurchase()
        {
            var purchaseModel = new PurchaseModel();
            PreparePurchaseModel(purchaseModel);
            TempData["PurchaseModel"] = purchaseModel;
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml",
                                purchaseModel);
        }
        // Load payment info
        public ActionResult LoadPaymentInfoDetail()
        {
            CustomPaymentInfoModel customPaymentInfoModel = new CustomPaymentInfoModel();
            LoadPaymentInfo(null, customPaymentInfoModel, TempData["PurchaseModel"] as PurchaseModel);
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", customPaymentInfoModel);
        }

        //Title 3 new layout change
        public ActionResult LoadConfirmationOptions()
        {
            CustomPaymentInfoModel customPaymentInfoModel = new CustomPaymentInfoModel();
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ConfirmationOptions.cshtml", customPaymentInfoModel);
        }
        // Load Billing info
        public ActionResult LoadBillingInfo()
        {
            var billingAddressModel = PrepareBillingAddressModel(_workContext.CurrentCustomer.ShoppingCartItems.ToList());
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_BillingAddress.cshtml",
                    billingAddressModel);
        }
        // Load Shipping info
        public ActionResult LoadShippingInfo()
        {
            Product product;
            var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            if (tempProductAttribute != null)
            {
                product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
            }
            else
            {
                return Json(new { error = 1, message = "Can't find product attribute" });
            }
            var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

            if (cart.RequiresShipping())
            {
                //shipping is required
                var shippingAddressModel = PrepareShippingAddressModel(prePopulateNewAddressWithCustomerFields: true);

                // save shipping method
                var shippingMethodModel = PrepareShippingMethodModel(cart, _workContext.CurrentCustomer.ShippingAddress);
                //if we have only one shipping method, then a customer doesn't have to choose a shipping method
                _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                    SystemCustomerAttributeNames.SelectedShippingOption,
                    shippingMethodModel.ShippingMethods.First().ShippingOption,
                    _storeContext.CurrentStore.Id);

                return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ShippingAddress.cshtml", shippingAddressModel);
            }
            else
            {
                return new EmptyResult();
            }
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult InvestmentDetail(FormCollection form)
        {
            // SavePurchase           
            dynamic result = SavePurchase(form);
            if (result.Data.Success)
            {
                // SavePaymentInfo
                result = SavePaymentInfo(form);
                if (result.Data.Success)
                {
                    // SaveBilling
                    result = SaveBilling(form);
                    if (result.Data.Success)
                    {
                        result = SaveShipping(form);
                        if (result.Data.Success)
                        {
                            if (form["hdnSkipSubscriptionAgreement"] != null && form["hdnSkipSubscriptionAgreement"] == "1")
                            {
                                var purchaseModel = new PurchaseModel();
                                TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
                                var model = PrepareSubscriptionHTMLTemplate(purchaseModel);

                                // Load confirm tab
                                var confirmOrderModel = PrepareConfirmOrderModel();

                                var resultHtml =
                                     RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                                         confirmOrderModel);
                                return Json(new
                                {
                                    section_name = "confirm",
                                    Success = true,
                                    Error = "",
                                    html = resultHtml
                                });
                            }
                            else
                            {
                                // SubscriptionAgreement code

                                var purchaseModel = new PurchaseModel();
                                TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
                                //TempData["purchaseModel"] = purchaseModel;

                                string resultHtml = string.Empty;
                                if (IsDocusignEnable())
                                {
                                    #region Use Docusign
                                    var subscriptionAgreementModel = PrepareSigningModel(ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId, purchaseModel);

                                    if (!String.IsNullOrEmpty(subscriptionAgreementModel.DocumentUrl))
                                    {
                                        resultHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_SigningCeremony.cshtml",
                                            subscriptionAgreementModel);
                                    }
                                    #endregion
                                }
                                else
                                {
                                    #region Use HTML Signing
                                    //resultHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_HTMLSigningCeremony.cshtml",
                                    //       PrepareHTMLSigningModel(purchaseModel));
                                    var model = PrepareSubscriptionHTMLTemplate(purchaseModel);
                                    if (string.IsNullOrEmpty(model.HTMLTemplate))
                                    {
                                        return Json(new
                                        {
                                            Error = "Subscription Aggrement Template is not added.",
                                            Success = false
                                        });
                                    }
                                    resultHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_HTMLSigningTemplate.cshtml",
                                           model);

                                    #endregion
                                }
                                return Json(new
                                {
                                    Success = true,
                                    section_name = "subagreement",
                                    html = resultHtml
                                });
                            }
                        }
                    }
                }
            }
            return result;
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SubscriptionAgreement(HTMLSignModel model, string[] hdnSignJSONsmallSign, string[] hdnSignJSONbigSign)
        {
            model = TempData["htmlSignModel"] as HTMLSignModel;
            if (hdnSignJSONsmallSign != null)
                model.hdnSignJSONsmallSign = hdnSignJSONsmallSign.ToList();
            if (hdnSignJSONbigSign != null)
                model.hdnSignJSONbigSign = hdnSignJSONbigSign.ToList();
            TempData["htmlSignModel"] = model;

            var confirmOrderModel = PrepareConfirmOrderModel();

            var resultHtml =
                 RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                     confirmOrderModel);
            return Json(new
            {
                section_name = "confirm",
                Success = true,
                Error = "",
                html = resultHtml
            });
        }

        [HttpPost]
        public new ActionResult ConfirmOrder()
        {
            var confirmModel = new ConfirmOrderModel();
            TryUpdateModel(confirmModel, ClientConstants.FormPrefix.ConfirmPrefix);

            var processPaymentRequest = _httpContext.Session["CrowdPayOrderPaymentInfo"] as ProcessPaymentRequest;
            if (processPaymentRequest == null)
            {
                throw new Exception("Payment information is not entered");
            }

            _customOrderProccessingService.InitOrderProcessing(confirmModel.ProductId, confirmModel.DeliveredQuantity);
            processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
            processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
            processPaymentRequest.PaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            var placeOrderResult = _customOrderProccessingService.PlaceOrder(processPaymentRequest);

            if (placeOrderResult.Success)
            {
                _httpContext.Session["CrowdPayOrderPaymentInfo"] = null;

                SaveInvestorOrder(confirmModel.ProductId, _workContext.CurrentCustomer.Id);

                var postProcessPaymentRequest = new PostProcessPaymentRequest
                {
                    Order = placeOrderResult.PlacedOrder
                };

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(placeOrderResult.PlacedOrder.PaymentMethodSystemName);
                if (paymentMethod == null)
                    //payment method could be null if order total is 0
                    //success
                    //return Json(new { success = 1 });
                    return Json(new
                    {
                        Error = "",
                        Success = true
                    });

                if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                {
                    //Redirection will not work because it's AJAX request.
                    //That's why we don't process it here (we redirect a user to another page where he'll be redirected)

                    //return Json(new
                    //{
                    //    redirect = string.Format("{0}checkout/OpcCompleteRedirectionPayment", _webHelper.GetStoreLocation())
                    //});
                    //redirect
                    return Json(new
                    {
                        Error = "",
                        Success = true,
                        redirect = string.Format("{0}checkout/OpcCompleteRedirectionPayment", _webHelper.GetStoreLocation())
                    });
                }

                _paymentService.PostProcessPayment(postProcessPaymentRequest);

                var orderSuccessUrl = Url.Action("CrowdPayCompleted", "CrowdPayInvestment",
                    new { orderId = placeOrderResult.PlacedOrder.Id });

                // Create PDF of subscription aggrement if docusign is not enable
                if (!IsDocusignEnable())
                {
                    if (TempData["htmlSignModel"] != null)
                    {
                        HTMLSignModel htmlSignModel = TempData["htmlSignModel"] as HTMLSignModel;
                        PrepareHTMLToPDF(htmlSignModel, placeOrderResult.PlacedOrder.Id);
                    }
                }

                //return Json(new { success = 1, confirmRedirectedUrl = orderSuccessUrl });
                //success
                return Json(new
                {
                    Error = "",
                    Success = true,
                    confirmRedirectedUrl = orderSuccessUrl
                });
            }

            //error

            if (confirmModel.ProductId != 0)
            {
                var product = _productService.GetProductById(confirmModel.ProductId);
                var productModel = PrepareSimpleProductDetailsModel(product);

                confirmModel.DeliveredProduct = productModel;
            }

            foreach (var error in placeOrderResult.Errors)
                confirmModel.Warnings.Add(error);

            var resultHtml =
                           RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                               confirmModel);
            return Json(new
            {
                Error = "warnings",
                Success = false,
                html = resultHtml
            });
        }

        public ActionResult CrowdPayCompleted(int? orderId)
        {
            //validation
            if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                return new HttpUnauthorizedResult();

            Order order = null;
            if (orderId.HasValue)
            {
                //load order by identifier (if provided)
                order = _orderService.GetOrderById(orderId.Value);
            }
            if (order == null)
            {
                order = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                customerId: _workContext.CurrentCustomer.Id, pageSize: 1)
                    .FirstOrDefault();
            }
            if (order == null || order.Deleted || _workContext.CurrentCustomer.Id != order.CustomerId)
            {
                return RedirectToRoute("HomePage");
            }

            //disable "order completed" page?
            if (_orderSettings.DisableOrderCompletedPage)
            {
                return RedirectToRoute("OrderDetails", new { orderId = order.Id });
            }

            //model
            var model = new CheckoutCompletedModel
            {
                OrderId = order.Id,
                OnePageCheckoutEnabled = _orderSettings.OnePageCheckoutEnabled
            };

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/SuccesfulInvestment.cshtml", model);
        }

        [HttpPost]
        public JsonResult CheckAllowToInvestOnPurchaseAmount(FormCollection fc)
        {
            try
            {
                bool result = false;
                // s-1 type condition
                if (!CanAllowNetwork1Security())
                {
                    string OrderedSharesCount = fc["PurchasePrefix.OrderedSharesCount"];
                    string PerShare = fc["PurchasePrefix.PerShare"];
                    decimal purchaseAmount = Convert.ToDecimal(PerShare) * Convert.ToInt32(OrderedSharesCount);
                    result = AllowToInvest(purchaseAmount);
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                //--------------
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        [ValidateInput(false)]
        public ActionResult SubscriptionAgreementExternal(decimal perShare = 0, int OrderedSharesCount = 0, string SignatureName = "", string Agreement = "subscription")
        {
            var purchaseModel = new PurchaseModel();
            TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
            purchaseModel.OrderedSharesCount = OrderedSharesCount;
            purchaseModel.PerShare = perShare;
            purchaseModel.SignatureName = SignatureName;
            var model = PrepareSubscriptionHTMLTemplate(purchaseModel,Agreement);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/SubscriptionAgreementExternal.cshtml",
                   model);
        }

        #region Investor Form Methods
        public ActionResult LoadInvestorForm(int productId)
        {
            InvestorFormModel model = new InvestorFormModel();
            model.productId = productId;
            model.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = ""
            });
            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                model.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString()
                });
            }
            model.AvailableStates.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectState"),
                Value = ""
            });
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InvestorForm.cshtml",
                    model);
        }

        [HttpPost]
        public ActionResult LoadInvestorForm(InvestorFormModel model)
        {
            string Errors = string.Empty;
            List<string> PreferedContacts = new List<string>();
            if (ModelState.IsValid)
            {
                // Save Investor form data
                var investorForm = new BD_investorForm();
                investorForm.productId = model.productId;
                investorForm.FirstName = model.FirstName;
                investorForm.LastName = model.LastName;
                investorForm.Email = model.Email;
                investorForm.Phone = model.Phone;
                investorForm.CountryId = model.CountryId;
                investorForm.StateId = model.StateId;
                investorForm.LookingToInvest = model.LookingToInvest;
                if (model.IsEmail)
                {
                    PreferedContacts.Add("Email");
                }
                if (model.IsPhone)
                {
                    PreferedContacts.Add("Phone");
                    investorForm.TimeToCall = Convert.ToDateTime(model.TimeToCall);
                }
                investorForm.PreferedContacts = string.Join(",", PreferedContacts.ToArray());
                _bDAddressService.InsertInvestorFormData(investorForm);

                // Send email to model.email
                _workflowMessageServiceBD.SendInvestorFormOwnerNotificationMessage(model, _workContext.WorkingLanguage.Id);
                _workflowMessageServiceBD.SendInvestorFormCustomerNotificationMessage(model, _workContext.WorkingLanguage.Id);

                return Json(new
                {
                    Success = true
                });
            }
            Errors = "Error! something went wrong. Please try it again";
            return Json(new
            {
                Success = false,
                Result = Errors
            });
        }

        [ChildActionOnly]
        public ActionResult InvestorFormsList(int productId)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");
            ViewBag.productId = productId;
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/InvestorFormsList.cshtml");
        }

        public ActionResult InvestorFormsListForAllProducts()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/InvestorForms.cshtml");
        }

        [HttpPost]
        public ActionResult InvestorFormsList(DataSourceRequest command, int productId, InvestorFormListModel searchModel)
        {
            IEnumerable<BD_investorForm> investormFormModel;
            if (productId > 0)
            {
                investormFormModel = _bDAddressService.GetInvestorFormDataByProduct(productId);
            }
            else
            {
                investormFormModel = _bDAddressService.GetInvestorFormData();
            }

            List<InvestorFormModel> model = new List<InvestorFormModel>();
            if (investormFormModel.Any())
            {
                model = investormFormModel.Select(i => new InvestorFormModel()
                    {
                        Id = i.Id,
                        productId = i.productId,
                        ProductName = _productService.GetProductById(i.productId).Name ?? "",
                        FirstName = i.FirstName,
                        LastName = i.LastName,
                        Phone = i.Phone,
                        Email = i.Email,
                        CountryId = i.CountryId,
                        StateId = i.StateId,
                        LookingToInvest = i.LookingToInvest,
                        PreferedContacts = i.PreferedContacts
                    }).ToList();
                if (!string.IsNullOrEmpty(searchModel.SearchProductName))
                {
                    model = model.Where(p => p.ProductName.ToLower().Contains(searchModel.SearchProductName.ToLower())).ToList();
                }
                if (!string.IsNullOrEmpty(searchModel.SearchEmail))
                {
                    model = model.Where(p => p.Email.ToLower().Contains(searchModel.SearchEmail.ToLower())).ToList();
                }
            }

            var gridModel = new DataSourceResult
            {
                Data = model,
                Total = model.Count()
            };
            return Json(gridModel);
        }

        public ActionResult InvestorFormDetail(int Id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");

            var investorForm = _bDAddressService.GetInvestorFormDataById(Id);
            InvestorFormModel model = new InvestorFormModel();
            model.productId = investorForm.productId;
            model.ProductName = _productService.GetProductById(investorForm.productId).Name ?? "";
            model.FirstName = investorForm.FirstName;
            model.LastName = investorForm.LastName;
            model.Email = investorForm.Email;
            model.Phone = investorForm.Phone;
            model.CountryName = _countryService.GetCountryById(investorForm.CountryId).Name;
            model.StateName = _stateProvinceService.GetStateProvinceById(investorForm.StateId).Name;
            model.LookingToInvestName = model.LookingToInvestList.FirstOrDefault(i => i.Value == investorForm.LookingToInvest.ToString()).Text;
            model.PreferedContacts = investorForm.PreferedContacts;
            model.TimeToCall = (investorForm.PreferedContacts.Contains("Phone")) ? Convert.ToString(investorForm.TimeToCall) : "";
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/InvestorFormDetail.cshtml", model);
        }

        #endregion

        #region Subscription Template Methods
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult SubscriptionTemplate(int productId)
        {
            SubscriptionTemplateModel model = new SubscriptionTemplateModel();

            var subscriptionTemplate = _bDAddressService.GetSubscriptionTemplateByProduct(productId);
            if (subscriptionTemplate != null)
            {
                model.SubscriptionTemplateId = subscriptionTemplate.Id;
                model.productId = subscriptionTemplate.productId;
                model.HTMLTemplate = subscriptionTemplate.HTMLTemplate;
                model.PDFUploadId = subscriptionTemplate.PDFUploadId;
                model.HTMLTemplateForProductAgreement = subscriptionTemplate.HTMLTemplateForProductAgreement;
                model.PDFUploadIdForProductAgreement = subscriptionTemplate.PDFUploadIdForProductAgreement;
                model.IsDocusign = subscriptionTemplate.IsDocusign;
                model.DocusignUsername = subscriptionTemplate.DocusignUsername;
                model.DocusignPassword = subscriptionTemplate.DocusignPassword;
                model.DocuSignIntegratorKey = subscriptionTemplate.DocuSignIntegratorKey;
                model.OfferingType = subscriptionTemplate.OfferingType;
            }
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/SubscriptionTemplate.cshtml", model);
        }

        // This method is not in use
        [HttpPost]
        public ActionResult SubscriptionTemplate(SubscriptionTemplateModel model)
        {
            //if (ModelState.IsValid)
            //{
            BD_SubscriptionTemplate subscriptionTemplate = new BD_SubscriptionTemplate();
            subscriptionTemplate.HTMLTemplate = model.HTMLTemplate;
            subscriptionTemplate.productId = model.productId;
            subscriptionTemplate.Id = model.SubscriptionTemplateId;
            if (model.SubscriptionTemplateId > 0)
            {
                subscriptionTemplate = _bDAddressService.GetSubscriptionTemplateById(model.SubscriptionTemplateId);
                subscriptionTemplate.HTMLTemplate = model.HTMLTemplate;
                _bDAddressService.UpdateSubscriptionTemplate(subscriptionTemplate);
            }
            else
            {
                _bDAddressService.InsertSubscriptionTemplate(subscriptionTemplate);
            }
            //}
            return Json(new
            {
                Success = true,
                Message = "Subscription Template updated successfullu."
            });
        }
        #endregion

        #region Utils

        #region Prepare models
        [NonAction]
        private ProductDetailsModel PrepareSimpleProductDetailsModel(Product product)
        {
            if (product == null)
                throw new ArgumentNullException("product");

            var model = new ProductDetailsModel
            {
                Id = product.Id,
                Name = product.GetLocalized(x => x.Name),
                SeName = product.GetSeName(),
            };

            model.ProductPrice.ProductId = product.Id;

            model.ProductPrice.HidePrices = false;
            if (product.CustomerEntersPrice)
            {
                model.ProductPrice.CustomerEntersPrice = true;
            }
            else
            {
                if (product.CallForPrice)
                {
                    model.ProductPrice.CallForPrice = true;
                }
                else
                {
                    decimal taxRate;
                    decimal oldPriceBase = _taxService.GetProductPrice(product, product.OldPrice, out taxRate);
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: true), out taxRate);

                    decimal oldPrice = _currencyService.ConvertFromPrimaryStoreCurrency(oldPriceBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithDiscountBase, _workContext.WorkingCurrency);

                    if (finalPriceWithoutDiscountBase != oldPriceBase && oldPriceBase > decimal.Zero)
                        model.ProductPrice.OldPrice = _priceFormatter.FormatPrice(oldPrice);

                    model.ProductPrice.Price = _priceFormatter.FormatPrice(finalPriceWithoutDiscount);

                    if (finalPriceWithoutDiscountBase != finalPriceWithDiscountBase)
                        model.ProductPrice.PriceWithDiscount = _priceFormatter.FormatPrice(finalPriceWithDiscount);

                    model.ProductPrice.PriceValue = finalPriceWithDiscount;
                }
            }

            return model;
        }
        [NonAction]
        private void PreparePurchaseModel(PurchaseModel purchaseModel, int SingleOfferProductId = 0)
        {
            //var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            int productId = GetProductId(SingleOfferProductId);
            if (productId > 0)
            {
                var product = _productService.GetProductById(productId);
                if (product != null)
                {
                    var currentCurrency = _currencyService.GetCurrencyById(_workContext.WorkingCurrency.Id);
                    if (currentCurrency != null)
                    {
                        purchaseModel.CurrencySymbol = !String.IsNullOrEmpty(currentCurrency.DisplayLocale)
                            ? new RegionInfo(currentCurrency.DisplayLocale).CurrencySymbol
                            : String.Empty;

                        if (String.IsNullOrEmpty(purchaseModel.CurrencySymbol) && !String.IsNullOrEmpty(currentCurrency.CustomFormatting))
                        {
                            purchaseModel.CurrencySymbol = currentCurrency.CustomFormatting[0].ToString();
                        }
                    }
                    purchaseModel.MaximumSharesCount = product.StockQuantity;
                    purchaseModel.MinimumSharesCount = product.OrderMinimumQuantity;

                    decimal taxRate;
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    purchaseModel.PerShare = finalPriceWithoutDiscount;

                    purchaseModel.MinimumInvest = finalPriceWithoutDiscount * product.OrderMinimumQuantity;
                    purchaseModel.MaximumInvest = (finalPriceWithoutDiscount * product.StockQuantity);
                }
            }

            var existAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            // s-1 type condition
            if (CanAllowNetwork1Security())
            {
                decimal annualIncome;
                decimal netWorth;
                decimal.TryParse(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                    ClientConstants.CustomAttributes.AnnualIncome), out annualIncome);
                decimal.TryParse(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                    ClientConstants.CustomAttributes.NetWorth), out netWorth);
                // 10% condition - this is not in used currently. It used in offering type now
                purchaseModel.MaxShareAmount = (Math.Max(annualIncome, netWorth) * 10) / 100;
            }
            //-------------------

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);
            purchaseModel.SelectedInvestorType = investorType ?? ClientConstants.InvestorType.NonAccreditted;

            //add payment methods
            var paymentMethods = _paymentService
                .LoadActivePaymentMethods(_workContext.CurrentCustomer.Id, _storeContext.CurrentStore.Id)
                .Where(pm => pm.PaymentMethodType == PaymentMethodType.Standard || pm.PaymentMethodType == PaymentMethodType.Redirection)
               .ToList();
            foreach (var pm in paymentMethods)
            {

                var pmModel = new CheckoutPaymentMethodModel.PaymentMethodModel
                {
                    Name = pm.GetLocalizedFriendlyName(_localizationService, _workContext.WorkingLanguage.Id),
                    PaymentMethodSystemName = pm.PluginDescriptor.SystemName,
                    LogoUrl = pm.PluginDescriptor.GetLogoUrl(_webHelper)
                };

                purchaseModel.PaymentMethods.Add(pmModel);
            }

            //find a selected (previously) payment method
            var selectedPaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            if (!String.IsNullOrEmpty(selectedPaymentMethodSystemName))
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.ToList()
                    .Find(pm => pm.PaymentMethodSystemName.Equals(selectedPaymentMethodSystemName, StringComparison.InvariantCultureIgnoreCase));
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }
            //if no option has been selected, let's do it for the first one
            if (purchaseModel.PaymentMethods.FirstOrDefault(so => so.Selected) == null)
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.FirstOrDefault();
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }
        }

        private int GetProductId(int SingleOfferProductId = 0)
        {
            if (SingleOfferProductId > 0)
            {
                return SingleOfferProductId;
            }
            else
            {
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    return int.Parse(tempProductAttribute.Value);
                }
            }
            return 0;
        }
        [NonAction]
        protected ConfirmOrderModel PrepareConfirmOrderModel()
        {
            var tempProductIdAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            var tempQuantityAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity);

            var product = _productService.GetProductById(int.Parse(tempProductIdAttribute.Value));
            var productModel = PrepareSimpleProductDetailsModel(product);

            var model = new ConfirmOrderModel
            {
                DeliveredQuantity = int.Parse(tempQuantityAttribute.Value),
                ProductId = int.Parse(tempProductIdAttribute.Value),
                DeliveredProduct = productModel,
                Warnings = new List<string>()
            };

            return model;
        }

        // Used for Docusign but we have to replicate this method to match " protected void PrepareHTMLToPDF(HTMLSignModel htmlSignModel, int orderId = 0)"
        [NonAction]
        protected SigningCeremonyModel PrepareSigningModel(string attributeName, PurchaseModel purchaseModel)
        {
            var tempProductIdAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            var product = _productService.GetProductById(int.Parse(tempProductIdAttribute.Value));

            var model = new SigningCeremonyModel();
            var templateAttribute = product.ProductSpecificationAttributes.SingleOrDefault(x => x.SpecificationAttributeOption.SpecificationAttribute.Name == attributeName);
            var useNewTemplate = true;
            if (templateAttribute != null)
            {
                var oldTemplateId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    String.Format(ClientConstants.TempCheckOutGenericAttirubutes.OldTemplateId, product.Id, attributeName));
                if (oldTemplateId != null)
                {
                    if (templateAttribute.CustomValue != oldTemplateId.Value)
                    {
                        useNewTemplate = true;
                    }
                }

                var temporaryEnvelopeId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                 String.Format(ClientConstants.TempCheckOutGenericAttirubutes.TemporaryEnvelopId, product.Id, attributeName));

                var succesfullySingedDocument = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    String.Format(ClientConstants.TempCheckOutGenericAttirubutes.SuccesfulyEnvelopId, product.Id, attributeName));
                if (succesfullySingedDocument != null && temporaryEnvelopeId == null && !useNewTemplate)
                {
                    model.DocumentUrl = Url.Action("DownloadFile", "CrowdPayCheckOut", new { templateId = succesfullySingedDocument.Value });
                    model.ShowContinue = true;
                    if (attributeName == ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId)
                    {
                        model.ShowBack = true;
                    }
                }
                else
                {
                    var template = _bDAddressService.GetSubscriptionTemplateByProduct(product.Id);
                    if (template != null)
                    {
                        var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadById(template.PDFUploadId);
                        if (download != null)
                        {
                            if (download.DownloadBinary != null)
                            {
                                // create a new PDF reader based on the PDF template document
                                //string pdfTemplate = Server.MapPath("~/Plugins/BD.CrowdPay/Documents/Templates/Subscription-Agreement.pdf");
                                //var pdfReader = new PdfReader(pdfTemplate);
                                var pdfReader = new PdfReader(download.DownloadBinary);

                                // create a new PDF stamper to create investor PDF from template document
                                //var investorPdfFile = Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/Subscription-Agreement-{0}.pdf", _workContext.CurrentCustomer.Id));
                                var investorPdfFile = Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/Subscription-Agreement-{0}-{1}.pdf", _workContext.CurrentCustomer.Email, 0));
                                var pdfStamper = new PdfStamper(pdfReader, new FileStream(investorPdfFile, FileMode.Create));
                                var formFields = SetPDFCommonField(pdfStamper, PrepareHTMLSigningModel(purchaseModel));

                                // Below code is transferred to "SetPDFCommonField" method.
                                //// set investor information in PDF
                                //var formFields = pdfStamper.AcroFields;
                                //// name & mailing address
                                //formFields.SetField("IssueDateMonth", System.DateTime.Now.Month.ToString());
                                //formFields.SetField("IssueDateDay", System.DateTime.Now.Day.ToString());
                                //formFields.SetField("Subscription", (purchaseModel.OrderedSharesCount * purchaseModel.PerShare).ToString());
                                //formFields.SetField("Number of Shares", purchaseModel.PerShare.ToString());

                                //formFields.SetField("Name", String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                                //    _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName)));
                                //formFields.SetField("Tax ID Number", "721-07-4426");

                                //// home address
                                //formFields.SetField("Street Address", "200 Park Avenue, Suite 1700");
                                //formFields.SetField("CityStateZip Code", "New York, NY 10166");
                                //formFields.SetField("Country", "United States");

                                //// contact information
                                //formFields.SetField("Telephone number", "2122780900");
                                //formFields.SetField("Dated", "03/30");
                                //--------------------------------------------------------

                                pdfStamper.FormFlattening = true;
                                pdfStamper.Close();
                                pdfReader.Close();

                                model.DocumentUrl = _docusignService.GenerateSigningSessionUrl(attributeName, product.Id, investorPdfFile);
                            }
                        }
                    }
                }
            }

            return model;
        }

        [NonAction]
        protected HTMLSignModel PrepareHTMLSigningModel(PurchaseModel purchaseModel)
        {
            HTMLSignModel htmlSignModel = new HTMLSignModel();
            DateTime userDateTime = _dateTimeHelper.ConvertToUserTime(DateTime.Now);
            htmlSignModel.IssueDateMonth = System.DateTime.Now.Month.ToString("d2");
            htmlSignModel.IssueDateDay = System.DateTime.Now.Day.ToString("d2");
            htmlSignModel.IssueDateYear = System.DateTime.Now.Year.ToString();
            htmlSignModel.SubscriptionAmount = _priceFormatter.FormatPrice(purchaseModel.OrderedSharesCount * purchaseModel.PerShare);
            htmlSignModel.NumberOfShares = String.Format(CultureInfo.InvariantCulture,
               "{0:#,##0.##}", purchaseModel.OrderedSharesCount);

            htmlSignModel.Name = String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName));
            htmlSignModel.TaxIDNumber = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id).SSN;

            // home address
            int stateId = _workContext.CurrentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId);
            htmlSignModel.StreetAddress = string.Join(",", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress),
                _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2));
            htmlSignModel.CityStateZipCode = _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.City) + "," +
                (stateId > 0 ? _stateProvinceService.GetStateProvinceById(stateId).Name : _localizationService.GetResource("Address.OtherNonUS")) + "," +
                    _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode);
            htmlSignModel.Country = _countryService.GetCountryById(_workContext.CurrentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId)).Name;

            // contact information
            htmlSignModel.TelephoneNumber = _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Phone);
            htmlSignModel.Dated = System.DateTime.Now.ToString("dd MMM");
            htmlSignModel.DateAndIPAddress = userDateTime.ToString("F") + " (UTC) from IP address " + _workContext.CurrentCustomer.LastIpAddress;
            htmlSignModel.SignatureName = purchaseModel.SignatureName;
            TempData["htmlSignModel"] = htmlSignModel;
            return htmlSignModel;
        }

        protected SubscriptionTemplateModel PrepareSubscriptionHTMLTemplate(PurchaseModel purchaseModel, string Agreement = "")
        {
            // get subscription template based on product
            SubscriptionTemplateModel subscriptionTemplateModel = new Models.SubscriptionTemplateModel();
            var template = _bDAddressService.GetSubscriptionTemplateByProduct(GetProductId());
            //var product = _productService.GetProductById(GetProductId());
            //string htmlString = product.UserAgreementText;
            if(!string.IsNullOrEmpty(Agreement))
            {
                if (Agreement == "product")
                {
                    template.HTMLTemplate = template.HTMLTemplateForProductAgreement;
                }
            }
            if (template != null && template.HTMLTemplate != null && !string.IsNullOrEmpty(template.HTMLTemplate.Trim()))
            //if (htmlString != null && !string.IsNullOrEmpty(htmlString.Trim()))
            {
                HTMLSignModel htmlSignModel = PrepareHTMLSigningModel(purchaseModel);
                string htmlString = template.HTMLTemplate;

                // Set tokens
                StringBuilder sb = new StringBuilder(htmlString);
                sb = SetSignToken("%Subscription.Initials%", sb, "smallSign", "smallSign");
                sb = SetSignToken("%Subscription.Signature%", sb, "bigSign", "bigSign");
                sb.Replace("%Subscription.NumberOfShares%", htmlSignModel.NumberOfShares);
                sb.Replace("%Subscription.IssueDateMonth%", htmlSignModel.IssueDateMonth);
                sb.Replace("%Subscription.IssueDateDay%", htmlSignModel.IssueDateDay);
                sb.Replace("%Subscription.IssueDateYear%", htmlSignModel.IssueDateYear);
                sb.Replace("%Subscription.TaxIDNumber%", htmlSignModel.TaxIDNumber);
                sb.Replace("%Subscription.StreetAddress%", htmlSignModel.StreetAddress);
                sb.Replace("%Subscription.CityStateZipcode%", htmlSignModel.CityStateZipCode);
                sb.Replace("%Subscription.Country%", htmlSignModel.Country);
                sb.Replace("%Subscription.TelephoneNumber%", htmlSignModel.TelephoneNumber);
                sb.Replace("%Subscription.SubscriptionDate%", htmlSignModel.Dated);
                sb.Replace("%Subscription.Name%", htmlSignModel.Name);
                sb.Replace("%Subscription.SubscriptionAmount%", htmlSignModel.SubscriptionAmount);
                sb.Replace("%Subscription.DateAndIPAddress%", htmlSignModel.DateAndIPAddress);
                sb.Replace("%Subscription.SignatureName%", htmlSignModel.SignatureName);

                // New Tokens
                string countryCode = _countryService.GetCountryById(_workContext.CurrentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId)).TwoLetterIsoCode;
                sb.Replace("%Subscription.IsUS%", (countryCode == "US") ? "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />" : "");
                sb.Replace("%Subscription.IsNotUS%", (countryCode == "US") ? "" : "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />");

                var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.InvestorType) ?? ClientConstants.InvestorType.NonAccreditted;
                sb.Replace("%Subscription.IsAccreditted%", (investorType == ClientConstants.InvestorType.Accreddited) ? "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />" : "");
                sb.Replace("%Subscription.IsNonAccreditted%", (investorType == ClientConstants.InvestorType.Accreddited) ? "" : "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />");
                //------------------------

                subscriptionTemplateModel.HTMLTemplate = sb.ToString();
            }
            return subscriptionTemplateModel;
        }

        private StringBuilder SetSignToken(string signToken, StringBuilder sb, string cssCLass, string type)
        {
            int lastIndex = 0;
            int count = 0;
            while (lastIndex != -1)
            {
                lastIndex = sb.ToString().IndexOf(signToken, lastIndex);
                if (lastIndex != -1)
                {
                    count++;
                    sb.Replace(signToken, string.Format("<div id='{0}{1}' data-signcount='{0}{1}' class='{2} signBox'></div><input type='hidden' id='hdnSignJSON{0}{1}' name='hdnSignJSON{0}' />", type, count, cssCLass), lastIndex, signToken.Length);
                    lastIndex += signToken.Length;
                }
            }
            return sb;
        }

        protected void PrepareHTMLToPDF(HTMLSignModel htmlSignModel, int orderId = 0)
        {
            var productId = GetProductId();
            var template = _bDAddressService.GetSubscriptionTemplateByProduct(productId);
            if (template != null)
            {
                var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadById(template.PDFUploadId);
                if (download != null)
                {
                    if (download.DownloadBinary != null)
                    {
                        //string fileName = !String.IsNullOrWhiteSpace(download.Filename) ? download.Filename : productId.ToString();
                        //var purchaseModel = TempData["purchaseModel"] as PurchaseModel;
                        //if (purchaseModel == null)
                        //{
                        //    PreparePurchaseModel(purchaseModel);
                        //}

                        // Convert signature JSON to image        
                        foreach (var signJson in htmlSignModel.hdnSignJSONsmallSign)
                        {
                            htmlSignModel.signIamgeSmall.Add(Draw2DLineGraphic(signJson, 65, 39));
                        }
                        foreach (var signJson in htmlSignModel.hdnSignJSONbigSign)
                        {
                            htmlSignModel.signIamgeBig.Add(Draw2DLineGraphic(signJson, 410, 120));
                        }
                        //htmlSignModel.sign1Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign1JSON, 65, 39);
                        //htmlSignModel.sign2Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign2JSON, 65, 39);
                        //htmlSignModel.sign3Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign3JSON, 65, 39);
                        //htmlSignModel.sign4Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign4JSON, 65, 39);
                        //htmlSignModel.sign5Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign5JSON, 65, 39);
                        //htmlSignModel.sign6Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign6JSON, 65, 39);
                        //htmlSignModel.sign7Iamge = Draw2DLineGraphic(htmlSignModel.hdnSign7JSON, 410, 120);

                        // create PDF
                        // create a new PDF reader based on the PDF template document
                        try
                        {
                            //string pdfTemplate = Server.MapPath("~/Plugins/BD.CrowdPay/Documents/Templates/Subscription-Agreement.pdf");
                            //var pdfReader = new PdfReader(pdfTemplate);
                            var pdfReader = new PdfReader(download.DownloadBinary);

                            // create a new PDF stamper to create investor PDF from template document
                            var investorPdfFile = Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/Subscription-Agreement-{0}-{1}.pdf", _workContext.CurrentCustomer.Email, orderId));
                            var pdfStamper = new PdfStamper(pdfReader, new FileStream(investorPdfFile, FileMode.OpenOrCreate));

                            var formFields = SetPDFCommonField(pdfStamper, htmlSignModel);
                            int imageCount = 0;
                            foreach (var signImage in htmlSignModel.signIamgeSmall)
                            {
                                imageCount++;
                                FillImage("Initials" + imageCount, pdfStamper, signImage);
                                //FillImage("image" + 7, pdfStamper, signImage);                    
                            }
                            imageCount = 0;
                            foreach (var signImage in htmlSignModel.signIamgeBig)
                            {
                                imageCount++;
                                FillImage("Signature" + imageCount, pdfStamper, signImage);
                                //FillImage("image" + 7, pdfStamper, signImage);                    
                            }

                            // New Tokens
                            byte[] tickImage = System.IO.File.ReadAllBytes(Server.MapPath("/Plugins/BD.CrowdPay/Content/images/tick.png"));
                            string countryCode = _countryService.GetCountryById(_workContext.CurrentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId)).TwoLetterIsoCode;
                            if (countryCode == "US")
                            {
                                FillImage("IsUS", pdfStamper, tickImage);
                            }
                            else
                            {
                                FillImage("IsNotUS", pdfStamper, tickImage);
                            }
                            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                                ClientConstants.CustomAttributes.InvestorType) ?? ClientConstants.InvestorType.NonAccreditted;
                            if (investorType == ClientConstants.InvestorType.NonAccreditted)
                            {
                                FillImage("IsNonAccreditted", pdfStamper, tickImage);
                            }
                            else
                            {
                                FillImage("IsAccreditted", pdfStamper, tickImage);
                            }
                            //----------------------------------
                            //FillImage("image1", pdfStamper, htmlSignModel.sign1Iamge);
                            //FillImage("image2", pdfStamper, htmlSignModel.sign2Iamge);
                            //FillImage("image3", pdfStamper, htmlSignModel.sign3Iamge);
                            //FillImage("image4", pdfStamper, htmlSignModel.sign4Iamge);
                            //FillImage("image5", pdfStamper, htmlSignModel.sign5Iamge);
                            //FillImage("image6", pdfStamper, htmlSignModel.sign6Iamge);
                            //FillImage("image7", pdfStamper, htmlSignModel.sign7Iamge);


                            pdfStamper.FormFlattening = true;
                            pdfStamper.Close();
                            pdfReader.Close();
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
        }

        private AcroFields SetPDFCommonField(PdfStamper pdfStamper, HTMLSignModel htmlSignModel)
        {
            // set investor information in PDF
            var formFields = pdfStamper.AcroFields;
            // name & mailing address
            formFields.SetField("IssueDateMonth", htmlSignModel.IssueDateMonth);
            formFields.SetField("IssueDateDay", htmlSignModel.IssueDateDay);
            formFields.SetField("IssueDateYear", htmlSignModel.IssueDateYear);

            // also year to be fillable in PDF

            formFields.SetField("SubscriptionAmount", htmlSignModel.SubscriptionAmount);
            formFields.SetField("NumberOfShares", htmlSignModel.NumberOfShares);

            formFields.SetField("Name", htmlSignModel.Name);
            formFields.SetField("TaxIDNumber", htmlSignModel.TaxIDNumber);

            // home address
            formFields.SetField("StreetAddress", htmlSignModel.StreetAddress);
            formFields.SetField("CityStateZipcode", htmlSignModel.CityStateZipCode);
            formFields.SetField("Country", htmlSignModel.Country);

            // contact information  
            formFields.SetField("TelephoneNumber", htmlSignModel.TelephoneNumber);
            formFields.SetField("SubscriptionDate", htmlSignModel.Dated);
            formFields.SetField("DateAndIPAddress", htmlSignModel.DateAndIPAddress);
            formFields.SetField("SignatureName", htmlSignModel.SignatureName);

            return formFields;
        }
        private void FillImage(string fieldName, PdfStamper pdfStamper, byte[] signImage)
        {
            if (signImage != null)
            {
                if (pdfStamper.AcroFields.GetFieldPositions(fieldName) != null)
                {
                    AcroFields.FieldPosition fieldPosition = pdfStamper.AcroFields.GetFieldPositions(fieldName)[0];
                    PushbuttonField imageField = new PushbuttonField(pdfStamper.Writer, fieldPosition.position, fieldName);
                    imageField.Layout = PushbuttonField.LAYOUT_ICON_ONLY;
                    imageField.Image = iTextSharp.text.Image.GetInstance(signImage);
                    imageField.ScaleIcon = PushbuttonField.SCALE_ICON_ALWAYS;
                    imageField.ProportionalIcon = false;
                    imageField.Options = BaseField.READ_ONLY;
                    pdfStamper.AcroFields.RemoveField(fieldName);
                    pdfStamper.AddAnnotation(imageField.Field, fieldPosition.page);
                }
            }
        }

        private byte[] Draw2DLineGraphic(string jsonSign, int width, int height)
        {
            if (!string.IsNullOrEmpty(jsonSign))
            {
                I2DLineGraphic lineGraphic = new JavaScriptSerializer().Deserialize<Signature>(jsonSign);
                //The png's bytes 
                byte[] png = null;

                //Create the Bitmap set Width and height 
                using (Bitmap b = new Bitmap(width, height))
                {
                    using (Graphics g = Graphics.FromImage(b))
                    {
                        //Make sure the image is drawn Smoothly (this makes the pen lines look smoother) 
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                        //Set the background to white 
                        g.Clear(Color.White);

                        //Create a pen to draw the signature with 
                        Pen pen = new Pen(Color.Blue, 2);

                        //Smooth out the pen, making it rounded 
                        pen.DashCap = System.Drawing.Drawing2D.DashCap.Round;

                        //Last point a line finished at 
                        Point LastPoint = new Point();
                        bool hasLastPoint = false;

                        //Draw the signature on the bitmap 
                        foreach (List<List<double>> line in lineGraphic.lines)
                        {
                            foreach (List<double> point in line)
                            {
                                var x = (int)Math.Round(point[0]);
                                var y = (int)Math.Round(point[1]);

                                if (hasLastPoint)
                                {
                                    g.DrawLine(pen, LastPoint, new Point(x, y));
                                }

                                LastPoint.X = x;
                                LastPoint.Y = y;
                                hasLastPoint = true;
                            }
                            hasLastPoint = false;
                        }
                    }

                    //Convert the image to a png in memory 
                    using (MemoryStream stream = new MemoryStream())
                    {
                        b.Save(stream, ImageFormat.Png);
                        png = stream.ToArray();
                    }
                }
                //return Convert.ToBase64String(png);
                return png;
            }
            else
            {
                return null;
            }
        }

        private bool CanGoToMyAccountAccreditation(string investorType, bool resultNetwork1Security, int? productId)
        {
            // s-1 type condition
            if (!resultNetwork1Security)
            {
                // 1) Investor type should not null            
                if (string.IsNullOrEmpty(investorType))
                {
                    _logger.Information("Network1Security");
                    return true;
                }
            }
            //----------------------
            // 2) Required Basic information of Individual or company must be filed. Should not be empty or null            
            var individualBasic = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
            if (individualBasic != null)
            {
                if (string.IsNullOrEmpty(_currentCustomer.Email) ||
                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName)) ||
                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName)) ||
                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress)) ||
                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CountryId)) ||
                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StateProvinceId)) ||
                                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.City)) ||
                                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StateProvinceId)) ||
                                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode)) ||
                                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StateProvinceId)) ||
                                                    string.IsNullOrEmpty(_currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Phone)) ||
                    string.IsNullOrEmpty(individualBasic.SSN) ||
                    string.IsNullOrEmpty(individualBasic.Address_Years))
                {
                    _logger.Information("IndividualBasic");
                    return true;
                }
            }
            else
            {
                return true;
            }
            // s-1 type condition
            if (resultNetwork1Security)
            {
                // 3) if Investor type == NonAccreditted => check AnnualIncome > 0 and annualIncome > 0
                // because OrderedSharesCount is dependent on AnnualIncome or annualIncome
                // Look at PreparePurchaseModel method for more      
                var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                var AnnualIncome = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.AnnualIncome);
                var NetWorth = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.NetWorth);
                if (string.IsNullOrEmpty(AnnualIncome) || string.IsNullOrEmpty(NetWorth))
                {
                    return true;
                }
            }

            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (settings.VerifyInvestorValidationEnabled)
            {
                var viUserId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);
                if (viUserId == null)
                {
                    return true;
                }
            }
            //----------------
            return false;
        }

        private bool AllowToInvest(decimal purchaseAmount = 0)
        {
            var productId = GetProductId();
            var subscription = _bDAddressService.GetSubscriptionTemplateByProduct(productId);
            int offeringType = 0;
            if (subscription != null)
            {
                offeringType = Convert.ToInt32(subscription.OfferingType);
            }
            if (offeringType > 0)
            {
                if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_506b) ||
                    offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_506c))
                {
                    return true;
                }
                var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.InvestorType) ?? ClientConstants.InvestorType.NonAccreditted;
                if (investorType == ClientConstants.InvestorType.NonAccreditted)
                {
                    //Order total for 1 year cycle from starting first order              
                    var orders = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                        customerId: _workContext.CurrentCustomer.Id);
                    decimal TotalOrderAmount = 0;
                    if (orders != null && orders.Any())
                    {
                        DateTime firstOrderDate = Convert.ToDateTime(orders.OrderBy(o => o.CreatedOnUtc).FirstOrDefault().CreatedOnUtc);
                        DateTime currentCycleStartDate = firstOrderDate.ChangeYear(DateTime.Now.Year);
                        var filterOrder = orders.Where(o => o.CreatedOnUtc >= currentCycleStartDate);
                        TotalOrderAmount = filterOrder.Sum(o => o.OrderTotal);
                    }
                    //Calculation of MaxAmountToInvest.
                    decimal compareAmount = 100000; // 1,00,000
                    decimal fixMinimumAmount = 2200; // 2,200
                    decimal fixMaximumAmount = 107000; // 1,07,000
                    decimal MaxAmountToInvest = 0;
                    decimal purchaseModelMinimumInvest = 0;
                    decimal annualIncome;
                    decimal netWorth;
                    var existAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                    decimal.TryParse(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                        ClientConstants.CustomAttributes.AnnualIncome), out annualIncome);
                    decimal.TryParse(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                        ClientConstants.CustomAttributes.NetWorth), out netWorth);
                    if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_title3))
                    {
                        if (annualIncome < compareAmount && netWorth < compareAmount)
                        {
                            MaxAmountToInvest = (Math.Max(annualIncome, netWorth) * 5) / 100;
                            if (MaxAmountToInvest < fixMinimumAmount) MaxAmountToInvest = fixMinimumAmount;
                        }
                        else if (annualIncome >= compareAmount && netWorth >= compareAmount)
                        {
                            MaxAmountToInvest = (Math.Min(annualIncome, netWorth) * 10) / 100;
                            if (MaxAmountToInvest > fixMaximumAmount) MaxAmountToInvest = fixMaximumAmount;
                        }
                        else
                        {
                            MaxAmountToInvest = (Math.Min(annualIncome, netWorth) * 5) / 100;
                            if (MaxAmountToInvest < fixMinimumAmount) MaxAmountToInvest = fixMinimumAmount;
                        }
                    }
                    else // if offeringType = type_rega_tier1,type_rega_tier2
                    {
                        MaxAmountToInvest = (Math.Min(annualIncome, netWorth) * 10) / 100;
                    }

                    //Condition on PurchaseOrderAmount            
                    if (productId > 0)
                    {
                        var product = _productService.GetProductById(productId);

                        decimal taxRate;
                        decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                        decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);

                        purchaseModelMinimumInvest = finalPriceWithoutDiscount * product.OrderMinimumQuantity;
                    }
                    if (MaxAmountToInvest >= purchaseModelMinimumInvest)
                    {
                        if (TotalOrderAmount < MaxAmountToInvest)
                        {
                            if (purchaseAmount > 0)
                            {
                                if ((purchaseAmount + TotalOrderAmount) <= MaxAmountToInvest)
                                {
                                    return true;
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    //}
                    //return true;
                }
            }
            return true;
        }

        private bool IsDocusignEnable(int productId = 0)
        {
            if (productId == 0)
            {
                productId = GetProductId();
            }
            var subscription = _bDAddressService.GetSubscriptionTemplateByProduct(productId);
            if (subscription != null)
            {
                return subscription.IsDocusign;
            }
            return false;
        }

        private bool CanAllowNetwork1Security(int currentOfferingType = 0)
        {
            if (currentOfferingType == 0)
            {
                var settings = _settingsService.LoadSetting<CrowdPaySettings>();
                if (settings.SingleOfferProductId > 0)
                {
                    var subscription = _bDAddressService.GetSubscriptionTemplateByProduct(settings.SingleOfferProductId);
                    if (subscription != null)
                    {
                        currentOfferingType = subscription.OfferingType ?? 0;
                    }
                }
            }
            if (currentOfferingType == ClientConstants.OfferingType.type_S_1_IPO)
            {
                var verification = _bDAddressService.GetVerificationTemplateByCustomer(_currentCustomer.Id);
                if (verification != null)
                {
                    if (Convert.ToBoolean(verification.IsNetwork1Security))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private void PreparePersonalInformationModel(PersonalInformationModel model)
        {
            var personalInfoTypesAttribute =
                _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                    ClientConstants.CustomAttributes.PersonalInfoType);
            model.PersonalInfoType = GetSelectListItemsModel(personalInfoTypesAttribute);
        }

        private int? GetOfferingTypeOfProduct(int productId = 0)
        {
            var subscription = _bDAddressService.GetSubscriptionTemplateByProduct(productId);
            if (subscription != null)
            {
                return subscription.OfferingType;
            }
            return 0;
        }        

        #endregion

        #region Save Methods
        [NonAction]
        private JsonResult SavePurchase(FormCollection form)
        {
            //add payment methods
            var paymentMethods = _paymentService
                .LoadActivePaymentMethods(_workContext.CurrentCustomer.Id, _storeContext.CurrentStore.Id)
                .Where(
                    pm =>
                        pm.PaymentMethodType == PaymentMethodType.Standard ||
                        pm.PaymentMethodType == PaymentMethodType.Redirection)
                .ToList();

            string paymentmethod = string.Empty;
            if (paymentMethods.Any())
            {
                paymentmethod = paymentMethods[0].PluginDescriptor.SystemName;
            }
            //if (paymentMethods.Count == 1)
            //{
            //    paymentmethod = paymentMethods[0].PluginDescriptor.SystemName;
            //}
            //else
            //{
            //    paymentmethod = form["paymentmethod"];
            //}            
            //payment method error
            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var purchaseModel = new PurchaseModel();
            TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
            TryValidateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);

            if (!ModelState.IsValid)
            {
                PreparePurchaseModel(purchaseModel);
                return Json(new
                {
                    Error = "Purchase information is not valid",
                    Success = false
                });
            }
            //save payment method
            if (!String.IsNullOrEmpty(paymentmethod))
            {
                _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                    SystemCustomerAttributeNames.SelectedPaymentMethod, paymentmethod, _storeContext.CurrentStore.Id);
            }

            // save OrderedSharesCount
            _customGenericAttributeService.SaveGenericAttirubteValue(ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity, purchaseModel.OrderedSharesCount.ToString());
            return Json(new
            {
                Error = "",
                Success = true
            });
        }

        [NonAction]
        private ActionResult SavePaymentInfo(FormCollection form)
        {
            try
            {
                var customPaymentInfoModel = new CustomPaymentInfoModel();
                TryUpdateModel(customPaymentInfoModel, ClientConstants.FormPrefix.PaymentInfoPrefix);

                //validation
                var paymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                    SystemCustomerAttributeNames.SelectedPaymentMethod,
                    _genericAttributeService, _storeContext.CurrentStore.Id);
                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentMethodSystemName);
                if (paymentMethod == null)
                    throw new Exception("Payment method is not selected");

                var paymentControllerType = paymentMethod.GetControllerType();
                var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as BasePaymentController;
                if (paymentController == null)
                    throw new Exception("Payment controller cannot be loaded");

                var warnings = paymentController.ValidatePaymentForm(form);
                foreach (var warning in warnings)
                    ModelState.AddModelError("", warning);
                if (ModelState.IsValid)
                {
                    //get payment info
                    var paymentInfo = paymentController.GetPaymentInfo(form);
                    //session save
                    _httpContext.Session["CrowdPayOrderPaymentInfo"] = paymentInfo;

                    return Json(new
                    {
                        Error = "",
                        Success = true
                    });
                }
                return Json(new
                {
                    Error = "Payment information is not valid",
                    Success = false
                });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _currentCustomer);
                return Json(new
                {
                    Error = exc.Message,
                    Success = false
                });
            }
        }

        [NonAction]
        private ActionResult SaveBilling(FormCollection form)
        {
            try
            {
                Product product;
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                }
                else
                {
                    return Json(new
                    {
                        Error = "Can't find product attribute",
                        Success = false
                    });
                }
                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                int billingAddressId;
                int.TryParse(form["billing_address_id"], out billingAddressId);

                if (billingAddressId > 0)
                {
                    //existing address
                    var address = _currentCustomer.Addresses.FirstOrDefault(a => a.Id == billingAddressId);
                    if (address == null)
                        throw new Exception("Address can't be loaded");

                    _currentCustomer.BillingAddress = address;
                    _customerService.UpdateCustomer(_currentCustomer);
                }
                else
                {
                    //new address
                    var model = new CheckoutBillingAddressModel();
                    TryUpdateModel(model.NewAddress, "BillingNewAddress");

                    //custom address attributes
                    var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                    var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                    foreach (var error in customAttributeWarnings)
                    {
                        ModelState.AddModelError("", error);
                    }

                    //validate model
                    TryValidateModel(model.NewAddress);
                    if (!ModelState.IsValid)
                    {
                        return Json(new
                        {
                            Error = "Billing information is not valid",
                            Success = false
                        });
                    }

                    //try to find an address with the same values (don't duplicate records)
                    var address = _currentCustomer.Addresses.ToList().FindAddress(
                        model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                        model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                        model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                        model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                        model.NewAddress.CountryId, customAttributes);
                    if (address == null)
                    {
                        //address is not found. let's create a new one
                        address = model.NewAddress.ToEntity();
                        address.CustomAttributes = customAttributes;
                        address.CreatedOnUtc = DateTime.UtcNow;
                        //some validation
                        if (address.CountryId == 0)
                            address.CountryId = null;
                        if (address.StateProvinceId == 0)
                            address.StateProvinceId = null;
                        if (address.CountryId.HasValue && address.CountryId.Value > 0)
                        {
                            address.Country = _countryService.GetCountryById(address.CountryId.Value);
                        }
                        _currentCustomer.Addresses.Add(address);
                    }
                    _currentCustomer.BillingAddress = address;
                    _customerService.UpdateCustomer(_currentCustomer);
                }
                if (!cart.RequiresShipping())
                {
                    //shipping is not required
                    _genericAttributeService.SaveAttribute<ShippingOption>(_currentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, null, _storeContext.CurrentStore.Id);
                }
                return Json(new
                {
                    Error = "",
                    Success = true
                });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _currentCustomer);
                return Json(new
                {
                    Error = exc.Message,
                    Success = false
                });
            }
        }

        [NonAction]
        public ActionResult SaveShipping(FormCollection form)
        {
            try
            {
                Product product;
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                }
                else
                {
                    return Json(new
                    {
                        Error = "Can't find product attribute",
                        Success = false
                    });
                }

                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                //Pick up in store?
                if (_shippingSettings.AllowPickUpInStore)
                {
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model);

                    if (model.PickUpInStore)
                    {
                        //customer decided to pick up in store

                        _workContext.CurrentCustomer.ShippingAddress = null;
                        _customerService.UpdateCustomer(_workContext.CurrentCustomer);

                        var pickupPoint = form["pickup-points-id"].Split(new[] { "___" }, StringSplitOptions.None);
                        var pickupPoints = _shippingService
                            .GetPickupPoints(_workContext.CurrentCustomer.BillingAddress, pickupPoint[1], _storeContext.CurrentStore.Id).PickupPoints.ToList();
                        var selectedPoint = pickupPoints.FirstOrDefault(x => x.Id.Equals(pickupPoint[0]));
                        if (selectedPoint == null)
                            throw new Exception("Pickup point is not allowed");

                        var pickUpInStoreShippingOption = new ShippingOption
                        {
                            Name = string.Format(_localizationService.GetResource("Checkout.PickupPoints.Name"), selectedPoint.Name),
                            Rate = selectedPoint.PickupFee,
                            Description = selectedPoint.Description,
                            ShippingRateComputationMethodSystemName = selectedPoint.ProviderSystemName
                        };
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, pickUpInStoreShippingOption, _storeContext.CurrentStore.Id);
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickupPoint, selectedPoint, _storeContext.CurrentStore.Id);
                        return Json(new
                        {
                            Error = "",
                            Success = true
                        });
                    }

                    //set value indicating that "pick up in store" option has not been chosen
                    _genericAttributeService.SaveAttribute<PickupPoint>(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickupPoint, null, _storeContext.CurrentStore.Id);
                }

                int shippingAddressId;
                int.TryParse(form["shipping_address_id"], out shippingAddressId);

                if (shippingAddressId > 0)
                {
                    //existing address
                    var address = _workContext.CurrentCustomer.Addresses.FirstOrDefault(a => a.Id == shippingAddressId);
                    if (address == null)
                        throw new Exception("Address can't be loaded");

                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }
                else
                {
                    //new address
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model.NewAddress, "ShippingNewAddress");

                    //custom address attributes
                    var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                    var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                    foreach (var error in customAttributeWarnings)
                    {
                        ModelState.AddModelError("", error);
                    }

                    //validate model
                    TryValidateModel(model.NewAddress);
                    if (!ModelState.IsValid)
                    {
                        return Json(new
                        {
                            Error = "Shipping information is not valid",
                            Success = false
                        });
                    }

                    //try to find an address with the same values (don't duplicate records)
                    var address = _workContext.CurrentCustomer.Addresses.ToList().FindAddress(
                        model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                        model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                        model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                        model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                        model.NewAddress.CountryId, customAttributes);
                    if (address == null)
                    {
                        address = model.NewAddress.ToEntity();
                        address.CustomAttributes = customAttributes;
                        address.CreatedOnUtc = DateTime.UtcNow;
                        //little hack here (TODO: find a better solution)
                        //EF does not load navigation properties for newly created entities (such as this "Address").
                        //we have to load them manually 
                        //otherwise, "Country" property of "Address" entity will be null in shipping rate computation methods
                        if (address.CountryId.HasValue)
                            address.Country = _countryService.GetCountryById(address.CountryId.Value);
                        if (address.StateProvinceId.HasValue)
                            address.StateProvince = _stateProvinceService.GetStateProvinceById(address.StateProvinceId.Value);

                        //other null validations
                        if (address.CountryId == 0)
                            address.CountryId = null;
                        if (address.StateProvinceId == 0)
                            address.StateProvinceId = null;
                        _workContext.CurrentCustomer.Addresses.Add(address);
                    }
                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }

                var shippingMethodModel = PrepareShippingMethodModel(cart, _workContext.CurrentCustomer.ShippingAddress);

                //if (_shippingSettings.BypassShippingMethodSelectionIfOnlyOne &&
                //    shippingMethodModel.ShippingMethods.Count == 1)
                //{
                //if we have only one shipping method, then a customer doesn't have to choose a shipping method
                _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                    SystemCustomerAttributeNames.SelectedShippingOption,
                    shippingMethodModel.ShippingMethods.First().ShippingOption,
                    _storeContext.CurrentStore.Id);
                //}
                return Json(new
                {
                    Error = "",
                    Success = true
                });

            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new
                {
                    Error = exc.Message,
                    Success = false
                });
            }
        }

        private void SaveInvestorOrder(int productId, int customerId)
        {
            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            BD_InvestorOrder investorOrder = new BD_InvestorOrder()
            {
                ProductId = productId,
                CustomerId = customerId,
                InvestorType = investorType,
                StoreId = _storeContext.CurrentStore.Id,
                CreatedOnUtc = DateTime.UtcNow
            };
            _bDAddressService.InsertUpdateInvestorOrder(investorOrder);
        }

        #endregion

        #region Load Models
        private void LoadPaymentInfo(FormCollection form, CustomPaymentInfoModel customPaymentInfoModel, PurchaseModel purchaseModel)
        {
            string paymentmethod = null;
            if (form != null)
            {
                paymentmethod = form["paymentmethod"];
            }
            else if (purchaseModel != null)
            {
                if (purchaseModel.PaymentMethods.Any())
                {
                    paymentmethod = purchaseModel.PaymentMethods.FirstOrDefault(p => p.Selected).PaymentMethodSystemName;
                }
            }
            else
            {
                //add payment methods
                var paymentMethods = _paymentService
                    .LoadActivePaymentMethods(_workContext.CurrentCustomer.Id, _storeContext.CurrentStore.Id)
                    .Where(
                        pm =>
                            pm.PaymentMethodType == PaymentMethodType.Standard ||
                            pm.PaymentMethodType == PaymentMethodType.Redirection)
                    .ToList();
                if (paymentMethods.Any())
                {
                    paymentmethod = paymentMethods[0].PluginDescriptor.SystemName;
                }
            }

            //= form["paymentmethod"];
            //payment method 
            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            if (paymentMethodInst == null ||
                !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
                !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
                throw new Exception("Selected payment method can't be parsed");

            var paymentInfoModel = PreparePaymentInfoModel(paymentMethodInst);
            customPaymentInfoModel.CheckoutPaymentInfoModel = paymentInfoModel;
        }
        #endregion

        [NonAction]
        private IList<SelectListItem> GetSelectListItemsModel(IList<CustomerAttributeValue> attributeValues)
        {
            var langId = _workContext.WorkingLanguage.Id;

            var query = attributeValues.Select(x => new SelectListItem()    
            {
                Text = _localizationService.GetResource(
                        string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                            ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                Selected = x.IsPreSelected,
                Value = x.Name
            }).ToList();

            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!settings.VerifyInvestorValidationEnabled && !settings.SelfAccredited && !settings.InternalAccreditation)
            {
                return attributeValues.Where(x => x.Name == ClientConstants.InvestorType.NonAccreditted).Select(x => new SelectListItem()
                {
                    Text = _localizationService.GetResource(
                            string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                                ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                    " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                    Selected = (attributeValues.Count() > 1) ? x.IsPreSelected : true,
                    Value = x.Name
                }).ToList();
            }
            else
            {
                return attributeValues.Select(x => new SelectListItem()
                {
                    Text = _localizationService.GetResource(
                            string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                                ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                    " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                    Selected = (attributeValues.Count() > 1) ? x.IsPreSelected : true,
                    Value = x.Name
                }).ToList();
            }
        }

        #endregion

        #region Check default models for skipping steps

        private bool CanSkipInvestorInformationStep(Product product)
        {
            var investorInformationTemplate = product.ProductSpecificationAttributes.SingleOrDefault(
                      x =>
                          x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                          ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId);

            var oldTemplateId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                            String.Format(ClientConstants.TempCheckOutGenericAttirubutes.OldTemplateId, product.Id,
                                 ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId));

            var succesfullyId =
                _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    String.Format(ClientConstants.TempCheckOutGenericAttirubutes.SuccesfulyEnvelopId,
                        product.Id, ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId));

            if (investorInformationTemplate == null)
            {
                _logger.Information("1. CanSkipInvestorInformationStep");
                return true;
            }
            if (oldTemplateId != null && investorInformationTemplate.CustomValue != oldTemplateId.Value)
            {
                _logger.Information("2. CanSkipInvestorInformationStep");
                return false;
            }
            if (oldTemplateId != null && investorInformationTemplate.CustomValue == oldTemplateId.Value &&
                succesfullyId == null)
            {
                _logger.Information("3. CanSkipInvestorInformationStep");
                return false;
            }

            _logger.Information("4. CanSkipInvestorInformationStep");
            return true;
        }

        private bool CanSkipPersonalInformationStep()
        {
            var resultModel = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType);

            resultModel.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;

            PreparePersonalInformationModel(resultModel);

            TryValidateModel(resultModel);

            _logger.Information("CanSkipPersonalInformationStep: " + ModelState.IsValid);
            return ModelState.IsValid;
        }

        private bool CanSkipVerifyInvestorStep()
        {
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!settings.VerifyInvestorValidationEnabled)
            {
                return true;
            }

            var viUseridAttribute =
                _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);
            if (viUseridAttribute != null)
            {
                var verifyStatus = _verifyInvestorService.GetVerificationStatus(int.Parse(viUseridAttribute.Value));
                _logger.Information("CanSkipVerifyInvestorStep_Verifivation_Status: " + verifyStatus);
                if (verifyStatus != null)
                {
                    switch (verifyStatus.verification_status)
                    {
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.Verified:
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.PendingVerification:
                            _logger.Information("CanSkipVerifyInvestorStep: true");
                            return true;
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.Unverified:
                            {
                                switch (verifyStatus.verification_request_step)
                                {
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.AcceptedExpire:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.DeclinedByInvestor:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.DeclinedExpire:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.NoRequest:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForInfoFromInvestor:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForInvestorAcceptance:
                                        _logger.Information("CanSkipVerifyInvestorStep: false");
                                        return false;
                                    default:
                                        {
                                            _logger.Information("CanSkipVerifyInvestorStep: true(default)");
                                            return true;
                                        }
                                }
                            }
                    }
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        private bool CanSkipInvestorTypeStep()
        {
            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            return investorType == ClientConstants.InvestorType.Accreddited;
        }

        #endregion
    }
}
