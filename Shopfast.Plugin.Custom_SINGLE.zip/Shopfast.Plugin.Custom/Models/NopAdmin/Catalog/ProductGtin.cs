﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Catalog
{
    public class ProductGtin
    {
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.SearchGtin")]
        public string SearchGtin { get; set; }
    }
}