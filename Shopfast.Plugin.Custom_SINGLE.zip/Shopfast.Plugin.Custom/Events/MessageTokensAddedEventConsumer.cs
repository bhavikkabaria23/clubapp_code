﻿using Nop.Core.Domain.Messages;
using Nop.Services.Events;
using Nop.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class MessageTokensAddedEventConsumer : IConsumer<MessageTokensAddedEvent<Token>>
    {
        public void HandleEvent(MessageTokensAddedEvent<Token> eventMessage)
        {
            if(eventMessage.Message.Name == MessageTemplateSystemNames.GiftCardNotification)
            {
                // get coupon code from "GiftCard.CouponCode"
                // generate QR code and save to a path
                // then use that path with "Store.URL" token
                // set path with new token "GiftCard.CouponQRCode"
                eventMessage.Tokens.Add(new Token("Gift.Test","bhavik"));
            }
        }
    }
}