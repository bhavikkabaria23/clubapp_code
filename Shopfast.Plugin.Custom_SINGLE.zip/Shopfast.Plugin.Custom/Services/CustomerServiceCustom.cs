﻿using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public class CustomerServiceCustom : ICustomerServiceCustom
    {
        public virtual Customer GetAdminCustomer()
        {
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            Customer customer = dbContext.SqlQuery<Customer>("sp_GetAdminCustomer").FirstOrDefault();
            return customer;
        }
    }
}