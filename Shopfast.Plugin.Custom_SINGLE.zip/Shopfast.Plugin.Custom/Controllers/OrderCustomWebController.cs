﻿using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Web.Controllers;
using Nop.Web.Models.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Services.Localization;
using Nop.Web.Extensions;
using Nop.Services.Payments;
using Nop.Services.Orders;
using Nop.Services.Catalog;
using Nop.Services.Helpers;
using Nop.Core;
using Nop.Core.Domain.Common;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Core.Domain.Catalog;
using Nop.Services.Security;
using Nop.Services.Customers;
using Nop.Services.Media;
using Nop.Services.Seo;
using Shopfast.Plugin.Custom.Services;
using Shopfast.Plugin.Custom.Models.NopWeb.Orders;
using Nop.Web.Models.Common;
using Nop.Web.Factories;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class OrderCustomWebController : BasePublicController
    {
        #region Fields
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly IWorkContext _workContext;
        private readonly ILocalizationService _localizationService;
        private readonly OrderSettings _orderSettings;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly PdfSettings _pdfSettings;
        private readonly AddressSettings _addressSettings;
        private readonly IAddressAttributeFormatter _addressAttributeFormatter;
        private readonly IPaymentService _paymentService;
        private readonly TaxSettings _taxSettings;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly CatalogSettings _catalogSettings;
        private readonly IOrderService _orderService;
        private readonly IEncryptionService _encryptionService;
        private readonly ICustomerService _customerService;
        private readonly IDownloadService _downloadService;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IStoreContext _storeContext;

        private readonly IAddressModelFactory _addressModelFactory;

        // custom services
        private readonly ICustomerServiceCustom _customerServiceCustom;
        #endregion

        #region Constructors
        public OrderCustomWebController(IOrderService orderService,
            IWorkContext workContext,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IOrderProcessingService orderProcessingService,
            IDateTimeHelper dateTimeHelper,
            IPaymentService paymentService,
            ILocalizationService localizationService,
            IProductAttributeParser productAttributeParser,
            IDownloadService downloadService,
            IAddressAttributeFormatter addressAttributeFormatter,
            CatalogSettings catalogSettings,
            OrderSettings orderSettings,
            TaxSettings taxSettings,
            AddressSettings addressSettings,
            PdfSettings pdfSettings,
            ICustomerService customerService,
            IEncryptionService encryptionService,
            ICustomerServiceCustom customerServiceCustom,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IStoreContext storeContext,
            IAddressModelFactory addressModelFactory)
        {
            this._orderService = orderService;
            this._workContext = workContext;
            this._currencyService = currencyService;
            this._priceFormatter = priceFormatter;
            this._orderProcessingService = orderProcessingService;
            this._dateTimeHelper = dateTimeHelper;
            this._paymentService = paymentService;
            this._localizationService = localizationService;
            this._productAttributeParser = productAttributeParser;
            this._downloadService = downloadService;
            this._addressAttributeFormatter = addressAttributeFormatter;

            this._catalogSettings = catalogSettings;
            this._orderSettings = orderSettings;
            this._taxSettings = taxSettings;
            this._addressSettings = addressSettings;
            this._pdfSettings = pdfSettings;

            this._customerService = customerService;
            this._encryptionService = encryptionService;

            this._customerServiceCustom = customerServiceCustom;

            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;

            this._storeContext = storeContext;

            this._addressModelFactory = addressModelFactory;
        }
        #endregion

        #region Utilities
        [NonAction]
        protected virtual OrderDetailsModelCustom PrepareOrderDetailsModelSMS(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");
            var model = new OrderDetailsModelCustom();

            model.Id = order.Id;
            model.CreatedOn = _dateTimeHelper.ConvertToUserTime(order.CreatedOnUtc, DateTimeKind.Utc);
            model.OrderStatus = order.OrderStatus.GetLocalizedEnum(_localizationService, _workContext);
            model.IsReOrderAllowed = _orderSettings.IsReOrderAllowed;
            model.IsReturnRequestAllowed = _orderProcessingService.IsReturnRequestAllowed(order);
            model.PdfInvoiceDisabled = _pdfSettings.DisablePdfInvoicesForPendingOrders && order.OrderStatus == OrderStatus.Pending;
            model.CustomOrderNumber = order.CustomOrderNumber;

            //shipping info
            model.ShippingStatus = order.ShippingStatus.GetLocalizedEnum(_localizationService, _workContext);
            if (order.ShippingStatus != ShippingStatus.ShippingNotRequired)
            {
                model.IsShippable = true;
                model.PickUpInStore = order.PickUpInStore;
                if (!order.PickUpInStore)
                {
                    _addressModelFactory.PrepareAddressModel(model.ShippingAddress,
                        address: order.ShippingAddress,
                        excludeProperties: false,
                        addressSettings: _addressSettings);
                }
                else
                    if (order.PickupAddress != null)
                        model.PickupAddress = new AddressModel
                        {
                            Address1 = order.PickupAddress.Address1,
                            City = order.PickupAddress.City,
                            CountryName = order.PickupAddress.Country != null ? order.PickupAddress.Country.Name : string.Empty,
                            ZipPostalCode = order.PickupAddress.ZipPostalCode
                        };
                model.ShippingMethod = order.ShippingMethod;


                //shipments (only already shipped)
                var shipments = order.Shipments.Where(x => x.ShippedDateUtc.HasValue).OrderBy(x => x.CreatedOnUtc).ToList();
                foreach (var shipment in shipments)
                {
                    var shipmentModel = new OrderDetailsModelCustom.ShipmentBriefModel
                    {
                        Id = shipment.Id,
                        TrackingNumber = shipment.TrackingNumber,
                    };
                    if (shipment.ShippedDateUtc.HasValue)
                        shipmentModel.ShippedDate = _dateTimeHelper.ConvertToUserTime(shipment.ShippedDateUtc.Value, DateTimeKind.Utc);
                    if (shipment.DeliveryDateUtc.HasValue)
                        shipmentModel.DeliveryDate = _dateTimeHelper.ConvertToUserTime(shipment.DeliveryDateUtc.Value, DateTimeKind.Utc);
                    model.Shipments.Add(shipmentModel);
                }
            }


            //billing info
            _addressModelFactory.PrepareAddressModel(model.BillingAddress,
                 address: order.BillingAddress,
                 excludeProperties: false,
                 addressSettings: _addressSettings);

            //VAT number
            model.VatNumber = order.VatNumber;

            //payment method
            var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(order.PaymentMethodSystemName);
            model.PaymentMethod = paymentMethod != null ? paymentMethod.GetLocalizedFriendlyName(_localizationService, _workContext.WorkingLanguage.Id) : order.PaymentMethodSystemName;
            model.PaymentMethodStatus = order.PaymentStatus.GetLocalizedEnum(_localizationService, _workContext);
            model.CanRePostProcessPayment = _paymentService.CanRePostProcessPayment(order);
            //custom values
            model.CustomValues = order.DeserializeCustomValues();

            //order subtotal
            if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax && !_taxSettings.ForceTaxExclusionFromOrderSubtotal)
            {
                //including tax

                //order subtotal
                var orderSubtotalInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubtotalInclTax, order.CurrencyRate);
                model.OrderSubtotal = _priceFormatter.FormatPrice(orderSubtotalInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                //discount (applied to order subtotal)
                var orderSubTotalDiscountInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubTotalDiscountInclTax, order.CurrencyRate);
                if (orderSubTotalDiscountInclTaxInCustomerCurrency > decimal.Zero)
                    model.OrderSubTotalDiscount = _priceFormatter.FormatPrice(-orderSubTotalDiscountInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
            }
            else
            {
                //excluding tax

                //order subtotal
                var orderSubtotalExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubtotalExclTax, order.CurrencyRate);
                model.OrderSubtotal = _priceFormatter.FormatPrice(orderSubtotalExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                //discount (applied to order subtotal)
                var orderSubTotalDiscountExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubTotalDiscountExclTax, order.CurrencyRate);
                if (orderSubTotalDiscountExclTaxInCustomerCurrency > decimal.Zero)
                    model.OrderSubTotalDiscount = _priceFormatter.FormatPrice(-orderSubTotalDiscountExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
            }

            if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
            {
                //including tax

                //order shipping
                var orderShippingInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderShippingInclTax, order.CurrencyRate);
                model.OrderShipping = _priceFormatter.FormatShippingPrice(orderShippingInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                //payment method additional fee
                var paymentMethodAdditionalFeeInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.PaymentMethodAdditionalFeeInclTax, order.CurrencyRate);
                if (paymentMethodAdditionalFeeInclTaxInCustomerCurrency > decimal.Zero)
                    model.PaymentMethodAdditionalFee = _priceFormatter.FormatPaymentMethodAdditionalFee(paymentMethodAdditionalFeeInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
            }
            else
            {
                //excluding tax

                //order shipping
                var orderShippingExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderShippingExclTax, order.CurrencyRate);
                model.OrderShipping = _priceFormatter.FormatShippingPrice(orderShippingExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                //payment method additional fee
                var paymentMethodAdditionalFeeExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.PaymentMethodAdditionalFeeExclTax, order.CurrencyRate);
                if (paymentMethodAdditionalFeeExclTaxInCustomerCurrency > decimal.Zero)
                    model.PaymentMethodAdditionalFee = _priceFormatter.FormatPaymentMethodAdditionalFee(paymentMethodAdditionalFeeExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
            }

            //tax
            bool displayTax = true;
            bool displayTaxRates = true;
            if (_taxSettings.HideTaxInOrderSummary && order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
            {
                displayTax = false;
                displayTaxRates = false;
            }
            else
            {
                if (order.OrderTax == 0 && _taxSettings.HideZeroTax)
                {
                    displayTax = false;
                    displayTaxRates = false;
                }
                else
                {
                    displayTaxRates = _taxSettings.DisplayTaxRates && order.TaxRatesDictionary.Any();
                    displayTax = !displayTaxRates;

                    var orderTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderTax, order.CurrencyRate);
                    //TODO pass languageId to _priceFormatter.FormatPrice
                    model.Tax = _priceFormatter.FormatPrice(orderTaxInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

                    foreach (var tr in order.TaxRatesDictionary)
                    {
                        model.TaxRates.Add(new OrderDetailsModelCustom.TaxRate
                        {
                            Rate = _priceFormatter.FormatTaxRate(tr.Key),
                            //TODO pass languageId to _priceFormatter.FormatPrice
                            Value = _priceFormatter.FormatPrice(_currencyService.ConvertCurrency(tr.Value, order.CurrencyRate), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage),
                        });
                    }
                }
            }
            model.DisplayTaxRates = displayTaxRates;
            model.DisplayTax = displayTax;
            model.DisplayTaxShippingInfo = _catalogSettings.DisplayTaxShippingInfoOrderDetailsPage;
            model.PricesIncludeTax = order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax;

            //discount (applied to order total)
            var orderDiscountInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderDiscount, order.CurrencyRate);
            if (orderDiscountInCustomerCurrency > decimal.Zero)
                model.OrderTotalDiscount = _priceFormatter.FormatPrice(-orderDiscountInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);


            //gift cards
            foreach (var gcuh in order.GiftCardUsageHistory)
            {
                model.GiftCards.Add(new OrderDetailsModelCustom.GiftCard
                {
                    CouponCode = gcuh.GiftCard.GiftCardCouponCode,
                    Amount = _priceFormatter.FormatPrice(-(_currencyService.ConvertCurrency(gcuh.UsedValue, order.CurrencyRate)), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage),
                });
            }

            //reward points           
            if (order.RedeemedRewardPointsEntry != null)
            {
                model.RedeemedRewardPoints = -order.RedeemedRewardPointsEntry.Points;
                model.RedeemedRewardPointsAmount = _priceFormatter.FormatPrice(-(_currencyService.ConvertCurrency(order.RedeemedRewardPointsEntry.UsedAmount, order.CurrencyRate)), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);
            }

            //total
            var orderTotalInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderTotal, order.CurrencyRate);
            model.OrderTotal = _priceFormatter.FormatPrice(orderTotalInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

            //checkout attributes
            model.CheckoutAttributeInfo = order.CheckoutAttributeDescription;

            //order notes
            foreach (var orderNote in order.OrderNotes
                .Where(on => on.DisplayToCustomer)
                .OrderByDescending(on => on.CreatedOnUtc)
                .ToList())
            {
                model.OrderNotes.Add(new OrderDetailsModelCustom.OrderNote
                {
                    Id = orderNote.Id,
                    HasDownload = orderNote.DownloadId > 0,
                    Note = orderNote.FormatOrderNoteText(),
                    CreatedOn = _dateTimeHelper.ConvertToUserTime(orderNote.CreatedOnUtc, DateTimeKind.Utc)
                });
            }


            //purchased products
            model.ShowSku = _catalogSettings.ShowSkuOnProductDetailsPage;
            var orderItems = order.OrderItems;
            foreach (var orderItem in orderItems)
            {
                var orderItemModel = new OrderDetailsModelCustom.OrderItemModel
                {
                    Id = orderItem.Id,
                    OrderItemGuid = orderItem.OrderItemGuid,
                    Sku = orderItem.Product.FormatSku(orderItem.AttributesXml, _productAttributeParser),
                    ProductId = orderItem.Product.Id,
                    ProductName = orderItem.Product.GetLocalized(x => x.Name),
                    ProductSeName = orderItem.Product.GetSeName(),
                    Quantity = orderItem.Quantity,
                    AttributeInfo = orderItem.AttributeDescription,
                };
                //rental info
                if (orderItem.Product.IsRental)
                {
                    var rentalStartDate = orderItem.RentalStartDateUtc.HasValue ? orderItem.Product.FormatRentalDate(orderItem.RentalStartDateUtc.Value) : "";
                    var rentalEndDate = orderItem.RentalEndDateUtc.HasValue ? orderItem.Product.FormatRentalDate(orderItem.RentalEndDateUtc.Value) : "";
                    orderItemModel.RentalInfo = string.Format(_localizationService.GetResource("Order.Rental.FormattedDate"),
                        rentalStartDate, rentalEndDate);
                }
                model.Items.Add(orderItemModel);

                //unit price, subtotal
                if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
                {
                    //including tax
                    var unitPriceInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.UnitPriceInclTax, order.CurrencyRate);
                    orderItemModel.UnitPrice = _priceFormatter.FormatPrice(unitPriceInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);

                    var priceInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.PriceInclTax, order.CurrencyRate);
                    orderItemModel.SubTotal = _priceFormatter.FormatPrice(priceInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                }
                else
                {
                    //excluding tax
                    var unitPriceExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.UnitPriceExclTax, order.CurrencyRate);
                    orderItemModel.UnitPrice = _priceFormatter.FormatPrice(unitPriceExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);

                    var priceExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.PriceExclTax, order.CurrencyRate);
                    orderItemModel.SubTotal = _priceFormatter.FormatPrice(priceExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                }

                //downloadable products
                if (_downloadService.IsDownloadAllowed(orderItem))
                    orderItemModel.DownloadId = orderItem.Product.DownloadId;
                if (_downloadService.IsLicenseDownloadAllowed(orderItem))
                    orderItemModel.LicenseId = orderItem.LicenseDownloadId.HasValue ? orderItem.LicenseDownloadId.Value : 0;
            }

            // Changes - Print Order in OrderDetails and POS
            #region Credit Card information
            if (!string.IsNullOrEmpty(order.CardType))
            {
                model.CardType = _encryptionService.DecryptText(order.CardType);
            }
            if (!string.IsNullOrEmpty(order.CardName))
            {
                model.CardName = _encryptionService.DecryptText(order.CardName);
            }
            if (!string.IsNullOrEmpty(order.CardNumber))
            {
                model.CardNumber = _encryptionService.DecryptText(order.CardNumber);
            }
            if (!string.IsNullOrEmpty(order.MaskedCreditCardNumber))
            {
                model.MaskedCreditCardNumber = _encryptionService.DecryptText(order.MaskedCreditCardNumber);
            }
            if (!string.IsNullOrEmpty(order.CardCvv2))
            {
                model.CardCvv2 = _encryptionService.DecryptText(order.CardCvv2);
            }
            if (!string.IsNullOrEmpty(order.CardExpirationMonth))
            {
                model.CardExpirationMonth = _encryptionService.DecryptText(order.CardExpirationMonth);
            }
            if (!string.IsNullOrEmpty(order.CardExpirationYear))
            {
                model.CardExpirationYear = _encryptionService.DecryptText(order.CardExpirationYear);
            }
            if (!string.IsNullOrEmpty(order.AuthorizationTransactionId))
            {
                model.AuthorizationTransactionId = order.AuthorizationTransactionId;
            }
            #endregion

            //#region Customer info
            //model.CustomerId = order.CustomerId;
            Customer adminCustomer = _customerServiceCustom.GetAdminCustomer();
            if (adminCustomer != null)
            {
                // Cashier is the admin customer name
                model.Cashier = adminCustomer.GetFullName();

                // currently no need to show Google map based on customer store address
                //model.StreetAddress = adminCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress);
                //model.StreetAddress2 = adminCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2);
                //model.ZipPostalCode = adminCustomer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode);
                //model.City = adminCustomer.GetAttribute<string>(SystemCustomerAttributeNames.City);
                //if (adminCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId) > 0)
                //{
                //    model.Country = _countryService.GetCountryById(adminCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId)).Name;
                //}
                //if (adminCustomer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId) > 0)
                //{
                //    model.State = _stateProvinceService.GetStateProvinceById(adminCustomer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId)).Name;
                //}
            }

            if (!string.IsNullOrEmpty(_storeContext.CurrentStore.CompanyName))
            {
                model.CompanyName = _storeContext.CurrentStore.CompanyName.Trim();
            }
            if (!string.IsNullOrEmpty(_storeContext.CurrentStore.CompanyPhoneNumber))
            {
                model.CompanyPhoneNumber = _storeContext.CurrentStore.CompanyPhoneNumber.Trim();
            }

            if (!string.IsNullOrEmpty(_storeContext.CurrentStore.CompanyAddress))
            {
                model.StoreAddress = _storeContext.CurrentStore.CompanyAddress.Trim();
            }


            //#endregion

            //#region Qr code And Barcode
            //string domainUrl = _webHelper.GetStoreLocation();
            //if (!string.IsNullOrEmpty(domainUrl))
            //{
            //    model.DomainUrlQRCode = "/" + CommonHelper.GenerateQRCodeImage(Convert.ToString(domainUrl), true);
            //}

            //if (order.CustomerId > 0)
            //{
            //    model.CustomerIdQRCode = "/" + CommonHelper.GenerateQRCodeImage(Convert.ToString(order.CustomerId));
            //}

            //if (order.Id > 0)
            //{
            //    model.OrderIdBarcodeCode = Nop.Core.NopBarCodeImage.GenerateBarCode(Convert.ToString(order.Id), "13");
            //}
            //#endregion

            //model.Signature = order.Signature;
            //------------------------

            return model;
        }
        #endregion

        // Print Order Details For SMS
        // Here order print is applied wthout login (will be used for Mobile App)
        public ActionResult PrintOrderDetailsForSMS(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            if (order == null || order.Deleted)
                return RedirectToAction("Common", "PageNotFound");

            var model = PrepareOrderDetailsModelSMS(order);
            model.PrintMode = true;
            // Changes - Print Order in OrderDetails and POS
            return View("DetailsPrint", model);
            //---------------------------
        }
    }
}