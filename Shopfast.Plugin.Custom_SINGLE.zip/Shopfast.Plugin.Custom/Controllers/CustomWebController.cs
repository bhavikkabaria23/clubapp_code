﻿using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain;
using Nop.Core.Domain.Configuration;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Messages;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Web.Controllers;
using Nop.Web.Factories;
using Nop.Web.Framework.Themes;
using Nop.Web.Infrastructure.Cache;
using Nop.Web.Models.Common;
using Shopfast.Plugin.Custom.Models.NopAdmin.Affiliates;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using Shopfast.Plugin.Custom.Models.NopWeb.CustomWeb;
using Shopfast.Plugin.Custom.Models.NopWeb.Newsletter;
using Shopfast.Plugin.Custom.Models.NopWeb.Product;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class CustomWebController : BasePublicController
    {
        private readonly IDbContext _dbContext;
        private const string SETTINGS_PATTERN_KEY = "Nop.setting.";
        private readonly IStoreContext _storeContext;
        private readonly IThemeContext _themeContext;
        private readonly IWebHelper _webHelper;
        private readonly ICacheManager _cacheManager;
        private readonly IPictureService _pictureService;
        private readonly ICommonModelFactory _commonModelFactory;

        private readonly ISpecificationAttributeService _specificationAttributeService;
        private readonly IProductAttributeService _productAttributeService;
        private readonly IManufacturerService _manufacturerService;
        private readonly IProductService _productService;
        private readonly MediaSettings _mediaSettings;

        public CustomWebController(
            IDbContext dbContext,
            IStoreContext storeContext,
            IThemeContext themeContext,
            IWebHelper webHelper,
            ICacheManager cacheManager,
            IPictureService pictureService,
            ICommonModelFactory commonModelFactory,

            IProductService productService,
              ISpecificationAttributeService specificationAttributeService,
            IProductAttributeService productAttributeService,
            IManufacturerService manufacturerService,
            MediaSettings mediaSettings
            )
        {
            this._dbContext = dbContext;
            this._storeContext = storeContext;
            this._themeContext = themeContext;
            this._webHelper = webHelper;
            this._cacheManager = cacheManager;
            this._pictureService = pictureService;
            this._commonModelFactory = commonModelFactory;

            this._productService = productService;
            this._specificationAttributeService = specificationAttributeService;
            this._productAttributeService = productAttributeService;
            this._manufacturerService = manufacturerService;
            this._mediaSettings = mediaSettings;
        }
        // GET: CustomWeb
        public ActionResult CustomPolls()
        {
            return View();
        }

        [ChildActionOnly]
        public ActionResult CustomProductFullDescription(int productId)
        {
            var model =
               _dbContext.SqlQuery<ProductModelCustom>(
                   "select top 1 CustomFullDescription from Product where id=@p0", productId)
                   .FirstOrDefault() ?? new ProductModelCustom();
            return View(model);
        }

        [ChildActionOnly]
        public ActionResult GetProductVideoUrl(int productId)
        {
            var model =
                 _dbContext.SqlQuery<ProductModelCustom>(
                     "select top 1 VideoUrl from Product where id=@p0", productId)
                     .FirstOrDefault() ?? new ProductModelCustom();
            return Content(model.VideoUrl);
        }

        [HttpPost]
        public ActionResult SaveThemeSettings(ThemeSettings model)
        {
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            if (!string.IsNullOrEmpty(model.PresetColor))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".preset") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".preset").Value = model.PresetColor;
                }
            }

            if (!string.IsNullOrEmpty(model.HeaderLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".headerlayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".headerlayout").Value = model.HeaderLayout;
                }
            }

            if (!string.IsNullOrEmpty(model.MegaMenu))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".megamenuwithpictureslayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".megamenuwithpictureslayout").Value = model.MegaMenu;
                }
            }

            if (!string.IsNullOrEmpty(model.CategoriesHoverEffect))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".categorieshovereffect") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".categorieshovereffect").Value = model.CategoriesHoverEffect;
                }
            }

            if (!string.IsNullOrEmpty(model.ProductsPerRow))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".catalogpagesitemboxesperrow") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".catalogpagesitemboxesperrow").Value = model.ProductsPerRow;
                }
            }

            if (!string.IsNullOrEmpty(model.ProductPageLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".productpagelayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".productpagelayout").Value = model.ProductPageLayout;
                }
            }

            if (!string.IsNullOrEmpty(model.FooterLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".footerlayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".footerlayout").Value = model.FooterLayout;
                }
            }
            dbContext.SaveChanges();
            //EngineContext.Current.Resolve<ICacheManager>().RemoveByPattern(SETTINGS_PATTERN_KEY);
            EngineContext.Current.Resolve<ISettingService>().ClearCache();
            return Json(new { success = true });
        }

        [HttpPost]
        public ActionResult GetThemeSettings(string ThemeName)
        {
            ThemeSettings model = new ThemeSettings();
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".preset") != null)
            {
                model.PresetColor = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".preset").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".headerlayout") != null)
            {
                model.HeaderLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".headerlayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".megamenuwithpictureslayout") != null)
            {
                model.MegaMenu = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".megamenuwithpictureslayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".categorieshovereffect") != null)
            {
                model.CategoriesHoverEffect = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".categorieshovereffect").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".catalogpagesitemboxesperrow") != null)
            {
                model.ProductsPerRow = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".catalogpagesitemboxesperrow").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".productpagelayout") != null)
            {
                model.ProductPageLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".productpagelayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".footerlayout") != null)
            {
                model.FooterLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".footerlayout").Value;
            }

            return Json(new { model });
        }

        public ActionResult testAPI()
        {
            string responseData = "";
            Random r = new Random();
            int n = r.Next();
            string url = "http://192.168.0.40:8483/cgi.html?TerminalTransaction=<request><PaymentType>Credit</PaymentType><TransType>Sale</TransType><Amount>1.00</Amount><InvNum>687</InvNum><RefId>" + n.ToString() + "</RefId><AuthKey>234123-74653252-663525223</AuthKey><RegisterId>3</RegisterId></request>";
            url = "http://shopfast.com/HtmlPage1.html";

            //WebRequest request = WebRequest.Create(url); //Type url here
            //using (WebResponse response = request.GetResponse())
            //{
            //    using (StreamReader responseReader = new StreamReader(response.GetResponseStream()))
            //    {
            //        responseData = responseReader.ReadToEnd();

            //    }
            //}

            //HttpClient client = new HttpClient();
            //HttpResponseMessage response = client.GetAsync(url).Result;
            //HttpContent content = response.Content;
            //Task<string> result = content.ReadAsStringAsync();

            responseData = "<response> <RefId>777</RefId> <RegisterId>3</RegisterId> <InvNum>687</InvNum> <ResultCode>0</ResultCode> <RespMSG>APPROVED</RespMSG> <Message>Approved</Message> <AuthCode>198208</AuthCode> <PNRef>00000026</PNRef> <PaymentType>Credit</PaymentType> <HostSpecific>TID: 001,</HostSpecific> <ExtData>InvNum=687,CardType=MASTERCARD,BatchNum=189002,Tip=0.00,CashBack=0.00,Fee=0.00,AcntLast4=4111,Name=UL%20Demo%2fCard%2001%20%20%20%20%20%20%20%20%20%20%20,SVC=0.00,TotalAmt=0.63,DISC=0.00,Donation=0.00,SHFee=0.00,RwdPoints=0,RwdBalance=0,RwdIssued=,EBTFSLedgerBalance=,EBTFSAvailBalance=,EBTFSBeginBalance=,EBTCashLedgerBalance=,EBTCashAvailBalance=,EBTCashBeginBalance=,RewardCode=,AcqRefData=,ProcessData=,RefNo=,RewardQR=,Language=English,EntryType=CHIP,table_num=0,clerk_id=,ticket_num=</ExtData> <EMVData>AID=A0000000041010,AppName=MasterCardCredit,TVR=0800008000,TSI=E800</EMVData> <Sign>Qk2aAQAAAAAAAD4AAAAoAAAAYAAAAB0AAAABAAEAAAAAAFwBAADEDgAAxA4AAAAAAAAAAAAAAAAAAP///wD////z//////////////+D//////////////4P//////////////g//////////////+D//////////////4P//////////////g///////////////D//////////////8P//////////////wf//////////////h//////////////+H//////////////4P//////////////w///////////////j///////////////n///////////////H//////////////CP/////////////gCf////////////wAcf///////////4AP8///////////8AH////////////8AD////////////4AB///+f///////gAB////+P//////wAD//////B/////gAP///////gH///AAH////////8Bn/wAP//////////xn/wf/////////8=</Sign> <Token></Token> </response>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseData);

            return Content(responseData);
        }

        // This is used to render same website logo (CommonController -> Logo) for Native Mobile App.
        // For Native mobile app "/merchant/logo" URL is used strickly bases. 
        // So we have to decide to make a replica of "Logo" action of "Common" controller.
        public ActionResult Logo()
        {
            var cacheKey = string.Format(ModelCacheEventConsumer.STORE_LOGO_PATH, EngineContext.Current.Resolve<IStoreContext>().CurrentStore.Id, EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName, EngineContext.Current.Resolve<IWebHelper>().IsCurrentConnectionSecured());
            Picture logoPicture = new Picture();
            logoPicture = EngineContext.Current.Resolve<ICacheManager>().Get(cacheKey, () =>
            {
                var logoPictureId = EngineContext.Current.Resolve<StoreInformationSettings>().LogoPictureId;
                if (logoPictureId > 0)
                {
                    logoPicture = EngineContext.Current.Resolve<IPictureService>().GetPictureById(logoPictureId);
                }
                else
                {
                    //use default logo
                    string logo = string.Format(@"~/Themes/{0}/Content/images/logo.png", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName);
                    logoPicture = new Picture
                    {
                        PictureBinary = System.IO.File.ReadAllBytes(Server.MapPath(logo)),
                        MimeType = "image/png"
                    };
                }
                return logoPicture;
            });

            return File(logoPicture.PictureBinary, logoPicture.MimeType);
        }

        public ActionResult PostEmail()
        {
            var themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;
            return PartialView("~/Themes/" + themeName + "/Views/Shared/EmailLink.cshtml");
        }
        [HttpPost]
        public ActionResult PostEmail(NewsletterPopupModel model)
        {
            string result = string.Empty;
            bool success = false;
            var subscription = new NewsLetterSubscription
            {
                NewsLetterSubscriptionGuid = Guid.NewGuid(),
                Email = model.Email,
                Active = false,
                StoreId = EngineContext.Current.Resolve<IStoreContext>().CurrentStore.Id,
                CreatedOnUtc = DateTime.UtcNow
            };
            EngineContext.Current.Resolve<IWorkflowMessageService>().SendNewsLetterSubscriptionActivationMessage(subscription, EngineContext.Current.Resolve<IWorkContext>().WorkingLanguage.Id);
            result = EngineContext.Current.Resolve<ILocalizationService>().GetResource("NewsletterPopup.EmailSent");
            success = true;
            return Json(new
            {
                Success = success,
                Result = result,
            });
        }       

        #region Equipment and Setup Form
        [AcceptVerbs(HttpVerbs.Get)]
        public virtual ActionResult EquipmentManufacturer(int Count = 1)
        {
            EquipmentManufacturer model = new EquipmentManufacturer();
            // Bind Manufacturer drop down
            model.ManufacturerList = _manufacturerService.GetAllManufacturers().ToList();
            model.Count = Count;
            return PartialView("/Themes/Main/Views/Product/_EquipmentManufacturer.cshtml", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public virtual ActionResult EquipmentProduct(int manufacturerId = 0)
        {
            // Bind Model number drop down
            // ModelNumber -> spec attribute
            // PaymentType => PurchasePrice, RentalPrice, ReprogramPrice (checkboxes) -> product attributes            
            // then filter products by that spec. attribute id            
            string ModelNumberName = "ModelNumber";
            string PaymentTypeName = "PaymentType";
            string PurchasePriceName = "PurchasePrice";
            string RentalPriceName = "RentalPrice";
            string ReprogramPriceName = "ReprogramPrice";
            EquipmentManufacturer model = new EquipmentManufacturer();

            // get only ModelNumber specification attribute from  _specificationAttributeService.GetSpecificationAttributes().Where(...);
            var specAttribute = _specificationAttributeService.GetSpecificationAttributes().FirstOrDefault(s => s.Name == ModelNumberName);
            if (specAttribute != null)
            {
                var products = _productService.SearchProducts(manufacturerId: manufacturerId).Where(p => p.ProductSpecificationAttributes.Any(ps => ps.SpecificationAttributeOption.SpecificationAttributeId == specAttribute.Id
                && p.ProductAttributeMappings.Any(pa => pa.ProductAttribute.Name == PaymentTypeName)
                )).ToList();
                foreach (var pro in products)   
                {
                    var picture = _pictureService.GetPicturesByProductId(pro.Id).FirstOrDefault();
                    string ThumbImageUrl = _pictureService.GetPictureUrl(picture, _mediaSettings.ProductThumbPictureSizeOnProductDetailsPage);

                    var productAttribute = pro.ProductAttributeMappings.FirstOrDefault(pa => pa.ProductAttribute.Name == PaymentTypeName);
                    if (productAttribute != null && productAttribute.ProductAttributeValues.Any())
                    {
                        model.ProductList.Add(new ProductInformation()
                        {
                            ProductId = pro.Id,
                            Name = pro.Name,
                            ModelNumber = pro.ProductSpecificationAttributes.FirstOrDefault(ps => ps.SpecificationAttributeOption.SpecificationAttributeId == specAttribute.Id).CustomValue,
                            PurchasePrice = productAttribute.ProductAttributeValues.FirstOrDefault(pav => pav.Name == PurchasePriceName)?.PriceAdjustment,
                            RentalPrice = productAttribute.ProductAttributeValues.FirstOrDefault(pav => pav.Name == RentalPriceName)?.PriceAdjustment,
                            ReprogramPrice = productAttribute.ProductAttributeValues.FirstOrDefault(pav => pav.Name == ReprogramPriceName)?.PriceAdjustment,
                            ThumbImageUrl = (picture != null)?_pictureService.GetPictureUrl(picture, _mediaSettings.ProductThumbPictureSizeOnProductDetailsPage):""
                    });
                    }
                }
            }
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }

}