﻿using Nop.Admin.Controllers;
using Nop.Data;
using Shopfast.Plugin.Custom.Models.NopAdmin.Affiliates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class AffiliateCustomAdminController : BaseAdminController
    {
        private readonly IDbContext _dbContext;

        public AffiliateCustomAdminController(IDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [ChildActionOnly]
        public ActionResult LogoIdView(int affiliateId)
        {
            var model =
                _dbContext.SqlQuery<AffiliateModelCustom>(
                    "select top 1 LogoId from [Affiliate] where id=@p0", affiliateId)
                    .FirstOrDefault() ?? new AffiliateModelCustom();
            return View(model);
        }    
    }
}