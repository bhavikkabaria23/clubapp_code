﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class AffiliateFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(AffiliateController)) &&
                ( actionDescriptor.ActionName.Equals("Edit")  || actionDescriptor.ActionName.Equals("Create") )  && 
                 controllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                return new[]
                    {
                        new Filter(new AffiliateFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}