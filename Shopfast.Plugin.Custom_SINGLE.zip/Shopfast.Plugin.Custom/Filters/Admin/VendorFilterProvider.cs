﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class VendorFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(VendorController)) &&
                ( actionDescriptor.ActionName.ToLower().Equals("edit")  || actionDescriptor.ActionName.ToLower().Equals("create") )  && 
                 controllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                return new[]
                    {
                        new Filter(new VendorFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}