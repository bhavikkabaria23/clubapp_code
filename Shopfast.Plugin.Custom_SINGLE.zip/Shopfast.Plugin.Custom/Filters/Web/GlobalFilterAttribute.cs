﻿using MultiSite.Data;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Seo;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Web.Models.Topics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Domain.Customers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    /// <summary>
    /// This filter is used for all URLs / actions for store owner (except main store).
    /// It will not accessed any page without store registration
    /// </summary>
    public class GlobalFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // get sub domain name from url
            // get site owner from subdomain
            // then check "IsRegistered" true or false
            // if true then no action
            // if false then redirect to specific page.                        
            if (!MultisiteHelper.IsAdminSite)
            {
                var subdomain = MultisiteHelper.SubDomain;
                if (!string.IsNullOrEmpty(subdomain))
                {
                    using (var dbContext = new Sites4Entities())
                    {
                        var site = dbContext.Sites.FirstOrDefault(s => s.StoreName.ToLower() == subdomain.ToLower());
                        if(site != null)
                        {
                            if (HttpContext.Current.Request.Url.ToString().ToLower().Contains("admin") && EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.IsRegistered())
                            {
                                if (MultisiteHelper.GetStoreTrialDaysLeft(site.CreationDate) <= 0)
                                {
                                    filterContext.Result = new RedirectResult("/Admin/store-plan");
                                }
                            }
                            else
                            {
                                var owner = dbContext.Owners.FirstOrDefault(o => o.Id == site.Owner_Id);
                                if (owner != null)
                                {
                                    if (!owner.IsRegistered)
                                    {
                                        filterContext.Result = new RedirectResult("/store-registration/?accountid=" + site.Id);
                                    }
                                }
                            }
                        }
                    }
                }                
            }            
        }
    }
}