﻿using System.Linq;
using System.Web.Mvc;
using System.Collections.Generic;
using Nop.Core;
using Nop.Web.Controllers;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Models;
using Nop.Services.Media;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdpayInvestorController : BasePublicController
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IInvestorBankAccountService _investorBankAccountService;
        private readonly IDownloadService _downloadService;
        private readonly IInvestorDocumentService _investorDocumentService;

        #endregion

        #region Ctor

        public CrowdpayInvestorController(IWorkContext workContext, IInvestorBankAccountService investorBankAccountService,
                                          IDownloadService downloadService, IInvestorDocumentService investorDocumentService)
        {
            this._workContext = workContext;
            this._investorBankAccountService = investorBankAccountService;
            this._downloadService = downloadService;
            this._investorDocumentService = investorDocumentService;
        }

        #endregion

        #region Utils

        protected void PrepareBankAccountInfoModel(BankAccountInfoModel model)
        {
            var investorBankAccountDetail = _investorBankAccountService.GetInvestorBankAccountById(_workContext.CurrentCustomer.Id);
            if (investorBankAccountDetail != null)
            {
                model.BankAccountType = investorBankAccountDetail.BankAccountType;
                model.AccountType = investorBankAccountDetail.AccountType;
                model.NameOnAccount = investorBankAccountDetail.NameOnAccount;
                model.RoutingNumber = investorBankAccountDetail.RoutingNumber;
                model.AccountNumber = investorBankAccountDetail.AccountNumber;
                model.BankName = investorBankAccountDetail.BankName;
                model.BankSwiftCode = investorBankAccountDetail.BankSwiftCode;
                model.AccountName1 = investorBankAccountDetail.AccountName1;
                model.AccountNumber1 = investorBankAccountDetail.AccountNumber1;
                model.ContactName = investorBankAccountDetail.ContactName;
                model.ReferenceText = investorBankAccountDetail.ReferenceText;
                model.PhoneNumber = investorBankAccountDetail.PhoneNumber;
            }
            model.AvailabelBankAccountTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "Personal", Text = "Personal", Selected = (!string.IsNullOrEmpty(model.BankAccountType) ? model.BankAccountType.Split(',').Contains("Personal") : false)},
                new SelectListItem { Value = "Business" , Text = "Business", Selected = (!string.IsNullOrEmpty(model.BankAccountType) ? model.BankAccountType.Split(',').Contains("Business") : false)}
            };
            model.AccountTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "Saving", Text = "Saving", Selected = (!string.IsNullOrEmpty(model.AccountType) ? model.AccountType.Split(',').Contains("Saving") : false)},
                new SelectListItem { Value = "Currrent" , Text = "Currrent", Selected = (!string.IsNullOrEmpty(model.AccountType) ? model.AccountType.Split(',').Contains("Currrent") : false)}
            };
        }

        protected void PrepareInvestorDocumentDetailModel(InvestorDocumentModel model)
        {
            var investorDocument = _investorDocumentService.GetInvestorDocumentByCustomerId(_workContext.CurrentCustomer.Id);
            if (investorDocument != null)
            {
                var document = _downloadService.GetDownloadById(investorDocument.DocumentId);
                if (document != null)
                {
                    model.DocumentId = investorDocument.DocumentId;
                    model.DocumentTitle = investorDocument.DocumentTitle;
                }
            }
        }

        #endregion

        #region Methods

        public ActionResult BankAccount()
        {
            var model = new BankAccountInfoModel();
            PrepareBankAccountInfoModel(model);
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/BankAccount.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult BankAccount(BankAccountInfoModel model)
        {
            var investorBankAccountDetail = _investorBankAccountService.GetInvestorBankAccountById(_workContext.CurrentCustomer.Id);

            if (investorBankAccountDetail == null)
            {
                _investorBankAccountService.InsertInvestorBankAccount(new InvestorBankAccount
                {
                    CustomerId = _workContext.CurrentCustomer.Id,
                    BankAccountType = model.BankAccountType,
                    AccountType = model.AccountType,
                    NameOnAccount = model.NameOnAccount,
                    RoutingNumber = model.RoutingNumber,
                    AccountNumber = model.AccountNumber,
                    BankName = model.BankName,
                    BankSwiftCode = model.BankSwiftCode,
                    AccountName1 = model.AccountName1,
                    AccountNumber1 = model.AccountNumber1,
                    ReferenceText = model.ReferenceText,
                    ContactName = model.ContactName,
                    PhoneNumber = model.PhoneNumber
                });
            }
            else
            {
                investorBankAccountDetail.BankAccountType = model.BankAccountType;
                investorBankAccountDetail.AccountType = model.AccountType;
                investorBankAccountDetail.NameOnAccount = model.NameOnAccount;
                investorBankAccountDetail.RoutingNumber = model.RoutingNumber;
                investorBankAccountDetail.AccountNumber = model.AccountNumber;
                investorBankAccountDetail.BankName = model.BankName;
                investorBankAccountDetail.BankSwiftCode = model.BankSwiftCode;
                investorBankAccountDetail.AccountName1 = model.AccountName1;
                investorBankAccountDetail.AccountNumber1 = model.AccountNumber1;
                investorBankAccountDetail.ReferenceText = model.ReferenceText;
                investorBankAccountDetail.ContactName = model.ContactName;
                investorBankAccountDetail.PhoneNumber = model.PhoneNumber;

                _investorBankAccountService.UpdateInvestorBankAccount(investorBankAccountDetail);
            }

            return BankAccount();
        }

        public ActionResult InvestorDocument()
        {
            var model = new InvestorDocumentModel();
            PrepareInvestorDocumentDetailModel(model);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/InvestorDocument.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult InvestorDocument(InvestorDocumentModel model)
        {
            var investorDocument = _investorDocumentService.GetInvestorDocumentByCustomerId(_workContext.CurrentCustomer.Id);
            if (investorDocument == null)
            {
                _investorDocumentService.InsertInvestorDocument(new InvestorDocument
                {
                    CustomerId = _workContext.CurrentCustomer.Id,
                    DocumentId = model.DocumentId,
                    DocumentTitle = model.DocumentTitle
                });
            }
            else
            {
                investorDocument.DocumentId = model.DocumentId;
                investorDocument.DocumentTitle = model.DocumentTitle;

                _investorDocumentService.UpdateInvestorDocument(investorDocument);
            }

            return InvestorDocument();
        }

        #endregion
    }
}
