﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Shipping;
using Nop.Services.Tax;
using Nop.Web.Controllers;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Models.ShoppingCart;
using Nop.Web.Factories;
using Nop.Services.Shipping.Date;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdPayShoppingCartController : ShoppingCartController
    {
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly IProductService _productService;
        private readonly IShoppingCartModelFactory _shoppingCartModelFactory;
        private readonly IDateRangeService _dateRangeService;

        public CrowdPayShoppingCartController(IShoppingCartModelFactory shoppingCartModelFactory,
            IDateRangeService dateRangeService,
            IProductService productService, 
            IStoreContext storeContext,
            IWorkContext workContext,
            IShoppingCartService shoppingCartService, 
            IPictureService pictureService,
            ILocalizationService localizationService, 
            IProductAttributeService productAttributeService, 
            IProductAttributeFormatter productAttributeFormatter,
            IProductAttributeParser productAttributeParser,
            ITaxService taxService, ICurrencyService currencyService, 
            IPriceCalculationService priceCalculationService,
            IPriceFormatter priceFormatter,
            ICheckoutAttributeParser checkoutAttributeParser,
            ICheckoutAttributeFormatter checkoutAttributeFormatter, 
            IOrderProcessingService orderProcessingService,
            IDiscountService discountService,
            ICustomerService customerService, 
            IGiftCardService giftCardService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IShippingService shippingService, 
            IOrderTotalCalculationService orderTotalCalculationService,
            ICheckoutAttributeService checkoutAttributeService, 
            IPaymentService paymentService,
            IWorkflowMessageService workflowMessageService,
            IPermissionService permissionService, 
            IDownloadService downloadService,
            ICacheManager cacheManager,
            IWebHelper webHelper, 
            ICustomerActivityService customerActivityService,
            IGenericAttributeService genericAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            HttpContextBase httpContext,
            MediaSettings mediaSettings,
            ShoppingCartSettings shoppingCartSettings,
            CatalogSettings catalogSettings, 
            OrderSettings orderSettings,
            ShippingSettings shippingSettings, 
            TaxSettings taxSettings,
            CaptchaSettings captchaSettings, 
            AddressSettings addressSettings,
            RewardPointsSettings rewardPointsSettings,
            CustomerSettings customerSettings) : base(shoppingCartModelFactory, productService, storeContext, workContext, shoppingCartService,
                             pictureService, localizationService, productAttributeService, productAttributeParser, taxService, currencyService,
                             priceCalculationService, priceFormatter, checkoutAttributeParser, discountService, customerService, giftCardService,
                             dateRangeService, checkoutAttributeService, workflowMessageService, permissionService, downloadService, cacheManager,
                             webHelper, customerActivityService, genericAttributeService, mediaSettings, shoppingCartSettings, orderSettings,
                             captchaSettings, customerSettings)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _productService = productService;
            _shoppingCartModelFactory = shoppingCartModelFactory;
            _dateRangeService = dateRangeService;
        }

        [ChildActionOnly]
        public ActionResult CrowdPayOrderSummary(bool? prepareAndDisplayOrderReviewData, int productId, int quantity)
        {
            var cart = new List<ShoppingCartItem>();

            Product product = _productService.GetProductById(productId);

            cart.Add(new ShoppingCartItem()
            {
                CreatedOnUtc = DateTime.UtcNow,
                Customer = _workContext.CurrentCustomer,
                CustomerId = _workContext.CurrentCustomer.Id,
                Product = product,
                ProductId = product.Id,
                Quantity = quantity,
                AttributesXml = string.Empty,
                StoreId = _storeContext.CurrentStore.Id,
                ShoppingCartType = ShoppingCartType.ShoppingCart
            });

            var model = new ShoppingCartModel();
            _shoppingCartModelFactory.PrepareShoppingCartModel(model, cart,
                isEditable: false,
                prepareEstimateShippingIfEnabled: false,
                prepareAndDisplayOrderReviewData: prepareAndDisplayOrderReviewData.GetValueOrDefault());
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/ShoppingCart/_OrderSummary.cshtml", model);
        }

        [ChildActionOnly]
        public ActionResult CrowdPayOrderTotals(bool isEditable, int productId, int quantity)
        {
            var cart = new List<ShoppingCartItem>();

            Product product = _productService.GetProductById(productId);

            cart.Add(new ShoppingCartItem()
            {
                CreatedOnUtc = DateTime.UtcNow,
                Customer = _workContext.CurrentCustomer,
                CustomerId = _workContext.CurrentCustomer.Id,
                Product = product,
                ProductId = product.Id,
                Quantity = quantity,
                AttributesXml = string.Empty,
                StoreId = _storeContext.CurrentStore.Id,
                ShoppingCartType = ShoppingCartType.ShoppingCart
            });
            var model = _shoppingCartModelFactory.PrepareOrderTotalsModel(cart, isEditable);
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/ShoppingCart/_OrderTotals.cshtml", model);
        }
    }
}
