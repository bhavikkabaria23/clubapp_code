using System.Web.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Nop.Web.Framework;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class BankAccountInfoModel
    {
        public BankAccountInfoModel()
        {
            AvailabelBankAccountTypes = new List<SelectListItem>();
            AccountTypes = new List<SelectListItem>();
        }

        #region BankInfo

        public string BankName { get; set; }

        public string BankSwiftCode { get; set; }

        #endregion

        #region AccountInfo

        public string NameOnAccount { get; set; }

        public string AccountNumber { get; set; }

        public string AccountType { get; set; }
        public IList<SelectListItem> AccountTypes { get; set; }

        public string BankAccountType { get; set; }
        public IList<SelectListItem> AvailabelBankAccountTypes { get; set; }

        public string RoutingNumber { get; set; }

        #endregion

        #region AddtionalInfo

        public string AccountName1 { get; set; }

        public string AccountNumber1 { get; set; }

        public string ReferenceText { get; set; }

        public string ContactName { get; set; }

        public string PhoneNumber { get; set; }

        #endregion

    }

    public  class InvestorDocumentModel
    {
        [NopResourceDisplayName("Shopfast.Fields.DocumentId")]
        [UIHint("UploadFile")]
        public int DocumentId { get; set; }

        [NopResourceDisplayName("Shopfast.Fields.DocumentTitle")]
        public string DocumentTitle { get; set; }
    }
}
