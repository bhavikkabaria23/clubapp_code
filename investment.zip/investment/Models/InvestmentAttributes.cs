﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class InvestmentAttributes
    {
        // today code
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowTotalInvestment")]
        public bool ShowTotalInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMaxInvestment")]
        public bool ShowMaxInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMinInvestment")]
        public bool ShowMinInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowPrice")]
        public bool ShowPrice { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowDaysLeft")]
        public bool ShowDaysLeft { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowInvestors")]
        public bool ShowInvestors { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowRaised")]
        public bool ShowRaised { get; set; }
    }
}
