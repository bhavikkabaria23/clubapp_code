﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class VerificationTemplateModel
    {
        public int VerificationTemplateId { get; set; }
        public int customerId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.TokenListIndividual")]
        public string TokenListIndividual { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.TokenListCompany")]
        public string TokenListCompany { get; set; }
        public string HTMLTemplateCurrent { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.HTMLTemplateIndividual")]
        [AllowHtml]
        public string HTMLTemplateIndividual { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.HTMLTemplateCompany")]
        [AllowHtml]
        public string HTMLTemplateCompany { get; set; }

        [NopResourceDisplayName("Admin.Catalog.Products.Fields.PDFIndividualUploadId")]
        [UIHint("Download")]
        public int PDFIndividualUploadId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.PDFCompanyUploadId")]
        [UIHint("Download")]
        public int PDFCompanyUploadId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.IsDocusign")]
        public bool IsDocusign { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignUserName")]
        public string DocusignUsername { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignPassword")]
        public string DocusignPassword { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignIntegratorKey")]
        public string DocuSignIntegratorKey { get; set; }

        [NopResourceDisplayName("BD.Network1Security.IsNetwork1Security")]
        public bool? IsNetwork1Security { get; set; }
        [NopResourceDisplayName("BD.Network1Security.AccountNumber")]
        public string AccountNumber { get; set; }
        [NopResourceDisplayName("BD.Network1Security.AssociatedBroker")]
        public string AssociatedBroker { get; set; }

    }
}
