﻿namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class SigningCeremonyModel
    {
        public string DocumentUrl { get; set; }

        public bool ShowContinue { get; set; }

        public bool ShowBack { get; set; }
    }
}