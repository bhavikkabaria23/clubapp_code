﻿using System.Collections.Generic;
using System.Web.Mvc;
using FluentValidation.Attributes;
using Nop.Web.Framework;
using ShopFast.Plugin.BD.CrowdPay.Validation;
using System.ComponentModel.DataAnnotations;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    [Validator(typeof(InfoGatheringValidation))]
    public class InformationGatheringModel
    {
        public InformationGatheringModel()
        {
            UploadedDocumentList = new List<UploadDocument>();
            UploadDocumentList = new List<UploadDocument>();
        }
        public bool AccreditedInvestor { get; set; }

        public IList<SelectListItem> AccreditedInvestorQualifyList { get; set; }

        public string SelectedQualify { get; set; }

        [NopResourceDisplayName("shopfast.crowdpay.fields.AnnualIncome")]
        public decimal AnnualIncome { get; set; }

        [NopResourceDisplayName("shopfast.crowdpay.fields.NetWorth")]
        public decimal NetWorth { get; set; }

        public IList<SelectListItem> BackupWithholdingList { get; set; }

        public string SelectedBackupWithholding { get; set; }

        public string CurrencySymbol { get; set; }

        public string CurrencyName { get; set; }

        public string InvestorType { get; set; }

        public List<UploadDocument> UploadedDocumentList { get; set; }
        public List<UploadDocument> UploadDocumentList { get; set; }
        
        //[UIHint("UploadFile")]
        //public int DocumentUploadId1 { get; set; }
        //public string description1 { get; set; }
        //[UIHint("UploadFile")]
        //public int DocumentUploadId2 { get; set; }
        //public string description2 { get; set; }
        //[UIHint("UploadFile")]
        //public int DocumentUploadId3 { get; set; }
        //public string description3 { get; set; }
        //[UIHint("UploadFile")]
        //public int DocumentUploadId4 { get; set; }
        //public string description4 { get; set; }
        //[UIHint("UploadFile")]
        //public int DocumentUploadId5 { get; set; }
        //public string description5 { get; set; }
    }

    public class UploadDocument
    {
        public int DocumentId { get; set; }
        [UIHint("UploadFile")]
        public int DocumentUploadId { get; set; }
        public string description { get; set; }
        public string DocumentUrl { get; set; }
        public string Filename { get; set; }
        public bool ReadOnlyDocument { get; set; }
        public string InvestorComment { get; set; }

    }
}
