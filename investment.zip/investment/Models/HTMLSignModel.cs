﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class HTMLSignModel
    {
        public HTMLSignModel()
        {
            hdnSignJSONsmallSign = new List<string>();
            hdnSignJSONbigSign = new List<string>();
            signIamgeSmall = new List<byte[]>();
            signIamgeBig = new List<byte[]>();
        }
        public string hdnSign1JSON { get; set; }
        public string hdnSign2JSON { get; set; }
        public string hdnSign3JSON { get; set; }
        public string hdnSign4JSON { get; set; }
        public string hdnSign5JSON { get; set; }
        public string hdnSign6JSON { get; set; }
        public string hdnSign7JSON { get; set; }
        public List<string> hdnSignJSONsmallSign { get; set; }
        public List<string> hdnSignJSONbigSign { get; set; }
        public List<byte[]> signIamgeSmall { get; set; }
        public List<byte[]> signIamgeBig { get; set; }

        //public string sign1Base64 { get; set; }
        //public string sign2Base64 { get; set; }
        //public string sign3Base64 { get; set; }
        //public string sign4Base64 { get; set; }
        //public string sign5Base64 { get; set; }
        //public string sign6Base64 { get; set; }
        //public string sign7Base64 { get; set; }

        public byte[] sign1Iamge { get; set; }
        public byte[] sign2Iamge { get; set; }
        public byte[] sign3Iamge { get; set; }
        public byte[] sign4Iamge { get; set; }
        public byte[] sign5Iamge { get; set; }
        public byte[] sign6Iamge { get; set; }
        public byte[] sign7Iamge { get; set; }


        public string IssueDateMonth { get; set; }
        public string IssueDateDay { get; set; }
        public string IssueDateYear { get; set; }
        public string SubscriptionAmount { get; set; }
        public string NumberOfShares { get; set; }
        public string Name { get; set; }
        public string TaxIDNumber { get; set; }
        public string StreetAddress { get; set; }
        public string CityStateZipCode { get; set; }
        public string Country { get; set; }
        public string TelephoneNumber { get; set; }        
        public string Dated { get; set; }
        public string By { get; set; }
        public string Title { get; set; }
        public string Email { get; set; }
        public string ShortDate { get; set; }
        public string LongDate { get; set; }
        public string DateAndTime { get; set; }
        public string LogoPath { get; set; }

        public string DateAndIPAddress { get; set; }
        //New Tokens
        public string PerShare { get; set; }

        public string SignatureText { get; set; }
        public string SignatureName { get; set; }

        public string AgreementType { get; set; }
        //Joint account details
        public string JointName { get; set; }

        public string JointTaxIdNumber { get; set; }
        public string JointStreetAddress { get; set; }

        public string JointCityStateZipcode { get; set; }

        public string JointTelephoneNumber { get; set; }

        public string JointEmail { get; set; }
    }

    public class Signature : I2DLineGraphic
    {      
        public List<List<List<double>>> lines { get; set; }
    }

    interface I2DLineGraphic
    {
        List<List<List<double>>> lines { get; set; }
    }
}
