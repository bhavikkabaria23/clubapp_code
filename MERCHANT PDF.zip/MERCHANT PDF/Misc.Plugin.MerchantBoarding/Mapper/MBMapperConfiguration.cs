﻿using System;
using AutoMapper;
using Misc.Plugin.MerchantBoarding.Domain;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Core.Infrastructure.Mapper;

namespace Misc.Plugin.MerchantBoarding.Mapper
{
    /// <summary>
    /// AutoMapper configuration for admin area models
    /// </summary>
    public class MBMapperConfiguration : IMapperConfiguration
    {
        /// <summary>
        /// Get configuration
        /// </summary>
        /// <returns>Mapper configuration action</returns>
        public Action<IMapperConfigurationExpression> GetConfiguration()
        {
            //TODO remove 'CreatedOnUtc' ignore mappings because now presentation layer models have 'CreatedOn' property and core entities have 'CreatedOnUtc' property (distinct names)

            Action<IMapperConfigurationExpression> action = cfg =>
            {
                //address
                cfg.CreateMap<MerchantInformationModel, MB_MerchantInformation>();                    
            };
            return action;
        }

        /// <summary>
        /// Order of this mapper implementation
        /// </summary>
        public int Order
        {
            get { return 0; }
        }
    }
}