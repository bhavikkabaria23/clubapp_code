﻿using Misc.Plugin.MerchantBoarding.Models;

namespace Misc.Plugin.MerchantBoarding.Services
{
    public interface IMerchantBoardingService
    {
        void AddUpdateEntity(MerchantInformationModel model);
    }
}