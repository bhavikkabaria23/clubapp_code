﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using iTextSharp.text.pdf;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Seo;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Web.Controllers;
using Nop.Web.Extensions;
using Nop.Web.Factories;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System.Net;
using Nop.Services.Helpers;
using Nop.Core.Domain.Media;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdPayCheckOutController : CheckoutController
    {
        #region Properties
        private readonly ICheckoutModelFactory _checkoutModelFactory;
        private readonly IDocusignService _docusignService;
        private readonly ICustomCustomerAttributeService _crowdPayCustomerAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ILocalizationService _localizationService;
        private readonly IWorkContext _workContext;
        private readonly CustomerSettings _customerSettings;
        private readonly Customer _currentCustomer;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;
        private readonly AddressSettings _addressSettings;
        private readonly ICustomAddressAttributeParser _customAddressAttributeParser;
        private readonly ICustomCustomerAttributeParser _customCustomerAttributeParser;
        private readonly ICurrencyService _currencyService;
        private readonly IPaymentService _paymentService;
        private readonly IStoreContext _storeContext;
        private readonly ITaxService _taxService;
        private readonly IWebHelper _webHelper;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IProductService _productService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly PaymentSettings _paymentSettings;
        private readonly IPluginFinder _pluginFinder;
        private readonly HttpContextBase _httpContext;
        private readonly ICustomOrderProccessingService _customOrderProccessingService;
        private readonly ISettingService _settingsService;
        private readonly ILogger _logger;
        private readonly ShippingSettings _shippingSettings;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IShippingService _shippingService;
        private readonly OrderSettings _orderSettings;
        private readonly IOrderService _orderService;
        private readonly IBlockScoreService _blockScoreService;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly IVerifyInvestorService _verifyInvestorService;
        private readonly IBDAddressService _bDAddressService;
        private readonly IPermissionService _permissionService;
		private readonly IDownloadService _downloadService;

        //private const int productId = 57;
        #endregion

        #region Ctors
        public CrowdPayCheckOutController(ICheckoutModelFactory checkoutModelFactory,
            IWorkContext workContext,
            IStoreContext storeContext,
            IStoreMappingService storeMappingService,
            IShoppingCartService shoppingCartService,
            ILocalizationService localizationService,
            ITaxService taxService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IOrderProcessingService orderProcessingService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IShippingService shippingService,
            IPaymentService paymentService,
            IPluginFinder pluginFinder,
            IOrderTotalCalculationService orderTotalCalculationService,
            IRewardPointService rewardPointService,
            ILogger logger,
            IOrderService orderService,
            IWebHelper webHelper,
            HttpContextBase httpContext,
            IAddressAttributeParser addressAttributeParser,
            IAddressAttributeService addressAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            OrderSettings orderSettings,
            RewardPointsSettings rewardPointsSettings,
            PaymentSettings paymentSettings,
            ShippingSettings shippingSettings,
            AddressSettings addressSettings,
            CustomerSettings customerSettings, IDocusignService docusignService, ICustomCustomerAttributeService crowdPayCustomerAttributeService, ICustomAddressAttributeParser customAddressAttributeParser,
            ICustomCustomerAttributeParser customCustomerAttributeParser, IAddressService addressService, IProductService productService,
            IPriceCalculationService priceCalculationService, ICustomOrderProccessingService customOrderProccessingService, ISettingService settingsService,
            IBlockScoreService blockScoreService, ICustomGenericAttributeService customGenericAttributeService, IVerifyInvestorService verifyInvestorService,
            IBDAddressService bDAddressService,
            IPermissionService permissionService,
            IDownloadService downloadService)
            : base(checkoutModelFactory, workContext, storeContext, shoppingCartService, localizationService, orderProcessingService,
                  customerService, genericAttributeService, countryService, stateProvinceService, shippingService, paymentService, pluginFinder,
                  orderTotalCalculationService, logger, orderService, webHelper, httpContext, addressAttributeParser, addressAttributeService,
                  orderSettings, rewardPointsSettings, paymentSettings, shippingSettings, addressSettings, customerSettings)
        {

            _workContext = workContext;
            _checkoutModelFactory = checkoutModelFactory;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _taxService = taxService;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _paymentService = paymentService;
            _pluginFinder = pluginFinder;
            _logger = logger;
            _webHelper = webHelper;
            _httpContext = httpContext;
            _addressAttributeParser = addressAttributeParser;
            _addressAttributeService = addressAttributeService;
            _paymentSettings = paymentSettings;
            _shippingSettings = shippingSettings;
            _addressSettings = addressSettings;
            _docusignService = docusignService;
            _crowdPayCustomerAttributeService = crowdPayCustomerAttributeService;
            _customerSettings = customerSettings;
            _currentCustomer = _workContext.CurrentCustomer;
            _customAddressAttributeParser = customAddressAttributeParser;
            _customCustomerAttributeParser = customCustomerAttributeParser;
            _addressService = addressService;
            _productService = productService;
            _priceCalculationService = priceCalculationService;
            _customOrderProccessingService = customOrderProccessingService;
            _settingsService = settingsService;
            _shippingService = shippingService;
            _blockScoreService = blockScoreService;
            _customGenericAttributeService = customGenericAttributeService;
            _verifyInvestorService = verifyInvestorService;
            _orderService = orderService;
            _orderSettings = orderSettings;
            _bDAddressService = bDAddressService;
            _permissionService = permissionService;
            this._downloadService = downloadService;
        }

        #endregion

        [AdminAuthorize]
        public ActionResult Configure()
        {
            var settingsEntity = _settingsService.LoadSetting<CrowdPaySettings>();

            var configurationModel = new ConfigurationModel()
            {
                DocuSignUserName = settingsEntity.DocuSignUserName,
                DocuSignPassword = settingsEntity.DocuSignPassword,
                DocuSignIntegratorKey = settingsEntity.IntegratorKey,
                BlockScoreKey = settingsEntity.BlockScoreKey,
                VerifyInvestorValidationEnabled = settingsEntity.VerifyInvestorValidationEnabled,
                SelfAccredited = settingsEntity.SelfAccredited,
                InternalAccreditation = settingsEntity.InternalAccreditation,
                VerifyInvestorApiKey = settingsEntity.VerifyInvestorApiKey,
                VerifyInvestorUserKey = settingsEntity.VerifyInvestorUserKey,
                VerifyInvestorModeId = Convert.ToInt32(settingsEntity.VerifyInvestorMode),
                VerifyInvestorModeValues = settingsEntity.VerifyInvestorMode.ToSelectList(),
                OfferingType = settingsEntity.OfferingType,
                SingleOfferProductId = settingsEntity.SingleOfferProductId,

                Net1CrmApiUrl = settingsEntity.Net1CrmApiUrl,
                Net1CrmUsername = settingsEntity.Net1CrmUsername,
                Net1AccessKey = settingsEntity.Net1AccessKey,
                Net1AssignedUserId = settingsEntity.Net1AssignedUserId
            };
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Configure.cshtml", configurationModel);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult Configure(ConfigurationModel model)
        {
            var settingsEntity = _settingsService.LoadSetting<CrowdPaySettings>();
            settingsEntity.DocuSignUserName = model.DocuSignUserName;
            settingsEntity.DocuSignPassword = model.DocuSignPassword;
            settingsEntity.IntegratorKey = model.DocuSignIntegratorKey;
            settingsEntity.BlockScoreKey = model.BlockScoreKey;
            settingsEntity.VerifyInvestorValidationEnabled = model.VerifyInvestorValidationEnabled;
            settingsEntity.SelfAccredited = model.SelfAccredited;
            settingsEntity.InternalAccreditation = model.InternalAccreditation;
            settingsEntity.VerifyInvestorApiKey = model.VerifyInvestorApiKey;
            settingsEntity.VerifyInvestorUserKey = model.VerifyInvestorUserKey;
            settingsEntity.VerifyInvestorMode = (VerifyInvestorMode)model.VerifyInvestorModeId;
            settingsEntity.OfferingType = model.OfferingType;
            settingsEntity.SingleOfferProductId = model.SingleOfferProductId;

            settingsEntity.Net1CrmApiUrl = model.Net1CrmApiUrl;
            settingsEntity.Net1CrmUsername = model.Net1CrmUsername;
            settingsEntity.Net1AccessKey = model.Net1AccessKey;
            settingsEntity.Net1AssignedUserId = model.Net1AssignedUserId;

            _settingsService.SaveSetting(settingsEntity);
            _settingsService.ClearCache();
            return Configure();
        }

        // This not in use
        [Authorize]
        public ActionResult PublicInfo(int? productId, bool? goToInformationGatheringSection, int? vi_user_id)
        {
            //resetting checkout state 
            _customGenericAttributeService.DeleteAttriutes(ClientConstants.TempCheckOutGenericAttirubutes.ProductId,
                ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity);

            var model = new PublicInfoModel();

            if (productId.HasValue && productId != 0)
            {
                var product = _productService.GetProductById(productId.Value);
                if (product != null)
                {
                    model.InvestorInformationExists = false;

                    model.SubscriptionAgreementExists = product.ProductSpecificationAttributes.Any(
                    x =>
                        x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                        ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId);

                    var tempProductIdAttribute = new GenericAttribute()
                    {
                        KeyGroup = ClientConstants.GerenicAttributeKeyGroup.CustomerGroup,
                        EntityId = _currentCustomer.Id,
                        Key = ClientConstants.TempCheckOutGenericAttirubutes.ProductId,
                        Value = productId.ToString()
                    };

                    _genericAttributeService.InsertAttribute(tempProductIdAttribute);

                    model.ShippingRequired = product.IsShipEnabled;

                    if (goToInformationGatheringSection.HasValue && CanSkipInvestorInformationStep(product) && CanSkipPersonalInformationStep() && CanSkipVerifyInvestorStep() &&
                        CanSkipInvestorTypeStep())
                    {
                        model.GoToInformationGatheringSection = goToInformationGatheringSection.Value;
                    }
                    if (vi_user_id.HasValue)
                    {
                        var verifyStatus = _verifyInvestorService.GetUserVerificationStatus(vi_user_id.Value);
                        if (verifyStatus != null)
                        {
                            string redirectUrl;

                            switch (verifyStatus.verification_status)
                            {
                                case ClientConstants.VerifyInvestor.InvestorValidationStatus.PendingVerification:
                                    return RedirectToAction("PublicInfo", "CrowdPayCheckOut", new { productId = productId.Value, goToInformationGatheringSection = true });
                                    break;
                                case ClientConstants.VerifyInvestor.InvestorValidationStatus.Unverified:
                                    return RedirectToAction("PublicInfo", "CrowdPayCheckOut", new { productId = productId.Value, goToInformationGatheringSection = true });
                                    break;
                                default:
                                    return RedirectToAction("PublicInfo", "CrowdPayCheckOut", new { productId = productId.Value, goToInformationGatheringSection = true });
                            }

                            if (!String.IsNullOrEmpty(redirectUrl))
                            {
                                return Redirect(redirectUrl);
                            }

                            return RedirectToAction("Index", "Home");
                        }

                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Accreditation.cshtml", model);
        }

        /// <summary>
        /// This is same as "PublicInfo". "PublicInfo" was used for OLD approach of all steps together from "Investor Type" to "Finish"
        /// "Accreditation" is used in my account page
        /// </summary>        
        /// <param name="goToInformationGatheringSection"></param>
        /// <param name="vi_user_id"></param>
        /// <returns></returns>
        [Authorize]
        //public ActionResult Accreditation(bool? goToInformationGatheringSection, int? vi_user_id, int? productId = productId)
        public ActionResult Accreditation(bool? goToInformationGatheringSection, int? vi_user_id)
        {
            if (TempData["goToAccreditation"] == null)
                Session["productId"] = null;

            var model = new PublicInfoModel();
            model.InvestorInformationExists = false;
            model.Network1SecurityExists = CanAllowNetwork1Security();

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Accreditation.cshtml", model);
        }

        // This is not in use
        public ActionResult SingingCeremony(string signingAttributeName)
        {
            var signingCeremonyModel = PrepareSigningModel(signingAttributeName);
            if (!String.IsNullOrEmpty(signingCeremonyModel.DocumentUrl))
            {
                return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_SigningCeremony.cshtml", signingCeremonyModel);
            }

            return null;
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInvestorInformation()
        {
            return LoadPersonalTab();
        }

        

        #region Network 1

        public ActionResult Network1Security()
        {
            var model = new Network1SecurityModel();
            var investor = _bDAddressService.GetVerificationTemplateByCustomer(_currentCustomer.Id);
            if (investor != null)
            {
                model.Network1SecurityId = investor.Id;
                model.IsNetwork1Security = investor.IsNetwork1Security;
                model.AccountNumber = investor.AccountNumber;
                model.AssociatedBroker = investor.AssociatedBroker;
            }

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Network1Security.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveNetwork1Security(Network1SecurityModel model)
        {
            TryValidateModel(model);
            if (!ModelState.IsValid)
            {
                var resultHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Network1Security.cshtml", model);
                return Json(new { section_name = "network1-security", html = resultHtml });
            }

            var investor = new BD_VerificationTemplate();
            if (model.Network1SecurityId > 0)
                investor = _bDAddressService.GetVerificationTemplateById(model.Network1SecurityId);
            investor.customerId = _currentCustomer.Id;
            investor.IsNetwork1Security = model.IsNetwork1Security;
            investor.AccountNumber = model.AccountNumber;
            investor.AssociatedBroker = model.AssociatedBroker;

            if (model.Network1SecurityId > 0)
                _bDAddressService.UpdateVerificationTemplate(investor);
            else
                _bDAddressService.InsertVerificationTemplate(investor);

            return LoadPersonalTab();
        }

        #endregion

        #region Personal information

        [NonAction]
        private void PreparePersonalInformationModel(PersonalInformationModel model)
        {
            var personalInfoTypesAttribute = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(ClientConstants.CustomAttributes.PersonalInfoType);
            model.PersonalInfoType = GetSelectListItemsModel(personalInfoTypesAttribute);
        }

        [NonAction]
        private JsonResult LoadPersonalTab()
        {
            var model = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml, ClientConstants.CustomAttributes.PersonalInfoType);

            model.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;
            PreparePersonalInformationModel(model);

            var stepHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml", model);
            var firstSelectedTypeContent = (JsonResult)InvestorInfoTypeChange(model.SelectedPersonalInfoType, true);
            return Json(new
            {
                section_name = "personal-information",
                html = stepHtml,
                selectedOptionContent = firstSelectedTypeContent,
                selectedOptionArea = "personal-type-content"
            });
        }

        //called when investor information is not required     
        public ActionResult PesonalInformation()
        {
            var resultModel = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml, ClientConstants.CustomAttributes.PersonalInfoType);

            resultModel.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;
            PreparePersonalInformationModel(resultModel);

            resultModel.InvestorInfoNotRequired = true;
            resultModel.PersonalInfoContent = (string)InvestorInfoTypeChange(resultModel.SelectedPersonalInfoType, false);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml", resultModel);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePersonalInformation()
        {
            var model = new PersonalInformationModel();
            TryUpdateModel(model, ClientConstants.FormPrefix.IndividualPrefix);

            switch (model.SelectedPersonalInfoType)
            {
                case ClientConstants.PersonalInfoType.Individual:
                    {
                        TryValidateModel(model.IniIndividualsModel);
                        if (ModelState.IsValid)
                        {
                            TempData["IniIndividualsModel"] = model.IniIndividualsModel;
                            SaveIndividualInfo(model.IniIndividualsModel, model.SelectedPersonalInfoType);
                            _blockScoreService.VerifyCustomer(model.IniIndividualsModel);
                        }
                    }
                    break;
                case ClientConstants.PersonalInfoType.Company:
                case ClientConstants.PersonalInfoType.SelfDirectedIRA:
                case ClientConstants.PersonalInfoType.Trust:
                    {
                        TryValidateModel(model.OtherInfoModel);
                        if (ModelState.IsValid)
                        {
                            if (model.OtherInfoModel.IsBasicSaving)
                            {
                                //model.IniIndividualsModel.SSN = "123456789";
                                _blockScoreService.VerifyCompany(model);
                            }
                            SaveOtherInfo(model.OtherInfoModel);
                        }
                        break;
                    }
            }

            Session["PersonalInformationModel"] = model;
            if (!ModelState.IsValid)
            {
                PreparePersonalInformationModel(model);
                model.IniIndividualsModel.invalidForm = true;
                model.OtherInfoModel.invalidForm = true;

                var stepHtml = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml", model);
                var firstSelectedTypeContent = (JsonResult)InvestorInfoTypeChange(model.SelectedPersonalInfoType, true, model);
                return Json(new
                {
                    section_name = "personal-information",
                    html = stepHtml,
                    selectedOptionContent = firstSelectedTypeContent,
                    selectedOptionArea = "personal-type-content",
                    invalidForm = true
                });
            }

            if(CanAllowNetwork1Security())
            {
                if (model.IniIndividualsModel.IsBasicSaving)
                    return Json(new { });
                else
                    return Json(new { redirect = Url.RouteUrl("Plugin.CrowdPay.Investment") });
            }
            
            //investor verify api redirect...
            #region verify API or Self Accredited or Internal Accreditation
            string SelectedInvestorType = ClientConstants.InvestorType.NonAccreditted;
            if (TempData["SelectedInvestorType"] != null)
            {
                SelectedInvestorType = Convert.ToString(TempData["SelectedInvestorType"]);
                TempData.Keep("SelectedInvestorType");
            }
            else
            {
                var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                SelectedInvestorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.InvestorType);
            }
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (SelectedInvestorType == ClientConstants.InvestorType.Accreddited)
            {

                if (settings.VerifyInvestorValidationEnabled)
                {
                    var existingIdentifyIds =
                   _customGenericAttributeService.GetAttributesByName(
                       ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorApiIdentityId).Select(x => x.Value).ToList();

                    //???
                    int lastIdInt = 2;

                    if (existingIdentifyIds.Any())
                    {
                        var existingIdForCurrentCustomer =
                            _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                                ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorApiIdentityId);

                        if (existingIdForCurrentCustomer != null)
                        {
                            lastIdInt = int.Parse(existingIdForCurrentCustomer.Value);
                        }
                        else
                        {
                            var lastId = existingIdentifyIds.Last();
                            lastIdInt = int.Parse(lastId);
                            lastIdInt++;
                        }
                    }

                    _customGenericAttributeService.SaveGenericAttirubteValue(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorApiIdentityId, lastIdInt.ToString());

                    var redirectUrl = String.Format("{0}authorization/{1}?identifier={2}&portal_name={3}&first_name={4}&last_name={5}&email={6}&legal_name={7}",
                        ClientConstants.ExternalApi.VerifyInvestorTest,
                        settings.VerifyInvestorUserKey,
                        lastIdInt,
                        _storeContext.CurrentStore.Name,
                         _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                       _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName),
                      _currentCustomer.Email,
                        _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Company)
                        );

                    return Json(new
                    {
                        redirect = redirectUrl
                    });
                }
            }
            #endregion


            var resultModel = new InformationGatheringModel();
            PrepareInformationGatheringModel(resultModel, SelectedInvestorType);

            var resultHtml =
                RenderPartialViewToString(
                    "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InformationGathering.cshtml", resultModel);
            return Json(new
            {
                section_name = "info-gathering",
                html = resultHtml,
                goToContinue = CanSkipPersonalOtherStepsAndPDFVerification(settings)
            });



            //var investorTypeModel = new InvestorTypeModel();
            //PrepareInvestorTypeModel(investorTypeModel);

            //var resultHtml =
            //    RenderPartialViewToString(
            //        "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InvestorType.cshtml", investorTypeModel);

            //return Json(new
            //{
            //    section_name = "investor-type",
            //    html = resultHtml,
            //    goToContinue = CanSkipPersonalOtherStepsAndPDFVerification()
            //});
        }

        [NonAction]
        private void SaveIndividualInfo(IndividualsModel model, string infoType)
        {
            BD_IndividualBasicInfo individualBasic = new BD_IndividualBasicInfo();
            BD_IndividualJointInfo individualJoint = new BD_IndividualJointInfo();
            if (model.IsBasicSaving)
            {
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.LastName, model.LastName);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.FirstName, model.FirstName);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StreetAddress, model.StreetAddress);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CountryId, model.CountryId);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.ZipPostalCode, model.ZipPostalCode);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.City, model.City);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StreetAddress2, model.StreetAddress2);
                DateTime dateofbirth;
                if (DateTime.TryParse(model.DateOfBirth, out dateofbirth))
                    _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.DateOfBirth, dateofbirth);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.Phone, model.Phone);

                if (model.IndividualBasicId > 0) //update
                {
                    var basic = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
                    basic.Address_Years = model.Address_Years;
                    basic.SSN = model.SSN;
                    _bDAddressService.UpdateIndividualBasicInfo(basic);
                }
                else //insert
                {
                    individualBasic.CustomerId = _currentCustomer.Id;
                    individualBasic.Address_Years = model.Address_Years;
                    individualBasic.SSN = model.SSN;
                    _bDAddressService.InsertIndividualBasicInfo(individualBasic);
                }

                _logger.Information("IsJointBasicSaving: " +  model.IsJointBasicSaving);
                if (model.IsJointBasicSaving)
                {
                    // joint account
                    if (model.IndividualJointInfoModel.IndividualBasicId > 0) //update
                    {
                        var basic_joint = _bDAddressService.GetIndividualJointInfo(_currentCustomer.Id);
                        basic_joint.FirstName = model.IndividualJointInfoModel.FirstName;
                        basic_joint.LastName = model.IndividualJointInfoModel.LastName;
                        basic_joint.Street = model.IndividualJointInfoModel.Street;
                        basic_joint.City = model.IndividualJointInfoModel.City;
                        basic_joint.Country = model.IndividualJointInfoModel.Country;
                        basic_joint.State = model.IndividualJointInfoModel.State;
                        basic_joint.Zip = model.IndividualJointInfoModel.Zip;
                        basic_joint.SSN = model.IndividualJointInfoModel.SSN;
                        basic_joint.Address_Years = model.IndividualJointInfoModel.Address_Years;
                        _bDAddressService.UpdateIndividualJointInfo(basic_joint);
                    }
                    else //insert
                    {
                        _logger.Information("JointAccount First Name: " + model.IndividualJointInfoModel.FirstName);
                        _logger.Information("JointAccount Last Name: " + model.IndividualJointInfoModel.LastName);
                        individualJoint.CustomerId = _currentCustomer.Id;
                        individualJoint.FirstName = model.IndividualJointInfoModel.FirstName;
                        individualJoint.LastName = model.IndividualJointInfoModel.LastName;
                        individualJoint.Street = model.IndividualJointInfoModel.Street;
                        individualJoint.City = model.IndividualJointInfoModel.City;
                        individualJoint.Country = model.IndividualJointInfoModel.Country;
                        individualJoint.State = model.IndividualJointInfoModel.State;
                        individualJoint.Zip = model.IndividualJointInfoModel.Zip;
                        individualJoint.SSN = model.IndividualJointInfoModel.SSN;
                        individualJoint.Address_Years = model.IndividualJointInfoModel.Address_Years;
                        _bDAddressService.InsertIndividualJointInfo(individualJoint);
                    }
                }
            }
            else if (model.IsHomeSaving)
            {
                if (model.IndividualBasicId > 0) //update
                {
                    var home = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
                    home.Home_City = model.Home_City;
                    home.Home_Country = model.Home_Country;
                    home.Home_State = model.Home_State;
                    home.Home_Zip = model.Home_Zip;
                    home.Driver_License = model.Driver_License;
                    home.Driver_Country = model.Driver_Country;
                    home.Driver_State = model.Driver_State;
                    home.USA_Citizen = model.USA_Citizen;
                    if (!model.USA_Citizen ?? false)
                        home.USA_Citizen_Country = model.USA_Citizen_Country;
                    else
                        home.USA_Citizen_Country = 0;
                    home.Cell_Phone = model.Cell_Phone;
                    _bDAddressService.UpdateIndividualBasicInfo(home);
                }

                // joint account
                if (model.IsJointHomeSaving)
                {
                    if (model.IndividualJointInfoModel.IndividualBasicId > 0) // update
                    {
                        var home_joint = _bDAddressService.GetIndividualJointInfo(_currentCustomer.Id);
                        home_joint.Home_Street = model.IndividualJointInfoModel.Home_Street;
                        home_joint.DateOfBirth = model.IndividualJointInfoModel.DateOfBirth;
                        home_joint.Home_Phone = model.IndividualJointInfoModel.Home_Phone;
                        home_joint.Home_Email = model.IndividualJointInfoModel.Home_Email;
                        home_joint.Home_City = model.IndividualJointInfoModel.Home_City;
                        home_joint.Home_Country = model.IndividualJointInfoModel.Home_Country;
                        home_joint.Home_State = model.IndividualJointInfoModel.Home_State;
                        home_joint.Home_Zip = model.IndividualJointInfoModel.Home_Zip;
                        home_joint.Driver_License = model.IndividualJointInfoModel.Driver_License;
                        home_joint.Driver_Country = model.IndividualJointInfoModel.Driver_Country;
                        home_joint.Driver_State = model.IndividualJointInfoModel.Driver_State;
                        home_joint.USA_Citizen = model.IndividualJointInfoModel.USA_Citizen;
                        if (!model.IndividualJointInfoModel.USA_Citizen ?? false)
                            home_joint.USA_Citizen_Country = model.IndividualJointInfoModel.USA_Citizen_Country;
                        else
                            home_joint.USA_Citizen_Country = 0;
                        home_joint.Cell_Phone = model.IndividualJointInfoModel.Cell_Phone;
                        _bDAddressService.UpdateIndividualJointInfo(home_joint);
                    }
                }
            }
            else if (model.IsEmployerSaving)
            {
                if (model.IndividualBasicId > 0)
                {
                    var employer = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
                    employer.Employer_Name = model.Employer_Name;
                    employer.Employer_Street = model.Employer_Street;
                    employer.Employer_City = model.Employer_City;
                    employer.Employer_Country = model.Employer_Country;
                    employer.Employer_State = model.Employer_State;
                    employer.Employer_Zip = model.Employer_Zip;
                    employer.Employer_Business_Type = model.Employer_Business_Type;
                    employer.Employer_Position = model.Employer_Position;
                    employer.Employer_YRS = model.Employer_YRS;
                    employer.Employer_Phone = model.Employer_Phone;
                    employer.Employer_Email = model.Employer_Email;
                    _bDAddressService.UpdateIndividualBasicInfo(employer);
                }

                // joint account
                if (model.IsJointEmployerSaving)
                {
                    if (model.IndividualJointInfoModel.IndividualBasicId > 0)
                    {
                        var employer_joint = _bDAddressService.GetIndividualJointInfo(_currentCustomer.Id);
                        employer_joint.Employer_Name = model.IndividualJointInfoModel.Employer_Name;
                        employer_joint.Employer_Street = model.IndividualJointInfoModel.Employer_Street;
                        employer_joint.Employer_City = model.IndividualJointInfoModel.Employer_City;
                        employer_joint.Employer_Country = model.IndividualJointInfoModel.Employer_Country;
                        employer_joint.Employer_State = model.IndividualJointInfoModel.Employer_State;
                        employer_joint.Employer_Zip = model.IndividualJointInfoModel.Employer_Zip;
                        employer_joint.Employer_Business_Type = model.IndividualJointInfoModel.Employer_Business_Type;
                        employer_joint.Employer_Position = model.IndividualJointInfoModel.Employer_Position;
                        employer_joint.Employer_YRS = model.IndividualJointInfoModel.Employer_YRS;
                        employer_joint.Employer_Phone = model.IndividualJointInfoModel.Employer_Phone;
                        employer_joint.Employer_Email = model.IndividualJointInfoModel.Employer_Email;
                        _bDAddressService.UpdateIndividualJointInfo(employer_joint);
                    }
                }
            }
            else if (model.IsIncomeSaving)
            {
                if (model.IndividualBasicId > 0)
                {
                    var income = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
                    income.Income1 = model.Income1;
                    income.Income2 = model.Income2;
                    income.Income3 = model.Income3;
                    _bDAddressService.UpdateIndividualBasicInfo(income);
                }
            }

            var existCustomAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml, ClientConstants.CustomAttributes.PersonalInfoType, infoType);
            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);
        }

        #endregion



        //called when investor information and personal information can be skipped
        public ActionResult InvestorType()
        {
            var investorTypeModel = new InvestorTypeModel();
            PrepareInvestorTypeModel(investorTypeModel);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InvestorType.cshtml", investorTypeModel);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInvestorType(InvestorTypeModel model)
        {
            if (!string.IsNullOrEmpty(model.SelectedInvestorType))
            {
                var existCustomAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

                var customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml,
               ClientConstants.CustomAttributes.InvestorType, model.SelectedInvestorType);

                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);
                TempData["SelectedInvestorType"] = model.SelectedInvestorType;
            }

            return LoadPersonalTab();
        }

        
        //called when investor information, personal information and ivestor type can be skipped
        public ActionResult InformationGathering()
        {
            var informationGatheringModel = new InformationGatheringModel();
            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            var selectedInvestorType = investorType ?? ClientConstants.InvestorType.NonAccreditted;
            PrepareInformationGatheringModel(informationGatheringModel, selectedInvestorType);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InformationGathering.cshtml", informationGatheringModel);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInfoGathering()
        {
            var model = new InformationGatheringModel();
            TryUpdateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);
            TryValidateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);

            if (ModelState.IsValid)
            {
                var existCustomAttributesXml =
                    _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes,
                        _genericAttributeService);

                string customAttributesXml = String.Empty;
                if (model.AccreditedInvestor)
                {
                    customAttributesXml =
                        _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml,
                            ClientConstants.CustomAttributes.AccreditedQualify, model.SelectedQualify);
                }

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(model.AccreditedInvestor ? customAttributesXml : existCustomAttributesXml,
                    ClientConstants.CustomAttributes.AnnualIncome,
                    model.AnnualIncome.ToString(CultureInfo.InvariantCulture));

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(customAttributesXml,
                    ClientConstants.CustomAttributes.NetWorth, model.NetWorth.ToString(CultureInfo.InvariantCulture));

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(customAttributesXml,
                    ClientConstants.CustomAttributes.BackUpWithholding, model.SelectedBackupWithholding);

                _genericAttributeService.SaveAttribute(_currentCustomer,
                    SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);

                //SaveDocuments(model);
            }
            else
            {
                PrepareInformationGatheringModel(model, model.InvestorType);
                var repeatHtml =
                RenderPartialViewToString(
                    "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_InformationGathering.cshtml", model);
                return Json(new
                {
                    section_name = "info-gathering",
                    html = repeatHtml
                });
            }


            // Block score verification for customer
            var individualsModel = new IndividualsModel();
            if (TempData["IniIndividualsModel"] != null)
            {
                individualsModel = TempData["IniIndividualsModel"] as IndividualsModel;
            }
            else
            {
                PrepareIndividualsInformationModel(individualsModel);
            }
            _blockScoreService.VerifyCustomer(individualsModel);

            // Block score verification for company
            // write code at here for company


            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (CanSkipPersonalOtherStepsAndPDFVerification(settings))
            {
                return Json(new
                {
                    section_name = "",
                    //redirect = Url.RouteUrl("Plugin.CrowdPay.Investment") + "/" + productId,
                    redirect = (Session["productId"] != null) ?
                    (Session["offering"] == "multiple") ? Url.RouteUrl("Plugin.CrowdPay.Investment") + "/" + Session["productId"] : Url.RouteUrl("Plugin.CrowdPay.Investment")
                    : Url.RouteUrl("HomePage"),
                    html = "",
                });
            }
            else // for self-Accreditation or Broker-dealer then load Individual/Company PDF verification step
            {
                var resultModel = PrepareVerificationHTMLTemplate();
                if (!string.IsNullOrEmpty(resultModel.HTMLTemplateCurrent))
                {
                    var resultHtml =
             RenderPartialViewToString(
                 "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_HTMLVerificationTemplate.cshtml", resultModel);
                    return Json(new
                    {
                        section_name = "individual-company-verification",
                        html = resultHtml
                    });
                }
                else
                {
                    return Json(new { error = 1, message = "Verification HTML Template is not added." });
                }
            }
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveIndividualCompanyVerification(string[] hdnSignJSONsmallSign, string[] hdnSignJSONbigSign)
        {
            HTMLSignModel htmlSignModel = new HTMLSignModel();
            if (hdnSignJSONsmallSign != null)
                htmlSignModel.hdnSignJSONsmallSign = hdnSignJSONsmallSign.ToList();
            if (hdnSignJSONbigSign != null)
                htmlSignModel.hdnSignJSONbigSign = hdnSignJSONbigSign.ToList();
            PrepareHTMLToPDF(htmlSignModel);
            return Json(new
            {
                section_name = "",
                //redirect = Url.RouteUrl("Plugin.CrowdPay.Investment") + "/" + productId,
                redirect = (Session["productId"] != null) ?
                (Session["offering"] == "multiple") ? Url.RouteUrl("Plugin.CrowdPay.Investment") + "/" + Session["productId"] : Url.RouteUrl("Plugin.CrowdPay.Investment")
                : Url.RouteUrl("HomePage"),
                html = "",
            });
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveBilling(FormCollection form)
        {
            try
            {
                Product product;
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't find product attribute" });
                }
                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                int billingAddressId;
                int.TryParse(form["billing_address_id"], out billingAddressId);

                if (billingAddressId > 0)
                {
                    //existing address
                    var address = _currentCustomer.Addresses.FirstOrDefault(a => a.Id == billingAddressId);
                    if (address == null)
                        throw new Exception("Address can't be loaded");

                    _currentCustomer.BillingAddress = address;
                    _customerService.UpdateCustomer(_currentCustomer);
                }
                else
                {
                    //new address
                    var model = new CheckoutBillingAddressModel();
                    TryUpdateModel(model.NewAddress, "BillingNewAddress");

                    //custom address attributes
                    var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                    var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                    foreach (var error in customAttributeWarnings)
                    {
                        ModelState.AddModelError("", error);
                    }

                    //validate model
                    TryValidateModel(model.NewAddress);
                    if (!ModelState.IsValid)
                    {
                        //model is not valid. redisplay the form with errors
                        var billingAddressModel = _checkoutModelFactory.PrepareBillingAddressModel(_currentCustomer.ShoppingCartItems.ToList(),
                            selectedCountryId: model.NewAddress.CountryId,
                            overrideAttributesXml: customAttributes);
                        billingAddressModel.NewAddressPreselected = true;

                        var resultHtml =
                            RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_BillingAddress.cshtml",
                                billingAddressModel);

                        return Json(new
                        {
                            section_name = "billing-address",
                            html = resultHtml,
                            validation_error = true,
                            validation_span_id = "billing-new-address-form"
                        });
                    }

                    //try to find an address with the same values (don't duplicate records)
                    var address = _currentCustomer.Addresses.ToList().FindAddress(
                        model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                        model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                        model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                        model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                        model.NewAddress.CountryId, customAttributes);
                    if (address == null)
                    {
                        //address is not found. let's create a new one
                        address = model.NewAddress.ToEntity();
                        address.CustomAttributes = customAttributes;
                        address.CreatedOnUtc = DateTime.UtcNow;
                        //some validation
                        if (address.CountryId == 0)
                            address.CountryId = null;
                        if (address.StateProvinceId == 0)
                            address.StateProvinceId = null;
                        if (address.CountryId.HasValue && address.CountryId.Value > 0)
                        {
                            address.Country = _countryService.GetCountryById(address.CountryId.Value);
                        }
                        _currentCustomer.Addresses.Add(address);
                    }
                    _currentCustomer.BillingAddress = address;
                    _customerService.UpdateCustomer(_currentCustomer);
                }
                if (cart.RequiresShipping())
                {
                    //shipping is required                    
                    return Json(new
                    {
                        section_name = "shipping-address"
                    });
                }
                //shipping is not required
                _genericAttributeService.SaveAttribute<ShippingOption>(_currentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, null, _storeContext.CurrentStore.Id);
                //load next step
                var purchaseModel = new PurchaseModel();
                PreparePurchaseModel(purchaseModel);
                #region Load payment info
                var resultHtml2 =
                    LoadPaymentInfo(null, purchaseModel);
                #endregion

                return Json(new
                {
                    section_name = "purchase",
                    section_name2 = "paymentinfo",
                    html = this.RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml", purchaseModel),
                    html2 = resultHtml2
                });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _currentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveShipping(FormCollection form)
        {
            try
            {
                Product product;
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't find product attribute" });
                }

                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                //Pick up in store?
                if (_shippingSettings.AllowPickUpInStore)
                {
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model);

                    if (model.PickUpInStore)
                    {
                        //customer decided to pick up in store

                        _workContext.CurrentCustomer.ShippingAddress = null;
                        _customerService.UpdateCustomer(_workContext.CurrentCustomer);

                        var pickupPoint = form["pickup-points-id"].Split(new[] { "___" }, StringSplitOptions.None);
                        var pickupPoints = _shippingService
                            .GetPickupPoints(_workContext.CurrentCustomer.BillingAddress, _workContext.CurrentCustomer, pickupPoint[1], _storeContext.CurrentStore.Id).PickupPoints.ToList();
                        var selectedPoint = pickupPoints.FirstOrDefault(x => x.Id.Equals(pickupPoint[0]));
                        if (selectedPoint == null)
                            throw new Exception("Pickup point is not allowed");

                        var pickUpInStoreShippingOption = new ShippingOption
                        {
                            Name = string.Format(_localizationService.GetResource("Checkout.PickupPoints.Name"), selectedPoint.Name),
                            Rate = selectedPoint.PickupFee,
                            Description = selectedPoint.Description,
                            ShippingRateComputationMethodSystemName = selectedPoint.ProviderSystemName
                        };
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, pickUpInStoreShippingOption, _storeContext.CurrentStore.Id);
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickupPoint, selectedPoint, _storeContext.CurrentStore.Id);

                        //load next step
                        var resultModel = new PurchaseModel();
                        PreparePurchaseModel(resultModel);

                        var resultHtml =
                            RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml",
                                resultModel);
                        #region Load payment info
                        var resultHtml2 =
                            LoadPaymentInfo(null, resultModel);
                        #endregion

                        return Json(new
                        {
                            section_name = "purchase",
                            section_name2 = "paymentinfo",
                            html = resultHtml,
                            html2 = resultHtml2
                        });
                    }

                    //set value indicating that "pick up in store" option has not been chosen
                    _genericAttributeService.SaveAttribute<PickupPoint>(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickupPoint, null, _storeContext.CurrentStore.Id);
                }

                int shippingAddressId;
                int.TryParse(form["shipping_address_id"], out shippingAddressId);

                if (shippingAddressId > 0)
                {
                    //existing address
                    var address = _workContext.CurrentCustomer.Addresses.FirstOrDefault(a => a.Id == shippingAddressId);
                    if (address == null)
                        throw new Exception("Address can't be loaded");

                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }
                else
                {
                    //new address
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model.NewAddress, "ShippingNewAddress");

                    //custom address attributes
                    var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                    var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                    foreach (var error in customAttributeWarnings)
                    {
                        ModelState.AddModelError("", error);
                    }

                    //validate model
                    TryValidateModel(model.NewAddress);
                    if (!ModelState.IsValid)
                    {
                        //model is not valid. redisplay the form with errors
                        var shippingAddressModel = _checkoutModelFactory.PrepareShippingAddressModel(
                            selectedCountryId: model.NewAddress.CountryId,
                            overrideAttributesXml: customAttributes);
                        shippingAddressModel.NewAddressPreselected = true;
                        return Json(new
                        {
                            section_name = "shipping-address",
                            html = RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ShippingAddress.cshtml", shippingAddressModel),
                            validation_error = true,
                            validation_span_id = "shipping-new-address-form"
                        });
                    }

                    //try to find an address with the same values (don't duplicate records)
                    var address = _workContext.CurrentCustomer.Addresses.ToList().FindAddress(
                        model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                        model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                        model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                        model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                        model.NewAddress.CountryId, customAttributes);
                    if (address == null)
                    {
                        address = model.NewAddress.ToEntity();
                        address.CustomAttributes = customAttributes;
                        address.CreatedOnUtc = DateTime.UtcNow;
                        //little hack here (TODO: find a better solution)
                        //EF does not load navigation properties for newly created entities (such as this "Address").
                        //we have to load them manually 
                        //otherwise, "Country" property of "Address" entity will be null in shipping rate computation methods
                        if (address.CountryId.HasValue)
                            address.Country = _countryService.GetCountryById(address.CountryId.Value);
                        if (address.StateProvinceId.HasValue)
                            address.StateProvince = _stateProvinceService.GetStateProvinceById(address.StateProvinceId.Value);

                        //other null validations
                        if (address.CountryId == 0)
                            address.CountryId = null;
                        if (address.StateProvinceId == 0)
                            address.StateProvinceId = null;
                        _workContext.CurrentCustomer.Addresses.Add(address);
                    }
                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }

                var shippingMethodModel = _checkoutModelFactory.PrepareShippingMethodModel(cart, _workContext.CurrentCustomer.ShippingAddress);

                if (_shippingSettings.BypassShippingMethodSelectionIfOnlyOne &&
                    shippingMethodModel.ShippingMethods.Count == 1)
                {
                    //if we have only one shipping method, then a customer doesn't have to choose a shipping method
                    _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                        SystemCustomerAttributeNames.SelectedShippingOption,
                        shippingMethodModel.ShippingMethods.First().ShippingOption,
                        _storeContext.CurrentStore.Id);

                    //load next step
                    return null;
                }

                return Json(new
                {
                    section_name = "shipping-method",
                    //html = this.RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ShippingMethods.cshtml", shippingMethodModel)
                });

            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveShippingMethod(FormCollection form)
        {
            try
            {
                Product product;
                var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
                if (tempProductAttribute != null)
                {
                    product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't find product attribute" });
                }

                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                if (cart.Count == 0)
                    throw new Exception("Your cart is empty");

                if (!cart.RequiresShipping())
                    throw new Exception("Shipping is not required");

                //parse selected method 
                string shippingoption = form["shippingoption"];
                if (String.IsNullOrEmpty(shippingoption))
                    throw new Exception("Selected shipping method can't be parsed");
                var splittedOption = shippingoption.Split(new[] { "___" }, StringSplitOptions.RemoveEmptyEntries);
                if (splittedOption.Length != 2)
                    throw new Exception("Selected shipping method can't be parsed");
                string selectedName = splittedOption[0];
                string shippingRateComputationMethodSystemName = splittedOption[1];

                //find it
                //performance optimization. try cache first
                var shippingOptions = _workContext.CurrentCustomer.GetAttribute<List<ShippingOption>>(SystemCustomerAttributeNames.OfferedShippingOptions, _storeContext.CurrentStore.Id);
                if (shippingOptions == null || shippingOptions.Count == 0)
                {
                    //not found? let's load them using shipping service
                    shippingOptions = _shippingService
                        .GetShippingOptions(cart, _workContext.CurrentCustomer.ShippingAddress, _workContext.CurrentCustomer, shippingRateComputationMethodSystemName, _storeContext.CurrentStore.Id)
                        .ShippingOptions
                        .ToList();
                }
                else
                {
                    //loaded cached results. let's filter result by a chosen shipping rate computation method
                    shippingOptions = shippingOptions.Where(so => so.ShippingRateComputationMethodSystemName.Equals(shippingRateComputationMethodSystemName, StringComparison.InvariantCultureIgnoreCase))
                        .ToList();
                }

                var shippingOption = shippingOptions
                    .Find(so => !String.IsNullOrEmpty(so.Name) && so.Name.Equals(selectedName, StringComparison.InvariantCultureIgnoreCase));
                if (shippingOption == null)
                    throw new Exception("Selected shipping method can't be loaded");

                //save
                _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, shippingOption, _storeContext.CurrentStore.Id);

                #region Load purchase
                var resultModel = new PurchaseModel();
                PreparePurchaseModel(resultModel);
                var resultHtml =
                    RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml",
                        resultModel);
                #endregion

                #region Load payment info
                var resultHtml2 =
                    LoadPaymentInfo(null, resultModel);
                #endregion

                return Json(new
                {
                    section_name = "purchase",
                    section_name2 = "paymentinfo",
                    html = resultHtml,
                    html2 = resultHtml2
                });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePurchase(FormCollection form)
        {

            //add payment methods
            var paymentMethods = _paymentService
                .LoadActivePaymentMethods(_workContext.CurrentCustomer, _storeContext.CurrentStore.Id)
                .Where(
                    pm =>
                        pm.PaymentMethodType == PaymentMethodType.Standard ||
                        pm.PaymentMethodType == PaymentMethodType.Redirection)
                .ToList();

            string paymentmethod;
            if (paymentMethods.Count == 1)
            {
                paymentmethod = paymentMethods[0].PluginDescriptor.SystemName;
            }
            else
            {
                paymentmethod = form["paymentmethod"];
            }
            //= form["paymentmethod"];
            //payment method 
            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var purchaseModel = new PurchaseModel();
            TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
            TryValidateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);

            if (!ModelState.IsValid)
            {
                PreparePurchaseModel(purchaseModel);

                var repeatHtml =
                    RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml",
                        purchaseModel);
                return Json(new
                {
                    section_name = "purchase",
                    html = repeatHtml
                });
            }

            //var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            //if (paymentMethodInst == null ||
            //    !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
            //    !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
            //    throw new Exception("Selected payment method can't be parsed");

            //save
            _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                SystemCustomerAttributeNames.SelectedPaymentMethod, paymentmethod, _storeContext.CurrentStore.Id);

            _customGenericAttributeService.SaveGenericAttirubteValue(ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity, purchaseModel.OrderedSharesCount.ToString());

            //var paymentInfoModel = PreparePaymentInfoModel(paymentMethodInst);

            //var resultModel = new CustomPaymentInfoModel()
            //{
            //    CheckoutPaymentInfoModel = paymentInfoModel
            //};

            //var resultHtml =
            //    RenderPartialViewToString(
            //        "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", resultModel);

            #region HTML to PDF
            ConvertHtmlToPdf();
            #endregion

            return Json(new
            {
                section_name = "paymentinfo"
                //html = resultHtml
            });
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult LoadPaymentInfoForm(FormCollection form)
        {
            return Json(new
            {
                section_name = "paymentinfo",
                html = LoadPaymentInfo(form, null)
            });
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePaymentInfo(FormCollection form)
        {
            try
            {
                var customPaymentInfoModel = new CustomPaymentInfoModel();
                TryUpdateModel(customPaymentInfoModel, ClientConstants.FormPrefix.PaymentInfoPrefix);

                //validation
                var paymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                    SystemCustomerAttributeNames.SelectedPaymentMethod,
                    _genericAttributeService, _storeContext.CurrentStore.Id);
                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentMethodSystemName);
                if (paymentMethod == null)
                    throw new Exception("Payment method is not selected");

                var paymentControllerType = paymentMethod.GetControllerType();
                var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as BasePaymentController;
                if (paymentController == null)
                    throw new Exception("Payment controller cannot be loaded");

                var warnings = paymentController.ValidatePaymentForm(form);
                foreach (var warning in warnings)
                    ModelState.AddModelError("", warning);
                if (ModelState.IsValid)
                {
                    //get payment info
                    var paymentInfo = paymentController.GetPaymentInfo(form);
                    //session save
                    _httpContext.Session["CrowdPayOrderPaymentInfo"] = paymentInfo;

                    var subscriptionAgreementModel = PrepareSigningModel(ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId);

                    if (!String.IsNullOrEmpty(subscriptionAgreementModel.DocumentUrl))
                    {
                        var resultHtml =
                             RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_SigningCeremony.cshtml",
                                 subscriptionAgreementModel);
                        return Json(new
                        {
                            section_name = "subagreement",
                            html = resultHtml
                        });
                    }
                    else
                    {
                        var confirmOrderModel = PrepareConfirmOrderModel();

                        var resultHtml =
                             RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                                 confirmOrderModel);
                        return Json(new
                        {
                            section_name = "confirm",
                            html = resultHtml
                        });
                    }
                }

                var paymentInfoModel = _checkoutModelFactory.PreparePaymentInfoModel(paymentMethod);

                var resultModel = new CustomPaymentInfoModel
                {
                    CheckoutPaymentInfoModel = paymentInfoModel
                };

                var repeatHtml =
                    RenderPartialViewToString(
                        "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", resultModel);
                return Json(new
                {
                    section_name = "paymentinfo",
                    html = repeatHtml
                });
            }
            catch (Exception exc)
            {
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [HttpPost]
        public ActionResult SaveSubscriptionAgreement()
        {
            var confirmOrderModel = PrepareConfirmOrderModel();

            var resultHtml =
                 RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                     confirmOrderModel);
            return Json(new
            {
                section_name = "confirm",
                html = resultHtml
            });
        }

        [HttpPost]
        public new ActionResult ConfirmOrder()
        {
            var confirmModel = new ConfirmOrderModel();
            TryUpdateModel(confirmModel, ClientConstants.FormPrefix.ConfirmPrefix);

            var processPaymentRequest = _httpContext.Session["CrowdPayOrderPaymentInfo"] as ProcessPaymentRequest;
            if (processPaymentRequest == null)
            {
                throw new Exception("Payment information is not entered");
            }

            _customOrderProccessingService.InitOrderProcessing(confirmModel.ProductId, confirmModel.DeliveredQuantity);
            processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
            processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
            processPaymentRequest.PaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            var placeOrderResult = _customOrderProccessingService.PlaceOrder(processPaymentRequest);

            if (placeOrderResult.Success)
            {
                _httpContext.Session["CrowdPayOrderPaymentInfo"] = null;
                var postProcessPaymentRequest = new PostProcessPaymentRequest
                {
                    Order = placeOrderResult.PlacedOrder
                };

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(placeOrderResult.PlacedOrder.PaymentMethodSystemName);
                if (paymentMethod == null)
                    //payment method could be null if order total is 0
                    //success
                    return Json(new { success = 1 });

                if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                {
                    //Redirection will not work because it's AJAX request.
                    //That's why we don't process it here (we redirect a user to another page where he'll be redirected)

                    //redirect
                    return Json(new
                    {
                        redirect = string.Format("{0}checkout/OpcCompleteRedirectionPayment", _webHelper.GetStoreLocation())
                    });
                }

                _paymentService.PostProcessPayment(postProcessPaymentRequest);

                var orderSuccessUrl = Url.Action("CrowdPayCompleted", "CrowdPayCheckOut",
                    new { orderId = placeOrderResult.PlacedOrder.Id });

                //success
                return Json(new { success = 1, confirmRedirectedUrl = orderSuccessUrl });
            }

            //error

            if (confirmModel.ProductId != 0)
            {
                var product = _productService.GetProductById(confirmModel.ProductId);
                var productModel = PrepareSimpleProductDetailsModel(product);

                confirmModel.DeliveredProduct = productModel;
            }

            foreach (var error in placeOrderResult.Errors)
                confirmModel.Warnings.Add(error);

            var resultHtml =
                           RenderPartialViewToString("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                               confirmModel);
            return Json(new
            {
                section_name = "confirm",
                html = resultHtml
            });
        }

        public ActionResult CrowdPayCompleted(int? orderId)
        {
            //validation
            if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                return new HttpUnauthorizedResult();

            Order order = null;
            if (orderId.HasValue)
            {
                //load order by identifier (if provided)
                order = _orderService.GetOrderById(orderId.Value);
            }
            if (order == null)
            {
                order = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                customerId: _workContext.CurrentCustomer.Id, pageSize: 1)
                    .FirstOrDefault();
            }
            if (order == null || order.Deleted || _workContext.CurrentCustomer.Id != order.CustomerId)
            {
                return RedirectToRoute("HomePage");
            }

            //disable "order completed" page?
            if (_orderSettings.DisableOrderCompletedPage)
            {
                return RedirectToRoute("OrderDetails", new { orderId = order.Id });
            }

            //model
            var model = new CheckoutCompletedModel
            {
                OrderId = order.Id,
                OnePageCheckoutEnabled = _orderSettings.OnePageCheckoutEnabled
            };

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/SuccesfulInvestment.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult UploadDocuments()
        {
            var model = new InformationGatheringModel();
            TryUpdateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);
            TryValidateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);
            SaveDocuments(model);

            var informationGatheringModel = new InformationGatheringModel();
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!CanSkipPersonalOtherStepsAndPDFVerification(settings))
            {
                ViewBag.ShowUploadDocuments = true;
                PrepareUploadDocumentsModel(informationGatheringModel);
            }
            var resultHtml =
            RenderPartialViewToString(
                "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_UploadDocuments.cshtml", informationGatheringModel);
            return Json(new
            {
                html = resultHtml
            });
        }
		
		 [HttpPost]
        public ActionResult AsyncUpload()
        {
            //we process it distinct ways based on a browser
            //find more info here http://stackoverflow.com/questions/4884920/mvc3-valums-ajax-file-upload
            Stream stream = null;
            var fileName = "";
            var contentType = "";
            if (String.IsNullOrEmpty(Request["qqfile"]))
            {
                // IE
                HttpPostedFileBase httpPostedFile = Request.Files[0];
                if (httpPostedFile == null)
                    throw new ArgumentException("No file uploaded");
                stream = httpPostedFile.InputStream;
                fileName = Path.GetFileName(httpPostedFile.FileName);
                contentType = httpPostedFile.ContentType;
            }
            else
            {
                //Webkit, Mozilla
                stream = Request.InputStream;
                fileName = Request["qqfile"];
            }

            var fileBinary = new byte[stream.Length];
            stream.Read(fileBinary, 0, fileBinary.Length);

            var fileExtension = Path.GetExtension(fileName);
            if (!String.IsNullOrEmpty(fileExtension))
                fileExtension = fileExtension.ToLowerInvariant();

            var download = new Download
            {
                DownloadGuid = Guid.NewGuid(),
                UseDownloadUrl = false,
                DownloadUrl = "",
                DownloadBinary = fileBinary,
                ContentType = contentType,
                //we store filename without extension for downloads
                Filename = Path.GetFileNameWithoutExtension(fileName),
                Extension = fileExtension,
                IsNew = true
            };
            _downloadService.InsertDownload(download);

            //when returning JSON the mime-type must be set to text/plain
            //otherwise some browsers will pop-up a "Save As" dialog.
            return Json(new
            {
                success = true,
                downloadId = download.Id,
                downloadUrl = Url.Action("DownloadDocument", new { downloadGuid = download.DownloadGuid })
            },
            MimeTypes.TextPlain);
        }

        public ActionResult DownloadDocument(Guid downloadGuid)
        {
            var download = _downloadService.GetDownloadByGuid(downloadGuid);
            if (download == null)
                return Content("No download record found with the specified id");

            if (download.UseDownloadUrl)
                return new RedirectResult(download.DownloadUrl);

            //use stored data
            if (download.DownloadBinary == null)
                return Content(string.Format("Download data is not available any more. Download GD={0}", download.Id));

            string fileName = !String.IsNullOrWhiteSpace(download.Filename) ? download.Filename : download.Id.ToString();
            string contentType = !String.IsNullOrWhiteSpace(download.ContentType)
                ? download.ContentType
                : MimeTypes.ApplicationOctetStream;
            return new FileContentResult(download.DownloadBinary, contentType)
            {
                FileDownloadName = fileName + download.Extension
            };
        }

        #region NDA Form
        [Authorize]
        public ActionResult LoadNDAForm()
        {
            if (!this._bDAddressService.CheckForRequireNDAToSigne(_currentCustomer.Id,0))
                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
            SubscriptionTemplateModel subscriptionTemplateModel = new SubscriptionTemplateModel();
            CrowdPaySettings crowdPaySettings = _settingsService.LoadSetting<CrowdPaySettings>();
            HTMLSignModel htmlSignModel = new HTMLSignModel();
            if (crowdPaySettings.SingleOfferProductId > 0)
            {
                BD_SubscriptionTemplate templateByProduct = this._bDAddressService.GetSubscriptionTemplateByProduct(crowdPaySettings.SingleOfferProductId);
                if (templateByProduct != null && templateByProduct.NDAHTMLTemplate != null && !string.IsNullOrEmpty(templateByProduct.NDAHTMLTemplate.Trim()))
                {
                    htmlSignModel.Name = String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                          _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName));
                    DateTime dateTime = EngineContext.Current.Resolve<IDateTimeHelper>().ConvertToUserTime(DateTime.Now);
                    htmlSignModel.LongDate = dateTime.ToString("MMMM dd, yyyy");
                    var logoModel = EngineContext.Current.Resolve<Nop.Web.Factories.ICommonModelFactory>().PrepareLogoModel();
                    StringBuilder stringBuilder = this.SetSignToken("%NDA.Signature%", new StringBuilder(templateByProduct.NDAHTMLTemplate), "bigSign", "bigSign");
                    stringBuilder.Replace("%NDA.Logo%", string.Format("<img title='' alt='{0}' src='{1}'>", (object)logoModel.StoreName, (object)logoModel.LogoPath));
                    stringBuilder.Replace("%NDA.Name%", htmlSignModel.Name);
                    stringBuilder.Replace("%NDA.LongDate%", htmlSignModel.LongDate);
                    subscriptionTemplateModel.HTMLTemplate = stringBuilder.ToString();
                    subscriptionTemplateModel.productId = templateByProduct.productId;
                    htmlSignModel.LogoPath = logoModel.LogoPath;
                }
            }
            if (string.IsNullOrEmpty(subscriptionTemplateModel.HTMLTemplate))
            {
                ViewBag.EmptyHtml = _localizationService.GetResource("hopFast.BD.NDA.NDAHTMLTemplate.EmptyMessage");
            }
            ((ControllerBase)this).TempData["htmlSignModel"] = (object)htmlSignModel;
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_NDAForm.cshtml", (object)subscriptionTemplateModel);
        }

        [HttpPost]
        public ActionResult LoadNDAForm(string[] hdnSignJSONbigSign, SubscriptionTemplateModel subscriptionTemplateModel)
        {
            if (hdnSignJSONbigSign == null || !Enumerable.Any<string>((IEnumerable<string>)hdnSignJSONbigSign))
                return RedirectToRoute("Plugin.CrowdPay.LoadNDAForm");
            this._bDAddressService.SignNDA(_currentCustomer.Id, subscriptionTemplateModel.productId);
            if (((ControllerBase)this).TempData["htmlSignModel"] != null)
            {
                HTMLSignModel htmlSignModel = ((ControllerBase)this).TempData["htmlSignModel"] as HTMLSignModel;
                htmlSignModel.hdnSignJSONbigSign = Enumerable.ToList<string>((IEnumerable<string>)hdnSignJSONbigSign);
                BD_SubscriptionTemplate templateByProduct = this._bDAddressService.GetSubscriptionTemplateByProduct(subscriptionTemplateModel.productId);
                if (templateByProduct != null && Convert.ToInt32((object)templateByProduct.NDAPDFUploadId) > 0)
                {
                    var downloadById = ((IDownloadService)EngineContext.Current.Resolve<IDownloadService>()).GetDownloadById(Convert.ToInt32((object)templateByProduct.NDAPDFUploadId));
                    if (downloadById != null && downloadById.DownloadBinary != null)
                    {
                        foreach (string jsonSign in htmlSignModel.hdnSignJSONbigSign)
                        {
                            if (!string.IsNullOrEmpty(jsonSign))
                                htmlSignModel.signIamgeBig.Add(this.Draw2DLineGraphic(jsonSign, 410, 120));
                        }
                        try
                        {
                            var pdfReader = new PdfReader(downloadById.DownloadBinary);
                            if (!Directory.Exists(((Controller)this).Server.MapPath("~/Plugins/BD.CrowdPay/Documents")))
                                Directory.CreateDirectory(((Controller)this).Server.MapPath("~/Plugins/BD.CrowdPay/Documents"));
                            string path = ((Controller)this).Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/Signed-NDA-{0}.pdf", (object)subscriptionTemplateModel.productId));
                            PdfStamper pdfStamper = new PdfStamper(pdfReader, (Stream)new FileStream(path, FileMode.OpenOrCreate));
                            AcroFields acroFields = pdfStamper.AcroFields;
                            acroFields.SetField("%NDA.Name%", htmlSignModel.Name);
                            acroFields.SetField("%NDA.LongDate%", htmlSignModel.LongDate);
                            int num = 0;
                            foreach (byte[] signImage in htmlSignModel.signIamgeBig)
                            {
                                ++num;
                                this.FillImage("%NDA.Signature" + (object)num + "%", pdfStamper, signImage);
                            }
                            byte[] signImage1 = new WebClient().DownloadData(htmlSignModel.LogoPath);
                            if (signImage1 != null && signImage1.Length > 0)
                                this.FillImage("%NDA.LongDate%", pdfStamper, signImage1);
                            pdfStamper.FormFlattening = true;
                            pdfStamper.Close();
                            pdfReader.Close();
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            return RedirectToRoute("Plugin.CrowdPay.Accreditation");
        }

        [ChildActionOnly]
        public virtual ActionResult ShowNDAPdfs(int selectedTabId = 0)
        {
            if (this._bDAddressService.CheckForRequireNDAToSigne(_currentCustomer.Id,0))
                return (ActionResult)new EmptyResult();
            List<UploadDocument> list = new List<UploadDocument>();
            CrowdPaySettings crowdPaySettings = (CrowdPaySettings)this._settingsService.LoadSetting<CrowdPaySettings>(0);
            if (crowdPaySettings.SingleOfferProductId > 0)
            {
                BD_SubscriptionTemplate templateByProduct = this._bDAddressService.GetSubscriptionTemplateByProduct(crowdPaySettings.SingleOfferProductId);
                if (templateByProduct != null && Convert.ToInt32((object)templateByProduct.PPMPDFUploadId) > 0)
                {
                    var downloadById = ((IDownloadService)EngineContext.Current.Resolve<IDownloadService>()).GetDownloadById(Convert.ToInt32((object)templateByProduct.PPMPDFUploadId));
                    if (Directory.Exists(((Controller)this).Server.MapPath("~/Plugins/BD.CrowdPay/Documents")) && System.IO.File.Exists(((Controller)this).Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/Signed-NDA-{0}.pdf", (object)crowdPaySettings.SingleOfferProductId))))
                        list.Add(new UploadDocument()
                        {
                            DocumentId = 0,
                            Filename = this._localizationService.GetResource("ShopFast.BD.NDA.Signed-NDA-Filename"),
                            DocumentUrl = string.Format("/Plugins/BD.CrowdPay/Documents/Signed-NDA-{0}.pdf", (object)crowdPaySettings.SingleOfferProductId)
                        });
                    if (downloadById != null)
                    {
                        list.Add(new UploadDocument()
                        {
                            DocumentId = downloadById.Id,
                            Filename = this._localizationService.GetResource("ShopFast.BD.NDA.PPM-PDF-Filename"),
                            DocumentUrl = "/Admin/Download/DownloadFile?downloadGuid=" + downloadById.DownloadGuid
                        });
                    }
                }
            }
            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_ShowNDAPdfs.cshtml", (object)list);
        }

        #endregion

        #region Verification Template Methods

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult VerificationTemplate(int customerId)
        {
            VerificationTemplateModel model = new VerificationTemplateModel();

            var verificationTemplate = _bDAddressService.GetVerificationTemplateByCustomer(customerId);
            if (verificationTemplate != null)
            {
                model.VerificationTemplateId = verificationTemplate.Id;
                model.customerId = verificationTemplate.customerId;
                model.HTMLTemplateIndividual = verificationTemplate.HTMLTemplateIndividual;
                model.HTMLTemplateCompany = verificationTemplate.HTMLTemplateCompany;
                model.PDFIndividualUploadId = verificationTemplate.PDFIndividualUploadId;
                model.PDFCompanyUploadId = verificationTemplate.PDFCompanyUploadId;
                model.IsDocusign = verificationTemplate.IsDocusign;
                model.DocusignUsername = verificationTemplate.DocusignUsername;
                model.DocusignPassword = verificationTemplate.DocusignPassword;
                model.DocuSignIntegratorKey = verificationTemplate.DocuSignIntegratorKey;
            }
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/VerificationTemplate.cshtml", model);
        }

        #endregion

        #region Admin Side Uploaded Documents List

        [AdminAuthorize]
        [ChildActionOnly]
        // Show the list of startup customers stored in external table
        public ActionResult UploadDocumentsList(int customerId)
        {
            ViewBag.customerId = customerId;
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/UploadDocumentsList.cshtml");
        }

        [HttpPost]
        public ActionResult UploadDocumentsList(DataSourceRequest command, int customerId)
        {
            //if (!_permissionService.Authorize(StandardPermissionProvider.ManageTaxSettings))
            //    return Content("Access denied");

            var uploadDocumentsModel = _bDAddressService.GetDocumentsByCustomer(customerId);

            var gridModel = new DataSourceResult
            {
                Data = uploadDocumentsModel,
                Total = uploadDocumentsModel.Count()
            };
            return Json(gridModel);
        }

        [AdminAuthorize]
        public ActionResult UploadDocumentDetail(int Id)
        {
            var document = _bDAddressService.GetDocumentsById(Id);
            UploadDocumentModel model = new UploadDocumentModel();
            model.DocumentUploadId = document.DocumentUploadId;
            model.DocumentId = document.Id;
            model.CustomerId = document.CustomerId;
            var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadById(document.DocumentUploadId);
            if (download != null)
            {
                model.Filename = download.Filename + download.Extension;
                model.DocumentUrl = "/Admin/Download/DownloadFile?downloadGuid=" + download.DownloadGuid;
            }
            model.Description = document.description;
            model.IsApproved = document.IsApproved;
            model.ApprovedById = document.ApprovedById;
            model.ApprovedByName = document.ApprovedByName;
            model.ApprovedByEmail = document.ApprovedByEmail;
            model.ApproveDate = document.ApproveDate;
            model.Comment = document.Comment;
            model.InvestorComment = document.InvestorComment;
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/UploadDocumentDetail.cshtml", model);
        }

        [HttpPost]
        public ActionResult UploadDocumentDetail(UploadDocumentModel model)
        {
            //if (!_permissionService.Authorize(StandardPermissionProvider.ManageTaxSettings))
            //    return Content("Access denied");
            var document = _bDAddressService.GetDocumentsById(model.DocumentId);
            document.IsApproved = model.IsApproved;
            if (model.IsApproved)
            {
                document.ApprovedByEmail = _currentCustomer.Email;
                document.ApprovedByName = _currentCustomer.GetFullName();
                document.ApprovedById = _currentCustomer.Id;
                document.ApproveDate = DateTime.Now;
            }
            document.Comment = model.Comment;
            document.InvestorComment = model.InvestorComment;
            _bDAddressService.UpdateDocuments(document);
            return Redirect("/Admin/Customer/Edit/" + model.CustomerId);
        }

        [HttpPost]
        public ActionResult DeleteDocument(int id = 0)
        {
            //if (!_permissionService.Authorize(StandardPermissionProvider.ManageProducts))
            //    return Content("Access denied");
            _bDAddressService.DeleteDocumentById(id);
            return new NullJsonResult();
        }

        #endregion

        #region Other Actions

        public ActionResult SigningResult(string @event, string documentType, int productId)
        {
            if (String.IsNullOrEmpty(@event))
            {
                return RedirectToAction("Index", "Home");
            }

            var model = new SigningResult
            {
                Status = @event
            };
            if (@event == ClientConstants.DocuSign.SigningResult.Complete)
            {
                model.Complete = true;
                if (documentType == ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId)
                {
                    model.StepName = "InvestorInformation";
                }
                else if (documentType == ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId)
                {
                    model.StepName = "SubscriptionAgreement";
                }
            }
            if (@event != ClientConstants.DocuSign.SigningResult.Cancel)
            {
                if (@event == ClientConstants.DocuSign.SigningResult.Complete)
                {
                    var genericAttribute =
                        _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                            String.Format(ClientConstants.TempCheckOutGenericAttirubutes.TemporaryEnvelopId, productId, documentType));
                    if (genericAttribute != null)
                    {
                        _customGenericAttributeService.SaveGenericAttirubteValue(String.Format(ClientConstants.TempCheckOutGenericAttirubutes.SuccesfulyEnvelopId, productId, documentType), genericAttribute.Value);
                    }
                }
                _customGenericAttributeService.DeleteAttriutes(
                String.Format(ClientConstants.TempCheckOutGenericAttirubutes.TemporaryEnvelopId, productId, documentType));
            }

            return PartialView("~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_SigningResult.cshtml", model);
        }

        public ActionResult DownloadFile(string templateId)
        {
            var docusignDocument = _docusignService.GetDocumentFromTemplate(templateId);

            if (docusignDocument != Stream.Null)
            {
                var byteBuffer = new byte[docusignDocument.Length];
                docusignDocument.Read(byteBuffer, 0, (int)docusignDocument.Length);

                return File(byteBuffer, "application/pdf");
            }

            return null;
        }

        public object InvestorInfoTypeChange(string investorType, bool ajaxRequest, PersonalInformationModel model = null)
        {
            string resultHtml = string.Empty;

            switch (investorType)
            {
                case ClientConstants.PersonalInfoType.Individual:
                    {

                        var individualInfoModel = new IndividualsModel();
                        if (model != null)
                        {
                            if (model.IniIndividualsModel != null)
                            {
                                individualInfoModel = model.IniIndividualsModel;
                            }
                        }
                        PrepareIndividualsInformationModel(individualInfoModel);

                        var resulInfoModel = new PersonalInformationModel()
                        {
                            IniIndividualsModel = individualInfoModel
                        };

                        resultHtml =
                             RenderPartialViewToString(
                                 "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/PersonalInvoViews/_IndividualInfo.cshtml",
                                 resulInfoModel);
                        break;
                    }
                case ClientConstants.PersonalInfoType.Company:
                case ClientConstants.PersonalInfoType.Trust:
                case ClientConstants.PersonalInfoType.SelfDirectedIRA:
                    {
                        var otherInfoModel = new OtherInfoModel();
                        if (model != null)
                        {
                            if (model.OtherInfoModel != null)
                            {
                                otherInfoModel = model.OtherInfoModel;
                            }
                        }
                        if (investorType.Equals(ClientConstants.PersonalInfoType.SelfDirectedIRA))
                        {
                            otherInfoModel.SelfDirected = true;
                        }

                        var individualInfo = new IndividualsModel();
                        PrepareOtherTypeInformationModel(otherInfoModel, individualInfo, investorType);

                        var resulInfoModel = new PersonalInformationModel()
                        {
                            OtherInfoModel = otherInfoModel,
                            IniIndividualsModel = individualInfo
                        };

                        resultHtml =
                            RenderPartialViewToString(
                                "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/PersonalInvoViews/_OtherInfo.cshtml",
                                resulInfoModel);
                        break;
                    }
            }

            if (!String.IsNullOrEmpty(resultHtml))
            {
                if (!ajaxRequest)
                {
                    return resultHtml;
                }
                return Json(new
                {
                    result_html = resultHtml
                }, JsonRequestBehavior.AllowGet);
            }
            return Json(new
            {
                error = "This investor type is not implemented"
            }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Utils

        #region Prepare models

        [NonAction]
        private void PrepareIndividualsInformationModel(IndividualsModel model)
        {
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            model.GoToContinue = CanSkipPersonalOtherStepsAndPDFVerification(settings);

            model.Email = _currentCustomer.Email;
            model.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
            model.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);

            var dateOfBirth = _currentCustomer.GetAttribute<DateTime?>(SystemCustomerAttributeNames.DateOfBirth);
            if (dateOfBirth.HasValue)
            {
                model.DateOfBirth = dateOfBirth.Value.ToShortDateString();
            }

            model.DateOfBirthEnabled = _customerSettings.DateOfBirthEnabled;
            model.DateOfBirthRequired = _customerSettings.DateOfBirthEnabled;

            model.StreetAddress = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress);
            model.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            model.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;

            model.StreetAddress2 = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2);
            model.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            model.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;

            model.ZipPostalCode = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode);
            model.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            model.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;


            model.City = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.City);
            model.CityRequired = _customerSettings.CityRequired;
            model.CityEnabled = _customerSettings.CityEnabled;

            model.CountryId = _currentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId);
            model.CountryRequired = _customerSettings.CountryRequired;
            model.CountryEnabled = _customerSettings.CountryEnabled;

            model.StateProvinceId = _currentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId);
            model.StateProvinceRequired = _customerSettings.StateProvinceRequired;
            model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;

            model.Phone = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Phone);
            model.PhoneEnabled = _customerSettings.PhoneEnabled;
            model.PhoneRequired = _customerSettings.PhoneRequired;

            model.Fax = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Fax);
            model.FaxEnabled = _customerSettings.FaxEnabled;
            model.FaxRequired = _customerSettings.FaxRequired;

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            #region All Other customer attributes for "Individual" (PDF 1)

            var individualBasic = _bDAddressService.GetIndividualBasicInfo(_currentCustomer.Id);
            var individualJointInfo = _bDAddressService.GetIndividualJointInfo(_currentCustomer.Id);
            if (!model.invalidForm)
            {
                if (individualBasic != null)
                {
                    model.IndividualBasicId = individualBasic.Id;
                    model.Address_Years = individualBasic.Address_Years;
                    model.Home_Address = individualBasic.Home_Address;
                    model.Home_City = individualBasic.Home_City;
                    model.Home_Country = individualBasic.Home_Country;
                    model.Home_State = individualBasic.Home_State;
                    model.Home_Zip = individualBasic.Home_Zip;
                    model.SSN = individualBasic.SSN;
                    model.Driver_License = individualBasic.Driver_License;
                    model.Driver_Country = individualBasic.Driver_Country;
                    model.Driver_State = individualBasic.Driver_State;
                    model.USA_Citizen_Country = individualBasic.USA_Citizen_Country;
                    model.USA_Citizen = individualBasic.USA_Citizen;
                    model.Cell_Phone = individualBasic.Cell_Phone;
                    model.Employer_Name = individualBasic.Employer_Name;
                    model.Employer_Street = individualBasic.Employer_Street;
                    model.Employer_City = individualBasic.Employer_City;
                    model.Employer_Country = individualBasic.Employer_Country;
                    model.Employer_State = individualBasic.Employer_State;
                    model.Employer_Zip = individualBasic.Employer_Zip;
                    model.Employer_Business_Type = individualBasic.Employer_Business_Type;
                    model.Employer_Position = individualBasic.Employer_Position;
                    model.Employer_YRS = individualBasic.Employer_YRS;
                    model.Employer_Phone = individualBasic.Employer_Phone;
                    model.Employer_Email = individualBasic.Employer_Email;
                    model.Income1 = individualBasic.Income1;
                    model.Income2 = individualBasic.Income2;
                    model.Income3 = individualBasic.Income3;

                    // Joint account info                    
                    if (individualJointInfo != null)
                    {
                        model.IndividualJointInfoModel.IndividualBasicId = individualJointInfo.Id;
                        model.IndividualJointInfoModel.FirstName = individualJointInfo.FirstName;
                        model.IndividualJointInfoModel.LastName = individualJointInfo.LastName;
                        model.IndividualJointInfoModel.Street = individualJointInfo.Street;
                        model.IndividualJointInfoModel.City = individualJointInfo.City;
                        model.IndividualJointInfoModel.Country = individualJointInfo.Country;
                        model.IndividualJointInfoModel.State = individualJointInfo.State;
                        model.IndividualJointInfoModel.Zip = individualJointInfo.Zip;
                        model.IndividualJointInfoModel.Address_Years = individualJointInfo.Address_Years;
                        model.IndividualJointInfoModel.SSN = individualJointInfo.SSN;

                        model.IndividualJointInfoModel.Home_Street = individualJointInfo.Home_Street;
                        model.IndividualJointInfoModel.DateOfBirth = individualJointInfo.DateOfBirth;
                        model.IndividualJointInfoModel.Home_Phone = individualJointInfo.Home_Phone;
                        model.IndividualJointInfoModel.Home_Email = individualJointInfo.Home_Email;
                        model.IndividualJointInfoModel.Home_City = individualJointInfo.Home_City;
                        model.IndividualJointInfoModel.Home_Country = individualJointInfo.Home_Country;
                        model.IndividualJointInfoModel.Home_State = individualJointInfo.Home_State;
                        model.IndividualJointInfoModel.Home_Zip = individualJointInfo.Home_Zip;
                        model.IndividualJointInfoModel.Driver_License = individualJointInfo.Driver_License;
                        model.IndividualJointInfoModel.Driver_Country = individualJointInfo.Driver_Country;
                        model.IndividualJointInfoModel.Driver_State = individualJointInfo.Driver_State;
                        model.IndividualJointInfoModel.USA_Citizen_Country = individualJointInfo.USA_Citizen_Country;
                        model.IndividualJointInfoModel.USA_Citizen = individualJointInfo.USA_Citizen;
                        model.IndividualJointInfoModel.Cell_Phone = individualJointInfo.Cell_Phone;

                        model.IndividualJointInfoModel.Employer_Name = individualJointInfo.Employer_Name;
                        model.IndividualJointInfoModel.Employer_Street = individualJointInfo.Employer_Street;
                        model.IndividualJointInfoModel.Employer_City = individualJointInfo.Employer_City;
                        model.IndividualJointInfoModel.Employer_Country = individualJointInfo.Employer_Country;
                        model.IndividualJointInfoModel.Employer_State = individualJointInfo.Employer_State;
                        model.IndividualJointInfoModel.Employer_Zip = individualJointInfo.Employer_Zip;
                        model.IndividualJointInfoModel.Employer_Business_Type = individualJointInfo.Employer_Business_Type;
                        model.IndividualJointInfoModel.Employer_Position = individualJointInfo.Employer_Position;
                        model.IndividualJointInfoModel.Employer_YRS = individualJointInfo.Employer_YRS;
                        model.IndividualJointInfoModel.Employer_Phone = individualJointInfo.Employer_Phone;
                        model.IndividualJointInfoModel.Employer_Email = individualJointInfo.Employer_Email;
                    }
                }
            }

            #region Available Years

            model.AvailableAddressYears.Add(new SelectListItem
            {
                Text = "Select Year",
                Value = "0"
            });
            model.AvailableEmployerYears.Add(new SelectListItem
            {
                Text = "Select Year",
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableAddressYears.Add(new SelectListItem
            {
                Text = "Select Year",
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableEmployerYears.Add(new SelectListItem
            {
                Text = "Select Year",
                Value = "0"
            });
            for (int i = 1; i < 20; i++)
            {
                model.AvailableAddressYears.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString(),
                    Selected = i.ToString() == ((individualBasic != null) ? individualBasic.Address_Years : "0")
                });
                model.AvailableEmployerYears.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString(),
                    Selected = i.ToString() == ((individualBasic != null) ? individualBasic.Employer_YRS : "0")
                });
                model.IndividualJointInfoModel.AvailableAddressYears.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString(),
                    Selected = i.ToString() == ((individualJointInfo != null) ? individualJointInfo.Address_Years : "0")
                });
                model.IndividualJointInfoModel.AvailableEmployerYears.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString(),
                    Selected = i.ToString() == ((individualJointInfo != null) ? individualJointInfo.Employer_YRS : "0")
                });
            }
            model.AvailableAddressYears.Add(new SelectListItem
            {
                Text = "20+",
                Value = "20+",
                Selected = "20+" == ((individualBasic != null) ? individualBasic.Address_Years : "0")
            });
            model.AvailableEmployerYears.Add(new SelectListItem
            {
                Text = "20+",
                Value = "20+",
                Selected = "20+" == ((individualBasic != null) ? individualBasic.Employer_YRS : "0")
            });
            model.IndividualJointInfoModel.AvailableAddressYears.Add(new SelectListItem
            {
                Text = "20+",
                Value = "20+",
                Selected = "20+" == ((individualJointInfo != null) ? individualJointInfo.Address_Years : "0")
            });
            model.IndividualJointInfoModel.AvailableEmployerYears.Add(new SelectListItem
            {
                Text = "20+",
                Value = "20+",
                Selected = "20+" == ((individualJointInfo != null) ? individualJointInfo.Employer_YRS : "0")
            });

            #endregion

            #endregion

            #region Countries and states

            //countries and states
            model.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.AvailableHomeCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.AvailableDriverCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.AvailableUSACitizenCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.AvailableEmployerCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });

            model.IndividualJointInfoModel.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableHomeCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableDriverCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableUSACitizenCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.IndividualJointInfoModel.AvailableEmployerCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });

            model.CountryRequired = _customerSettings.CountryRequired;
            model.CountryEnabled = _customerSettings.CountryEnabled;

            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                model.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.CountryId
                });
                model.AvailableHomeCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Home_Country
                });
                model.AvailableDriverCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Driver_Country
                });
                model.AvailableUSACitizenCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.USA_Citizen_Country
                });
                model.AvailableEmployerCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Employer_Country
                });


                model.IndividualJointInfoModel.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.CountryId
                });
                model.IndividualJointInfoModel.AvailableHomeCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Home_Country
                });
                model.IndividualJointInfoModel.AvailableDriverCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Driver_Country
                });
                model.IndividualJointInfoModel.AvailableUSACitizenCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.USA_Citizen_Country
                });
                model.IndividualJointInfoModel.AvailableEmployerCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.Employer_Country
                });
            }

            model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;
            model.StateProvinceRequired = _customerSettings.StateProvinceRequired;
            //states
            var states =
                _stateProvinceService.GetStateProvincesByCountryId(model.CountryId,
                    _workContext.WorkingLanguage.Id).ToList();
            if (states.Count > 0)
            {
                model.AvailableStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in states)
                {
                    model.AvailableStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.StateProvinceId)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.AvailableCountries.Any(x => x.Selected);

                model.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // Home States
            var homeStates =
              _stateProvinceService.GetStateProvincesByCountryId(model.Home_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (homeStates.Count > 0)
            {
                model.AvailableHomeStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in homeStates)
                {
                    model.AvailableHomeStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.Home_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.Home_Country > 0;

                model.AvailableHomeStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // driver states
            var driverStates =
              _stateProvinceService.GetStateProvincesByCountryId(model.Driver_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (driverStates.Count > 0)
            {
                model.AvailableDriverStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in driverStates)
                {
                    model.AvailableDriverStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.Driver_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.Driver_Country > 0;

                model.AvailableDriverStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // employer states
            var employerStates =
              _stateProvinceService.GetStateProvincesByCountryId(model.Employer_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (employerStates.Count > 0)
            {
                model.AvailableEmployerStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in employerStates)
                {
                    model.AvailableEmployerStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.Employer_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.Employer_Country > 0;

                model.AvailableEmployerStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            #region Joint account states

            //states
            var states_joint =
                _stateProvinceService.GetStateProvincesByCountryId(model.IndividualJointInfoModel.Country,
                    _workContext.WorkingLanguage.Id).ToList();
            if (states_joint.Count > 0)
            {
                model.IndividualJointInfoModel.AvailableStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in states_joint)
                {
                    model.IndividualJointInfoModel.AvailableStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.IndividualJointInfoModel.State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.IndividualJointInfoModel.AvailableCountries.Any(x => x.Selected);

                model.IndividualJointInfoModel.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // Home States
            var homeStates_joint =
              _stateProvinceService.GetStateProvincesByCountryId(model.IndividualJointInfoModel.Home_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (homeStates_joint.Count > 0)
            {
                model.IndividualJointInfoModel.AvailableHomeStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in homeStates_joint)
                {
                    model.IndividualJointInfoModel.AvailableHomeStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.IndividualJointInfoModel.Home_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.Home_Country > 0;

                model.IndividualJointInfoModel.AvailableHomeStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // driver states
            var driverStates_joint =
              _stateProvinceService.GetStateProvincesByCountryId(model.IndividualJointInfoModel.Driver_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (driverStates_joint.Count > 0)
            {
                model.IndividualJointInfoModel.AvailableDriverStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in driverStates_joint)
                {
                    model.IndividualJointInfoModel.AvailableDriverStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.IndividualJointInfoModel.Driver_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.IndividualJointInfoModel.Driver_Country > 0;

                model.IndividualJointInfoModel.AvailableDriverStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // employer states
            var employerStates_joint =
              _stateProvinceService.GetStateProvincesByCountryId(model.IndividualJointInfoModel.Employer_Country,
                  _workContext.WorkingLanguage.Id).ToList();
            if (employerStates_joint.Count > 0)
            {
                model.IndividualJointInfoModel.AvailableEmployerStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in employerStates_joint)
                {
                    model.IndividualJointInfoModel.AvailableEmployerStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.IndividualJointInfoModel.Employer_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.IndividualJointInfoModel.Employer_Country > 0;

                model.IndividualJointInfoModel.AvailableEmployerStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            #endregion

            #endregion
        }

        [NonAction]
        private void PrepareOtherTypeInformationModel(OtherInfoModel otherInfoModel, IndividualsModel individualsModel,
            string infoType)
        {
            otherInfoModel.InfoType = infoType;

            var langId = _workContext.WorkingLanguage.Id;
            otherInfoModel.CompanyLabel =
                _localizationService.GetResource(
                    string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                        ClientConstants.Localization.KeyTypes.Fields, infoType.Replace(
                            " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty) + "Name"), langId);

            var companyAddress = new Address();
            foreach (var address in _currentCustomer.Addresses)
            {
                var addressAttributes = _addressAttributeParser.ParseAddressAttributeValues(address.CustomAttributes);
                foreach (var addressAttribute in addressAttributes)
                {
                    if (addressAttribute.AddressAttribute.Name == ClientConstants.CustomAttributes.CompanyAddress)
                    {
                        companyAddress = address;
                        break;
                    }
                }
            }
            otherInfoModel.CompanyInfo.Company = companyAddress.Company;
            otherInfoModel.CompanyInfo.CompanyRequired = _addressSettings.CompanyRequired;
            otherInfoModel.CompanyInfo.CompanyEnabled = _addressSettings.CompanyEnabled;

            otherInfoModel.CompanyInfo.Address1 = companyAddress.Address1;
            otherInfoModel.CompanyInfo.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            otherInfoModel.CompanyInfo.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;

            otherInfoModel.CompanyInfo.Address2 = companyAddress.Address2;
            otherInfoModel.CompanyInfo.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            otherInfoModel.CompanyInfo.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;

            otherInfoModel.CompanyInfo.ZipPostalCode = companyAddress.ZipPostalCode;
            otherInfoModel.CompanyInfo.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            otherInfoModel.CompanyInfo.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;

            otherInfoModel.CompanyInfo.City = companyAddress.City;
            otherInfoModel.CompanyInfo.CityRequired = _customerSettings.CityRequired;
            otherInfoModel.CompanyInfo.CityEnabled = _customerSettings.CityEnabled;

            otherInfoModel.CompanyInfo.CountryId = companyAddress.CountryId;
            otherInfoModel.CompanyInfo.CountryEnabled = _customerSettings.CountryEnabled;

            otherInfoModel.CompanyInfo.StateProvinceId = companyAddress.StateProvinceId;
            otherInfoModel.CompanyInfo.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;

            otherInfoModel.CompanyInfo.PhoneNumber = companyAddress.PhoneNumber;
            otherInfoModel.CompanyInfo.PhoneEnabled = _customerSettings.PhoneEnabled;
            otherInfoModel.CompanyInfo.PhoneRequired = _customerSettings.PhoneRequired;


            otherInfoModel.CompanyInfo.FaxNumber = companyAddress.FaxNumber;
            otherInfoModel.CompanyInfo.FaxEnabled = _customerSettings.FaxEnabled;
            otherInfoModel.CompanyInfo.FaxRequired = _customerSettings.FaxRequired;

            otherInfoModel.CompanyInfo.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
            otherInfoModel.CompanyInfo.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);

            #region Countries and states

            //countries and states


            otherInfoModel.CompanyInfo.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            otherInfoModel.AvailableBusinessCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                otherInfoModel.CompanyInfo.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == otherInfoModel.CompanyInfo.CountryId
                });
                otherInfoModel.AvailableBusinessCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == otherInfoModel.Business_Country
                });
            }

            //states

            if (otherInfoModel.CompanyInfo.CountryId.HasValue)
            {
                var states =
                    _stateProvinceService.GetStateProvincesByCountryId(otherInfoModel.CompanyInfo.CountryId.Value,
                        _workContext.WorkingLanguage.Id).ToList();
                if (states.Count > 0)
                {
                    otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                    {
                        Text = _localizationService.GetResource("Address.SelectState"),
                        Value = "0"
                    });

                    foreach (var s in states)
                    {
                        otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                        {
                            Text = s.GetLocalized(x => x.Name),
                            Value = s.Id.ToString(),
                            Selected = (s.Id == otherInfoModel.CompanyInfo.StateProvinceId)
                        });
                    }
                }

                bool anyCountrySelected = otherInfoModel.CompanyInfo.AvailableCountries.Any(x => x.Selected);

                otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });

            }
            else
            {
                bool anyCountrySelected = otherInfoModel.CompanyInfo.AvailableCountries.Any(x => x.Selected);

                otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            // business states


            var businessStates =
                _stateProvinceService.GetStateProvincesByCountryId(otherInfoModel.Business_Country,
                    _workContext.WorkingLanguage.Id).ToList();
            if (businessStates.Count > 0)
            {
                otherInfoModel.AvailableBusinessStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in businessStates)
                {
                    otherInfoModel.AvailableBusinessStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == otherInfoModel.Business_State)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = otherInfoModel.Business_Country > 0;

                otherInfoModel.AvailableBusinessStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            #endregion

            otherInfoModel.CompanyInfo.Email = companyAddress.Email;

            #region // All Other address attributes for "Company" (PDF 2)
            otherInfoModel.RegionFormed =
                _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.RegionFormedIn);

            otherInfoModel.ContactName =
                _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.ContactName);

            //Tax Id
            otherInfoModel.TaxId = _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes, 
                    ClientConstants.CustomAttributes.TaxId);

            otherInfoModel.VestingName =
               _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                   ClientConstants.CustomAttributes.VestingName);

            if (!otherInfoModel.invalidForm)
            {
                var companyBasic = _bDAddressService.GetCompanyBasicInfo(_currentCustomer.Id);
                if (companyBasic != null)
                {
                    otherInfoModel.CompanyBasicId = companyBasic.Id;
                    otherInfoModel.EIN = companyBasic.EIN;
                    otherInfoModel.Business_City = companyBasic.Business_City;
                    otherInfoModel.Business_Country = companyBasic.Business_Country;
                    otherInfoModel.Business_State = companyBasic.Business_State;
                    otherInfoModel.Business_Zip = companyBasic.Business_Zip;
                    otherInfoModel.Business_Website = companyBasic.Business_Website;
                }
            }
            #endregion

            // commented by bhavik
            //PrepareIndividualsInformationModel(individualsModel);
        }



        [NonAction]
        private void PrepareInvestorTypeModel(InvestorTypeModel model)
        {
            var investorTypeAttrubute = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                ClientConstants.CustomAttributes.InvestorType);

            #region Check For Investor Permitted - Decide to show Accredited or Non-Accredited box
            if (investorTypeAttrubute != null && investorTypeAttrubute.Any())
            {
                var settings = _settingsService.LoadSetting<CrowdPaySettings>();
                if (settings.SingleOfferProductId > 0)
                {
                    int result = _bDAddressService.CheckForTypeAndNumberOfInvestor(settings.SingleOfferProductId, _storeContext.CurrentStore.Id);
                    if (result == 3)
                    {
                        investorTypeAttrubute = investorTypeAttrubute.Where(it => it.Name != ClientConstants.InvestorType.Accreddited &&
                            it.Name != ClientConstants.InvestorType.NonAccreditted).ToList();
                    }
                    else if (result == 2)
                    {
                        investorTypeAttrubute = investorTypeAttrubute.Where(it => it.Name != ClientConstants.InvestorType.Accreddited).ToList();
                    }
                    else if (result == 1)
                    {
                        investorTypeAttrubute = investorTypeAttrubute.Where(it => it.Name != ClientConstants.InvestorType.NonAccreditted).ToList();
                    }
                }
            }
            #endregion

            model.InvestorTypeList = GetSelectListItemsModel(investorTypeAttrubute);

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            model.SelectedInvestorType = investorType ?? ClientConstants.InvestorType.NonAccreditted;
        }

        [NonAction]
        private void PrepareInformationGatheringModel(InformationGatheringModel informationGatheringModel, string investorType)
        {
            if (investorType == ClientConstants.InvestorType.Accreddited)
            {
                informationGatheringModel.AccreditedInvestor = true;
                var accreditedQualifyList = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                  ClientConstants.CustomAttributes.AccreditedQualify);

                informationGatheringModel.AccreditedInvestorQualifyList = GetSelectListItemsModel(accreditedQualifyList);
            }
            var existAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            var annualIncome = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.AnnualIncome);
            var netWorth = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.NetWorth);

            var selectedQualifyValue = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.AccreditedQualify);

            var backUpWithholdingList = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                  ClientConstants.CustomAttributes.BackUpWithholding);

            informationGatheringModel.BackupWithholdingList = GetSelectListItemsModel(backUpWithholdingList);

            var selectedBackupWithholdingValue = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.BackUpWithholding);

            informationGatheringModel.AnnualIncome = !String.IsNullOrEmpty(annualIncome) ? Convert.ToDecimal(annualIncome) : 0;
            informationGatheringModel.NetWorth = !String.IsNullOrEmpty(netWorth) ? Convert.ToDecimal(netWorth) : 0;
            informationGatheringModel.SelectedQualify = selectedQualifyValue;
            informationGatheringModel.SelectedBackupWithholding = selectedBackupWithholdingValue;
            informationGatheringModel.InvestorType = investorType;

            var currentCurrency = _currencyService.GetCurrencyById(_workContext.WorkingCurrency.Id);
            if (currentCurrency != null)
            {
                informationGatheringModel.CurrencySymbol = !String.IsNullOrEmpty(currentCurrency.DisplayLocale)
                    ? new RegionInfo(currentCurrency.DisplayLocale).CurrencySymbol
                    : String.Empty;
                informationGatheringModel.CurrencyName = currentCurrency.CurrencyCode.ToUpper();
            }

            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!CanSkipPersonalOtherStepsAndPDFVerification(settings))
            {
                ViewBag.ShowUploadDocuments = true;
                PrepareUploadDocumentsModel(informationGatheringModel);
            }
        }

        [NonAction]
        private void PreparePurchaseModel(PurchaseModel purchaseModel)
        {

            var tempProductAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            if (tempProductAttribute != null)
            {
                var product = _productService.GetProductById(int.Parse(tempProductAttribute.Value));
                if (product != null)
                {
                    var currentCurrency = _currencyService.GetCurrencyById(_workContext.WorkingCurrency.Id);
                    if (currentCurrency != null)
                    {
                        purchaseModel.CurrencySymbol = !String.IsNullOrEmpty(currentCurrency.DisplayLocale)
                            ? new RegionInfo(currentCurrency.DisplayLocale).CurrencySymbol
                            : String.Empty;

                        if (String.IsNullOrEmpty(purchaseModel.CurrencySymbol) && !String.IsNullOrEmpty(currentCurrency.CustomFormatting))
                        {
                            purchaseModel.CurrencySymbol = currentCurrency.CustomFormatting[0].ToString();
                        }
                    }
                    purchaseModel.MaximumSharesCount = product.StockQuantity;
                    purchaseModel.MinimumSharesCount = product.OrderMinimumQuantity;

                    decimal taxRate;
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    purchaseModel.PerShare = finalPriceWithoutDiscount;

                    purchaseModel.MinimumInvest = finalPriceWithoutDiscount * product.OrderMinimumQuantity;
                    purchaseModel.MaximumInvest = (finalPriceWithoutDiscount * product.StockQuantity);
                }
            }

            var existAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            var annualIncome = Convert.ToDecimal(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.AnnualIncome));
            var netWorth = Convert.ToDecimal(_customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.NetWorth));
            purchaseModel.MaxShareAmount = (Math.Max(annualIncome, netWorth) * 10) / 100;

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);
            purchaseModel.SelectedInvestorType = investorType ?? ClientConstants.InvestorType.NonAccreditted;

            //add payment methods
            var paymentMethods = _paymentService
                .LoadActivePaymentMethods(_workContext.CurrentCustomer, _storeContext.CurrentStore.Id)
                .Where(pm => pm.PaymentMethodType == PaymentMethodType.Standard || pm.PaymentMethodType == PaymentMethodType.Redirection)
               .ToList();
            foreach (var pm in paymentMethods)
            {

                var pmModel = new CheckoutPaymentMethodModel.PaymentMethodModel
                {
                    Name = pm.GetLocalizedFriendlyName(_localizationService, _workContext.WorkingLanguage.Id),
                    PaymentMethodSystemName = pm.PluginDescriptor.SystemName,
                    LogoUrl = pm.PluginDescriptor.GetLogoUrl(_webHelper)
                };

                purchaseModel.PaymentMethods.Add(pmModel);
            }

            //find a selected (previously) payment method
            var selectedPaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            if (!String.IsNullOrEmpty(selectedPaymentMethodSystemName))
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.ToList()
                    .Find(pm => pm.PaymentMethodSystemName.Equals(selectedPaymentMethodSystemName, StringComparison.InvariantCultureIgnoreCase));
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }
            //if no option has been selected, let's do it for the first one
            if (purchaseModel.PaymentMethods.FirstOrDefault(so => so.Selected) == null)
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.FirstOrDefault();
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }

        }

        [NonAction]
        private ProductDetailsModel PrepareSimpleProductDetailsModel(Product product)
        {
            if (product == null)
                throw new ArgumentNullException("product");

            var model = new ProductDetailsModel
            {
                Id = product.Id,
                Name = product.GetLocalized(x => x.Name),
                SeName = product.GetSeName(),
            };

            model.ProductPrice.ProductId = product.Id;

            model.ProductPrice.HidePrices = false;
            if (product.CustomerEntersPrice)
            {
                model.ProductPrice.CustomerEntersPrice = true;
            }
            else
            {
                if (product.CallForPrice)
                {
                    model.ProductPrice.CallForPrice = true;
                }
                else
                {
                    decimal taxRate;
                    decimal oldPriceBase = _taxService.GetProductPrice(product, product.OldPrice, out taxRate);
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: true), out taxRate);

                    decimal oldPrice = _currencyService.ConvertFromPrimaryStoreCurrency(oldPriceBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithDiscountBase, _workContext.WorkingCurrency);

                    if (finalPriceWithoutDiscountBase != oldPriceBase && oldPriceBase > decimal.Zero)
                        model.ProductPrice.OldPrice = _priceFormatter.FormatPrice(oldPrice);

                    model.ProductPrice.Price = _priceFormatter.FormatPrice(finalPriceWithoutDiscount);

                    if (finalPriceWithoutDiscountBase != finalPriceWithDiscountBase)
                        model.ProductPrice.PriceWithDiscount = _priceFormatter.FormatPrice(finalPriceWithDiscount);

                    model.ProductPrice.PriceValue = finalPriceWithDiscount;
                }
            }

            return model;
        }

        [NonAction]
        protected SigningCeremonyModel PrepareSigningModel(string attributeName)
        {
            var tempProductIdAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);

            var product = _productService.GetProductById(int.Parse(tempProductIdAttribute.Value));

            var model = new SigningCeremonyModel();

            var templateAttribute = product.ProductSpecificationAttributes.SingleOrDefault(
               x =>
                   x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                   attributeName);

            var useNewTemplate = false;
            if (templateAttribute != null)
            {
                var oldTemplateId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                           String.Format(ClientConstants.TempCheckOutGenericAttirubutes.OldTemplateId, product.Id,
                               attributeName));
                if (oldTemplateId != null)
                {
                    if (templateAttribute.CustomValue != oldTemplateId.Value)
                    {
                        useNewTemplate = true;
                    }
                }

                var temporaryEnvelopeId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                 String.Format(ClientConstants.TempCheckOutGenericAttirubutes.TemporaryEnvelopId, product.Id,
                     attributeName));

                var succesfullySingedDocument =
             _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                 String.Format(ClientConstants.TempCheckOutGenericAttirubutes.SuccesfulyEnvelopId, product.Id,
                     attributeName));
                if (succesfullySingedDocument != null && temporaryEnvelopeId == null && !useNewTemplate)
                {

                    model.DocumentUrl = Url.Action("DownloadFile", "CrowdPayCheckOut",
                        new { templateId = succesfullySingedDocument.Value });

                    model.ShowContinue = true;

                    if (attributeName == ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId)
                    {
                        model.ShowBack = true;
                    }
                }
                else
                {
                    model.DocumentUrl = _docusignService.GenerateSigningSessionUrl(attributeName, product.Id, string.Empty);
                }
            }

            return model;
        }

        [NonAction]
        protected ConfirmOrderModel PrepareConfirmOrderModel()
        {
            var tempProductIdAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.ProductId);
            var tempQuantityAttribute = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(ClientConstants.TempCheckOutGenericAttirubutes.DeliveredQuantity);

            var product = _productService.GetProductById(int.Parse(tempProductIdAttribute.Value));
            var productModel = PrepareSimpleProductDetailsModel(product);

            var model = new ConfirmOrderModel
            {
                DeliveredQuantity = int.Parse(tempQuantityAttribute.Value),
                ProductId = int.Parse(tempProductIdAttribute.Value),
                DeliveredProduct = productModel,
                Warnings = new List<string>()
            };

            return model;
        }

        [NonAction]
        private IList<SelectListItem> GetSelectListItemsModel(IList<CustomerAttributeValue> attributeValues)
        {
            var langId = _workContext.WorkingLanguage.Id;

            var query = attributeValues.Select(x => new SelectListItem()
            {
                Text = _localizationService.GetResource(
                        string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                            ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                Selected = x.IsPreSelected,
                Value = x.Name
            }).ToList();

            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!settings.VerifyInvestorValidationEnabled && !settings.SelfAccredited && !settings.InternalAccreditation)
            {
                return attributeValues.Where(x => x.Name == ClientConstants.InvestorType.NonAccreditted).Select(x => new SelectListItem()
                {
                    Text = _localizationService.GetResource(
                            string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                                ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                    " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                    Selected = (attributeValues.Count() > 1) ? x.IsPreSelected : true,
                    Value = x.Name
                }).ToList();
            }
            else
            {
                return attributeValues.Select(x => new SelectListItem()
                {
                    Text = _localizationService.GetResource(
                            string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                                ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                    " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                    Selected = (attributeValues.Count() > 1) ? x.IsPreSelected : true,
                    Value = x.Name
                }).ToList();
            }
        }

        [NonAction]
        private void PrepareUploadDocumentsModel(InformationGatheringModel informationGatheringModel)
        {
            var documents = _bDAddressService.GetDocumentsByCustomer(_currentCustomer.Id);
            foreach (var doc in documents)
            {
                var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadById(doc.DocumentUploadId);
                informationGatheringModel.UploadedDocumentList.Add(new UploadDocument()
                {
                    DocumentId = doc.Id,
                    Filename = (download != null) ? download.Filename + download.Extension : "",
                    DocumentUrl = (download != null) ? "/crowdpay/DownloadDocument?downloadGuid=" + download.DownloadGuid : "",
                    description = doc.description,
                    InvestorComment = doc.InvestorComment,
                    ReadOnlyDocument = true
                });
            }
            if (documents.Count() < 10)
            {
                for (int i = 0; i < 10 - documents.Count(); i++)
                {
                    informationGatheringModel.UploadDocumentList.Add(new UploadDocument()
                    {
                        DocumentId = 0,
                        DocumentUploadId = 0,
                        description = ""
                    });
                }
            }
        }

        protected VerificationTemplateModel PrepareVerificationHTMLTemplate()
        {
            var model = Session["PersonalInformationModel"] as PersonalInformationModel;
            VerificationTemplateModel verificationTemplateModel = new VerificationTemplateModel();
            if (model != null)
            {
                var template = _bDAddressService.GetVerificationTemplateByCustomer(_currentCustomer.Id);
                if (template != null)
                {
                    string HTMLTemplate = string.Empty;
                    if (model.SelectedPersonalInfoType == ClientConstants.PersonalInfoType.Individual)
                    {
                        HTMLTemplate = template.HTMLTemplateIndividual;
                        if (!string.IsNullOrEmpty(HTMLTemplate))
                        {
                            StringBuilder sb = new StringBuilder(HTMLTemplate);
                            sb = SetSignToken("%Initials%", sb, "smallSign", "smallSign");
                            sb = SetSignToken("%Signature%", sb, "bigSign", "bigSign");
                            if (model.IniIndividualsModel != null)
                            {
                                IndividualsModel individualBasic = model.IniIndividualsModel;
                                sb.Replace("%IndividualBasic.Email%", individualBasic.Email);
                                sb.Replace("%IndividualBasic.LastName%", individualBasic.LastName);
                                sb.Replace("%IndividualBasic.FirstName%", individualBasic.FirstName);
                                sb.Replace("%IndividualBasic.DateOfBirth%", individualBasic.DateOfBirth);
                                sb.Replace("%IndividualBasic.StreetAddress%", individualBasic.StreetAddress);
                                sb.Replace("%IndividualBasic.StreetAddress2%", individualBasic.StreetAddress2);
                                sb.Replace("%IndividualBasic.ZipPostalCode%", individualBasic.ZipPostalCode);
                                sb.Replace("%IndividualBasic.City%", individualBasic.City);
                                if (individualBasic.CountryId > 0)
                                    sb.Replace("%IndividualBasic.Country%", _countryService.GetCountryById(individualBasic.CountryId).Name);
                                if (individualBasic.StateProvinceId > 0)
                                    sb.Replace("%IndividualBasic.StateProvince%", _stateProvinceService.GetStateProvinceById(individualBasic.StateProvinceId).Name);
                                sb.Replace("%IndividualBasic.Phone%", individualBasic.Phone);
                                sb.Replace("%IndividualBasic.Fax%", individualBasic.Fax);

                                sb.Replace("%IndividualBasic.Address_Years%", individualBasic.Address_Years);
                                sb.Replace("%IndividualBasic.Home_Address%", individualBasic.Home_Address);
                                sb.Replace("%IndividualBasic.Home_City%", individualBasic.Home_City);
                                if (individualBasic.Home_Country > 0)
                                    sb.Replace("%IndividualBasic.Home_Country%", _countryService.GetCountryById(individualBasic.Home_Country).Name);
                                if (individualBasic.Home_State > 0)
                                    sb.Replace("%IndividualBasic.Home_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Home_State).Name);
                                sb.Replace("%IndividualBasic.Home_Zip%", individualBasic.Home_Zip);
                                sb.Replace("%IndividualBasic.SSN%", individualBasic.SSN);
                                sb.Replace("%IndividualBasic.Driver_License%", individualBasic.Driver_License);
                                if (individualBasic.Driver_Country > 0)
                                    sb.Replace("%IndividualBasic.Driver_Country%", _countryService.GetCountryById(individualBasic.Driver_Country).Name);
                                if (individualBasic.Driver_State > 0)
                                    sb.Replace("%IndividualBasic.Driver_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Driver_State).Name);
                                if (individualBasic.USA_Citizen_Country > 0)
                                    sb.Replace("%IndividualBasic.USA_Citizen_Country%", _countryService.GetCountryById(individualBasic.USA_Citizen_Country).Name);
                                sb.Replace("%IndividualBasic.USA_Citizen%", (Convert.ToBoolean(individualBasic.USA_Citizen)) ? "Yes" : "No");
                                sb.Replace("%IndividualBasic.Cell_Phone%", individualBasic.Cell_Phone);
                                sb.Replace("%IndividualBasic.Employer_Name%", individualBasic.Employer_Name);
                                sb.Replace("%IndividualBasic.Employer_Street%", individualBasic.Employer_Street);
                                sb.Replace("%IndividualBasic.Employer_City%", individualBasic.Employer_City);
                                if (individualBasic.Employer_Country > 0)
                                    sb.Replace("%IndividualBasic.Employer_Country%", _countryService.GetCountryById(individualBasic.Employer_Country).Name);
                                if (individualBasic.Employer_State > 0)
                                    sb.Replace("%IndividualBasic.Employer_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Employer_State).Name);
                                sb.Replace("%IndividualBasic.Employer_Zip%", individualBasic.Employer_Zip);
                                sb.Replace("%IndividualBasic.Employer_Business_Type%", individualBasic.Employer_Business_Type);
                                sb.Replace("%IndividualBasic.Employer_Position%", individualBasic.Employer_Position);
                                sb.Replace("%IndividualBasic.Employer_YRS%", individualBasic.Employer_YRS);
                                sb.Replace("%IndividualBasic.Employer_Phone%", individualBasic.Employer_Phone);
                                sb.Replace("%IndividualBasic.Employer_Email%", individualBasic.Employer_Email);
                                sb.Replace("%IndividualBasic.Income1%", (individualBasic.Income1) ? "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />" : "No");
                                sb.Replace("%IndividualBasic.Income2%", (individualBasic.Income2) ? "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />" : "No");
                                sb.Replace("%IndividualBasic.Income3%", (individualBasic.Income3) ? "<img src='/Plugins/BD.CrowdPay/Content/images/tick.png' alt='Yes' />" : "No");


                                if (individualBasic.IndividualJointInfoModel != null)
                                {
                                    IndividualJointInfoModel individualJointInfo = individualBasic.IndividualJointInfoModel;
                                    sb.Replace("%IndividualJointInfo.FirstName%", individualJointInfo.FirstName);
                                    sb.Replace("%IndividualJointInfo.LastName%", individualJointInfo.LastName);
                                    sb.Replace("%IndividualJointInfo.Street%", individualJointInfo.Street);
                                    sb.Replace("%IndividualJointInfo.City%", individualJointInfo.City);
                                    sb.Replace("%IndividualJointInfo.Country%", GetCountryName(individualJointInfo.Country));
                                    sb.Replace("%IndividualJointInfo.State%", GetStateName(individualJointInfo.State));
                                    sb.Replace("%IndividualJointInfo.Zip%", individualJointInfo.Zip);
                                    sb.Replace("%IndividualJointInfo.Address_Years%", individualJointInfo.Address_Years);
                                    sb.Replace("%IndividualJointInfo.SSN%", individualJointInfo.SSN);

                                    sb.Replace("%IndividualJointInfo.Home_Street%", individualJointInfo.Home_Street);
                                    sb.Replace("%IndividualJointInfo.DateOfBirth%", individualJointInfo.DateOfBirth);
                                    sb.Replace("%IndividualJointInfo.Home_Phone%", individualJointInfo.Home_Phone);
                                    sb.Replace("%IndividualJointInfo.Home_Email%", individualJointInfo.Home_Email);
                                    sb.Replace("%IndividualJointInfo.Home_City%", individualJointInfo.Home_City);
                                    sb.Replace("%IndividualJointInfo.Home_Country%", GetCountryName(individualJointInfo.Home_Country));
                                    sb.Replace("%IndividualJointInfo.Home_State%", GetStateName(individualJointInfo.Home_State));
                                    sb.Replace("%IndividualJointInfo.Home_Zip%", individualJointInfo.Home_Zip);
                                    sb.Replace("%IndividualJointInfo.Driver_License%", individualJointInfo.Driver_License);
                                    sb.Replace("%IndividualJointInfo.Driver_Country%", GetCountryName(individualJointInfo.Driver_Country));
                                    sb.Replace("%IndividualJointInfo.Driver_State%", GetStateName(individualJointInfo.Driver_State));
                                    sb.Replace("%IndividualJointInfo.USA_Citizen_Country%", GetCountryName(individualJointInfo.USA_Citizen_Country));
                                    sb.Replace("%IndividualJointInfo.USA_Citizen%", (Convert.ToBoolean(individualJointInfo.USA_Citizen)) ? "Yes" : "No");
                                    sb.Replace("%IndividualJointInfo.Cell_Phone%", individualJointInfo.Cell_Phone);

                                    sb.Replace("%IndividualJointInfo.Employer_Name%", individualJointInfo.Employer_Name);
                                    sb.Replace("%IndividualJointInfo.Employer_Street%", individualJointInfo.Employer_Street);
                                    sb.Replace("%IndividualJointInfo.Employer_City%", individualJointInfo.Employer_City);
                                    sb.Replace("%IndividualJointInfo.Employer_Country%", GetCountryName(individualJointInfo.Employer_Country));
                                    sb.Replace("%IndividualJointInfo.Employer_State%", GetStateName(individualJointInfo.Employer_State));
                                    sb.Replace("%IndividualJointInfo.Employer_Zip%", individualJointInfo.Employer_Zip);
                                    sb.Replace("%IndividualJointInfo.Employer_Business_Type%", individualJointInfo.Employer_Business_Type);
                                    sb.Replace("%IndividualJointInfo.Employer_Position%", individualJointInfo.Employer_Position);
                                    sb.Replace("%IndividualJointInfo.Employer_YRS%", individualJointInfo.Employer_YRS);
                                    sb.Replace("%IndividualJointInfo.Employer_Phone%", individualJointInfo.Employer_Phone);
                                    sb.Replace("%IndividualJointInfo.Employer_Email%", individualJointInfo.Employer_Email);
                                    verificationTemplateModel.HTMLTemplateCurrent = sb.ToString();
                                }
                            }
                        }
                    }
                    else
                    {
                        HTMLTemplate = template.HTMLTemplateCompany;
                        if (!string.IsNullOrEmpty(HTMLTemplate.Trim()))
                        {
                            StringBuilder sb = new StringBuilder(HTMLTemplate);
                            sb = SetSignToken("%Initials%", sb, "smallSign", "smallSign");
                            sb = SetSignToken("%Signature%", sb, "bigSign", "bigSign");
                            if (model.OtherInfoModel != null)
                            {
                                OtherInfoModel otherInfoModel = model.OtherInfoModel;
                                if (otherInfoModel.CompanyInfo != null)
                                {
                                    sb.Replace("%Company.CompanyName%", otherInfoModel.CompanyInfo.Company);
                                    sb.Replace("%Company.Address1%", otherInfoModel.CompanyInfo.Address1);
                                    sb.Replace("%Company.Address2%", otherInfoModel.CompanyInfo.Address2);
                                    sb.Replace("%Company.ZipPostalCode%", otherInfoModel.CompanyInfo.ZipPostalCode);
                                    sb.Replace("%Company.City%", otherInfoModel.CompanyInfo.City);
                                    if (otherInfoModel.CompanyInfo.CountryId > 0)
                                        sb.Replace("%Company.Country%", _countryService.GetCountryById(Convert.ToInt32(otherInfoModel.CompanyInfo.CountryId)).Name);
                                    if (otherInfoModel.CompanyInfo.StateProvinceId > 0)
                                        sb.Replace("%Company.StateProvince%", _stateProvinceService.GetStateProvinceById(Convert.ToInt32(otherInfoModel.CompanyInfo.StateProvinceId)).Name);
                                    sb.Replace("%Company.PhoneNumber%", otherInfoModel.CompanyInfo.PhoneNumber);
                                    sb.Replace("%Company.FaxNumber%", otherInfoModel.CompanyInfo.FaxNumber);
                                    sb.Replace("%Company.LastName%", otherInfoModel.CompanyInfo.LastName);
                                    sb.Replace("%Company.FirstName%", otherInfoModel.CompanyInfo.FirstName);
                                }

                                sb.Replace("%Company.RegionFormed%", otherInfoModel.RegionFormed);
                                sb.Replace("%Company.ContactName%", otherInfoModel.ContactName);
                                sb.Replace("%Company.VestingName%", otherInfoModel.VestingName);

                                sb.Replace("%Company.EIN%", otherInfoModel.EIN);
                                sb.Replace("%Company.Business_City%", otherInfoModel.Business_City);
                                if (otherInfoModel.Business_Country > 0)
                                    sb.Replace("%Company.Business_Country%", _countryService.GetCountryById(otherInfoModel.Business_Country).Name);
                                if (otherInfoModel.Business_State > 0)
                                    sb.Replace("%Company.Business_State%", _stateProvinceService.GetStateProvinceById(otherInfoModel.Business_State).Name);
                                sb.Replace("%Company.Business_Zip%", otherInfoModel.Business_Zip);
                                sb.Replace("%Company.Business_Website%", otherInfoModel.Business_Website);

                                verificationTemplateModel.HTMLTemplateCurrent = sb.ToString();
                            }
                        }
                    }
                }
            }
            return verificationTemplateModel;
        }

        protected void PrepareHTMLToPDF(HTMLSignModel htmlSignModel)
        {
            var model = Session["PersonalInformationModel"] as PersonalInformationModel;
            if (model != null)
            {
                var template = _bDAddressService.GetVerificationTemplateByCustomer(_currentCustomer.Id);
                if (template != null)
                {
                    int pdfId = (model.SelectedPersonalInfoType == ClientConstants.PersonalInfoType.Individual) ? template.PDFIndividualUploadId : template.PDFCompanyUploadId;
                    var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadById(pdfId);
                    if (download != null)
                    {
                        if (download.DownloadBinary != null)
                        {
                            // Convert signature JSON to image        
                            foreach (var signJson in htmlSignModel.hdnSignJSONsmallSign)
                            {
                                htmlSignModel.signIamgeSmall.Add(Draw2DLineGraphic(signJson, 65, 39));
                            }
                            foreach (var signJson in htmlSignModel.hdnSignJSONbigSign)
                            {
                                htmlSignModel.signIamgeBig.Add(Draw2DLineGraphic(signJson, 410, 120));
                            }

                            // create PDF
                            // create a new PDF reader based on the PDF template document
                            try
                            {
                                //string pdfTemplate = Server.MapPath("~/Plugins/BD.CrowdPay/Documents/Templates/Subscription-Agreement.pdf");
                                //var pdfReader = new PdfReader(pdfTemplate);
                                var pdfReader = new PdfReader(download.DownloadBinary);

                                // create a new PDF stamper to create investor PDF from template document
                                var investorPdfFile = Server.MapPath(string.Format("~/Plugins/BD.CrowdPay/Documents/{0}-verification-{1}.pdf", model.SelectedPersonalInfoType, _workContext.CurrentCustomer.Email));
                                var pdfStamper = new PdfStamper(pdfReader, new FileStream(investorPdfFile, FileMode.OpenOrCreate));

                                var formFields = SetPDFCommonField(pdfStamper, htmlSignModel, model);
                                int imageCount = 0;
                                foreach (var signImage in htmlSignModel.signIamgeSmall)
                                {
                                    imageCount++;
                                    FillImage("%Initials" + imageCount + "%", pdfStamper, signImage);
                                    //FillImage("image" + 7, pdfStamper, signImage);                    
                                }
                                imageCount = 0;
                                foreach (var signImage in htmlSignModel.signIamgeBig)
                                {
                                    imageCount++;
                                    FillImage("%Signature" + imageCount + "%", pdfStamper, signImage);
                                }

                                if (model.SelectedPersonalInfoType == ClientConstants.PersonalInfoType.Individual)
                                {
                                    if (model.IniIndividualsModel != null)
                                    {
                                        byte[] tickImage = System.IO.File.ReadAllBytes(Server.MapPath("/Plugins/BD.CrowdPay/Content/images/tick.png"));
                                        if (model.IniIndividualsModel.Income1)
                                        {
                                            FillImage("%IndividualBasic.Income1%", pdfStamper, tickImage);
                                        }
                                        if (model.IniIndividualsModel.Income2)
                                        {
                                            FillImage("%IndividualBasic.Income2%", pdfStamper, tickImage);
                                        }
                                        if (model.IniIndividualsModel.Income3)
                                        {
                                            FillImage("%IndividualBasic.Income3%", pdfStamper, tickImage);
                                        }
                                    }
                                }

                                pdfStamper.FormFlattening = true;
                                pdfStamper.Close();
                                pdfReader.Close();
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }
                }
            }
        }

        private AcroFields SetPDFCommonField(PdfStamper pdfStamper, HTMLSignModel htmlSignModel, PersonalInformationModel model)
        {
            // set investor information in PDF
            var formFields = pdfStamper.AcroFields;
            if (model.SelectedPersonalInfoType == ClientConstants.PersonalInfoType.Individual)
            {
                if (model.IniIndividualsModel != null)
                {
                    IndividualsModel individualBasic = model.IniIndividualsModel;
                    formFields.SetField("%IndividualBasic.Email%", individualBasic.Email);
                    formFields.SetField("%IndividualBasic.LastName%", individualBasic.LastName);
                    formFields.SetField("%IndividualBasic.FirstName%", individualBasic.FirstName);
                    formFields.SetField("%IndividualBasic.DateOfBirth%", individualBasic.DateOfBirth);
                    formFields.SetField("%IndividualBasic.StreetAddress%", individualBasic.StreetAddress);
                    formFields.SetField("%IndividualBasic.StreetAddress2%", individualBasic.StreetAddress2);
                    formFields.SetField("%IndividualBasic.ZipPostalCode%", individualBasic.ZipPostalCode);
                    formFields.SetField("%IndividualBasic.City%", individualBasic.City);
                    if (individualBasic.CountryId > 0)
                        formFields.SetField("%IndividualBasic.Country%", _countryService.GetCountryById(individualBasic.CountryId).Name);
                    if (individualBasic.StateProvinceId > 0)
                        formFields.SetField("%IndividualBasic.StateProvince%", _stateProvinceService.GetStateProvinceById(individualBasic.StateProvinceId).Name);
                    formFields.SetField("%IndividualBasic.Phone%", individualBasic.Phone);
                    formFields.SetField("%IndividualBasic.Fax%", individualBasic.Fax);

                    formFields.SetField("%IndividualBasic.Address_Years%", individualBasic.Address_Years);
                    formFields.SetField("%IndividualBasic.Home_Address%", individualBasic.Home_Address);
                    formFields.SetField("%IndividualBasic.Home_City%", individualBasic.Home_City);
                    if (individualBasic.Home_Country > 0)
                        formFields.SetField("%IndividualBasic.Home_Country%", _countryService.GetCountryById(individualBasic.Home_Country).Name);
                    if (individualBasic.Home_State > 0)
                        formFields.SetField("%IndividualBasic.Home_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Home_State).Name);
                    formFields.SetField("%IndividualBasic.Home_Zip%", individualBasic.Home_Zip);
                    formFields.SetField("%IndividualBasic.SSN%", individualBasic.SSN);
                    formFields.SetField("%IndividualBasic.Driver_License%", individualBasic.Driver_License);
                    if (individualBasic.Driver_Country > 0)
                        formFields.SetField("%IndividualBasic.Driver_Country%", _countryService.GetCountryById(individualBasic.Driver_Country).Name);
                    if (individualBasic.Driver_State > 0)
                        formFields.SetField("%IndividualBasic.Driver_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Driver_State).Name);
                    if (individualBasic.USA_Citizen_Country > 0)
                        formFields.SetField("%IndividualBasic.USA_Citizen_Country%", _countryService.GetCountryById(individualBasic.USA_Citizen_Country).Name);
                    formFields.SetField("%IndividualBasic.USA_Citizen%", (Convert.ToBoolean(individualBasic.USA_Citizen)) ? "Yes" : "No");
                    formFields.SetField("%IndividualBasic.Cell_Phone%", individualBasic.Cell_Phone);
                    formFields.SetField("%IndividualBasic.Employer_Name%", individualBasic.Employer_Name);
                    formFields.SetField("%IndividualBasic.Employer_Street%", individualBasic.Employer_Street);
                    formFields.SetField("%IndividualBasic.Employer_City%", individualBasic.Employer_City);
                    if (individualBasic.Employer_Country > 0)
                        formFields.SetField("%IndividualBasic.Employer_Country%", _countryService.GetCountryById(individualBasic.Employer_Country).Name);
                    if (individualBasic.Employer_State > 0)
                        formFields.SetField("%IndividualBasic.Employer_State%", _stateProvinceService.GetStateProvinceById(individualBasic.Employer_State).Name);
                    formFields.SetField("%IndividualBasic.Employer_Zip%", individualBasic.Employer_Zip);
                    formFields.SetField("%IndividualBasic.Employer_Business_Type%", individualBasic.Employer_Business_Type);
                    formFields.SetField("%IndividualBasic.Employer_Position%", individualBasic.Employer_Position);
                    formFields.SetField("%IndividualBasic.Employer_YRS%", individualBasic.Employer_YRS);
                    formFields.SetField("%IndividualBasic.Employer_Phone%", individualBasic.Employer_Phone);
                    formFields.SetField("%IndividualBasic.Employer_Email%", individualBasic.Employer_Email);
                    formFields.SetField("%IndividualBasic.Income1%", (individualBasic.Income1) ? "Yes" : "No");
                    formFields.SetField("%IndividualBasic.Income2%", (individualBasic.Income2) ? "Yes" : "No");
                    formFields.SetField("%IndividualBasic.Income3%", (individualBasic.Income3) ? "Yes" : "No");

                    if (individualBasic.IndividualJointInfoModel != null)
                    {
                        IndividualJointInfoModel individualJointInfo = individualBasic.IndividualJointInfoModel;
                        formFields.SetField("%IndividualJointInfo.FirstName%", individualJointInfo.FirstName);
                        formFields.SetField("%IndividualJointInfo.LastName%", individualJointInfo.LastName);
                        formFields.SetField("%IndividualJointInfo.Street%", individualJointInfo.Street);
                        formFields.SetField("%IndividualJointInfo.City%", individualJointInfo.City);
                        formFields.SetField("%IndividualJointInfo.Country%", GetCountryName(individualJointInfo.Country));
                        formFields.SetField("%IndividualJointInfo.State%", GetStateName(individualJointInfo.State));
                        formFields.SetField("%IndividualJointInfo.Zip%", individualJointInfo.Zip);
                        formFields.SetField("%IndividualJointInfo.Address_Years%", individualJointInfo.Address_Years);
                        formFields.SetField("%IndividualJointInfo.SSN%", individualJointInfo.SSN);

                        formFields.SetField("%IndividualJointInfo.Home_Street%", individualJointInfo.Home_Street);
                        formFields.SetField("%IndividualJointInfo.DateOfBirth%", individualJointInfo.DateOfBirth);
                        formFields.SetField("%IndividualJointInfo.Home_Phone%", individualJointInfo.Home_Phone);
                        formFields.SetField("%IndividualJointInfo.Home_Email%", individualJointInfo.Home_Email);
                        formFields.SetField("%IndividualJointInfo.Home_City%", individualJointInfo.Home_City);
                        formFields.SetField("%IndividualJointInfo.Home_Country%", GetCountryName(individualJointInfo.Home_Country));
                        formFields.SetField("%IndividualJointInfo.Home_State%", GetStateName(individualJointInfo.Home_State));
                        formFields.SetField("%IndividualJointInfo.Home_Zip%", individualJointInfo.Home_Zip);
                        formFields.SetField("%IndividualJointInfo.Driver_License%", individualJointInfo.Driver_License);
                        formFields.SetField("%IndividualJointInfo.Driver_Country%", GetCountryName(individualJointInfo.Driver_Country));
                        formFields.SetField("%IndividualJointInfo.Driver_State%", GetStateName(individualJointInfo.Driver_State));
                        formFields.SetField("%IndividualJointInfo.USA_Citizen_Country%", GetCountryName(individualJointInfo.USA_Citizen_Country));
                        formFields.SetField("%IndividualJointInfo.USA_Citizen%", (Convert.ToBoolean(individualJointInfo.USA_Citizen)) ? "Yes" : "No");
                        formFields.SetField("%IndividualJointInfo.Cell_Phone%", individualJointInfo.Cell_Phone);

                        formFields.SetField("%IndividualJointInfo.Employer_Name%", individualJointInfo.Employer_Name);
                        formFields.SetField("%IndividualJointInfo.Employer_Street%", individualJointInfo.Employer_Street);
                        formFields.SetField("%IndividualJointInfo.Employer_City%", individualJointInfo.Employer_City);
                        formFields.SetField("%IndividualJointInfo.Employer_Country%", GetCountryName(individualJointInfo.Employer_Country));
                        formFields.SetField("%IndividualJointInfo.Employer_State%", GetStateName(individualJointInfo.Employer_State));
                        formFields.SetField("%IndividualJointInfo.Employer_Zip%", individualJointInfo.Employer_Zip);
                        formFields.SetField("%IndividualJointInfo.Employer_Business_Type%", individualJointInfo.Employer_Business_Type);
                        formFields.SetField("%IndividualJointInfo.Employer_Position%", individualJointInfo.Employer_Position);
                        formFields.SetField("%IndividualJointInfo.Employer_YRS%", individualJointInfo.Employer_YRS);
                        formFields.SetField("%IndividualJointInfo.Employer_Phone%", individualJointInfo.Employer_Phone);
                        formFields.SetField("%IndividualJointInfo.Employer_Email%", individualJointInfo.Employer_Email);
                    }
                }
            }
            else
            {
                // Company PDF fields
                if (model.OtherInfoModel != null)
                {
                    OtherInfoModel otherInfoModel = model.OtherInfoModel;
                    if (otherInfoModel.CompanyInfo != null)
                    {
                        formFields.SetField("%Company.CompanyName%", otherInfoModel.CompanyInfo.Company);
                        formFields.SetField("%Company.Address1%", otherInfoModel.CompanyInfo.Address1);
                        formFields.SetField("%Company.Address2%", otherInfoModel.CompanyInfo.Address2);
                        formFields.SetField("%Company.ZipPostalCode%", otherInfoModel.CompanyInfo.ZipPostalCode);
                        formFields.SetField("%Company.City%", otherInfoModel.CompanyInfo.City);
                        if (otherInfoModel.CompanyInfo.CountryId > 0)
                            formFields.SetField("%Company.Country%", _countryService.GetCountryById(Convert.ToInt32(otherInfoModel.CompanyInfo.CountryId)).Name);
                        if (otherInfoModel.CompanyInfo.StateProvinceId > 0)
                            formFields.SetField("%Company.StateProvince%", _stateProvinceService.GetStateProvinceById(Convert.ToInt32(otherInfoModel.CompanyInfo.StateProvinceId)).Name);
                        formFields.SetField("%Company.PhoneNumber%", otherInfoModel.CompanyInfo.PhoneNumber);
                        formFields.SetField("%Company.FaxNumber%", otherInfoModel.CompanyInfo.FaxNumber);
                        formFields.SetField("%Company.LastName%", otherInfoModel.CompanyInfo.LastName);
                        formFields.SetField("%Company.FirstName%", otherInfoModel.CompanyInfo.FirstName);
                    }

                    formFields.SetField("%Company.RegionFormed%", otherInfoModel.RegionFormed);
                    formFields.SetField("%Company.ContactName%", otherInfoModel.ContactName);
                    formFields.SetField("%Company.VestingName%", otherInfoModel.VestingName);

                    formFields.SetField("%Company.EIN%", otherInfoModel.EIN);
                    formFields.SetField("%Company.Business_City%", otherInfoModel.Business_City);
                    if (otherInfoModel.Business_Country > 0)
                        formFields.SetField("%Company.Business_Country%", _countryService.GetCountryById(otherInfoModel.Business_Country).Name);
                    if (otherInfoModel.Business_State > 0)
                        formFields.SetField("%Company.Business_State%", _stateProvinceService.GetStateProvinceById(otherInfoModel.Business_State).Name);
                    formFields.SetField("%Company.Business_Zip%", otherInfoModel.Business_Zip);
                    formFields.SetField("%Company.Business_Website%", otherInfoModel.Business_Website);
                }
            }

            return formFields;
        }

        private void FillImage(string fieldName, PdfStamper pdfStamper, byte[] signImage)
        {
            if (signImage != null)
            {
                if (pdfStamper.AcroFields.GetFieldPositions(fieldName) != null)
                {
                    AcroFields.FieldPosition fieldPosition = pdfStamper.AcroFields.GetFieldPositions(fieldName)[0];
                    PushbuttonField imageField = new PushbuttonField(pdfStamper.Writer, fieldPosition.position, fieldName);
                    imageField.Layout = PushbuttonField.LAYOUT_ICON_ONLY;
                    imageField.Image = iTextSharp.text.Image.GetInstance(signImage);
                    imageField.ScaleIcon = PushbuttonField.SCALE_ICON_ALWAYS;
                    imageField.ProportionalIcon = false;
                    imageField.Options = BaseField.READ_ONLY;
                    pdfStamper.AcroFields.RemoveField(fieldName);
                    pdfStamper.AddAnnotation(imageField.Field, fieldPosition.page);
                }
            }
        }

        private byte[] Draw2DLineGraphic(string jsonSign, int width, int height)
        {
            if (!string.IsNullOrEmpty(jsonSign))
            {
                I2DLineGraphic lineGraphic = new JavaScriptSerializer().Deserialize<Signature>(jsonSign);
                //The png's bytes 
                byte[] png = null;

                //Create the Bitmap set Width and height 
                using (Bitmap b = new Bitmap(width, height))
                {
                    using (Graphics g = Graphics.FromImage(b))
                    {
                        //Make sure the image is drawn Smoothly (this makes the pen lines look smoother) 
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                        //Set the background to white 
                        g.Clear(Color.White);

                        //Create a pen to draw the signature with 
                        Pen pen = new Pen(Color.Blue, 2);

                        //Smooth out the pen, making it rounded 
                        pen.DashCap = System.Drawing.Drawing2D.DashCap.Round;

                        //Last point a line finished at 
                        Point LastPoint = new Point();
                        bool hasLastPoint = false;

                        //Draw the signature on the bitmap 
                        foreach (List<List<double>> line in lineGraphic.lines)
                        {
                            foreach (List<double> point in line)
                            {
                                var x = (int)Math.Round(point[0]);
                                var y = (int)Math.Round(point[1]);

                                if (hasLastPoint)
                                {
                                    g.DrawLine(pen, LastPoint, new Point(x, y));
                                }

                                LastPoint.X = x;
                                LastPoint.Y = y;
                                hasLastPoint = true;
                            }
                            hasLastPoint = false;
                        }
                    }

                    //Convert the image to a png in memory 
                    using (MemoryStream stream = new MemoryStream())
                    {
                        b.Save(stream, ImageFormat.Png);
                        png = stream.ToArray();
                    }
                }
                //return Convert.ToBase64String(png);
                return png;
            }
            else
            {
                return null;
            }
        }

        private StringBuilder SetSignToken(string signToken, StringBuilder sb, string cssCLass, string type)
        {
            int lastIndex = 0;
            int count = 0;
            while (lastIndex != -1)
            {
                lastIndex = sb.ToString().IndexOf(signToken, lastIndex);
                if (lastIndex != -1)
                {
                    count++;
                    sb.Replace(signToken, string.Format("<div id='{0}{1}' data-signcount='{0}{1}' class='{2} signBox'></div><input type='hidden' id='hdnSignJSON{0}{1}' name='hdnSignJSON{0}' />", type, count, cssCLass), lastIndex, signToken.Length);
                    lastIndex += signToken.Length;
                }
            }
            return sb;
        }

        private string GetCountryName(int countryId)
        {
            if (countryId > 0)
                return _countryService.GetCountryById(countryId).Name;
            return string.Empty;
        }

        private string GetStateName(int stateId)
        {
            if (stateId > 0)
                return _stateProvinceService.GetStateProvinceById(stateId).Name;
            return string.Empty;
        }

        #endregion

        #region Check default models for skipping steps

        private bool CanSkipInvestorInformationStep(Product product)
        {
            var investorInformationTemplate = product.ProductSpecificationAttributes.SingleOrDefault(
                      x =>
                          x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                          ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId);

            var oldTemplateId = _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                            String.Format(ClientConstants.TempCheckOutGenericAttirubutes.OldTemplateId, product.Id,
                                 ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId));

            var succesfullyId =
                _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    String.Format(ClientConstants.TempCheckOutGenericAttirubutes.SuccesfulyEnvelopId,
                        product.Id, ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId));

            if (investorInformationTemplate == null)
            {
                _logger.Information("1. CanSkipInvestorInformationStep");
                return true;
            }
            if (oldTemplateId != null && investorInformationTemplate.CustomValue != oldTemplateId.Value)
            {
                _logger.Information("2. CanSkipInvestorInformationStep");
                return false;
            }
            if (oldTemplateId != null && investorInformationTemplate.CustomValue == oldTemplateId.Value &&
                succesfullyId == null)
            {
                _logger.Information("3. CanSkipInvestorInformationStep");
                return false;
            }

            _logger.Information("4. CanSkipInvestorInformationStep");
            return true;
        }

        private bool CanSkipPersonalInformationStep()
        {
            var resultModel = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType);

            resultModel.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;

            PreparePersonalInformationModel(resultModel);

            TryValidateModel(resultModel);

            _logger.Information("CanSkipPersonalInformationStep: " + ModelState.IsValid);
            return ModelState.IsValid;
        }

        private bool CanSkipVerifyInvestorStep()
        {
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (!settings.VerifyInvestorValidationEnabled)
            {
                return true;
            }

            var viUseridAttribute =
                _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                    ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);
            if (viUseridAttribute != null)
            {
                var verifyStatus = _verifyInvestorService.GetUserVerificationStatus(int.Parse(viUseridAttribute.Value));
				_logger.Information("CanSkipVerifyInvestorStep_Verifivation_Status: " + verifyStatus);
                if (verifyStatus != null)
                {
                    switch (verifyStatus.verification_status)
                    {
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.Verified:
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.PendingVerification:
                            return true;
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.Unverified:
                            {
                                switch (verifyStatus.verification_request_step)
                                {
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.AcceptedExpire:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.DeclinedByInvestor:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.DeclinedExpire:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.NoRequest:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForInfoFromInvestor:
                                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForInvestorAcceptance:
                                        _logger.Information("CanSkipVerifyInvestorStep: false");
                                        return false;
                                    default:
                                        {
                                            _logger.Information("CanSkipVerifyInvestorStep: true(default)");
                                            return true;
                                        }
                                }
                            }
                    }
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        private bool CanSkipInvestorTypeStep()
        {
            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            return investorType == ClientConstants.InvestorType.Accreddited;
        }

        private bool CanSkipPersonalOtherStepsAndPDFVerification(CrowdPaySettings settings)
        {
            string SelectedInvestorType = ClientConstants.InvestorType.NonAccreditted;
            if (TempData["SelectedInvestorType"] != null)
            {
                SelectedInvestorType = Convert.ToString(TempData["SelectedInvestorType"]);
                TempData.Keep("SelectedInvestorType");
                if (SelectedInvestorType == ClientConstants.InvestorType.NonAccreditted)
                {
                    return true;
                }
            }
            else
            {
                var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                SelectedInvestorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                    ClientConstants.CustomAttributes.InvestorType);
                if (SelectedInvestorType == ClientConstants.InvestorType.NonAccreditted)
                {
                    return true;
                }
            }

            //if (!settings.InternalAccreditation)
            if (settings.VerifyInvestorValidationEnabled)
            {
                return true;
            }
            return false;
        }

        private bool CanAllowNetwork1Security()
        {
            var settings = _settingsService.LoadSetting<CrowdPaySettings>();
            if (settings.SingleOfferProductId > 0)
            {
                var subscription = _bDAddressService.GetSubscriptionTemplateByProduct(settings.SingleOfferProductId);
                if (subscription != null && subscription.OfferingType == ClientConstants.OfferingType.type_S_1_IPO)
                    return true;
            }

            return false;
        }

        #endregion

        #region Save models

        [NonAction]
        private void SaveOtherInfo(OtherInfoModel model)
        {
            BD_CompanyBasicInfo companyBasic = new BD_CompanyBasicInfo();
            var companyAddress = new Address();
            var existingAddress = false;
            foreach (var address in _currentCustomer.Addresses)
            {
                var addressAttributes = _addressAttributeParser.ParseAddressAttributeValues(address.CustomAttributes);
                foreach (var addressAttribute in addressAttributes)
                {
                    if (addressAttribute.AddressAttribute.Name == ClientConstants.CustomAttributes.CompanyAddress)
                    {
                        companyAddress = address;
                        existingAddress = true;
                        break;
                    }
                }
            }
            if (model.IsBasicSaving)
            {
                companyAddress.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
                companyAddress.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);
                companyAddress.Company = model.CompanyInfo.Company;
                companyAddress.Address1 = model.CompanyInfo.Address1;
                companyAddress.City = model.CompanyInfo.City;
                companyAddress.CountryId = model.CompanyInfo.CountryId;
                companyAddress.StateProvinceId = model.CompanyInfo.StateProvinceId;
                companyAddress.ZipPostalCode = model.CompanyInfo.ZipPostalCode;
                companyAddress.Email = model.CompanyInfo.Email;
                companyAddress.PhoneNumber = model.CompanyInfo.PhoneNumber;
                companyAddress.FaxNumber = model.CompanyInfo.FaxNumber;
                if (!existingAddress)
                {
                    var companyAddressAttribute =
                        _addressAttributeService.GetAllAddressAttributes()
                            .SingleOrDefault(x => x.Name == ClientConstants.CustomAttributes.CompanyAddress);

                    if (companyAddressAttribute != null)
                    {
                        var attributeValue = companyAddressAttribute.AddressAttributeValues.FirstOrDefault();
                        if (attributeValue != null)
                        {
                            companyAddress.CustomAttributes =
                                _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                                    ClientConstants.CustomAttributes.CompanyAddress, attributeValue.Id.ToString());
                            _addressService.InsertAddress(companyAddress);
                            _currentCustomer.Addresses.Add(companyAddress);
                        }
                        else
                        {
                            throw new Exception("Can not find customer attribute value");
                        }
                    }
                    else
                    {
                        throw new Exception("Can not find customer attribute");
                    }
                }
                companyAddress.CustomAttributes =
                    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                        ClientConstants.CustomAttributes.RegionFormedIn, model.RegionFormed);
                companyAddress.CustomAttributes =
                    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                        ClientConstants.CustomAttributes.ContactName, model.ContactName);
                //TaxId
                _logger.Information("SaveOtherInfo Tax_Id: " + model.TaxId);
                companyAddress.CustomAttributes = _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                                        ClientConstants.CustomAttributes.TaxId, model.TaxId);

                if (model.SelfDirected)
                {
                    companyAddress.CustomAttributes =
                        _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                            ClientConstants.CustomAttributes.VestingName, model.VestingName);
                }
                //companyAddress.CustomAttributes =
                //    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                //        ClientConstants.CustomAttributes.EIN, model.EIN);

                //companyAddress.CustomAttributes =
                //    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                //        ClientConstants.CustomAttributes.Business_City, model.Business_City);
                //companyAddress.CustomAttributes =
                //    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                //        ClientConstants.CustomAttributes.Business_State, model.Business_State);
                //companyAddress.CustomAttributes =
                //    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                //        ClientConstants.CustomAttributes.Business_Zip, model.Business_Zip);
                //companyAddress.CustomAttributes =
                //    _customAddressAttributeParser.UpdateCustomAddressAttributes(companyAddress.CustomAttributes,
                //        ClientConstants.CustomAttributes.Business_Website, model.Business_Website);            
                _addressService.UpdateAddress(companyAddress);
            }
            else if (model.IsBusinessSaving)
            {
                if (companyAddress != null)
                {
                    companyAddress.Address2 = model.CompanyInfo.Address2;
                    _addressService.UpdateAddress(companyAddress);
                }
                #region Basic for "Company" (PDF 2)
                if (model.CompanyBasicId > 0)
                {
                    var basic = _bDAddressService.GetCompanyBasicInfo(_currentCustomer.Id);
                    basic.EIN = model.EIN;
                    basic.Business_City = model.Business_City;
                    basic.Business_Country = model.Business_Country;
                    basic.Business_State = model.Business_State;
                    basic.Business_Zip = model.Business_Zip;
                    basic.Business_Website = model.Business_Website;
                    // update
                    _bDAddressService.UpdateCompanyBasicInfo(basic);
                }
                else
                {
                    // insert
                    companyBasic.CustomerId = _currentCustomer.Id;
                    companyBasic.EIN = model.EIN;
                    companyBasic.Business_City = model.Business_City;
                    companyBasic.Business_Country = model.Business_Country;
                    companyBasic.Business_State = model.Business_State;
                    companyBasic.Business_Zip = model.Business_Zip;
                    companyBasic.Business_Website = model.Business_Website;
                    //companyBasic.IsBasicSaved = true;
                    _bDAddressService.InsertCompanyBasicInfo(companyBasic);
                }
                #endregion
            }
        }

        private void SaveDocuments(InformationGatheringModel model)
        {
            //_bDAddressService.DeleteDocumentByCustomer(_currentCustomer.Id);

            foreach (var doc in model.UploadDocumentList)
            {
                if (doc.DocumentUploadId > 0)
                {
                    var bD_Document = new BD_Documents
                    {
                        Id = doc.DocumentId,
                        CustomerId = _currentCustomer.Id,
                        DocumentUploadId = doc.DocumentUploadId,
                        description = doc.description,
                        IsApproved = false
                    };

                    _bDAddressService.InsertDocuments(bD_Document);
                }
            }
        }

        #endregion

        #region Load Models

        private string LoadPaymentInfo(FormCollection form, PurchaseModel purchaseModel)
        {
            string paymentmethod = null;
            if (form != null)
            {
                paymentmethod = form["paymentmethod"];
            }
            else if (purchaseModel != null)
            {
                if (purchaseModel.PaymentMethods.Any())
                {
                    paymentmethod = purchaseModel.PaymentMethods.FirstOrDefault(p => p.Selected).PaymentMethodSystemName;
                }
            }
            else
            {
                //add payment methods
                var paymentMethods = _paymentService
                    .LoadActivePaymentMethods(_workContext.CurrentCustomer, _storeContext.CurrentStore.Id)
                    .Where(
                        pm =>
                            pm.PaymentMethodType == PaymentMethodType.Standard ||
                            pm.PaymentMethodType == PaymentMethodType.Redirection)
                    .ToList();
                if (paymentMethods.Any())
                {
                    paymentmethod = paymentMethods[0].PluginDescriptor.SystemName;
                }
            }

            //= form["paymentmethod"];
            //payment method 
            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            if (paymentMethodInst == null ||
                !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
                !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
                throw new Exception("Selected payment method can't be parsed");

            var paymentInfoModel = _checkoutModelFactory.PreparePaymentInfoModel(paymentMethodInst);

            var resultModel2 = new CustomPaymentInfoModel()
            {
                CheckoutPaymentInfoModel = paymentInfoModel
            };

            return RenderPartialViewToString(
                    "~/Plugins/BD.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", resultModel2);
        }

        

        #endregion

        #region Others

        private void ConvertHtmlToPdf()
        {
            // propare individual model
            var individualInfoModel = new IndividualsModel();
            PrepareIndividualsInformationModel(individualInfoModel);
            //var builder = new PdfBuilder<IndividualsModel>(individualInfoModel, Server.MapPath("/Plugins/BD.CrowdPay/Views/CrowdPay/PdfHtml/IndividualPDF.cshtml"));
            //byte[] bytes = builder.GetPdf();
            //System.IO.File.WriteAllBytes(Server.MapPath("/Content/PDF/"+_currentCustomer.Id+"_"+_currentCustomer.GetFullName()+".pdf"), bytes);
            // prepare individual partial html with model
            // convert to pdf and save it
        }

        #endregion

        #endregion
    }
}
