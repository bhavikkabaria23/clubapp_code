﻿using MultiSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiSite.Models
{
    public class SiteRegistrationCRMModel
    {        
        public static List<RegisterControlField> SetCrmFIelds(SiteRegistrationModel model)
        {
            List<RegisterControlField> ControlFieldList = new List<RegisterControlField>();
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.SomethingToSell });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.HelpBusinessLogo)?"true":"false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.HelpBusinessBrainStorm) ? "true" : "false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.HelpBusinessWebinar) ? "true" : "false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.HelpBusinessProduct) ? "true" : "false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.SystemName });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.LaunchStore });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.WhatToSell });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.SellAtMarket) ? "true" : "false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.SellAtRetailStore) ? "true" : "false" });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.CurrentRevenue });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = (model.StoreForCLient) ? "true" : "false" });

            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.firstName });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.lastName });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.Country });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.State });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.City });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.ZipPostalCode });
            ControlFieldList.Add(new RegisterControlField() { CRMField = "c1", FieldValue = model.Website });
            return ControlFieldList;
        }
    }
    public class RegisterControlField
    {
        public string FieldValue { get; set; }
        public string CRMField { get; set; }
    }

    public class RegisterVtigerCrmResult
    {
        public string token { get; set; }
        public string sessionName { get; set; }
        public string userId { get; set; }
        public string id { get; set; }
    }

    public class RegisterVtigerCrmResponse
    {
        public bool success { get; set; }
        public RegisterVtigerCrmResult result { get; set; }
    }

}