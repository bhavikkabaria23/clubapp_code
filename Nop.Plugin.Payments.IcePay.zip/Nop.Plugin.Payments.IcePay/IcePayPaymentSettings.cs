using Nop.Core.Configuration;

namespace Nop.Plugin.Payments.IcePay
{
    public class IcePayPaymentSettings : ISettings
    {
        public bool AdditionalFeePercentage { get; set; }       
        public decimal AdditionalFee { get; set; }
        public int MerchantID { get; set; }
        public string MerchantSecret { get; set; }
        public string Description { get; set; }
        //public string PaymentMethod { get; set; }
        //public string Issuer { get; set; }     
    }
}
