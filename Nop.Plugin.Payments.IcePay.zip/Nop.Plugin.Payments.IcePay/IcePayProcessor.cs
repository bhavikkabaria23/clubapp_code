using System;
using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Plugins;
using Nop.Plugin.Payments.IcePay.Controllers;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Plugin.Payments.IcePay;
using System.Net;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Web;
using System.Net.Http.Headers;
using Nop.Plugin.Payments.IcePay.Models;
using System.Globalization;
using Nop.Services.Customers;

namespace Nop.Plugin.Payments.IcePay
{
    /// <summary>
    /// Manual payment processor
    /// </summary>
    public class IcePayPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly ILocalizationService _localizationService;
        private readonly IcePayPaymentSettings _IcePayPaymentSettings;
        private readonly ISettingService _settingService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ICustomerService _customerService;

        #endregion

        #region Ctor

        public IcePayPaymentProcessor(ILocalizationService localizationService,
            IcePayPaymentSettings IcePayPaymentSettings,
            ISettingService settingService, IOrderTotalCalculationService orderTotalCalculationService,
            ICustomerService customerService)
        {
            this._localizationService = localizationService;
            this._IcePayPaymentSettings = IcePayPaymentSettings;
            this._settingService = settingService;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._customerService = customerService;
        }

        #endregion

        #region Utilities
        private IcepayRestClient.Classes.Payment.GetPaymentResponse IcePayAPI(ProcessPaymentRequest request, out string error)
        {
            error = "";
            IcepayRestClient.Classes.Payment.GetPaymentResponse getPaymentResponse = new IcepayRestClient.Classes.Payment.GetPaymentResponse();
            try
            {
                IcepayRestClient.Payment restPayment =
    new IcepayRestClient.Payment(_IcePayPaymentSettings.MerchantID, _IcePayPaymentSettings.MerchantSecret);

                //IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
                //    restPayment.GetMyPaymentMethods();

                IcepayRestClient.Classes.Payment.CheckoutResponse checkoutResponse =
                    restPayment.Checkout(
                  new IcepayRestClient.Classes.Payment.CheckoutRequest
                  {
                      Amount = Convert.ToInt32(request.OrderTotal), //amount in cents
                      Country = "NL", //2 character ISO country code
                      Currency = "EUR", //3 characther ISO currency code
                      Description = _IcePayPaymentSettings.Description,
                      EndUserIP = "127.0.0.1", //read the end user's IP address
                      OrderID = request.OrderGuid.ToString(), //
                      PaymentMethod = "IDEAL", //Payment method code
                      Issuer = "ING", //Issuer code
                      Language = "NL" //2 character ISO language code
                  }
                );
                
                getPaymentResponse = restPayment.GetPayment(
                  new IcepayRestClient.Classes.Payment.GetPaymentRequest
                  {
                      PaymentID = checkoutResponse.PaymentID //the PaymentID is returned in the CheckoutResponse                 
                  }
                );

                return getPaymentResponse;
            }
            catch (Exception ex)
            {
                // Something else went wrong, e.g. invalid arguments passed to the order object.
                error = ex.Message;
                return getPaymentResponse;
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            string error = "";
            var paymentResponse = IcePayAPI(processPaymentRequest, out error);
            if (string.IsNullOrEmpty(error))
            {
                // Stutus can be "OK" or "OPEN" or "ERR"
                if (paymentResponse.Status.ToLower() == "ok")
                {
                    result.NewPaymentStatus = PaymentStatus.Paid;
                }
                else if (paymentResponse.Status.ToLower() == "open")
                {
                    result.NewPaymentStatus = PaymentStatus.Pending;
                }
                else // Status = "ERR"
                {
                    result.NewPaymentStatus = PaymentStatus.Voided;
                }
                result.CaptureTransactionResult = paymentResponse.Status;
                result.SubscriptionTransactionId = Convert.ToString(paymentResponse.PaymentID);
                result.CaptureTransactionId = Convert.ToString(paymentResponse.PaymentID);
            }
            else
            {
                result.AddError(error);
            }
            return result;
        }
        

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            var result = this.CalculateAdditionalFee(_orderTotalCalculationService, cart,
                _IcePayPaymentSettings.AdditionalFee, _IcePayPaymentSettings.AdditionalFeePercentage);
            return result;
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();
            result.AddError("Capture method not supported");
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();
            result.AddError("Refund method not supported");
            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();
            result.AddError("Void method not supported");
            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            //always success
            return new CancelRecurringPaymentResult();
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Nop.Core.Domain.Orders.Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "PaymentsIcePay";
            routeValues = new RouteValueDictionary { { "Namespaces", "Nop.Plugin.Payments.IcePay.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "PaymentsIcePay";
            routeValues = new RouteValueDictionary { { "Namespaces", "Nop.Plugin.Payments.IcePay.Controllers" }, { "area", null } };
        }

        public Type GetControllerType()
        {
            return typeof(PaymentsIcePayController);
        }

        public override void Install()
        {
            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFee", "Additional fee");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantID", "Merchant ID");            
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantID.Hint", "Merchant ID.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantSecret", "Merchant Secret");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantSecret.Hint", "Merchant Secret.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.Description", "Description");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.Description.Hint", "Description.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.PaymentMethod", "PaymentMethod");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.PaymentMethod.Hint", "PaymentMethod.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.Issuer", "Issuer");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.Fields.Issuer.Hint", "Issuer.");            
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.IcePay.PaymentMethodDescription", "Pay by credit / debit card");

            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<IcePayPaymentSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFee");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFee.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFeePercentage");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.AdditionalFeePercentage.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantID");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantID.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantSecret");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.MerchantSecret.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.Description");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.Description.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.PaymentMethod");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.PaymentMethod.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.Issuer");
            this.DeletePluginLocaleResource("Plugins.Payments.IcePay.Fields.Issuer.Hint");            
            this.DeletePluginLocaleResource("Plugins.Payments.Manual.PaymentMethodDescription");

            base.Uninstall();
        }


        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Manual;
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a payment method description that will be displayed on checkout pages in the public store
        /// </summary>
        public string PaymentMethodDescription
        {
            //return description of this payment method to be display on "payment method" checkout step. good practice is to make it localizable
            //for example, for a redirection payment method, description may be like this: "You will be redirected to PayPal site to complete the payment"
            get { return _localizationService.GetResource("Plugins.Payments.Manual.PaymentMethodDescription"); }
        }

        #endregion

    }
}
