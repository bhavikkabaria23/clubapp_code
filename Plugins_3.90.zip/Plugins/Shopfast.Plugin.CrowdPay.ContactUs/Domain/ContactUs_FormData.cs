﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.CrowdPay.ContactUs.Domain
{
    public class ContactUs_FormData : BaseEntity
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Subject { get; set; }
        public string Enquiry { get; set; }
        public string Phone { get; set; }
        public bool Investor { get; set; }
        public bool Startup { get; set; }
        public bool General { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
