using Nop.Data.Mapping;
using Shopfast.Plugin.CrowdPay.ContactUs.Domain;

namespace Shopfast.Plugin.CrowdPay.ContactUs.Data
{
    public partial class ContactUs_FormDataMap : NopEntityTypeConfiguration<ContactUs_FormData>
    {
        public ContactUs_FormDataMap()
        {
            this.ToTable("ContactUs_FormData");
            this.HasKey(tr => tr.Id);            
        }
    }
}