﻿using Shopfast.Plugin.CrowdPay.ContactUs.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.CrowdPay.ContactUs.Services
{
    public interface IContactUsFormService
    {
        IEnumerable<ContactUs_FormData> GetContactUsForms();
        ContactUs_FormData GetContactUsFormById(int Id);
        void InsertContactUsForm(ContactUs_FormData contactUs);
        void UpdateContactUsForm(ContactUs_FormData contactUs);
        void DeleteContactById(int Id);

    }
}
