﻿using Nop.Core.Domain.Cms;
using Nop.Core.Plugins;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;

namespace Shopfast.Plugin.Customer.GoogleMap
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerGoogleMapProvider : BasePlugin, IWidgetPlugin
    {
        private readonly ISettingService _settingService;
        private readonly WidgetSettings _widgetSettings;
        public CustomerGoogleMapProvider(ISettingService settingService, WidgetSettings widgetSettings)
        {
            this._settingService = settingService;
            this._widgetSettings = widgetSettings;
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string>() { "customer_google_map" };
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "ShowGoogleMap";
            controllerName = "GoogleMap";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.Customer.GoogleMap.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for displaying widget
        /// </summary>
        /// <param name="widgetZone">Widget zone where it's displayed</param>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "ShowGoogleMap";
            controllerName = "GoogleMap";
            routeValues = new RouteValueDictionary()
            {
                {"Namespaces", "Shopfast.Plugin.Customer.GoogleMap.Controllers"},
                {"area",null},
                {"widgetZone", widgetZone}
            };
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            base.Install();

            // Active plugin widget after plugin installed
            _widgetSettings.ActiveWidgetSystemNames.Add(this.PluginDescriptor.SystemName);
            _settingService.SaveSetting(_widgetSettings);
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            base.Uninstall();
        }
    }
}
