﻿using Nop.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Core.Domain.Customers;

namespace Shopfast.Plugin.Customer.GoogleMap.Services
{
    public partial class GoogleMapService : IGoogleMapService
    {
        #region Fields
        private readonly IRepository<Nop.Core.Domain.Customers.Customer> _customerRepository;
        #endregion

        #region Ctor
        public GoogleMapService(IRepository<Nop.Core.Domain.Customers.Customer> customerRepository)
        {
            this._customerRepository = customerRepository;
        }
        #endregion

        #region Methods
        public virtual IList<Nop.Core.Domain.Customers.Customer> GetAllCustomers()
        {

            //var genericAttributes = _genericAttributeRepository.Table.Where(ga => ga.KeyGroup.ToLower() == "customer").ToList();

            //var query = _customerRepository.Table.Where(c => c.Email != null && c.Username != null).ToList();
            //query = query.Where(c => genericAttributes.Any(ga => ga.EntityId == c.Id)).ToList();
            //query = query.OrderByDescending(c => c.CreatedOnUtc).ToList();

            //var query = _customerRepository.Table;
            var query = _customerRepository.Table.Where(c => c.Email != null && c.Username != null);
            query = query.OrderByDescending(c => c.CreatedOnUtc);
            var customers = query.ToList();
            return customers;
        }
        #endregion
    }
}
