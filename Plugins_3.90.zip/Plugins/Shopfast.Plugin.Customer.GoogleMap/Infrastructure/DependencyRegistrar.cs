using Autofac;
using Autofac.Core;
using Nop.Core.Caching;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Shopfast.Plugin.Customer.GoogleMap.Controllers;
using Nop.Data;
using Shopfast.Plugin.Customer.GoogleMap.Services;

namespace Shopfast.Plugin.Customer.GoogleMap.Infrastructure
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<GoogleMapService>().As<IGoogleMapService>().InstancePerLifetimeScope();

            //we cache presentation models between requests
            builder.RegisterType<GoogleMapController>()
                .WithParameter(ResolvedParameter.ForNamed<ICacheManager>("nop_cache_static"));
        }

        public int Order
        {
            get { return 2; }
        }
    }
}
