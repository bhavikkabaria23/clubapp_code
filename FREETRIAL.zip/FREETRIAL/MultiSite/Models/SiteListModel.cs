﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using MultiSite.Data;
using Nop.Core.Data;
using System.Data.SqlClient;
using Nop.Core.Infrastructure;

namespace MultiSite.Models
{
    public class SiteListModel
    {
        [UIHint("DateNullable")]
        [DisplayName("Start Date")]
        public DateTime? StartDate { get; set; }

        [UIHint("DateNullable")]
        [DisplayName("End Date")]
        public DateTime? EndDate { get; set; }

        [DisplayName("Customer Email")]
        public string CustomerEmail { get; set; }

        // For All Sites Order Totals        
        public string todayTotalAllSites { get; set; }
        public string weekTotalAllSites { get; set; }
        public string monthTotalAllSites { get; set; }
        public string yearTotalAllSites { get; set; }
        public string allTotalAllSites { get; set; }
        public string avgTotalAllSites { get; set; }
        public string avgTotal { get; set; }

        public List<SiteOrderDetails> lstSitesOrder { get; set; }
        //--------------------------------------

        public static IEnumerable<SiteModel> SearchSites(string email, int page, int pageSize, DateTime? startDate, DateTime? endDate, List<SiteOrderDetails> lstSitesOrder)
        {            
            if (!MultisiteHelper.IsAdminSite)
            {
                return null;
            }
            // For All Sites Order Totals
            using (var dbContext = new Sites4Entities())
            {
               
                var sites = dbContext.Sites.Include("Owner").OrderBy(s => s.Id).AsEnumerable();

                if (!string.IsNullOrEmpty(email))
                    sites = sites.Where(s => s.Owner.email == email);

                if (startDate.HasValue)
                    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                if (endDate.HasValue)
                    sites = sites.Where(s => s.CreationDate <= endDate.Value);

                if (pageSize > 0)
                {
                    sites = sites.Skip(pageSize * page).Take(pageSize);
                }

                return sites.Select(site =>
                    new SiteModel
                    {
                        Id = site.Id,
                        storeName = site.StoreName,
                        customerEmail = site.Owner.email,
                        CreationDate = site.CreationDate,
                        status = site.IsOrder ?? false ? "purchased" : "trial",
                        // For All Sites Order Totals
                        todayTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.todayTotal).FirstOrDefault()),
                        weekTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.weekTotal).FirstOrDefault()),
                        monthTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.monthTotal).FirstOrDefault()),
                        yearTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.yearTotal).FirstOrDefault()),
                        allTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.allTotal).FirstOrDefault()),
                        avgOrder = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => (so.allTotal)/so.orderCount).FirstOrDefault())
                        //--------------------------------------
                    }).ToList();
            }
        }

        public static int Total(string email, DateTime? startDate, DateTime? endDate)
        {
            if (!MultisiteHelper.IsAdminSite)
            {
                return 0;
            }

            using (var dbContext = new Sites4Entities())
            {
                var sites = dbContext.Sites.AsEnumerable();

                if (!string.IsNullOrEmpty(email))
                    sites = sites.Where(s => s.Owner.email == email);

                if (startDate.HasValue)
                    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                if (endDate.HasValue)
                    sites = sites.Where(s => s.CreationDate <= endDate.Value);

                return sites.Count();
            }
        }

        public int totalSites { get; set; }

        public static SiteModel GetById(int id)
        {
            using (var dbContext = new Sites4Entities())
            {
                var site = dbContext.Sites.Include("Owner").SingleOrDefault(s => s.Id == id);
                if (site == null)
                {
                    return null;
                }

                return new SiteModel
                {
                    CreationDate = site.CreationDate,
                    customerEmail = site.Owner.email,
                    Id = site.Id,
                    status = site.IsOrder ?? false ? "Purchased" : "Trial",
                    storeName = site.StoreName,
                    description = site.Owner.description,
                    firstName = site.Owner.firstName,
                    industryType = site.Owner.industryType,
                    lastName = site.Owner.LastName,
                    phone = site.Owner.phone,
                    starting = site.Owner.starting,
                    Country = site.Owner.Country,
                    Website = site.Owner.Website,
                    //Multisite_NewField_change
                    StreetAddress = site.Owner.StreetAddress,
                    City = site.Owner.City,
                    ZipPostalCode = site.Owner.ZipPostalCode,
                    State = site.Owner.State,

                    // Free trial integration in new page
                    AvgSaleAmout = site.Owner.AvgSaleAmout,
                    ProcessorName = site.Owner.ProcessorName,
                    ProcessorEmail = site.Owner.ProcessorEmail,
                    ProcessorPhoneNumber = site.Owner.ProcessorPhoneNumber
                    //-----------------------

                    //--------------------------
                };
            }
        }
        // For All Sites Order Totals
        public static List<SiteOrderDetails> GetSiteOrderDetails()
        {
            using (var dbContext = new Sites4Entities())
            {
                var siteOrderDetails = dbContext.Database.SqlQuery<SiteOrderDetails>(
        "sp_GetOrderDetailsOfAllSites @dbPrefix",
        new SqlParameter("@dbPrefix", MultisiteHelper.ApplicationName)
       ).ToList();
                return siteOrderDetails;
            }
        }
        //------------------
    }
}