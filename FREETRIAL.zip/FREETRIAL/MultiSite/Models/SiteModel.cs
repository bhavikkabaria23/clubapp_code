﻿using System;
using System.ComponentModel;
using System.Linq;
using Nop.Core.Data;
using System.Collections.Generic;
using MultiSite.Models.SiteTheme;
using System.ComponentModel.DataAnnotations;

namespace MultiSite.Models
{
    public class SiteModel
    {
        public int Id { get; set; }

        [DisplayName("Store Url")]
        public string storeName { get; set; }

        [DisplayName("Email")]
        public string customerEmail { get; set; }

        [DisplayName("Date of creation")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime CreationDate { get; set; }

        [DisplayName("Store status")]
        public string status { get; set; }

        [DisplayName("Industry type")]
        public string industryType { get; set; }

        [DisplayName("First name")]
        public string firstName { get; set; }

        [DisplayName("Last name")]
        public string lastName { get; set; }

        [DisplayName("Phone")]
        public string phone { get; set; }

        [DisplayName("Description")]
        public string description { get; set; }

        [DisplayName("Is starting...")]
        public string starting { get; set; }

        [DisplayName("Country")]
        public string Country { get; set; }

        [DisplayName("Website")]
        public string Website { get; set; }

        public bool? IsOrder { get; set; }

        string _storeUrl;
        [DisplayName("Password")]
        public string password { get; set; }

        public string storeUrl
        {
            get
            {
                if (_storeUrl == null)
                {
                    _storeUrl = string.IsNullOrEmpty(storeName) ? "" :
                                storeName.Contains('.') ? string.Format("http://{0}", storeName) :
                                string.Format("http://{0}.{1}", storeName, MultisiteHelper.Domain);
                }
                return _storeUrl;
            }
            set
            {
                _storeUrl = value;
            }
        }

        public bool isExternalUrl { get; set; }

        //Multisite_NewField_change
        [DisplayName("Street Address")]
        public string StreetAddress { get; set; }

        [DisplayName("City")]
        public string City { get; set; }

        [DisplayName("Zip Code")]
        public string ZipPostalCode { get; set; }

        [DisplayName("State")]
        public string State { get; set; }

        // Free trial integration in new page
        [DisplayName("Avg Sale Amout(eg $1200)")]
        public string AvgSaleAmout { get; set; }

        [DisplayName("Processor Name")]
        public string ProcessorName { get; set; }

        [DisplayName("Processor Email")]
        public string ProcessorEmail { get; set; }

        [DisplayName("Processor Phone Number")]
        public string ProcessorPhoneNumber { get; set; }
        //------------------------------------
        //--------------------------------------
        // For All Sites Order Totals
        public string dbname { get; set; }
        [DisplayName("TODAY")]
        public string todayTotal { get; set; }
        [DisplayName("THIS WEEK")]
        public string weekTotal { get; set; }
        [DisplayName("THIS MONTH")]
        public string monthTotal { get; set; }
        [DisplayName("THIS YEAR")]
        public string yearTotal { get; set; }
        [DisplayName("ALL TIME")]
        public string allTotal { get; set; }
        [DisplayName("AVG. ORDER")]
        public string avgOrder { get; set; }      
        //---------------------
        //Store Template Theme
        public IEnumerable<Theme> AvailableDesktopThemes { get; set; }
        public IEnumerable<MultiSite.Models.SiteTheme.Theme> SelectedDesktopThemes { get; set; }
        public PostedThemes PostedDesktopThemes { get; set; }
        public IEnumerable<MultiSite.Models.SiteTheme.Theme> AvailableMobileThemes { get; set; }
        public IEnumerable<MultiSite.Models.SiteTheme.Theme> SelectedMobileThemes { get; set; }
        public PostedThemes PostedMobileThemes { get; set; }
        public int? ParentId { get; set; }
        public bool IsDetails { get; set; }
        public int totalSites { get; set; }

        //-------------------------
    }

    public class DNSRecord
    {
        public string id { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public string content { get; set; }
        public bool proxied { get; set; }
    }

    public class DNSResult
    {
        DNSResult()
        {
            result = new List<DNSRecord>();
        }
        public List<DNSRecord> result { get; set; }
    }
}