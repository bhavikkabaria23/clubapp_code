﻿using System;
using Nop.Core.Data;

namespace MultiSite.Files
{
    public class MultisiteDataSettingsHelper : DataSettingsHelper
    {
        public static void ActivateMainDatabase()
        {
            var manager = new MultisiteDataSettingsManager();
            
            var settings = manager.LoadMainSettings();
            //_databaseIsInstalled = settings != null && !String.IsNullOrEmpty(settings.DataConnectionString);            
        }
    }
}
