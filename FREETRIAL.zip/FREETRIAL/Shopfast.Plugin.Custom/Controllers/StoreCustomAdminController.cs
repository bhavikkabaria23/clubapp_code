﻿using Nop.Admin.Controllers;
using Nop.Core.Data;
using Nop.Services.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Extensions;
using Shopfast.Plugin.Custom.Models.NopAdmin.Common;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class StoreCustomAdminController : BaseAdminController
    {
        private readonly IStoreService _storeService;

        public StoreCustomAdminController(IStoreService storeService)
        {
            this._storeService = storeService;            
        }

        #region Additional Methods
        // For package details
        [ValidateInput(false)]
        public ActionResult CheckPackageUpgradeDetails()
        {
            if (!MultisiteHelper.IsAdminSite)
            {
                var storesCount = _storeService.GetAllStores()
                   .Select(x => x.ToModel())
                   .ToList().Count();
                bool IsStoreLimit = MultisiteHelper.CheckPackageDetailsByCriteria("PackageStoreLimit", Convert.ToString(storesCount));
                if (IsStoreLimit)
                {
                    Session["StoreName"] = MultisiteHelper.SubDomain;
                    // here pass url of PackagesUpgrade.cshtml 
                    //string routeUrl = Url.RouteUrl("PackagesUpgrade", new { area = "" });
                    return Json(new
                    {
                        upgrade_section = new UpgradePackageJsonModel()
                        {
                            url = string.Format(@"http://{0}{1}", MultisiteHelper.Domain, "/plans-pricing"),
                            upgradeStatus = true
                        }
                    });
                }
            }
            return Json(new
            {
                upgrade_section = new UpgradePackageJsonModel()
                {
                    url = "",
                    upgradeStatus = false
                }
            });
        }
        //-------------------
        #endregion
    }
}