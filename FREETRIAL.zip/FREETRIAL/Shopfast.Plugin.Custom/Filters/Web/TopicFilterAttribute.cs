﻿using Nop.Core;
using Nop.Core.Domain.Seo;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Web.Models.Topics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Web
{


    public class TopicFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //if (filterContext != null)
            //{
            //    if (filterContext.ActionParameters != null && filterContext.ActionParameters.Any())
            //    {
            //        var dbContext = EngineContext.Current.Resolve<IDbContext>();
            //        TopicModel topicmodel = new TopicModel();
            //        if (filterContext.ActionParameters.SingleOrDefault().Key == "topicId")
            //        {
            //            int parameterValue = Convert.ToInt32(filterContext.ActionParameters.SingleOrDefault().Value);
            //            topicmodel = dbContext.SqlQuery<TopicModel>("select * from topic where id =" + parameterValue).FirstOrDefault();
            //        }
            //        else if (filterContext.ActionParameters.SingleOrDefault().Key == "systemName")
            //        {
            //            string parameterValue = Convert.ToString(filterContext.ActionParameters.SingleOrDefault().Value);
            //            topicmodel = dbContext.SqlQuery<TopicModel>("select * from topic where SystemName ='" + parameterValue+"'").FirstOrDefault();
            //        }

            //        if (topicmodel != null)
            //        {

            //            if (!string.IsNullOrEmpty(topicmodel.Body))
            //            {
            //                topicmodel.Body = Regex.Replace(topicmodel.Body, "%(Store[^%]+)%", m =>
            //                {
            //                    switch (m.Groups[1].Value.ToLower())
            //                    {
            //                        case "store.name":
            //                            return EngineContext.Current.Resolve<SeoSettings>().DefaultTitle;
            //                        case "store.url":
            //                            return EngineContext.Current.Resolve<IWebHelper>().GetStoreLocation(false);
            //                        case "storecdn.url":
            //                            if (!string.IsNullOrEmpty(EngineContext.Current.Resolve<ISettingService>().GetSettingByKey<string>("storeinformationsettings.cdnurl")))
            //                                return EngineContext.Current.Resolve<ISettingService>().GetSettingByKey<string>("storeinformationsettings.cdnurl");
            //                            break;
            //                    }
            //                    return "";
            //                }, RegexOptions.IgnoreCase);
            //            }

            //            dbContext.ExecuteSqlCommand("update topic SET Body=@p0,WHERE Id=@p1", false, null,
            //      topicmodel.Body, topicmodel.Id);
            //        }
            //    }
            //}

            

            //var dbContext = EngineContext.Current.Resolve<IDbContext>();
            //var orders = dbContext.SqlQuery<TopicModel>("select * from topic where ");
            //return orders.ToList();


            //dbContext.ExecuteSqlCommand("update Product SET BarcodeId=@p0, ShowOnPointOfSale=@p1  WHERE id=@p2", false, null,
            //      BarcodeId, ShowOnPointOfSale, productId);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var topicmodel = filterContext.Controller.ViewData.Model as TopicModel;
            if (topicmodel != null)
            {

                if (!string.IsNullOrEmpty(topicmodel.Body))
                {
                    topicmodel.Body = Regex.Replace(topicmodel.Body, "%(Store[^%]+)%", m =>
                    {
                        switch (m.Groups[1].Value.ToLower())
                        {
                            case "store.name":
                                return EngineContext.Current.Resolve<SeoSettings>().DefaultTitle;
                            case "store.url":
                                return EngineContext.Current.Resolve<IWebHelper>().GetStoreLocation(false);
                            case "storecdn.url":
                                if (!string.IsNullOrEmpty(EngineContext.Current.Resolve<ISettingService>().GetSettingByKey<string>("storeinformationsettings.cdnurl")))
                                    return EngineContext.Current.Resolve<ISettingService>().GetSettingByKey<string>("storeinformationsettings.cdnurl");
                                break;
                        }
                        return "";
                    }, RegexOptions.IgnoreCase);
                }
            }
        }
    }
}