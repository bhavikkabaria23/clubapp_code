﻿using Nop.Core.Domain.Customers;
using Nop.Services.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public class CustomerRegistrationServiceCustom : ICustomerRegistrationServiceCustom
    {
        #region Fields

        private readonly IEncryptionService _encryptionService;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="customerService">Customer service</param>
        /// <param name="encryptionService">Encryption service</param>
        /// <param name="newsLetterSubscriptionService">Newsletter subscription service</param>
        /// <param name="localizationService">Localization service</param>
        /// <param name="storeService">Store service</param>
        /// <param name="rewardPointsSettings">Reward points settings</param>
        /// <param name="customerSettings">Customer settings</param>
        public CustomerRegistrationServiceCustom(
            IEncryptionService encryptionService
            )
        {
            this._encryptionService = encryptionService;
        }

        #endregion

        #region Additional Methods
        public virtual string CreateManualPassword(PasswordFormat DefaultPasswordFormat, string HashedPasswordFormat, string PasswordSalt, string password)
        {
            string empty = string.Empty;
            switch (DefaultPasswordFormat)
            {
                case PasswordFormat.Clear:
                    {
                        empty = password;
                        break;
                    }
                case PasswordFormat.Hashed:
                    {
                        empty = this._encryptionService.CreatePasswordHash(password, PasswordSalt, HashedPasswordFormat);
                        break;
                    }
                case PasswordFormat.Encrypted:
                    {
                        empty = this._encryptionService.EncryptText(password, "");
                        break;
                    }
            }
            return empty;
        }
        #endregion
    }
}