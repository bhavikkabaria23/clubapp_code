﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nop.Services.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Security;
using Nop.Services.Messages;
using Nop.Services.Localization;
using Nop.Core.Domain.Customers;
using MultiSite.Data;
using Nop.Core.Data;
using Nop.Data;

namespace MultiSite.Services {
    public static class MultisiteCustomerRegistrationService //: CustomerRegistrationService 
    {
        //public MultisiteCustomerRegistrationService()
        //    : base(
        //        EngineContext.Current.Resolve<ICustomerService>(),
        //        EngineContext.Current.Resolve<IEncryptionService>(),
        //        EngineContext.Current.Resolve<INewsLetterSubscriptionService>(),
        //        EngineContext.Current.Resolve<ILocalizationService>(),
        //        EngineContext.Current.Resolve<RewardPointsSettings>(),
        //        EngineContext.Current.Resolve<CustomerSettings>()
        //    ) { }


        public static bool ValidateCustomer(string usernameOrEmail, string password,
            out List<string> storeNames) {

            Customer customer;
            storeNames = new List<string>();
            bool isValid = false;
            //storeName = MultisiteHelper.subdomain;

            //is user admin of main store?
            customer = GetCustomerFromStore(usernameOrEmail, MultisiteHelper.MainStoreName, true);
            if (customer != null && PasswordCorrect(customer, password)) {
                storeNames.Add(MultisiteHelper.MainStoreName);
                return true;
            }

            //is user a store owner?
            using (var dc = new Sites4Entities()) {
                var stores = dc.Sites.Include("Owner")
                    .Where(s => s.Owner.email == usernameOrEmail); //TODO: multiple stores per email
                foreach (var store in stores) {
                    customer = GetCustomerFromStore(usernameOrEmail, store.StoreName, true);
                    if (customer != null && PasswordCorrect(customer, password)) {
                        storeNames.Add(store.StoreName);
                        return true;
                    }
                }
            }

            //is user a customer on current store?
            customer = GetCustomerFromStore(usernameOrEmail, MultisiteHelper.SubDomain, false);
            if (customer != null && PasswordCorrect(customer, password)) {
                storeNames.Add(MultisiteHelper.SubDomain);
                return true;
            } else {
                //MultiSiteDataProvider.LogToAdminDB("pwd incorrect for " + usernameOrEmail);
            }

            return isValid;
        }

        private static bool PasswordCorrect(Customer customer, string password) {
            string pwd = "";
            var _encryptionService = EngineContext.Current.Resolve<IEncryptionService>();
            //var _encryptionService = new EncryptionService(null);
            var _customerSettings = EngineContext.Current.Resolve<CustomerSettings>();
            var customerPassword = EngineContext.Current.Resolve<ICustomerService>().GetCurrentPassword(customer.Id);
            if (customerPassword != null)
            {
                switch (customerPassword.PasswordFormat)
                {
                    case PasswordFormat.Encrypted:
                        pwd = _encryptionService.EncryptText(password);
                        break;
                    case PasswordFormat.Hashed:
                        pwd = _encryptionService.CreatePasswordHash(password, customerPassword.PasswordSalt, _customerSettings.HashedPasswordFormat);
                        //pwd = _encryptionService.CreatePasswordHash(password, customer.PasswordSalt);
                        break;
                    default:
                        pwd = password;
                        break;
                }
                return pwd == customerPassword.Password;
            }
            return false;
        }

        private static Customer GetCustomerFromStore(string email, string storeName, bool adminsOnly) {
            var connStr = MultisiteHelper.GetConnectionString(storeName);
            using (var dc = new MultisiteObjectContext(connStr, true)) {
                var customer = dc.Set<Customer>().SingleOrDefault(c =>
                    c.Active && !c.Deleted
                    && c.Email == email
                    && (!adminsOnly || c.CustomerRoles.Any(cr => cr.Id == 1))
                );
                return customer;
            }
        }

    }
}
