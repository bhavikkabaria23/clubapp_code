﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiSite.Models
{
    public class ChangePasswordSettings
    {
        public string DefaultPasswordFormat { get; set; }
        public string HashedPasswordFormat { get; set; }
        public string PasswordSalt { get; set; }
    }
}
