﻿// For package details                     
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiSite.Data
{
    [Table("Packages")]
    public class Package
    {
        public int Id { get; set; }

        public int PackageProductId { get; set; }

        public string PackageName { get; set; }

        public int PackagePeriod { get; set; }

        public bool PackageIsProductLimit { get; set; }

        public int PackageProductLimit { get; set; }

        public bool PackageIsStoreLimit { get; set; }

        public int PackageStoreLimit { get; set; }

        public decimal PackageDbStorageCapacity { get; set; }

        public string PackageDbStorageType { get; set; }

        public bool PackageIsPOSApiLimit { get; set; }        

        public bool PackageIsAllowQuickBook { get; set; }

        public bool PackageIsAllowCustomTheme { get; set; }

        public bool PackageIsEmailSupport { get; set; }

        public bool PackageIsLiveSupport { get; set; }
        

        public int PackagePOSApiLimit { get; set; }

        public bool PackageIsAllowFrontWebsite { get; set; }

        public bool PackageIsDbStorageCapacity { get; set; }        

        public bool PackageIsBestSell { get; set; }

        public string PackageCustomField1 { get; set; }

        public string PackageCustomField2 { get; set; }

        public string PackageCustomField3 { get; set; }

        public string PackageCustomField4 { get; set; }

        public string PackageCustomField5 { get; set; }

        
    }
}
//---------------------------------------