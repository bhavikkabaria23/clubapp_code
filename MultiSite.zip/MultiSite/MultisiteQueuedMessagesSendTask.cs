﻿using System;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Logging;
using Nop.Core.Domain.Messages;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Events;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Tasks;

namespace MultiSite.Services {
    public class MultisiteQueuedMessagesSendTask : ITask {
        public void Execute() {
            var maxTries = 3;
            IEventPublisher _eventPublisher = EngineContext.Current.Resolve<IEventPublisher>();
            IEmailSender _emailSender = EngineContext.Current.Resolve<IEmailSender>();
            IWebHelper _webHelper = EngineContext.Current.Resolve<IWebHelper>();
            IDbContext _dbContext = EngineContext.Current.Resolve<IDbContext>();
            IDataProvider dataProvider = EngineContext.Current.Resolve<IDataProvider>();
            CommonSettings commonSettings = EngineContext.Current.Resolve<CommonSettings>();

            foreach (var store in MultisiteHelper.AllSites) {
                var connStr = MultisiteHelper.GetConnectionString(store.storeName);
                var storeDC = new MultiSite.Data.MultisiteObjectContext(connStr, noRewrite: true);
                var queuedEmailRepository = new EfRepository<QueuedEmail>(storeDC);
                var _queuedEmailService = new QueuedEmailService(queuedEmailRepository, _eventPublisher, storeDC, dataProvider, commonSettings);
                var storeQueuedEmails = _queuedEmailService.SearchEmails(null, null, null, null,
                    false,true, maxTries, false, 0, 10000);                
                IRepository<Log> _logRepository = new EfRepository<Log>(storeDC);
                ILogger _logger = new DefaultLogger(_logRepository, _webHelper, storeDC, dataProvider, commonSettings);

                foreach (var queuedEmail in storeQueuedEmails) {
                    var bcc = String.IsNullOrWhiteSpace(queuedEmail.Bcc)
                                ? null
                                : queuedEmail.Bcc.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    var cc = String.IsNullOrWhiteSpace(queuedEmail.CC)
                                ? null
                                : queuedEmail.CC.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                    try {
                        _emailSender.SendEmail(queuedEmail.EmailAccount, queuedEmail.Subject, queuedEmail.Body,
                            queuedEmail.From, queuedEmail.FromName, queuedEmail.To, queuedEmail.ToName, bcc: bcc, cc: cc);

                        queuedEmail.SentOnUtc = DateTime.UtcNow;
                    }
                    catch (Exception exc) {
                        _logger.Error(string.Format("Error sending e-mail. {0}", exc.Message), exc);
                    }
                    finally {
                        queuedEmail.SentTries = queuedEmail.SentTries + 1;
                        _queuedEmailService.UpdateQueuedEmail(queuedEmail);
                    }
                }
            }

        }
    }
}
