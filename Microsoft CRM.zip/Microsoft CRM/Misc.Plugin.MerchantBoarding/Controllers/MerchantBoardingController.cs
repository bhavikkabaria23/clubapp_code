﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework.Controllers;
using System;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Common;
using System.Linq;
using System.Web;
using System.IO;
using Misc.Plugin.MerchantBoarding.Services;
using Nop.Web.Framework.Kendoui;
using Nop.Services.Security;
using System.Collections.Generic;
using Nop.Services.Catalog;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Collections.Specialized;
using System.Text;
using Newtonsoft.Json;
using System.Json;
using System.Security.Cryptography;
using Nop.Web.Framework.Security;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Framework;
using Nop.Core.Domain.Messages;
using Nop.Services.Messages;
using Nop.Services.Logging;
using Nop.Web.Framework.Mvc;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Samples.HelperCode;
using Nop.Core.Domain.Localization;
using Nop.Services.Authentication;
using Nop.Services.Events;
using Misc.Plugin.MerchantBoarding.Models;

namespace Misc.Plugin.MerchantBoarding.Controllers
{
    public class MerchantBoardingController : BaseController
    {
        private readonly ICustomerService _customerService;
        private readonly CustomerSettings _customerSettings;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IMerchantBoardingService _MerchantBoardingService;
        private readonly IPermissionService _permissionService;
        private readonly IPriceFormatter _priceFormatter;

        private readonly CaptchaSettings _captchaSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreContext _storeContext;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly IWorkContext _workContext;

        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IWebHelper _webHelper;
        private readonly IAuthenticationService _authenticationService;
        private readonly IEventPublisher _eventPublisher;




        #region Microsoft Dynamics CRM Variables
        //Provides a persistent client-to-CRM server communication channel.
        private HttpClient httpClient;
        //Start with base version and update with actual version later.
        private Version webAPIVersion = new Version(8, 2);
        //Centralized collection of entity URIs used to manage lifetimes.
        List<string> entityUris = new List<string>();

        //A set of variables to hold the state of and URIs for primary entity instances.
        private JObject registerForm = new JObject(), merchantForm = new JObject(),
            retrievedData;
        private string contact1Uri;
        private JObject account1 = new JObject(), account2 = new JObject(),
            retrievedAccount1, retrievedAccount2;
        private string account1Uri, account2Uri;
        #endregion



        public MerchantBoardingController(ICustomerService customerService,
            CustomerSettings customerSettings,
            IGenericAttributeService genericAttributeService,
            ICustomerRegistrationService customerRegistrationService,
            IMerchantBoardingService MerchantBoardingService,
            IPermissionService permissionService,
            IPriceFormatter priceFormatter,
            IStoreContext storeContext,
            IQueuedEmailService queuedEmailService,
            IEmailAccountService emailAccountService,
            ICustomerActivityService customerActivityService,
            ILocalizationService localizationService,
            CaptchaSettings captchaSettings,
            EmailAccountSettings emailAccountSettings,
            IWorkContext workContext,
            IWorkflowMessageService workflowMessageService,
            LocalizationSettings localizationSettings,
            IWebHelper webHelper,
            IAuthenticationService authenticationService,
            IEventPublisher eventPublisher
            )
        {
            this._customerService = customerService;
            this._customerSettings = customerSettings;
            this._genericAttributeService = genericAttributeService;
            this._customerRegistrationService = customerRegistrationService;
            this._MerchantBoardingService = MerchantBoardingService;
            this._permissionService = permissionService;
            this._priceFormatter = priceFormatter;

            this._storeContext = storeContext;
            this._queuedEmailService = queuedEmailService;
            this._emailAccountService = emailAccountService;
            this._localizationService = localizationService;
            this._customerActivityService = customerActivityService;
            this._captchaSettings = captchaSettings;
            this._emailAccountSettings = emailAccountSettings;
            this._workContext = workContext;

            this._workflowMessageService = workflowMessageService;
            this._localizationSettings = localizationSettings;
            this._webHelper = webHelper;
            this._authenticationService = authenticationService;
            this._eventPublisher = eventPublisher;

        }

        #region Microsoft Dynamics CRM Methods
        private string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        public async Task getWebAPIVersion()
        {

            HttpRequestMessage RetrieveVersionRequest =
              new HttpRequestMessage(HttpMethod.Get, getVersionedWebAPIPath() + "RetrieveVersion");

            HttpResponseMessage RetrieveVersionResponse =
                await httpClient.SendAsync(RetrieveVersionRequest);
            if (RetrieveVersionResponse.StatusCode == HttpStatusCode.OK)  //200
            {
                string str1 = await RetrieveVersionResponse.Content.ReadAsStringAsync();
                JObject RetrievedVersion = JsonConvert.DeserializeObject<JObject>(
                    await RetrieveVersionResponse.Content.ReadAsStringAsync());
                //Capture the actual version available in this organization
                webAPIVersion = Version.Parse((string)RetrievedVersion.GetValue("Version"));
            }
            else
            {
                Console.WriteLine("Failed to retrieve the version for reason: {0}",
                    RetrieveVersionResponse.ReasonPhrase);
                throw new CrmHttpResponseException(RetrieveVersionResponse.Content);
            }

        }

        /// <summary>
        /// Obtains the connection information from the application's configuration file, then 
        /// uses this info to connect to the specified CRM service.
        /// </summary>
        /// <param name="args"> Command line arguments. The first specifies the name of the 
        ///  connection string setting. </param>
        private void ConnectToCRM()
        {
            //Create a helper object to read app.config for service URL and application 
            // registration settings.
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //httpClient = new HttpClient(new HttpClientHandler() { Credentials = new NetworkCredential("akhasia@olb.com", "eVance1234!", "olb.com") });
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
            // httpClient.Timeout = new TimeSpan(0, 2, 0);
            //httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "8.2");
            //httpClient.DefaultRequestHeaders.Add("OData-Version", "8.2");
            //httpClient.DefaultRequestHeaders.Accept.Add(
            //    new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>  
        /// Demonstrates basic create, update, and retrieval operations for entity instances and 
        ///  single properties.  
        /// </summary>
        public async Task BasicCreateAndUpdatesAsync(FormCollection form)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //httpClient = new HttpClient(new HttpClientHandler() { Credentials = new NetworkCredential("akhasia@olb.com", "eVance1234!", "olb.com") });
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
            // httpClient.Timeout = new TimeSpan(0, 2, 0);


            string queryOptions;  //select, expand and filter clauses
            //First create a new contact instance,  then add additional property values and update 
            // several properties.
            //Local representation of CRM Contact instance
            registerForm.Add("new_companyname", form["CorporateName"]);
            registerForm.Add("new_name", form["ContactName"]);
            registerForm.Add("new_businessemailaddress", form["EmailAddress"]);
            registerForm.Add("new_businessphonenumber", form["TelephoneNumber"]);


            HttpRequestMessage createRequest1 =
                new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "new_merchantboardings");
            createRequest1.Content = new StringContent(registerForm.ToString(),
                Encoding.UTF8, "application/json");
            HttpResponseMessage createResponse1 =
                await httpClient.SendAsync(createRequest1);
            if (createResponse1.StatusCode == HttpStatusCode.NoContent)  //204
            {
                //Console.WriteLine("Contact '{0} {1}' created.",
                //    contact1.GetValue("firstname"), contact1.GetValue("lastname"));
                contact1Uri = createResponse1.Headers.
                    GetValues("OData-EntityId").FirstOrDefault();
                //contact1Uri = "https://olbgroup.olb.com:444/api/data/v8.2/contacts(cf7b784a-5e8b-e811-a94d-000d3a037737)";
                entityUris.Add(contact1Uri);
            }
            else
            {
                throw new CrmHttpResponseException(createResponse1.Content);
            }

            #region Other methods
            ////Add additional property values to the existing contact.  As a general 
            //// rule, only transmit a minimum working set of properties.
            //JObject contact1Add = new JObject();
            //contact1Add.Add("annualincome", 10000);
            //contact1Add.Add("jobtitle", "SSE");

            //HttpRequestMessage updateRequest1 = new HttpRequestMessage(
            //    new HttpMethod("PATCH"), contact1Uri);
            //updateRequest1.Content = new StringContent(contact1Add.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse1 =
            //    await httpClient.SendAsync(updateRequest1);
            //if (updateResponse1.StatusCode == HttpStatusCode.NoContent) //204
            //{
            //    Console.WriteLine("Contact '{0} {1}' updated with job title" +
            //        " and annual income.", contact1.GetValue("firstname"),
            //        contact1.GetValue("lastname"));
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update contact for reason: {0}",
            //        updateResponse1.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse1.Content);
            //}

            ////Retrieve the contact with its explicitly initialized properties.
            ////fullname is a read-only calculated value.
            //queryOptions = "?$select=fullname,annualincome,jobtitle,description";
            //HttpResponseMessage retrieveResponse1 = await httpClient.GetAsync(
            //    contact1Uri + queryOptions);
            //if (retrieveResponse1.StatusCode == HttpStatusCode.OK) //200
            //{
            //    retrievedContact1 = JsonConvert.DeserializeObject<JObject>(
            //        await retrieveResponse1.Content.ReadAsStringAsync());
            //    Console.WriteLine("Contact '{0}' retrieved: \n\tAnnual income: {1}" +
            //        "\n\tJob title: {2} \n\tDescription: {3}.",
            //        // Can use either indexer or GetValue method (or a mix of two)
            //        retrievedContact1.GetValue("fullname"),
            //        retrievedContact1["annualincome"],
            //        retrievedContact1["jobtitle"],
            //        retrievedContact1["description"]);   //description is initialized empty.
            //}
            //else
            //{
            //    Console.WriteLine("Failed to retrieve contact for reason: {0}",
            //        retrieveResponse1.ReasonPhrase);
            //    throw new CrmHttpResponseException(retrieveResponse1.Content);
            //}

            ////Modify specific properties and then update entity instance.
            //JObject contact1Update = new JObject();
            //contact1Update.Add("jobtitle", "Senior Developer");
            //contact1Update.Add("annualincome", 95000);
            //contact1Update.Add("description", "Assignment to-be-determined");
            //HttpRequestMessage updateRequest2 = new HttpRequestMessage(
            //    new HttpMethod("PATCH"), contact1Uri);
            //updateRequest2.Content = new StringContent(contact1Update.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse2 =
            //    await httpClient.SendAsync(updateRequest2);
            //if (updateResponse2.StatusCode == HttpStatusCode.NoContent)
            //{
            //    Console.WriteLine("Contact '{0}' updated:", retrievedContact1["fullname"]);
            //    Console.WriteLine("\tJob title: {0}", contact1Update["jobtitle"]);
            //    Console.WriteLine("\tAnnual income: {0}", contact1Update["annualincome"]);
            //    Console.WriteLine("\tDescription: {0}", contact1Update["description"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update contact for reason: {0}",
            //        updateResponse2.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse2.Content);
            //}

            //// Change just one property 
            //string phone1 = "555-0105";
            //// Create unique identifier by appending property name 
            //string contactPhoneUri =
            //        string.Format("{0}/{1}", contact1Uri, "telephone1");
            //JObject phoneValue = new JObject();
            //phoneValue.Add("value", phone1);   //Updates must use keyword "value". 

            //HttpRequestMessage updateRequest3 =
            //    new HttpRequestMessage(HttpMethod.Put, contactPhoneUri);
            //updateRequest3.Content = new StringContent(phoneValue.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse3 =
            //    await httpClient.SendAsync(updateRequest3);
            //if (updateResponse3.StatusCode == HttpStatusCode.NoContent)
            //{
            //    Console.WriteLine("Contact '{0}' phone number updated.",
            //        retrievedContact1["fullname"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update the contact phone number for reason: {0}.",
            //        updateResponse3.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse3.Content);
            //}

            ////Now retrieve just the single property.
            //JObject retrievedProperty1;
            //HttpResponseMessage retrieveResponse2 =
            //    await httpClient.GetAsync(contactPhoneUri);
            //if (retrieveResponse2.StatusCode == HttpStatusCode.OK)
            //{
            //    retrievedProperty1 = JsonConvert.DeserializeObject<JObject>(
            //        await retrieveResponse2.Content.ReadAsStringAsync());
            //    Console.WriteLine("Contact's telephone# is: {0}.",
            //        retrievedProperty1["value"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to retrieve the contact phone number for reason: {0}.",
            //        retrieveResponse2.ReasonPhrase);
            //    throw new CrmHttpResponseException(retrieveResponse2.Content);
            //}

            ////The following capabilities require version 8.2 or higher
            //if (webAPIVersion >= Version.Parse("8.2"))
            //{

            //    //Alternately, starting with December 2016 update (v8.2), a contact instance can be 
            //    //created and its properties returned in one operation by using a 
            //    //'Prefer: return=representation' header. Note that a 201 (Created) success status 
            //    // is returned, and not a 204 (No content).
            //    string contactAltUri;
            //    JObject contactAlt = new JObject();
            //    contactAlt.Add("firstname", "Peter_Alt");
            //    contactAlt.Add("lastname", "Cambel");
            //    contactAlt.Add("jobtitle", "Junior Developer");
            //    contactAlt.Add("annualincome", 80000);
            //    contactAlt.Add("telephone1", "555-0110");

            //    queryOptions = "?$select=fullname,annualincome,jobtitle,contactid";
            //    HttpRequestMessage createRequestAlt =
            //        new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "contacts" + queryOptions);
            //    createRequestAlt.Content = new StringContent(contactAlt.ToString(),
            //        Encoding.UTF8, "application/json");
            //    createRequestAlt.Headers.Add("Prefer", "return=representation");

            //    HttpResponseMessage createResponseAlt = await httpClient.SendAsync(createRequestAlt);
            //    if (createResponseAlt.StatusCode == HttpStatusCode.Created)  //201
            //    {
            //        //Body should contain the requested new-contact information.
            //        JObject createdContactAlt = JsonConvert.DeserializeObject<JObject>(
            //            await createResponseAlt.Content.ReadAsStringAsync());
            //        //Because 'OData-EntityId' header not returned in a 201 response, you must instead 
            //        // construct the URI.
            //        contactAltUri = httpClient.BaseAddress + getVersionedWebAPIPath() + "contacts(" + createdContactAlt["contactid"] + ")";
            //        entityUris.Add(contactAltUri);
            //        Console.WriteLine(
            //            "Contact '{0}' created: \n\tAnnual income: {1}" + "\n\tJob title: {2}",
            //            createdContactAlt["fullname"],
            //            createdContactAlt["annualincome"],
            //            createdContactAlt["jobtitle"]);
            //        Console.WriteLine("Contact URI: {0}", contactAltUri);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Failed to create contact for reason: {0}",
            //            createResponseAlt.ReasonPhrase);
            //        throw new CrmHttpResponseException(createResponseAlt.Content);
            //    }

            //    //Similarly, the December 2016 update (v8.2) also enables returning selected properties   
            //    //after an update operation (PATCH), with the 'Prefer: return=representation' header.
            //    //Here a success is indicated by 200 (OK) instead of 204 (No content).

            //    //Since we're reusing a local JObject, reinitialize it to remove extraneous properties.
            //    contactAlt.RemoveAll();
            //    contactAlt["annualincome"] = 95000;
            //    contactAlt["jobtitle"] = "Senior Developer";
            //    contactAlt["description"] = "MS Azure and Dynamics 365 Specialist";

            //    queryOptions = "?$select=fullname,annualincome,jobtitle";
            //    HttpRequestMessage updateRequestAlt = new HttpRequestMessage(
            //        new HttpMethod("PATCH"), contactAltUri + queryOptions);
            //    updateRequestAlt.Content = new StringContent(contactAlt.ToString(),
            //        Encoding.UTF8, "application/json");
            //    updateRequestAlt.Headers.Add("Prefer", "return=representation");

            //    HttpResponseMessage updateResponseAlt = await httpClient.SendAsync(updateRequestAlt);
            //    if (updateResponseAlt.StatusCode == HttpStatusCode.OK) //200
            //    {
            //        //Body should contain the requested updated-contact information.
            //        JObject UpdatedContactAlt = JsonConvert.DeserializeObject<JObject>(
            //            await updateResponseAlt.Content.ReadAsStringAsync());
            //        Console.WriteLine(
            //            "Contact '{0}' updated: \n\tAnnual income: {1}" + "\n\tJob title: {2}",
            //            UpdatedContactAlt["fullname"],
            //            UpdatedContactAlt["annualincome"],
            //            UpdatedContactAlt["jobtitle"]);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Failed to update contact for reason: {0}",
            //            updateResponse1.ReasonPhrase);
            //        throw new CrmHttpResponseException(updateResponse1.Content);
            //    }
            //}
            #endregion
        }

        /// <summary> Helper method to display caught exceptions </summary>
        private static void DisplayException(Exception ex)
        {
            Console.WriteLine("The application terminated with an error.");
            Console.WriteLine(ex.Message);
            while (ex.InnerException != null)
            {
                Console.WriteLine("\t* {0}", ex.InnerException.Message);
                ex = ex.InnerException;
            }
        }

        public async Task RunAsync(FormCollection form)
        {
            try
            {
                //await getWebAPIVersion();
                await BasicCreateAndUpdatesAsync(form);
                // await CreateWithAssociationAsync();
                //  await CreateRelatedAsync();
                // await AssociateExistingAsync();
            }
            catch (Exception ex)
            { DisplayException(ex); }
        }

        #endregion

        #region All Forms CRM Methods
        public async Task<MerchantInformationModel> MerchantInformationCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            MerchantInformationModel model = new MerchantInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";
                        model.FaxNumber = jvalue[0].SelectToken("new_faxnumber").ToString();
                        model.MerchantName = jvalue[0].SelectToken("new_merchantname").ToString();
                        model.LocationAddress = jvalue[0].SelectToken("new_locationaddress1").ToString();
                        model.City = jvalue[0].SelectToken("new_city1").ToString();
                        model.Zip = jvalue[0].SelectToken("new_zipcode1").ToString();
                        model.CustomerEmail = jvalue[0].SelectToken("new_businessemailaddress").ToString();
                        model.ContactName = jvalue[0].SelectToken("new_name").ToString();
                        model.TelePhoneNumber = jvalue[0].SelectToken("new_businessphonenumber").ToString();
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }
        public async Task<bool> MerchantInformationCRMPost(FormCollection fc, MerchantInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
        
            // Generate json object from model
            merchantForm.Add("new_faxnumber", model.FaxNumber);
            merchantForm.Add("new_merchantname", model.MerchantName);
            merchantForm.Add("new_locationaddress1", model.LocationAddress);
            merchantForm.Add("new_city1", model.City);
            merchantForm.Add("new_zipcode1", model.Zip);

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {               
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<LegalInformationModel> LegalInformationModelCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            LegalInformationModel model = new LegalInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.LegalName = jvalue[0].SelectToken("new_corporationlegalname").ToString();                        

                        model.LocationAddress = jvalue[0].SelectToken("new_corporateaddress").ToString();
                        model.City = jvalue[0].SelectToken("new_city3").ToString();
                        model.Zip = jvalue[0].SelectToken("new_zipcode3").ToString();

                        model.IsTaxId = Convert.ToBoolean(jvalue[0].SelectToken("new_federaltax"));
                        model.TaxOrSsn = jvalue[0].SelectToken("new_federaltaxid").ToString();

                        model.IsMailingAddressSame = Convert.ToBoolean(jvalue[0].SelectToken("new_mailingaddress"));
                        model.MailLocationAddress = jvalue[0].SelectToken("new_mailingaddress1").ToString();
                        model.MailCity = jvalue[0].SelectToken("new_city4").ToString();
                        model.MailZip = jvalue[0].SelectToken("new_zipcode4").ToString();

                        model.CustomerEmail = jvalue[0].SelectToken("new_businessemailaddress").ToString();
                        model.ContactName = jvalue[0].SelectToken("new_name").ToString();                        
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }
        public async Task<bool> LegalInformationCRMPost(FormCollection fc, LegalInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_corporationlegalname", model.LegalName);

            merchantForm.Add("new_corporateaddress", model.LocationAddress);
            merchantForm.Add("new_city3", model.City);
            merchantForm.Add("new_zipcode3", model.Zip);

            merchantForm.Add("new_federaltax", model.IsTaxId);
            merchantForm.Add("new_federaltaxid", model.TaxOrSsn);

            merchantForm.Add("new_mailingaddress", model.IsMailingAddressSame);
            merchantForm.Add("new_mailingaddress1", model.MailLocationAddress);
            merchantForm.Add("new_city4", model.MailCity);
            merchantForm.Add("new_zipcode4", model.MailZip);

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<BusinessInformationModel> BusinessInformationCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            BusinessInformationModel model = new BusinessInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.IsPaymentCard = Convert.ToBoolean(jvalue[0].SelectToken("new_doyoucurrentlyacceptpaymentcards"));
                        if(model.IsPaymentCard)
                            model.PaymentCard = Convert.ToString(jvalue[0].SelectToken("new_whoisitwith"));
                        model.IsTerminated = Convert.ToBoolean(jvalue[0].SelectToken("new_hasthemerchantbeenterminatedfromaccepting"));
                        if(model.IsTerminated)
                            model.AcceptCardExplanation = Convert.ToString(jvalue[0].SelectToken("new_ifsoexplain"));
                        model.IsSecurityBranch = Convert.ToBoolean(jvalue[0].SelectToken("new_haveyouhadasecuritybreach"));
                        if(model.IsSecurityBranch)
                            model.SecurityBranchExplanation = Convert.ToString(jvalue[0].SelectToken("new_whoisitwith1"));

                        int BusinessYears;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_lengthoftimeinbusinessyears")), out BusinessYears);
                        model.BusinessYears = BusinessYears;
                        int BusinessMonths;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_lengthoftimeinbusinessmonths")), out BusinessMonths);
                        model.BusinessMonths = BusinessMonths;                  
                    }
                }
            }
            return model;
        }
        public async Task<bool> BusinessInformationCRMPost(FormCollection fc, BusinessInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_doyoucurrentlyacceptpaymentcards", model.IsPaymentCard);
            if(model.IsPaymentCard)
                merchantForm.Add("new_whoisitwith", model.PaymentCard);            
            merchantForm.Add("new_hasthemerchantbeenterminatedfromaccepting", model.IsTerminated);
            if (model.IsTerminated)
                merchantForm.Add("new_ifsoexplain", model.AcceptCardExplanation);
            merchantForm.Add("new_haveyouhadasecuritybreach", model.IsSecurityBranch);
            if(model.IsSecurityBranch)
                merchantForm.Add("new_whoisitwith1", model.SecurityBranchExplanation);

            merchantForm.Add("new_lengthoftimeinbusinessyears", Convert.ToString(model.BusinessYears));
            merchantForm.Add("new_lengthoftimeinbusinessmonths", Convert.ToString(model.BusinessMonths));            

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<BusinessInformation2Model> BusinessInformation2CRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            BusinessInformation2Model model = new BusinessInformation2Model();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.IsSeasonalSales = Convert.ToBoolean(jvalue[0].SelectToken("new_seasonalsales"));                        
                        model.ProductsOrServices = Convert.ToString(jvalue[0].SelectToken("new_productsorservicesbeingoffered"));

                        model.MerchantUse = Convert.ToBoolean(jvalue[0].SelectToken("new_ifterminalwhattype"));
                        if (model.MerchantUse)
                        {
                            model.PaymentApplicationName = Convert.ToString(jvalue[0].SelectToken("new_whatisthepaymentapplicationname"));
                            model.PaymentApplicationVersion = Convert.ToString(jvalue[0].SelectToken("new_merchantnametoappearonconsumerstatement"));
                        }                        
                        else
                        {
                            model.TerminalType = Convert.ToString(jvalue[0].SelectToken("new_ifterminalwhattype"));
                        }

                        model.MerchantNameAppear = Convert.ToBoolean(jvalue[0].SelectToken("new_merchantnametoappearonconsumerstatement"));                        
                    }
                }
            }
            return model;
        }
        public async Task<bool> BusinessInformation2CRMPost(FormCollection fc, BusinessInformation2Model model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_seasonalsales", model.IsSeasonalSales);
            merchantForm.Add("new_productsorservicesbeingoffered", model.ProductsOrServices);

            merchantForm.Add("new_ifterminalwhattype", model.MerchantUse);
            if (model.MerchantUse)
            {
                merchantForm.Add("new_whatisthepaymentapplicationname", model.PaymentApplicationName);
                merchantForm.Add("new_merchantnametoappearonconsumerstatement", model.PaymentApplicationVersion);
            }
            else
            {
                merchantForm.Add("new_ifterminalwhattype", model.TerminalType);
            }            

            merchantForm.Add("new_merchantnametoappearonconsumerstatement", model.MerchantNameAppear);            

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }
        #endregion

        private string RegisterCustomer(FormCollection form, out List<string> errors)
        {
            errors = new List<string>();

            if (_workContext.CurrentCustomer.IsRegistered())
            {
                //Already registered customer. 
                _authenticationService.SignOut();

                //raise logged out event       
                _eventPublisher.Publish(new CustomerLoggedOutEvent(_workContext.CurrentCustomer));

                //Save a new record
                _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            }
            var customer = _workContext.CurrentCustomer;
            string Password = "password@123";

            bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
            var registrationRequest = new CustomerRegistrationRequest(customer,
                     form["EmailAddress"],
                     form["EmailAddress"],
                     Password,
                     _customerSettings.DefaultPasswordFormat,
                     _storeContext.CurrentStore.Id,
                     isApproved);
            //--------------------------------
            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
            if (registrationResult.Success)
            {

                //form fields
                string fullName = form["ContactName"];
                string firstName = string.Empty;
                string lastName = string.Empty;
                if (!string.IsNullOrEmpty(fullName) && fullName.Split(' ').Length > 1)
                {
                    string[] name = fullName.Split(' ');
                    if (name.Length > 1)
                    {
                        firstName = name[0];
                        lastName = name[1];
                    }
                    else
                    {
                        firstName = name[0];
                    }
                }
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, firstName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, lastName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, form["CorporateName"]);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, form["TelephoneNumber"]);

                //notifications
                if (_customerSettings.NotifyNewCustomerRegistration)
                    _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                //login customer now
                if (isApproved)
                    _authenticationService.SignIn(customer, true);

                switch (_customerSettings.UserRegistrationType)
                {
                    case UserRegistrationType.EmailValidation:
                        {
                            //email validation message
                            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                            _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id);

                            //result                            
                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });

                        }
                    case UserRegistrationType.AdminApproval:
                        {
                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                        }
                    case UserRegistrationType.Standard:
                        {
                            //send customer welcome message
                            _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);

                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                        }
                    default:
                        {
                            return Url.RouteUrl("HomePage");
                        }
                }
            }
            else
            {
                foreach (var err in registrationResult.Errors)
                {
                    errors.Add(err);
                }
                return "";
            }
        }

        [HttpPost]
        public ActionResult Register(FormCollection form)
        {
            string redirectUrl = "/";
            try
            {
                //Read configuration file and connect to specified CRM server.
                //ConnectToCRM();
                List<string> errors = new List<string>();
                redirectUrl = RegisterCustomer(form, out errors);
                if (!string.IsNullOrEmpty(redirectUrl))
                {
                    Task.WaitAll(Task.Run(async () => await RunAsync(form)));
                }
            }
            catch (System.Exception ex) { DisplayException(ex); }
            finally
            {
                if (httpClient != null)
                { httpClient.Dispose(); }
            }
            return Redirect(redirectUrl);
        }

        public ActionResult merchanthtml()
        {
            return View("/Themes/Main/Views/MerchantBoarding/HomeTest.cshtml");
        }

        [Authorize]
        public ActionResult MerchantInformation()
        {
            MerchantInformationModel model = new MerchantInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await MerchantInformationCRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_MerchantInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult MerchantInformation(FormCollection fc, MerchantInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await MerchantInformationCRMPost(fc, model); }));

            if(result == true)
            {
                return RedirectToAction("LegalInformation");
            }
            else
            {
                return Content("");
            }            
        }

        [Authorize]
        public ActionResult LegalInformation()
        {
            LegalInformationModel model = new LegalInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await LegalInformationModelCRMGet(); }));            
            return View("/Themes/Main/Views/MerchantBoarding/_LegalInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult LegalInformation(FormCollection fc, LegalInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await LegalInformationCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("BusinessInformation");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult BusinessInformation()
        {
            BusinessInformationModel model = new BusinessInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await BusinessInformationCRMGet(); }));            
            return View("/Themes/Main/Views/MerchantBoarding/_BusinessInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult BusinessInformation(FormCollection fc, BusinessInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await BusinessInformationCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("BusinessInformation2");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult BusinessInformation2()
        {
            BusinessInformation2Model model = new BusinessInformation2Model();
            Task.WaitAll(Task.Run(async () => { model = await BusinessInformation2CRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_BusinessInformation2.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult BusinessInformation2(FormCollection fc, BusinessInformation2Model model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await BusinessInformation2CRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("");
            }
            else
            {
                return Content("");
            }
        }

        //[HttpPost]
        //public ActionResult Index(MerchantBoardingodel model)
        //{          
        //    return Redirect("/MerchantBoarding");
        //}

    }
}