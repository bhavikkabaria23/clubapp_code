﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework.Controllers;
using System;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Common;
using System.Linq;
using System.Web;
using System.IO;
using Misc.Plugin.MerchantBoarding.Services;
using Nop.Web.Framework.Kendoui;
using Nop.Services.Security;
using System.Collections.Generic;
using Nop.Services.Catalog;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Collections.Specialized;
using System.Text;
using Newtonsoft.Json;
using System.Json;
using System.Security.Cryptography;
using Nop.Web.Framework.Security;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Framework;
using Nop.Core.Domain.Messages;
using Nop.Services.Messages;
using Nop.Services.Logging;
using Nop.Web.Framework.Mvc;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Samples.HelperCode;
using Nop.Core.Domain.Localization;
using Nop.Services.Authentication;
using Nop.Services.Events;
using Misc.Plugin.MerchantBoarding.Models;

namespace Misc.Plugin.MerchantBoarding.Controllers
{
    public class MerchantBoardingController : BaseController
    {
        private readonly ICustomerService _customerService;
        private readonly CustomerSettings _customerSettings;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IMerchantBoardingService _MerchantBoardingService;
        private readonly IPermissionService _permissionService;
        private readonly IPriceFormatter _priceFormatter;

        private readonly CaptchaSettings _captchaSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreContext _storeContext;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly IWorkContext _workContext;

        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IWebHelper _webHelper;
        private readonly IAuthenticationService _authenticationService;
        private readonly IEventPublisher _eventPublisher;




        #region Microsoft Dynamics CRM Variables
        //Provides a persistent client-to-CRM server communication channel.
        private HttpClient httpClient;
        //Start with base version and update with actual version later.
        private Version webAPIVersion = new Version(8, 2);
        //Centralized collection of entity URIs used to manage lifetimes.
        List<string> entityUris = new List<string>();

        //A set of variables to hold the state of and URIs for primary entity instances.
        private JObject registerForm = new JObject(), merchantForm = new JObject(),
            retrievedData;
        private string contact1Uri;
        private JObject account1 = new JObject(), account2 = new JObject(),
            retrievedAccount1, retrievedAccount2;
        private string account1Uri, account2Uri;
        #endregion



        public MerchantBoardingController(ICustomerService customerService,
            CustomerSettings customerSettings,
            IGenericAttributeService genericAttributeService,
            ICustomerRegistrationService customerRegistrationService,
            IMerchantBoardingService MerchantBoardingService,
            IPermissionService permissionService,
            IPriceFormatter priceFormatter,
            IStoreContext storeContext,
            IQueuedEmailService queuedEmailService,
            IEmailAccountService emailAccountService,
            ICustomerActivityService customerActivityService,
            ILocalizationService localizationService,
            CaptchaSettings captchaSettings,
            EmailAccountSettings emailAccountSettings,
            IWorkContext workContext,
            IWorkflowMessageService workflowMessageService,
            LocalizationSettings localizationSettings,
            IWebHelper webHelper,
            IAuthenticationService authenticationService,
            IEventPublisher eventPublisher
            )
        {
            this._customerService = customerService;
            this._customerSettings = customerSettings;
            this._genericAttributeService = genericAttributeService;
            this._customerRegistrationService = customerRegistrationService;
            this._MerchantBoardingService = MerchantBoardingService;
            this._permissionService = permissionService;
            this._priceFormatter = priceFormatter;

            this._storeContext = storeContext;
            this._queuedEmailService = queuedEmailService;
            this._emailAccountService = emailAccountService;
            this._localizationService = localizationService;
            this._customerActivityService = customerActivityService;
            this._captchaSettings = captchaSettings;
            this._emailAccountSettings = emailAccountSettings;
            this._workContext = workContext;

            this._workflowMessageService = workflowMessageService;
            this._localizationSettings = localizationSettings;
            this._webHelper = webHelper;
            this._authenticationService = authenticationService;
            this._eventPublisher = eventPublisher;

        }

        #region Private Methods - Common
        private bool ConvertToBoolean(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                return Convert.ToBoolean(value);
            }
            else
            {
                return false;
            }
        }
        private List<bool> SetCheckBoxValues(string values, List<bool> boolValues)
        {
            try
            {
                string[] arrValues = values.Split(',');
                if (arrValues.Length > 0)
                {
                    for (int i = 0; i < arrValues.Length; i++)
                    {
                        int index;
                        if (int.TryParse(arrValues[i], out index))
                        {
                            boolValues[index - 1] = true;
                        }
                    }
                }
                return boolValues;
            }
            catch (Exception ex)
            {
                return boolValues;
            }
        }
        private string GetCheckboxValues(List<bool> boolValues)
        {
            string strValues = null;
            try
            {
                for (int i = 0; i < boolValues.Count(); i++)
                {
                    if (boolValues[i])
                    {
                        strValues += i + 1 + ",";
                    }
                }
                return strValues;
            }
            catch (Exception ex)
            {
                return strValues;
            }            
        }
        #endregion

        #region Microsoft Dynamics CRM Methods
        private string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        public async Task getWebAPIVersion()
        {

            HttpRequestMessage RetrieveVersionRequest =
              new HttpRequestMessage(HttpMethod.Get, getVersionedWebAPIPath() + "RetrieveVersion");

            HttpResponseMessage RetrieveVersionResponse =
                await httpClient.SendAsync(RetrieveVersionRequest);
            if (RetrieveVersionResponse.StatusCode == HttpStatusCode.OK)  //200
            {
                string str1 = await RetrieveVersionResponse.Content.ReadAsStringAsync();
                JObject RetrievedVersion = JsonConvert.DeserializeObject<JObject>(
                    await RetrieveVersionResponse.Content.ReadAsStringAsync());
                //Capture the actual version available in this organization
                webAPIVersion = Version.Parse((string)RetrievedVersion.GetValue("Version"));
            }
            else
            {
                Console.WriteLine("Failed to retrieve the version for reason: {0}",
                    RetrieveVersionResponse.ReasonPhrase);
                throw new CrmHttpResponseException(RetrieveVersionResponse.Content);
            }

        }

        /// <summary>
        /// Obtains the connection information from the application's configuration file, then 
        /// uses this info to connect to the specified CRM service.
        /// </summary>
        /// <param name="args"> Command line arguments. The first specifies the name of the 
        ///  connection string setting. </param>
        private void ConnectToCRM()
        {
            //Create a helper object to read app.config for service URL and application 
            // registration settings.
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //httpClient = new HttpClient(new HttpClientHandler() { Credentials = new NetworkCredential("akhasia@olb.com", "eVance1234!", "olb.com") });
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
            // httpClient.Timeout = new TimeSpan(0, 2, 0);
            //httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "8.2");
            //httpClient.DefaultRequestHeaders.Add("OData-Version", "8.2");
            //httpClient.DefaultRequestHeaders.Accept.Add(
            //    new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>  
        /// Demonstrates basic create, update, and retrieval operations for entity instances and 
        ///  single properties.  
        /// </summary>
        public async Task BasicCreateAndUpdatesAsync(FormCollection form)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //httpClient = new HttpClient(new HttpClientHandler() { Credentials = new NetworkCredential("akhasia@olb.com", "eVance1234!", "olb.com") });
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
            // httpClient.Timeout = new TimeSpan(0, 2, 0);


            string queryOptions;  //select, expand and filter clauses
            //First create a new contact instance,  then add additional property values and update 
            // several properties.
            //Local representation of CRM Contact instance
            registerForm.Add("new_companyname", form["CorporateName"]);
            registerForm.Add("new_name", form["ContactName"]);
            registerForm.Add("new_businessemailaddress", form["EmailAddress"]);
            registerForm.Add("new_businessphonenumber", form["TelephoneNumber"]);


            HttpRequestMessage createRequest1 =
                new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "new_merchantboardings");
            createRequest1.Content = new StringContent(registerForm.ToString(),
                Encoding.UTF8, "application/json");
            HttpResponseMessage createResponse1 =
                await httpClient.SendAsync(createRequest1);
            if (createResponse1.StatusCode == HttpStatusCode.NoContent)  //204
            {
                //Console.WriteLine("Contact '{0} {1}' created.",
                //    contact1.GetValue("firstname"), contact1.GetValue("lastname"));
                contact1Uri = createResponse1.Headers.
                    GetValues("OData-EntityId").FirstOrDefault();
                //contact1Uri = "https://olbgroup.olb.com:444/api/data/v8.2/contacts(cf7b784a-5e8b-e811-a94d-000d3a037737)";
                entityUris.Add(contact1Uri);
            }
            else
            {
                throw new CrmHttpResponseException(createResponse1.Content);
            }

            #region Other methods
            ////Add additional property values to the existing contact.  As a general 
            //// rule, only transmit a minimum working set of properties.
            //JObject contact1Add = new JObject();
            //contact1Add.Add("annualincome", 10000);
            //contact1Add.Add("jobtitle", "SSE");

            //HttpRequestMessage updateRequest1 = new HttpRequestMessage(
            //    new HttpMethod("PATCH"), contact1Uri);
            //updateRequest1.Content = new StringContent(contact1Add.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse1 =
            //    await httpClient.SendAsync(updateRequest1);
            //if (updateResponse1.StatusCode == HttpStatusCode.NoContent) //204
            //{
            //    Console.WriteLine("Contact '{0} {1}' updated with job title" +
            //        " and annual income.", contact1.GetValue("firstname"),
            //        contact1.GetValue("lastname"));
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update contact for reason: {0}",
            //        updateResponse1.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse1.Content);
            //}

            ////Retrieve the contact with its explicitly initialized properties.
            ////fullname is a read-only calculated value.
            //queryOptions = "?$select=fullname,annualincome,jobtitle,description";
            //HttpResponseMessage retrieveResponse1 = await httpClient.GetAsync(
            //    contact1Uri + queryOptions);
            //if (retrieveResponse1.StatusCode == HttpStatusCode.OK) //200
            //{
            //    retrievedContact1 = JsonConvert.DeserializeObject<JObject>(
            //        await retrieveResponse1.Content.ReadAsStringAsync());
            //    Console.WriteLine("Contact '{0}' retrieved: \n\tAnnual income: {1}" +
            //        "\n\tJob title: {2} \n\tDescription: {3}.",
            //        // Can use either indexer or GetValue method (or a mix of two)
            //        retrievedContact1.GetValue("fullname"),
            //        retrievedContact1["annualincome"],
            //        retrievedContact1["jobtitle"],
            //        retrievedContact1["description"]);   //description is initialized empty.
            //}
            //else
            //{
            //    Console.WriteLine("Failed to retrieve contact for reason: {0}",
            //        retrieveResponse1.ReasonPhrase);
            //    throw new CrmHttpResponseException(retrieveResponse1.Content);
            //}

            ////Modify specific properties and then update entity instance.
            //JObject contact1Update = new JObject();
            //contact1Update.Add("jobtitle", "Senior Developer");
            //contact1Update.Add("annualincome", 95000);
            //contact1Update.Add("description", "Assignment to-be-determined");
            //HttpRequestMessage updateRequest2 = new HttpRequestMessage(
            //    new HttpMethod("PATCH"), contact1Uri);
            //updateRequest2.Content = new StringContent(contact1Update.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse2 =
            //    await httpClient.SendAsync(updateRequest2);
            //if (updateResponse2.StatusCode == HttpStatusCode.NoContent)
            //{
            //    Console.WriteLine("Contact '{0}' updated:", retrievedContact1["fullname"]);
            //    Console.WriteLine("\tJob title: {0}", contact1Update["jobtitle"]);
            //    Console.WriteLine("\tAnnual income: {0}", contact1Update["annualincome"]);
            //    Console.WriteLine("\tDescription: {0}", contact1Update["description"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update contact for reason: {0}",
            //        updateResponse2.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse2.Content);
            //}

            //// Change just one property 
            //string phone1 = "555-0105";
            //// Create unique identifier by appending property name 
            //string contactPhoneUri =
            //        string.Format("{0}/{1}", contact1Uri, "telephone1");
            //JObject phoneValue = new JObject();
            //phoneValue.Add("value", phone1);   //Updates must use keyword "value". 

            //HttpRequestMessage updateRequest3 =
            //    new HttpRequestMessage(HttpMethod.Put, contactPhoneUri);
            //updateRequest3.Content = new StringContent(phoneValue.ToString(),
            //    Encoding.UTF8, "application/json");
            //HttpResponseMessage updateResponse3 =
            //    await httpClient.SendAsync(updateRequest3);
            //if (updateResponse3.StatusCode == HttpStatusCode.NoContent)
            //{
            //    Console.WriteLine("Contact '{0}' phone number updated.",
            //        retrievedContact1["fullname"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to update the contact phone number for reason: {0}.",
            //        updateResponse3.ReasonPhrase);
            //    throw new CrmHttpResponseException(updateResponse3.Content);
            //}

            ////Now retrieve just the single property.
            //JObject retrievedProperty1;
            //HttpResponseMessage retrieveResponse2 =
            //    await httpClient.GetAsync(contactPhoneUri);
            //if (retrieveResponse2.StatusCode == HttpStatusCode.OK)
            //{
            //    retrievedProperty1 = JsonConvert.DeserializeObject<JObject>(
            //        await retrieveResponse2.Content.ReadAsStringAsync());
            //    Console.WriteLine("Contact's telephone# is: {0}.",
            //        retrievedProperty1["value"]);
            //}
            //else
            //{
            //    Console.WriteLine("Failed to retrieve the contact phone number for reason: {0}.",
            //        retrieveResponse2.ReasonPhrase);
            //    throw new CrmHttpResponseException(retrieveResponse2.Content);
            //}

            ////The following capabilities require version 8.2 or higher
            //if (webAPIVersion >= Version.Parse("8.2"))
            //{

            //    //Alternately, starting with December 2016 update (v8.2), a contact instance can be 
            //    //created and its properties returned in one operation by using a 
            //    //'Prefer: return=representation' header. Note that a 201 (Created) success status 
            //    // is returned, and not a 204 (No content).
            //    string contactAltUri;
            //    JObject contactAlt = new JObject();
            //    contactAlt.Add("firstname", "Peter_Alt");
            //    contactAlt.Add("lastname", "Cambel");
            //    contactAlt.Add("jobtitle", "Junior Developer");
            //    contactAlt.Add("annualincome", 80000);
            //    contactAlt.Add("telephone1", "555-0110");

            //    queryOptions = "?$select=fullname,annualincome,jobtitle,contactid";
            //    HttpRequestMessage createRequestAlt =
            //        new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "contacts" + queryOptions);
            //    createRequestAlt.Content = new StringContent(contactAlt.ToString(),
            //        Encoding.UTF8, "application/json");
            //    createRequestAlt.Headers.Add("Prefer", "return=representation");

            //    HttpResponseMessage createResponseAlt = await httpClient.SendAsync(createRequestAlt);
            //    if (createResponseAlt.StatusCode == HttpStatusCode.Created)  //201
            //    {
            //        //Body should contain the requested new-contact information.
            //        JObject createdContactAlt = JsonConvert.DeserializeObject<JObject>(
            //            await createResponseAlt.Content.ReadAsStringAsync());
            //        //Because 'OData-EntityId' header not returned in a 201 response, you must instead 
            //        // construct the URI.
            //        contactAltUri = httpClient.BaseAddress + getVersionedWebAPIPath() + "contacts(" + createdContactAlt["contactid"] + ")";
            //        entityUris.Add(contactAltUri);
            //        Console.WriteLine(
            //            "Contact '{0}' created: \n\tAnnual income: {1}" + "\n\tJob title: {2}",
            //            createdContactAlt["fullname"],
            //            createdContactAlt["annualincome"],
            //            createdContactAlt["jobtitle"]);
            //        Console.WriteLine("Contact URI: {0}", contactAltUri);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Failed to create contact for reason: {0}",
            //            createResponseAlt.ReasonPhrase);
            //        throw new CrmHttpResponseException(createResponseAlt.Content);
            //    }

            //    //Similarly, the December 2016 update (v8.2) also enables returning selected properties   
            //    //after an update operation (PATCH), with the 'Prefer: return=representation' header.
            //    //Here a success is indicated by 200 (OK) instead of 204 (No content).

            //    //Since we're reusing a local JObject, reinitialize it to remove extraneous properties.
            //    contactAlt.RemoveAll();
            //    contactAlt["annualincome"] = 95000;
            //    contactAlt["jobtitle"] = "Senior Developer";
            //    contactAlt["description"] = "MS Azure and Dynamics 365 Specialist";

            //    queryOptions = "?$select=fullname,annualincome,jobtitle";
            //    HttpRequestMessage updateRequestAlt = new HttpRequestMessage(
            //        new HttpMethod("PATCH"), contactAltUri + queryOptions);
            //    updateRequestAlt.Content = new StringContent(contactAlt.ToString(),
            //        Encoding.UTF8, "application/json");
            //    updateRequestAlt.Headers.Add("Prefer", "return=representation");

            //    HttpResponseMessage updateResponseAlt = await httpClient.SendAsync(updateRequestAlt);
            //    if (updateResponseAlt.StatusCode == HttpStatusCode.OK) //200
            //    {
            //        //Body should contain the requested updated-contact information.
            //        JObject UpdatedContactAlt = JsonConvert.DeserializeObject<JObject>(
            //            await updateResponseAlt.Content.ReadAsStringAsync());
            //        Console.WriteLine(
            //            "Contact '{0}' updated: \n\tAnnual income: {1}" + "\n\tJob title: {2}",
            //            UpdatedContactAlt["fullname"],
            //            UpdatedContactAlt["annualincome"],
            //            UpdatedContactAlt["jobtitle"]);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Failed to update contact for reason: {0}",
            //            updateResponse1.ReasonPhrase);
            //        throw new CrmHttpResponseException(updateResponse1.Content);
            //    }
            //}
            #endregion
        }

        /// <summary> Helper method to display caught exceptions </summary>
        private static void DisplayException(Exception ex)
        {
            Console.WriteLine("The application terminated with an error.");
            Console.WriteLine(ex.Message);
            while (ex.InnerException != null)
            {
                Console.WriteLine("\t* {0}", ex.InnerException.Message);
                ex = ex.InnerException;
            }
        }

        public async Task RunAsync(FormCollection form)
        {
            try
            {
                //await getWebAPIVersion();
                await BasicCreateAndUpdatesAsync(form);
                // await CreateWithAssociationAsync();
                //  await CreateRelatedAsync();
                // await AssociateExistingAsync();
            }
            catch (Exception ex)
            { DisplayException(ex); }
        }

        #endregion

        #region All Forms CRM Methods - Merchant Boarding
        public async Task<MerchantInformationModel> MerchantInformationCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            MerchantInformationModel model = new MerchantInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";
                        model.FaxNumber = jvalue[0].SelectToken("new_faxnumber").ToString();
                        model.MerchantName = jvalue[0].SelectToken("new_merchantname").ToString();
                        model.LocationAddress = jvalue[0].SelectToken("new_locationaddress1").ToString();
                        model.City = jvalue[0].SelectToken("new_city1").ToString();
                        model.Zip = jvalue[0].SelectToken("new_zipcode1").ToString();
                        model.CustomerEmail = jvalue[0].SelectToken("new_businessemailaddress").ToString();
                        model.ContactName = jvalue[0].SelectToken("new_name").ToString();
                        model.TelePhoneNumber = jvalue[0].SelectToken("new_businessphonenumber").ToString();
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }
        public async Task<bool> MerchantInformationCRMPost(FormCollection fc, MerchantInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");
        
            // Generate json object from model
            merchantForm.Add("new_faxnumber", model.FaxNumber);
            merchantForm.Add("new_merchantname", model.MerchantName);
            merchantForm.Add("new_locationaddress1", model.LocationAddress);
            merchantForm.Add("new_city1", model.City);
            merchantForm.Add("new_state1", model.SelectedState1);
            merchantForm.Add("new_zipcode1", model.Zip);

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {               
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<LegalInformationModel> LegalInformationModelCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            LegalInformationModel model = new LegalInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.LegalName = jvalue[0].SelectToken("new_corporationlegalname").ToString();                        

                        model.LocationAddress = jvalue[0].SelectToken("new_corporateaddress").ToString();
                        model.City = jvalue[0].SelectToken("new_city3").ToString();
                        model.Zip = jvalue[0].SelectToken("new_zipcode3").ToString();

                        model.IsTaxId = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_federaltax")));
                        model.TaxOrSsn = jvalue[0].SelectToken("new_federaltaxid").ToString();

                        model.IsMailingAddressSame = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_mailingaddress")));
                        if(!model.IsMailingAddressSame)
                            {
                            model.MailLocationAddress = jvalue[0].SelectToken("new_mailingaddress1").ToString();
                            model.MailCity = jvalue[0].SelectToken("new_city4").ToString();
                            model.MailZip = jvalue[0].SelectToken("new_zipcode4").ToString();
                        }

                        model.CustomerEmail = jvalue[0].SelectToken("new_businessemailaddress").ToString();
                        model.ContactName = jvalue[0].SelectToken("new_name").ToString();                        
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }
        public async Task<bool> LegalInformationCRMPost(FormCollection fc, LegalInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_corporationlegalname", model.LegalName);

            merchantForm.Add("new_corporateaddress", model.LocationAddress);
            merchantForm.Add("new_city3", model.City);
            merchantForm.Add("new_state3", model.SelectedState1);            
            merchantForm.Add("new_zipcode3", model.Zip);

            merchantForm.Add("new_federaltax", model.IsTaxId);
            merchantForm.Add("new_federaltaxid", model.TaxOrSsn);

            merchantForm.Add("new_mcccode", model.MCCCode);

            merchantForm.Add("new_mailingaddress", model.IsMailingAddressSame);
            if (!model.IsMailingAddressSame)
            {
                merchantForm.Add("new_mailingaddress1", model.MailLocationAddress);
                merchantForm.Add("new_city4", model.MailCity);
                merchantForm.Add("new_state4", model.SelectedState2);
                merchantForm.Add("new_zipcode4", model.MailZip);
            }

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<BusinessInformationModel> BusinessInformationCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            BusinessInformationModel model = new BusinessInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.IsPaymentCard = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_doyoucurrentlyacceptpaymentcards")));
                        if(model.IsPaymentCard)
                            model.PaymentCard = Convert.ToString(jvalue[0].SelectToken("new_whoisitwith"));
                        model.IsTerminated = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_hasthemerchantbeenterminatedfromaccepting")));
                        if(model.IsTerminated)
                            model.AcceptCardExplanation = Convert.ToString(jvalue[0].SelectToken("new_ifsoexplain"));
                        model.IsSecurityBranch = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_haveyouhadasecuritybreach")));
                        if(model.IsSecurityBranch)
                            model.SecurityBranchExplanation = Convert.ToString(jvalue[0].SelectToken("new_whoisitwith1"));

                        int BusinessYears;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_lengthoftimeinbusinessyears")), out BusinessYears);
                        model.BusinessYears = BusinessYears;
                        int BusinessMonths;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_lengthoftimeinbusinessmonths")), out BusinessMonths);
                        model.BusinessMonths = BusinessMonths;                  
                    }
                }
            }
            return model;
        }
        public async Task<bool> BusinessInformationCRMPost(FormCollection fc, BusinessInformationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_doyoucurrentlyacceptpaymentcards", model.IsPaymentCard);
            if(model.IsPaymentCard)
                merchantForm.Add("new_whoisitwith", model.PaymentCard);            
            merchantForm.Add("new_hasthemerchantbeenterminatedfromaccepting", model.IsTerminated);
            if (model.IsTerminated)
                merchantForm.Add("new_ifsoexplain", model.AcceptCardExplanation);
            merchantForm.Add("new_haveyouhadasecuritybreach", model.IsSecurityBranch);
            if(model.IsSecurityBranch)
                merchantForm.Add("new_whoisitwith1", model.SecurityBranchExplanation);

            merchantForm.Add("new_typeofbusiness", model.TypeOfBusiness);
            if(model.TypeOfBusiness == 4)
                merchantForm.Add("new_city5", model.LLCCity);

            merchantForm.Add("new_lengthoftimeinbusinessyears", Convert.ToString(model.BusinessYears));
            merchantForm.Add("new_lengthoftimeinbusinessmonths", Convert.ToString(model.BusinessMonths));            

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<BusinessInformation2Model> BusinessInformation2CRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            BusinessInformation2Model model = new BusinessInformation2Model();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.NatureOfBusiness = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_natureofbusinesscsv")), model.NatureOfBusiness);

                        model.IsSeasonalSales = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_seasonalsales")));
                        model.VolumeMonths = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_pleaseselecthighvolumemonthscsv")), model.VolumeMonths);
                        model.ProductsOrServices = Convert.ToString(jvalue[0].SelectToken("new_productsorservicesbeingoffered"));

                        model.MerchantUse = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_equipmentinformationdoesthemerchantuse")));
                        if (model.MerchantUse)
                        {
                            model.PaymentApplicationName = Convert.ToString(jvalue[0].SelectToken("new_whatisthepaymentapplicationname"));
                            model.PaymentApplicationVersion = Convert.ToString(jvalue[0].SelectToken("new_whatistheversionofthepaymentapplicationin"));
                        }                        
                        else
                        {
                            model.TerminalType = Convert.ToString(jvalue[0].SelectToken("new_ifterminalwhattype"));
                        }

                        model.MerchantNameAppear = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_merchantnametoappearonconsumerstatement")));

                        model.MethodOfAcceptance = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_methodofacceptancetotalstoequal100csv")), model.MethodOfAcceptance);
                    }
                }
            }
            return model;
        }
        public async Task<bool> BusinessInformation2CRMPost(FormCollection fc, BusinessInformation2Model model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_natureofbusinesscsv", GetCheckboxValues(model.NatureOfBusiness));

            merchantForm.Add("new_seasonalsales", model.IsSeasonalSales);
            merchantForm.Add("new_pleaseselecthighvolumemonthscsv", GetCheckboxValues(model.VolumeMonths));
            merchantForm.Add("new_productsorservicesbeingoffered", model.ProductsOrServices);

            merchantForm.Add("new_equipmentinformationdoesthemerchantuse", model.MerchantUse);
            if (model.MerchantUse)
            {
                merchantForm.Add("new_whatisthepaymentapplicationname", model.PaymentApplicationName);
                merchantForm.Add("new_whatistheversionofthepaymentapplicationin", model.PaymentApplicationVersion);
            }
            else
            {
                merchantForm.Add("new_ifterminalwhattype", model.TerminalType);
            }            

            merchantForm.Add("new_merchantnametoappearonconsumerstatement", model.MerchantNameAppear);

            merchantForm.Add("new_methodofacceptancetotalstoequal100csv", GetCheckboxValues(model.MethodOfAcceptance));

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<QuestionnaireModel> QuestionnaireCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            QuestionnaireModel model = new QuestionnaireModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";
                        
                        model.BusinessPercentage = Convert.ToString(jvalue[0].SelectToken("new_whatpercentagedoyouselltobusiness"));                        
                        model.PublicPercentage = Convert.ToString(jvalue[0].SelectToken("new_whatpercentagedoyouselltopublic"));

                        model.IsRetailLocation = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_doyouhavearetaillocation")));
                        if(model.IsRetailLocation)
                        {
                            model.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_locationaddress6"));
                            model.City = Convert.ToString(jvalue[0].SelectToken("new_city6"));
                            model.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode6"));
                        }

                        model.DoYouSell1 = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_doyousellaserviceorproductscsv")), model.DoYouSell1);

                        model.DecribeProduct = Convert.ToString(jvalue[0].SelectToken("new_describetheproductservices"));

                        model.PercentageOfSale = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_whatpercentageofsaleswillbefromcsv")), model.PercentageOfSale);

                        model.PhysicalAddress = Convert.ToString(jvalue[0].SelectToken("new_whatisthephysicaladdressofyourbusiness"));
                        model.PhysicalCity = Convert.ToString(jvalue[0].SelectToken("new_city7"));
                        model.PhysicalZip = Convert.ToString(jvalue[0].SelectToken("new_zipcode7"));

                        model.IsProductAddress = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_istheproductstoredattheaboveaddress")));
                        if (!model.IsProductAddress)
                        {
                            model.ProductAddress = Convert.ToString(jvalue[0].SelectToken("new_address8"));
                            model.ProductCity = Convert.ToString(jvalue[0].SelectToken("new_city8"));
                            model.ProductZip = Convert.ToString(jvalue[0].SelectToken("new_zipcode8"));
                        }

                        model.IsOwnProduct = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_doyouowntheproductinventory")));

                        model.DoYouSell2 = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_doyousellcheckallthatapplycsv")), model.DoYouSell2);

                        model.CardBrandProcessor = Convert.ToString(jvalue[0].SelectToken("new_whoisyourcurrentcardbrandprocessor"));
                        decimal ChargeBacks;
                        decimal.TryParse(Convert.ToString(jvalue[0].SelectToken("new_howmanychargebacksdidyouhaveforthisprevio")), out ChargeBacks);
                        model.ChargeBacks = ChargeBacks;                        
                        model.ChargeBackAmount = Convert.ToString(jvalue[0].SelectToken("new_whatwasthetotaldollaramountofthosechargeb"));
                        
                        int WhenCharged;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_whenisthecustomerscharged")), out WhenCharged);
                        model.WhenCharged = WhenCharged;
                        int DeliverDays;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_delivermerchandisetothecustomer")), out DeliverDays);
                        model.DeliverDays = DeliverDays;                        

                        model.IsOtherCompany = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_othershippingproduct")));
                        if (model.IsOtherCompany)
                        {
                            model.CompanyName = Convert.ToString(jvalue[0].SelectToken("new_name1"));
                            model.CompanyTelephone = Convert.ToString(jvalue[0].SelectToken("new_telephone9"));
                            model.CompanyAddress = Convert.ToString(jvalue[0].SelectToken("new_address9"));
                        }

                        model.Advertise = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_howdoyouadvertisecsv")), model.Advertise);

                        model.RefundPolicy = Convert.ToString(jvalue[0].SelectToken("new_pleasedescribeyourrefundpolicy"));
                    }
                }
            }
            return model;
        }
        public async Task<bool> QuestionnaireCRMPost(FormCollection fc, QuestionnaireModel model)
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            model.BusinessPercentage = (model.BusinessPercentage??string.Empty).Replace("%", "");
            merchantForm.Add("new_whatpercentagedoyouselltobusiness", model.BusinessPercentage);
            //decimal BusinessPercentage;
            //decimal.TryParse(model.BusinessPercentage, out BusinessPercentage);
            //merchantForm.Add("new_whatpercentagedoyouselltobusiness", BusinessPercentage);
            model.PublicPercentage = (model.PublicPercentage ?? string.Empty).Replace("%", "");
            merchantForm.Add("new_whatpercentagedoyouselltopublic", model.PublicPercentage);
            //decimal PublicPercentage;
            //decimal.TryParse(model.PublicPercentage, out PublicPercentage);
            //merchantForm.Add("new_whatpercentagedoyouselltobusiness", Convert.ToDecimal(model.PublicPercentage));

            merchantForm.Add("new_doyouhavearetaillocation", model.IsRetailLocation);
            if (model.IsRetailLocation)
            {
                merchantForm.Add("new_locationaddress6", model.LocationAddress);
                merchantForm.Add("new_city6", model.City);
                merchantForm.Add("new_zipcode6", model.Zip);
            }

            merchantForm.Add("new_doyousellaserviceorproductscsv", GetCheckboxValues(model.DoYouSell1));

            merchantForm.Add("new_describetheproductservices", model.DecribeProduct);

            merchantForm.Add("new_whatpercentageofsaleswillbefromcsv", GetCheckboxValues(model.PercentageOfSale));

            merchantForm.Add("new_whatisthephysicaladdressofyourbusiness", model.PhysicalAddress);
            merchantForm.Add("new_city7", model.PhysicalCity);
            merchantForm.Add("new_zipcode7", model.PhysicalZip);            

            merchantForm.Add("new_istheproductstoredattheaboveaddress", model.IsProductAddress);
            if (!model.IsProductAddress)
            {
                merchantForm.Add("new_address8", model.ProductAddress);
                merchantForm.Add("new_city8", model.ProductCity);
                merchantForm.Add("new_zipcode8", model.ProductZip);                
            }

            merchantForm.Add("new_doyouowntheproductinventory", model.IsOwnProduct);

            merchantForm.Add("new_doyousellcheckallthatapplycsv", GetCheckboxValues(model.DoYouSell2));

            merchantForm.Add("new_whoisyourcurrentcardbrandprocessor", model.CardBrandProcessor);
            merchantForm.Add("new_howmanychargebacksdidyouhaveforthisprevio", model.ChargeBacks);
            model.ChargeBackAmount = (model.ChargeBackAmount ?? string.Empty).Replace(" ", "").Replace("$", "");
            decimal ChargeBackAmount;
            decimal.TryParse(model.ChargeBackAmount, out ChargeBackAmount);
            merchantForm.Add("new_whatwasthetotaldollaramountofthosechargeb", ChargeBackAmount);

            merchantForm.Add("new_whenisthecustomerscharged", model.WhenCharged);
            merchantForm.Add("new_delivermerchandisetothecustomer", model.DeliverDays);

            merchantForm.Add("new_othershippingproduct", model.IsOtherCompany);
            if (model.IsOtherCompany)
            {
                merchantForm.Add("new_name1", model.CompanyName);
                merchantForm.Add("new_telephone9", model.CompanyTelephone);
                merchantForm.Add("new_address9", model.CompanyAddress);
            }

            merchantForm.Add("new_howdoyouadvertisecsv", GetCheckboxValues(model.Advertise));

            merchantForm.Add("new_pleasedescribeyourrefundpolicy", model.RefundPolicy);
                        
            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<Questionnaire2Model> Questionnaire2CRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            Questionnaire2Model model = new Questionnaire2Model();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";
                   
                        model.BusinessPercentage = Convert.ToString(jvalue[0].SelectToken("new_whatpercentagedoyouselltobusinessconsumer"));                     
                        model.IndividualPercentage = Convert.ToString(jvalue[0].SelectToken("new_whatpercentagedoyouselltoindividualconsum"));

                        model.MethodOfMarketing = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_methodofmarketingcsv")), model.MethodOfMarketing);
                        model.PercentageOfProducts = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_percentageofproductssoldviacsv")), model.PercentageOfProducts);
                        model.WhoProcessOrder = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_whoprocessestheordercsv")), model.WhoProcessOrder);
                        model.WhoEnterCreditCard = SetCheckBoxValues(Convert.ToString(jvalue[0].SelectToken("new_whoenterscreditcardinformationintothecsv")), model.WhoEnterCreditCard);

                        model.IsCreditCardPayment = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_creditcardpaymentinformation")));
                        if (model.IsCreditCardPayment)
                        {
                            model.MerchantCertiNumber = Convert.ToString(jvalue[0].SelectToken("new_merchantcertificatenumber"));
                            model.Issuer = Convert.ToString(jvalue[0].SelectToken("new_certificateissuer")); ;
                            model.ExpDate = Convert.ToString(jvalue[0].SelectToken("new_expdate"));
                        }

                        model.IsProduct = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_doyouowntheproductinventory1")));

                        model.IsProductLocationSame = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_istheproductstoredatyourbusinesslocation")));
                        if (!model.IsProductLocationSame)
                        {
                            model.ProductLocation = Convert.ToString(jvalue[0].SelectToken("new_whereisitstored"));                            
                        }
                        
                        int ProductShipDays;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_authorization")), out ProductShipDays);
                        model.ProductShipDays = ProductShipDays;

                        int WhoShipProduct;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_whoshipstheproduct")), out WhoShipProduct);
                        model.WhoShipProduct = WhoShipProduct;
                        int ProductShippedBy;
                        int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_productshippedby")), out ProductShippedBy);
                        model.ProductShippedBy = ProductShippedBy;
                        
                        if (model.ProductShippedBy == 1)
                        {
                            model.OtherShippedBy = Convert.ToString(jvalue[0].SelectToken("new_other"));
                        }

                        model.IsDeliveryReceipt = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_deliveryreceiptrequested")));
                    }
                }
            }
            return model;
        }
        public async Task<bool> Questionnaire2CRMPost(FormCollection fc, Questionnaire2Model model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            model.BusinessPercentage = (model.BusinessPercentage??string.Empty).Replace("%", "");
            decimal BusinessPercentage;
            decimal.TryParse(model.BusinessPercentage, out BusinessPercentage);
            merchantForm.Add("new_whatpercentagedoyouselltobusinessconsumer", BusinessPercentage);            
            model.IndividualPercentage = (model.IndividualPercentage ?? string.Empty).Replace("%", "");
            decimal IndividualPercentage;
            decimal.TryParse(model.IndividualPercentage, out IndividualPercentage);
            merchantForm.Add("new_whatpercentagedoyouselltoindividualconsum", IndividualPercentage);

            merchantForm.Add("new_methodofmarketingcsv", GetCheckboxValues(model.MethodOfMarketing));
            merchantForm.Add("new_percentageofproductssoldviacsv", GetCheckboxValues(model.PercentageOfProducts));
            merchantForm.Add("new_whoprocessestheordercsv", GetCheckboxValues(model.WhoProcessOrder));
            merchantForm.Add("new_whoenterscreditcardinformationintothecsv", GetCheckboxValues(model.WhoEnterCreditCard));

            merchantForm.Add("new_creditcardpaymentinformation", model.IsCreditCardPayment);
            if (model.IsCreditCardPayment)
            {
                merchantForm.Add("new_merchantcertificatenumber", model.MerchantCertiNumber);
                merchantForm.Add("new_certificateissuer", model.Issuer);
                merchantForm.Add("new_expdate", model.ExpDate);
            }

            merchantForm.Add("new_doyouowntheproductinventory1", model.IsProduct);

            merchantForm.Add("new_istheproductstoredatyourbusinesslocation", model.IsProductLocationSame);
            if (model.IsProductLocationSame)
            {
                merchantForm.Add("new_whereisitstored", model.ProductLocation);                
            }

            merchantForm.Add("new_authorization", Convert.ToString(model.ProductShipDays));

            merchantForm.Add("new_whoshipstheproduct", model.WhoShipProduct);            
            merchantForm.Add("new_productshippedby", model.ProductShippedBy);
            if (model.ProductShippedBy == 1) // Fulfillment Center
            {
                merchantForm.Add("new_other", model.OtherShippedBy);
            }

            merchantForm.Add("new_deliveryreceiptrequested", model.IsDeliveryReceipt);

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<ProcessingDetailsModel> ProcessingDetailsCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            ProcessingDetailsModel model = new ProcessingDetailsModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";
                     
                        model.PaymentCardMonthly = Convert.ToString(jvalue[0].SelectToken("new_monthlypaymentcardvolume"));                       
                        model.AmericanExpressMonthly = Convert.ToString(jvalue[0].SelectToken("new_americanexpressmonthlyvolume"));
                        model.AvgTicket = Convert.ToString(jvalue[0].SelectToken("new_averageticket")); ;
                        model.HighestTicket = Convert.ToString(jvalue[0].SelectToken("new_highestticket"));

                        model.IsServicer = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_transmitscardholderinformation")));
                        if (model.IsServicer)
                        {
                            model.ServicerName = Convert.ToString(jvalue[0].SelectToken("new_name2"));
                            model.ServicerContactNumber = Convert.ToString(jvalue[0].SelectToken("new_contactnumber2"));                     
                        }

                        model.IsFulfillmentHouse = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_merchantuse")));
                        if (model.IsFulfillmentHouse)
                        {
                            model.HouseName = Convert.ToString(jvalue[0].SelectToken("new_name3")); ;
                            model.HouseContactNumber = Convert.ToString(jvalue[0].SelectToken("new_contactnumber3"));
                        }

                        model.IsBankruptcy = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_havemerchantorownersprincipals")));
                        if (model.IsBankruptcy)
                        {
                            model.BankruptcyExplain = Convert.ToString(jvalue[0].SelectToken("new_pleaseexplain"));                            
                        }

                        model.IsSeasonalMerchant = ConvertToBoolean(Convert.ToString(jvalue[0].SelectToken("new_seasonalmerchant")));
                        if (model.IsSeasonalMerchant)
                        {                            
                            int MonthsSeason;
                            int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_monthsoutofseason")), out MonthsSeason);
                            model.MonthsSeason = MonthsSeason;
                        }
                    }
                }
            }
            return model;
        }
        public async Task<bool> ProcessingDetailsCRMPost(FormCollection fc, ProcessingDetailsModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            model.PaymentCardMonthly = (model.PaymentCardMonthly ?? string.Empty).Replace(" ", "").Replace("$", "");
            decimal PaymentCardMonthly;
            decimal.TryParse(model.PaymentCardMonthly, out PaymentCardMonthly);
            merchantForm.Add("new_monthlypaymentcardvolume", PaymentCardMonthly);
            
            model.AmericanExpressMonthly = (model.AmericanExpressMonthly ?? string.Empty).Replace(" ", "").Replace("$", "");
            decimal AmericanExpressMonthly;
            decimal.TryParse(model.AmericanExpressMonthly, out AmericanExpressMonthly);
            merchantForm.Add("new_americanexpressmonthlyvolume", AmericanExpressMonthly);
            
            merchantForm.Add("new_averageticket", model.AvgTicket);
            merchantForm.Add("new_highestticket", model.HighestTicket);

            merchantForm.Add("new_transmitscardholderinformation", model.IsServicer);
            if (model.IsServicer)
            {
                merchantForm.Add("new_name2", model.ServicerName);
                merchantForm.Add("new_contactnumber2", model.ServicerContactNumber);                
            }

            merchantForm.Add("new_merchantuse", model.IsFulfillmentHouse);
            if (model.IsFulfillmentHouse)
            {
                merchantForm.Add("new_name3", model.HouseName);
                merchantForm.Add("new_contactnumber3", model.HouseContactNumber);
            }

            merchantForm.Add("new_havemerchantorownersprincipals", model.IsBankruptcy);
            if (model.IsBankruptcy)
            {
                merchantForm.Add("new_pleaseexplain", model.BankruptcyExplain);
            }

            merchantForm.Add("new_seasonalmerchant", model.IsSeasonalMerchant);
            if (model.IsSeasonalMerchant)
            {
                merchantForm.Add("new_monthsoutofseason", Convert.ToString(model.MonthsSeason));
            }        

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<OwnershipInformation> OwnershipInformationCRMGet()
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            OwnershipInformation model = new OwnershipInformation();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = jvalue[0].SelectToken("new_merchantboardingid").ToString();
                        model.MerchantUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_merchantboardings(" + merchantId + ")";

                        model.Owner1.FirstName = Convert.ToString(jvalue[0].SelectToken("new_firstname1"));
                        model.Owner1.MiddleName = Convert.ToString(jvalue[0].SelectToken("new_middleint"));
                        model.Owner1.LastName = Convert.ToString(jvalue[0].SelectToken("new_lastname1"));
                        model.Owner1.Title = Convert.ToString(jvalue[0].SelectToken("new_title"));
                        model.Owner1.SSN = Convert.ToString(jvalue[0].SelectToken("new_ssn"));
                        model.Owner1.OwnershipPercent = Convert.ToString(jvalue[0].SelectToken("new_ownership"));
                        DateTime DateOfBirth;
                        DateTime.TryParse(Convert.ToString(jvalue[0].SelectToken("new_dateofbirth")), out DateOfBirth);
                        model.Owner1.DateOfBirth = DateOfBirth;
                        model.Owner1.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_homeaddress"));
                        model.Owner1.City = Convert.ToString(jvalue[0].SelectToken("new_city9"));
                        model.Owner1.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode9"));
                        model.Owner1.HomePhone = Convert.ToString(jvalue[0].SelectToken("new_homephone9"));
                        model.Owner1.EmailAddress = Convert.ToString(jvalue[0].SelectToken("new_emailaddress9"));

                        model.Owner2.FirstName = Convert.ToString(jvalue[0].SelectToken("new_firstname2"));
                        model.Owner2.MiddleName = Convert.ToString(jvalue[0].SelectToken("new_middleint1"));
                        model.Owner2.LastName = Convert.ToString(jvalue[0].SelectToken("new_lastname2"));
                        model.Owner2.Title = Convert.ToString(jvalue[0].SelectToken("new_title1"));
                        model.Owner2.SSN = Convert.ToString(jvalue[0].SelectToken("new_ssn1"));
                        model.Owner2.OwnershipPercent = Convert.ToString(jvalue[0].SelectToken("new_ownership1"));                        
                        DateTime.TryParse(Convert.ToString(jvalue[0].SelectToken("new_dateofbirth1")), out DateOfBirth);
                        model.Owner2.DateOfBirth = DateOfBirth;
                        model.Owner2.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_homeaddress1"));
                        model.Owner2.City = Convert.ToString(jvalue[0].SelectToken("new_city10"));
                        model.Owner2.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode10"));
                        model.Owner2.HomePhone = Convert.ToString(jvalue[0].SelectToken("new_homephone10"));
                        model.Owner2.EmailAddress = Convert.ToString(jvalue[0].SelectToken("new_emailaddress10"));

                        model.ControllingOwner.FirstName = Convert.ToString(jvalue[0].SelectToken("new_firstname3"));
                        model.ControllingOwner.MiddleName = Convert.ToString(jvalue[0].SelectToken("new_middleint2"));
                        model.ControllingOwner.LastName = Convert.ToString(jvalue[0].SelectToken("new_lastname3"));
                        model.ControllingOwner.Title = Convert.ToString(jvalue[0].SelectToken("new_title2"));
                        model.ControllingOwner.SSN = Convert.ToString(jvalue[0].SelectToken("new_ssn2"));
                        model.ControllingOwner.OwnershipPercent = Convert.ToString(jvalue[0].SelectToken("new_ownseship2"));                        
                        DateTime.TryParse(Convert.ToString(jvalue[0].SelectToken("new_dateofbirth2")), out DateOfBirth);
                        model.ControllingOwner.DateOfBirth = DateOfBirth;
                        model.ControllingOwner.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_homeaddress3"));
                        model.ControllingOwner.City = Convert.ToString(jvalue[0].SelectToken("new_city11"));
                        model.ControllingOwner.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode11"));
                        model.ControllingOwner.HomePhone = Convert.ToString(jvalue[0].SelectToken("new_homephone11"));
                        model.ControllingOwner.EmailAddress = Convert.ToString(jvalue[0].SelectToken("new_emailaddress11"));
                        model.Owner1.ControllingInterest = Convert.ToBoolean(jvalue[0].SelectToken("new_controllinginterest"));                       
                    }
                }
            }
            return model;
        }
        public async Task<bool> OwnershipInformationCRMPost(FormCollection fc, OwnershipInformation model)
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            merchantForm.Add("new_firstname1", model.Owner1.FirstName);
            merchantForm.Add("new_middleint", model.Owner1.MiddleName);
            merchantForm.Add("new_lastname1", model.Owner1.LastName);
            merchantForm.Add("new_title", model.Owner1.Title);
            merchantForm.Add("new_ssn", model.Owner1.SSN);
            model.Owner1.OwnershipPercent = (model.Owner1.OwnershipPercent ?? string.Empty).Replace("%", "");
            decimal OwnershipPercent;
            decimal.TryParse(model.Owner1.OwnershipPercent, out OwnershipPercent);
            merchantForm.Add("new_ownership", OwnershipPercent);
            merchantForm.Add("new_dateofbirth", model.Owner1.DateOfBirth);
            merchantForm.Add("new_homeaddress", model.Owner1.LocationAddress);
            merchantForm.Add("new_city9", model.Owner1.City);
            merchantForm.Add("new_zipcode9", model.Owner1.Zip);
            merchantForm.Add("new_homephone9", model.Owner1.HomePhone);
            merchantForm.Add("new_emailaddress9", model.Owner1.EmailAddress);           

            merchantForm.Add("new_firstname2", model.Owner2.FirstName);
            merchantForm.Add("new_middleint1", model.Owner2.MiddleName);
            merchantForm.Add("new_lastname2", model.Owner2.LastName);
            merchantForm.Add("new_title1", model.Owner2.Title);
            merchantForm.Add("new_ssn1", model.Owner2.SSN);
            model.Owner2.OwnershipPercent = (model.Owner2.OwnershipPercent ?? string.Empty).Replace("%", "");            
            decimal.TryParse(model.Owner2.OwnershipPercent, out OwnershipPercent);
            merchantForm.Add("new_ownership1", OwnershipPercent);
            merchantForm.Add("new_dateofbirth1", model.Owner2.DateOfBirth);
            merchantForm.Add("new_homeaddress1", model.Owner2.LocationAddress);
            merchantForm.Add("new_city10", model.Owner2.City);
            merchantForm.Add("new_zipcode10", model.Owner2.Zip);
            merchantForm.Add("new_homephone10", model.Owner2.HomePhone);
            merchantForm.Add("new_emailaddress10", model.Owner2.EmailAddress);        

            merchantForm.Add("new_firstname3", model.ControllingOwner.FirstName);
            merchantForm.Add("new_middleint2", model.ControllingOwner.MiddleName);
            merchantForm.Add("new_lastname3", model.ControllingOwner.LastName);
            merchantForm.Add("new_title2", model.ControllingOwner.Title);
            merchantForm.Add("new_ssn2", model.ControllingOwner.SSN);
            model.ControllingOwner.OwnershipPercent = (model.ControllingOwner.OwnershipPercent ?? string.Empty).Replace("%", "");
            decimal.TryParse(model.ControllingOwner.OwnershipPercent, out OwnershipPercent);
            merchantForm.Add("new_ownseship2", OwnershipPercent);
            merchantForm.Add("new_dateofbirth2", model.ControllingOwner.DateOfBirth);
            merchantForm.Add("new_homeaddress3", model.ControllingOwner.LocationAddress);
            merchantForm.Add("new_city11", model.ControllingOwner.City);
            merchantForm.Add("new_zipcode11", model.ControllingOwner.Zip);
            merchantForm.Add("new_homephone11", model.ControllingOwner.HomePhone);
            merchantForm.Add("new_emailaddress11", model.ControllingOwner.EmailAddress);
            merchantForm.Add("new_controllinginterest", model.Owner1.ControllingInterest);        

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }
        #endregion

        #region All Forms CRM Methods - Bank Template
        public async Task<BankDisclosureModel> BankDisclosureCRMGet(string bankName)
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            BankDisclosureModel model = new BankDisclosureModel();
            
            if (!string.IsNullOrEmpty(bankName))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                string queryOptions = "?$filter=new_name eq '" + bankName + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
               getVersionedWebAPIPath() + "new_banktemplates" + queryOptions);
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new CrmHttpResponseException(merchantResponse.Content);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string bankId = jvalue[0].SelectToken("new_banktemplateid").ToString();
                        model.BankUri = "https://olbgroup.olb.com:444/api/data/" + getVersionedWebAPIPath() + "new_banktemplates(" + bankId + ")";
                        model.Description = jvalue[0].SelectToken("new_bankformattemplate").ToString();
                        model.BankName = bankName;
                        model.CustomerEmail = _workContext.CurrentCustomer.Email;
                    }
                }
            }
            return model;
        }
        #endregion

        private string RegisterCustomer(FormCollection form, out List<string> errors)
        {
            errors = new List<string>();

            if (_workContext.CurrentCustomer.IsRegistered())
            {
                //Already registered customer. 
                _authenticationService.SignOut();

                //raise logged out event       
                _eventPublisher.Publish(new CustomerLoggedOutEvent(_workContext.CurrentCustomer));

                //Save a new record
                _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            }
            var customer = _workContext.CurrentCustomer;
            string Password = "password@123";

            bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
            var registrationRequest = new CustomerRegistrationRequest(customer,
                     form["EmailAddress"],
                     form["EmailAddress"],
                     Password,
                     _customerSettings.DefaultPasswordFormat,
                     _storeContext.CurrentStore.Id,
                     isApproved);
            //--------------------------------
            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
            if (registrationResult.Success)
            {

                //form fields
                string fullName = form["ContactName"];
                string firstName = string.Empty;
                string lastName = string.Empty;
                if (!string.IsNullOrEmpty(fullName) && fullName.Split(' ').Length > 1)
                {
                    string[] name = fullName.Split(' ');
                    if (name.Length > 1)
                    {
                        firstName = name[0];
                        lastName = name[1];
                    }
                    else
                    {
                        firstName = name[0];
                    }
                }
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, firstName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, lastName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, form["CorporateName"]);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, form["TelephoneNumber"]);

                //notifications
                if (_customerSettings.NotifyNewCustomerRegistration)
                    _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                //login customer now
                if (isApproved)
                    _authenticationService.SignIn(customer, true);

                switch (_customerSettings.UserRegistrationType)
                {
                    case UserRegistrationType.EmailValidation:
                        {
                            //email validation message
                            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                            _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id);

                            //result                            
                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });

                        }
                    case UserRegistrationType.AdminApproval:
                        {
                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                        }
                    case UserRegistrationType.Standard:
                        {
                            //send customer welcome message
                            _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);

                            return Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                        }
                    default:
                        {
                            return Url.RouteUrl("HomePage");
                        }
                }
            }
            else
            {
                foreach (var err in registrationResult.Errors)
                {
                    errors.Add(err);
                }
                return "";
            }
        }

        [HttpPost]
        public ActionResult Register(FormCollection form)
        {
            string redirectUrl = "/";
            try
            {
                //Read configuration file and connect to specified CRM server.
                //ConnectToCRM();
                List<string> errors = new List<string>();
                redirectUrl = RegisterCustomer(form, out errors);
                if (!string.IsNullOrEmpty(redirectUrl))
                {
                    Task.WaitAll(Task.Run(async () => await RunAsync(form)));
                }
            }
            catch (System.Exception ex) { DisplayException(ex); }
            finally
            {
                if (httpClient != null)
                { httpClient.Dispose(); }
            }
            return Redirect(redirectUrl);
        }

        public ActionResult merchanthtml()
        {
            return View("/Themes/Main/Views/MerchantBoarding/HomeTest.cshtml");
        }

        [Authorize]
        public ActionResult MerchantInformation()
        {
            MerchantInformationModel model = new MerchantInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await MerchantInformationCRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_MerchantInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult MerchantInformation(FormCollection fc, MerchantInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await MerchantInformationCRMPost(fc, model); }));

            if(result == true)
            {
                return RedirectToAction("LegalInformation");
            }
            else
            {
                return Content("");
            }            
        }

        [Authorize]
        public ActionResult LegalInformation()
        {
            LegalInformationModel model = new LegalInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await LegalInformationModelCRMGet(); }));            
            return View("/Themes/Main/Views/MerchantBoarding/_LegalInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult LegalInformation(FormCollection fc, LegalInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await LegalInformationCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("BusinessInformation");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult BusinessInformation()
        {
            BusinessInformationModel model = new BusinessInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await BusinessInformationCRMGet(); }));            
            return View("/Themes/Main/Views/MerchantBoarding/_BusinessInformation.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult BusinessInformation(FormCollection fc, BusinessInformationModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await BusinessInformationCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("BusinessInformation2");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult BusinessInformation2()
        {
            BusinessInformation2Model model = new BusinessInformation2Model();
            Task.WaitAll(Task.Run(async () => { model = await BusinessInformation2CRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_BusinessInformation2.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult BusinessInformation2(FormCollection fc, BusinessInformation2Model model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await BusinessInformation2CRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("Questionnaire");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult Questionnaire()
        {
            QuestionnaireModel model = new QuestionnaireModel();
            Task.WaitAll(Task.Run(async () => { model = await QuestionnaireCRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_Questionnaire.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Questionnaire(FormCollection fc, QuestionnaireModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await QuestionnaireCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("Questionnaire2");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult Questionnaire2()
        {
            Questionnaire2Model model = new Questionnaire2Model();
            Task.WaitAll(Task.Run(async () => { model = await Questionnaire2CRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_Questionnaire2.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Questionnaire2(FormCollection fc, Questionnaire2Model model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await Questionnaire2CRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("ProcessingDetails");
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult ProcessingDetails()
        {
            ProcessingDetailsModel model = new ProcessingDetailsModel();
            Task.WaitAll(Task.Run(async () => { model = await ProcessingDetailsCRMGet(); }));
            return View("/Themes/Main/Views/MerchantBoarding/_ProcessingDetails.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult ProcessingDetails(FormCollection fc, ProcessingDetailsModel model)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await ProcessingDetailsCRMPost(fc, model); }));

            if (result == true)
            {
                return RedirectToAction("BankDisclosure", new { bankName = "Merrick Bank" });
            }
            else
            {
                return Content("");
            }
        }

        [Authorize]
        public ActionResult BankDisclosure(string bankName)
        {
            BankDisclosureModel model = new BankDisclosureModel();
            Task.WaitAll(Task.Run(async () => { model = await BankDisclosureCRMGet(bankName); }));
            return View("/Themes/Main/Views/MerchantBoarding/_BankDisclosure.cshtml", model);
        }
        [Authorize]
        [HttpPost]
        public ActionResult BankDisclosure(FormCollection fc, BankDisclosureModel model)
        {
            bool result = false;
            result = true;
            // Post signature to CRM

            if (result == true)
            {
                return RedirectToAction("");
            }
            else
            {
                return Content("");
            }
        }

        //[HttpPost]
        //public ActionResult Index(MerchantBoardingodel model)
        //{          
        //    return Redirect("/MerchantBoarding");
        //}

    }
}