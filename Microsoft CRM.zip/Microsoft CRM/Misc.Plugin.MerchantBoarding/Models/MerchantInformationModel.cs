﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class MerchantInformationModel
    {
        // common
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantUri { get; set; }


        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }

    }
}
