﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantUri { get; set; }
        public string BankUri { get; set; }
        public string BankName { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public int SelectedState1 { get; set; }
        public int SelectedState2 { get; set; }
        public int SelectedState3 { get; set; }
        public int SelectedState4 { get; set; }
        public int SelectedState5 { get; set; }
        public int MCCCode { get; set; }
    }

    #region Merchant Information
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        public bool IsTerminated { get; set; }
        public string AcceptCardExplanation { get; set; }
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranchExplanation { get; set; }

        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; }
    }

    public class BusinessInformation2Model : BaseInformationModel
    {
        public BusinessInformation2Model()
        {
            NatureOfBusiness = new List<bool>();
            for (int i = 1; i <= 14; i++)
            {
                NatureOfBusiness.Add(false);
            }
            VolumeMonths = new List<bool>();
            for (int i = 1; i <= 12; i++)
            {
                VolumeMonths.Add(false);
            }
            MethodOfAcceptance = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                MethodOfAcceptance.Add(false);
            }
        }
        public List<bool> NatureOfBusiness { get; set; } //new_natureofbusinesscsv -> 1 - 14
        public bool IsSeasonalSales { get; set; }
        public List<bool> VolumeMonths { get; set; }// new_pleaseselecthighvolumemonthscsv -> Month wise
        public string ProductsOrServices { get; set; }
        public bool MerchantUse { get; set; } // if true then "Software" else "Terminal"
        public string TerminalType { get; set; } // if "Terminal"
        public string PaymentApplicationName { get; set; } // if "Software"
        public string PaymentApplicationVersion { get; set; } // if "Software"
        public bool MerchantNameAppear { get; set; } // if false then "DBA Name" else "Legal Name"
        public List<bool> MethodOfAcceptance { get; set; } // new_methodofacceptancetotalstoequal100csv -> 1 - Card Swipe,2 - MO/TO %, 3 - Key Entered %, 4 - Internet %
    }

    public class QuestionnaireModel : BaseInformationModel
    {
        public QuestionnaireModel()
        {
            DoYouSell1 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell1.Add(false);
            }
            PercentageOfSale = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfSale.Add(false);
            }
            DoYouSell2 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell2.Add(false);
            }
            Advertise = new List<bool>();
            for (int i = 1; i <= 5; i++)
            {
                Advertise.Add(false);
            }
        }
        public string BusinessPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public string PublicPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public bool IsRetailLocation { get; set; }
        public List<bool> DoYouSell1 { get; set; }// new_doyousellaserviceorproductscsv -> S,P
        public string DecribeProduct { get; set; }
        public List<bool> PercentageOfSale { get; set; } // new_whatpercentageofsaleswillbefromcsv -> M,T,I,C
        public string PhysicalAddress { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalZip { get; set; }
        public bool IsProductAddress { get; set; }
        public string ProductAddress { get; set; }
        public string ProductCity { get; set; }
        public string ProductZip { get; set; }
        public bool IsOwnProduct { get; set; }
        public List<bool> DoYouSell2 { get; set; }// new_doyousellcheckallthatapplycsv -> L,N
        public string CardBrandProcessor { get; set; }
        public decimal ChargeBacks { get; set; }
        public string ChargeBackAmount { get; set; } // price in dollar $ amount
        public int WhenCharged { get; set; } // if 0 then "Time of Order", if 1 then "Upon Shipment"...................
        public int DeliverDays { get; set; } // 0 -> "1-7 days", 1 -> "8-14 Days" and 2 -> 14+ Days
        public bool IsOtherCompany { get; set; }
        public string CompanyName { get; set; }
        public string CompanyTelephone { get; set; }
        public string CompanyAddress { get; set; }
        public List<bool> Advertise { get; set; }// new_howdoyouadvertisecsv -> C,M,T,I,O
        public string RefundPolicy { get; set; }
    }

    public class Questionnaire2Model : BaseInformationModel
    {
        public Questionnaire2Model()
        {
            MethodOfMarketing = new List<bool>();
            for (int i = 1; i <= 6; i++)
            {
                MethodOfMarketing.Add(false);
            }
            PercentageOfProducts = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfProducts.Add(false);
            }
            WhoProcessOrder = new List<bool>();
            for (int i = 1; i <= 3; i++)
            {
                WhoProcessOrder.Add(false);
            }
            WhoEnterCreditCard = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                WhoEnterCreditCard.Add(false);
            }
        }
        public string BusinessPercentage { get; set; }
        public string IndividualPercentage { get; set; }
        public List<bool> MethodOfMarketing { get; set; }// new_methodofmarketingcsv -> n,t,i,d,o,other
        public List<bool> PercentageOfProducts { get; set; }// new_percentageofproductssoldviacsv -> m,t,i,o
        public List<bool> WhoProcessOrder { get; set; }// new_whoprocessestheordercsv -> m,f,o
        public List<bool> WhoEnterCreditCard { get; set; }// new_whoenterscreditcardinformationintothecsv -> m,f,c,o
        public bool IsCreditCardPayment { get; set; }
        public string MerchantCertiNumber { get; set; }
        public string Issuer { get; set; }
        public string ExpDate { get; set; }
        public bool IsProduct { get; set; }
        public bool IsProductLocationSame { get; set; }
        public string ProductLocation { get; set; }
        public int ProductShipDays { get; set; }
        public int WhoShipProduct { get; set; } // 0 - Merchant, 1- Fullfillment Center
        public int ProductShippedBy { get; set; } // 0 - U.S. Mail , 1 - Other
        public string OtherShippedBy { get; set; }
        public bool IsDeliveryReceipt { get; set; }
    }

    public class ProcessingDetailsModel : BaseInformationModel
    {
        public string PaymentCardMonthly { get; set; } // $ amount
        public string AmericanExpressMonthly { get; set; } // $ amount        
        public string AvgTicket { get; set; }
        public string HighestTicket { get; set; }
        public bool IsServicer { get; set; }
        public string ServicerName { get; set; }
        public string ServicerContactNumber { get; set; }
        public bool IsFulfillmentHouse { get; set; }
        public string HouseName { get; set; }
        public string HouseContactNumber { get; set; }
        public bool IsBankruptcy { get; set; }
        public string BankruptcyExplain { get; set; }
        public bool IsSeasonalMerchant { get; set; }
        public int MonthsSeason { get; set; }
    }

    public class BaseOwnershipInformation : BaseInformationModel
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string SSN { get; set; }
        public string OwnershipPercent { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string HomePhone { get; set; }
        public string EmailAddress { get; set; }
        public int DLState { get; set; }
        public bool ControllingInterest { get; set; }
    }
    public class OwnershipInformation : BaseInformationModel
    {
        public OwnershipInformation()
        {
            Owner1 = new BaseOwnershipInformation();
            Owner2 = new BaseOwnershipInformation();
            ControllingOwner = new BaseOwnershipInformation();
        }
        public BaseOwnershipInformation Owner1 { get; set; }
        public BaseOwnershipInformation Owner2 { get; set; }
        public BaseOwnershipInformation ControllingOwner { get; set; }
    }
    #endregion

    #region
    public class BankDisclosureModel : BaseInformationModel
    {
        public string Description { get; set; }
    }
    #endregion    

}
