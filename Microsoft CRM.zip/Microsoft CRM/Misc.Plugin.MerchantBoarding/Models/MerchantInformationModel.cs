﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantUri { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
    }
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        public bool IsTerminated { get; set; }
        public string AcceptCardExplanation { get; set; }
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranchExplanation { get; set; }

        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; }
    }

    public class BusinessInformation2Model : BaseInformationModel
    {
        public bool IsSeasonalSales { get; set; }
        public string ProductsOrServices { get; set; }
        public bool MerchantUse { get; set; } // if true then "Software" else "Terminal"
        public string TerminalType { get; set; } // if "Terminal"
        public string PaymentApplicationName { get; set; } // if "Software"
        public string PaymentApplicationVersion { get; set; } // if "Software"
        public bool MerchantNameAppear { get; set; } // if false then "DBA Name" else "Legal Name"
    }

    public class QuestionnaireModel : BaseInformationModel
    {
        public string BusinessPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public string PublicPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public bool IsRetailLocation { get; set; }
        public string DecribeProduct { get; set; }
        public string PhysicalAddress { get; set; }        
        public string PhysicalCity { get; set; }
        public string PhysicalZip { get; set; }
        public bool IsProductAddress { get; set; }
        public string ProductAddress { get; set; }
        public string ProductCity { get; set; }
        public string ProductZip { get; set; }
        public bool IsOwnProduct { get; set; }
        public string CardBrandProcessor { get; set; }
        public decimal ChargeBacks { get; set; }
        public string ChargeBackAmount { get; set; } // price in dollar $ amount
        public int WhenCharged { get; set; } // if 0 then "Time of Order", if 1 then "Upon Shipment"...................
        public int DeliverDays { get; set; } // 0 -> "1-7 days", 1 -> "8-14 Days" and 2 -> 14+ Days
        public bool IsOtherCompany { get; set; }
        public string CompanyName { get; set; }
        public string CompanyTelephone { get; set; }
        public string CompanyAddress { get; set; }  
        public string RefundPolicy { get; set; }
    }

    public class Questionnaire2Model : BaseInformationModel
    {
        public string BusinessPercentage { get; set; }
        public string IndividualPercentage { get; set; }
        public bool IsCreditCardPayment { get; set; }
        public string MerchantCertiNumber { get; set; }
        public string Issuer { get; set; }
        public string ExpDate { get; set; }
        public bool IsProduct { get; set; }
        public bool IsProductLocationSame { get; set; }
        public string ProductLocation { get; set; }
        public int ProductShipDays { get; set; }
        public int WhoShipProduct { get; set; } // 0 - Merchant, 1- Fullfillment Center
        public int ProductShippedBy { get; set; } // 0 - U.S. Mail , 1 - Other
        public string OtherShippedBy { get; set; }
        public bool IsDeliveryReceipt { get; set; }
    }

    public class ProcessingDetailsModel : BaseInformationModel
    {
        public string PaymentCardMonthly { get; set; } // $ amount
        public string AmericanExpressMonthly { get; set; } // $ amount
        public string AvgTicket { get; set; }
        public string HighestTicket { get; set; }
        public bool IsServicer { get; set; }
        public string ServicerName { get; set; }
        public string ServicerContactNumber { get; set; }
        public bool IsFulfillmentHouse { get; set; }
        public string HouseName { get; set; }
        public string HouseContactNumber { get; set; }
        public bool IsBankruptcy { get; set; }
        public string BankruptcyExplain { get; set; }
        public bool IsSeasonalMerchant { get; set; }
        public int MonthsSeason { get; set; }
    }

}
