﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantUri { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
    }
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        public bool IsTerminated { get; set; }
        public string Explanation { get; set; }
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranch { get; set; }

        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; } 
    }
}
