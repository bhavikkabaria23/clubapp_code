﻿using Nop.Core.Domain.Customers;
using Nop.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.Messages
{
    public interface IMessageTokenProviderCustom
    {
        void AddCustomerTokens(IList<Token> tokens, Customer customer, bool showDemoSite = false);
        void AddErrorMessageTokens(IList<Token> tokens, string url);
    }
}