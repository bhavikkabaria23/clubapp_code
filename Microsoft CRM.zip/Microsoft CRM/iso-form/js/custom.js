$('.phone').mask('(000) 000-0000');
$('.percent').mask('##0 . 00%', {reverse: true});
$('.money').mask('$ 00.000.000.000.000');
$('.ssn').mask('000-00-0000');

$("#LLC").click(function(){
        $("#llcstate").slideDown();
    });
     $("#IndividualSole").click(function(){
        $("#llcstate").slideUp();
    });
     $("#Partnership").click(function(){
        $("#llcstate").slideUp();
    });
     $("#Corporation").click(function(){
        $("#llcstate").slideUp();
    });
     $("#NonProfit").click(function(){
        $("#llcstate").slideUp();
    });
      $("#Goverment").click(function(){
        $("#llcstate").slideUp();
    });
       $("#Private").click(function(){
        $("#llcstate").slideUp();
    });
        $("Publiclyt").click(function(){
        $("#llcstate").slideUp();
    });

        $("#LLC").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#IndividualSole").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#Partnership").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#Corporation").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#NonProfit").click(function(){
        $("#nonprofitdiv").slideDown();
    });
      $("#Goverment").click(function(){
        $("#nonprofitdiv").slideUp();
    });
       $("#Private").click(function(){
        $("#nonprofitdiv").slideUp();
    });
        $("#Publiclyt").click(function(){
        $("#nonprofitdiv").slideUp();
    });