﻿namespace MultiSite.Data
{
    public class Owner
    {
        public int Id { get; set; }

        public string email { get; set; }

        public string industryType { get; set; }

        public string firstName { get; set; }

        public string LastName { get; set; }

        public string phone { get; set; }

        public string description { get; set; }

        public string starting { get; set; }

        public string Country { get; set; }

        public string Website { get; set; }

        //Multisite_NewField_change        
        public string StreetAddress { get; set; }
        
        public string City { get; set; }
        
        public string ZipPostalCode { get; set; }
        
        public string State { get; set; }

        // Free trial integration in new page
        public string AvgSaleAmout { get; set; }

        public string ProcessorName { get; set; }

        public string ProcessorEmail { get; set; }

        public string ProcessorPhoneNumber { get; set; }
        
        public string SiteCategory { get; set; }
        public string TeamPeople { get; set; }
        public string Reason { get; set; }

        // This is used for new approach of store signup to check for store owner is filled or data or not.
        public bool IsRegistered { get; set; }

        #region New Store Sign Up Approach - Properties
        public string Selling { get; set; }

        // First - I'm not selling product yet
        public string SomethingToSell { get; set; }

        // I'm just playing around
        public bool HelpBusinessLogo { get; set; }
        public bool HelpBusinessBrainStorm { get; set; }
        public bool HelpBusinessWebinar { get; set; }
        public bool HelpBusinessProduct { get; set; }

        //I sell with a different system
        public string SystemName { get; set; }

        // I'm selling, just not online
        public string LaunchStore { get; set; }
        public string WhatToSell { get; set; }
        public bool SellAtMarket { get; set; }
        public bool SellAtRetailStore { get; set; }

        public string CurrentRevenue { get; set; }
        public bool StoreForCLient { get; set; }
        public string StreetAddress2 { get; set; }

        #endregion

        #region Owner Card Details
        /// <summary>
        /// Gets or sets credit card type.
        /// </summary>
        public string CardType { get; set; }
        /// <summary>
        /// Gets or sets credit card name.
        /// </summary>      
        public string CardName { get; set; }
        /// <summary>
        /// Gets or sets credit card number.
        /// </summary>        
        public string CardNumber { get; set; }
        /// <summary>
        /// Gets or sets credit card expiry month.
        /// </summary>        
        public string ExpiryMonth { get; set; }
        /// <summary>
        /// Gets or sets credit card expiry year.
        /// </summary>        
        public string ExpiryYear { get; set; }
        /// <summary>
        /// Gets or sets card verification value.
        /// </summary>        
        public string VerifyCode { get; set; }
        #endregion


    }
}
