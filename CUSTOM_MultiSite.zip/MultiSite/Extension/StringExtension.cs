﻿using System.Linq;
using System.Text.RegularExpressions;

namespace MultiSite.Extension
{
    public static class StringExtension
    {
        public static bool StartWithDomain(this string hosts, string domain)
        {
            return hosts.ToLower().Split(',').Any(host => Regex.Replace(host.Trim(), "^www\\.", "").StartsWith(domain));
        }
    }
}
