﻿using System.IO;
using Nop.Core.Data;
using Nop.Core;

namespace MultiSite.Files
{
    public class MultisiteDataSettingsManager : DataSettingsManager
    {                             
        public DataSettings LoadMainSettings()
        {
            var subDomain = MultisiteHelper.MainStoreName;
            string filePath = Path.Combine(CommonHelper.MapPath("~/App_Data/"), string.Format("{0}{1}", subDomain, filename));
            if (File.Exists(filePath))
            {
                string text = File.ReadAllText(filePath);
                return ParseSettings(text);
            }
            else return new DataSettings();
        }

        public new virtual DataSettings LoadSettings(string storeName = null)
        {
            var subDomain = storeName ?? MultisiteHelper.SubDomain;
            string filePath = Path.Combine(CommonHelper.MapPath("~/App_Data/"), string.Format("{0}{1}", subDomain, filename));
            if (File.Exists(filePath))
            {
                string text = File.ReadAllText(filePath);
                return ParseSettings(text);
            }
            else return new DataSettings();
        }

        // Below is that whatever Bhavik is tried
        //public DataSettings LoadMainSettings()
        //{
        //    var mainDomain = MultisiteHelper.MainStoreName;
        //    var subDomain = MultisiteHelper.SubDomain;
        //    filename = string.Format("{0}{1}", subDomain, "Settings.txt");
        //    //string filePath = Path.Combine(CommonHelper.MapPath("~/App_Data/"), filename);
        //    string filePath = Path.Combine(CommonHelper.MapPath("~/App_Data/"), string.Format("{0}{1}", mainDomain, "Settings.txt"));
        //    if (File.Exists(filePath))
        //    {
        //        string text = File.ReadAllText(filePath);
        //        return ParseSettings(text);
        //    }
        //    else return new DataSettings();
        //}

        //public new virtual DataSettings LoadSettings(string storeName = null)
        //{
        //    var subDomain = storeName ?? MultisiteHelper.SubDomain;
        //    filename = string.Format("{0}{1}", subDomain, "Settings.txt");
        //    string filePath = Path.Combine(CommonHelper.MapPath("~/App_Data/"), filename);
        //    if (File.Exists(filePath))
        //    {
        //        string text = File.ReadAllText(filePath);
        //        return ParseSettings(text);
        //    }
        //    else return new DataSettings();
        //}
    }
}
