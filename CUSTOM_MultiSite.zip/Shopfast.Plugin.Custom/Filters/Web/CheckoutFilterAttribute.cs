﻿using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Services.Orders;
using Nop.Web.Models.Checkout;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CheckoutFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
            {
                //validation
                if ((EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.IsGuest() && !EngineContext.Current.Resolve<OrderSettings>().AnonymousCheckoutAllowed))
                {
                    var result = new HttpUnauthorizedResult();
                    filterContext.Result = result;
                    return;
                }

                Order order = null;
                int? orderId = 0;

                orderId = Convert.ToInt32(filterContext.ActionParameters["orderId"]);
                if (orderId.HasValue)
                {
                    //load order by identifier (if provided)
                    order = EngineContext.Current.Resolve<IOrderService>().GetOrderById(orderId.Value);
                }
                if (order == null)
                {
                    order = EngineContext.Current.Resolve<IOrderService>().SearchOrders(storeId: EngineContext.Current.Resolve<IStoreContext>().CurrentStore.Id,
                    customerId: EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.Id, pageSize: 1)
                        .FirstOrDefault();
                }
                if (order == null || order.Deleted || EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.Id != order.CustomerId)
                {
                    //return RedirectToRoute("HomePage");
                    var result = new RedirectResult("/");
                    filterContext.Result = result;
                    return;
                }

                //disable "order completed" page?
                if (EngineContext.Current.Resolve<OrderSettings>().DisableOrderCompletedPage)
                {
                    //return RedirectToRoute("OrderDetails", new { orderId = order.Id });
                    var result = new RedirectResult("/orderdetails/" + orderId);
                    filterContext.Result = result;
                    return;
                }

                //model
                var model = new CheckoutCompletedModel
                {
                    OrderId = order.Id,
                    OnePageCheckoutEnabled = EngineContext.Current.Resolve<OrderSettings>().OnePageCheckoutEnabled
                };

                //upgrade_2.80_3.1
                if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
                {
                    // For package details         
                    if (System.Web.HttpContext.Current.Session["StoreName"] == null || System.Web.HttpContext.Current.Session["StoreName"] == "")
                    {
                        var siteRegistration = MultiSite.Models.SiteRegistrationModel.GetFromOrder(order);
                        if (siteRegistration != null)
                        {
                            if (!string.IsNullOrEmpty(siteRegistration.storeName))
                            {

                                filterContext.Controller.TempData["multisite"] = siteRegistration;
                                var result = new RedirectResult("/Merchant/SetupFinish");
                                filterContext.Result = result;
                                return;

                            }
                        }
                    }
                    else
                    {
                        //For package details  
                        var siteRegistration = MultiSite.Models.SiteRegistrationModel.GetFromOrderForUpgradePackage(order, Convert.ToString(System.Web.HttpContext.Current.Session["StoreName"]));
                        if (siteRegistration != null)
                        {
                            //System.Web.HttpContext.Current.Session["StoreName"] = null;
                            System.Web.HttpContext.Current.Session.Remove("StoreName");
                            filterContext.Controller.TempData["multisite"] = siteRegistration;
                            var result = new RedirectResult("/Merchant/UpgradeFinish");
                            filterContext.Result = result;
                            return;                            
                        }
                    }
                    //--------------------------------------
                }
                //-----------------------------


                ViewResult vr = new System.Web.Mvc.ViewResult
                    {
                        ViewName = "Completed",
                        ViewData = new ViewDataDictionary(filterContext.Controller.ViewData)
                            {
                                Model = model
                            }
                    };


                filterContext.Result = vr;
                return;
            }
        }


        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            //if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
            //{
            //    // For package details         
            //    if (System.Web.HttpContext.Current.Session["StoreName"] == null || System.Web.HttpContext.Current.Session["StoreName"] == "")
            //    {
            //        var siteRegistration = MultiSite.Models.SiteRegistrationModel.GetFromOrder(order);
            //        if (siteRegistration != null)
            //        {
            //            if (!string.IsNullOrEmpty(siteRegistration.storeName))
            //            {
            //                //My Account Module - Add store owner as a Customer.
            //                //bool result = StoreOwnerRegister(siteRegistration);
            //                //if (result)
            //                //{                                                               
            //                TempData["multisite"] = siteRegistration;
            //                return RedirectToAction("SetupFinish", "Merchant");
            //                //}
            //                //else
            //                //{
            //                //    return RedirectToRoute("HomePage");
            //                //}
            //                //-------------------------------------
            //            }
            //        }
            //    }
            //    else
            //    {
            //        //For package details  
            //        //var siteRegistration = MultiSite.Models.SiteRegistrationModel.GetFromOrderForUpgradePackage(order, Convert.ToString(Session["StoreName"]));
            //        //if (siteRegistration != null)
            //        //{
            //        //    //Session["StoreName"] = null;
            //        //    Session.Remove("StoreName");
            //        //    TempData["multisite"] = siteRegistration;
            //        //    return RedirectToAction("UpgradeFinish", "Merchant");
            //        //}
            //    }
            //    //--------------------------------------
        }
    }
}