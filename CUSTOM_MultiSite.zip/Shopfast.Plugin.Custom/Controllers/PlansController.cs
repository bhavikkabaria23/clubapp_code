﻿using Nop.Admin.Controllers;
using Nop.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Extensions;
using Shopfast.Plugin.Custom.Services;
using Nop.Core;
using MultiSite.Data;
using Nop.Web.Framework.Controllers;
using System.Net.Http;
using Nop.Core.Domain.Catalog;
using System.Web.Script.Serialization;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using MultiSite.Models;
using Nop.Services.Directory;
using Nop.Services.Customers;
using Nop.Core.Domain.Customers;
using System.Text;
using Newtonsoft.Json;
using Nop.Services.Localization;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Shopfast.Plugin.Custom.Models.NopAdmin.MerchantAdmin;
using System.Net;
using System.Collections.Specialized;
using System.Security.Cryptography;
using Nop.Core.Infrastructure;
using Nop.Web.Framework.Themes;
using Nop.Services.Stores;
using Nop.Core.Domain;
using Nop.Services.Configuration;
using Nop.Web.Models.Order;
using Shopfast.Plugin.Custom.Models.NopAdmin.Orders;
using MultiSite.Hubs;
using Nop.Web.Models.SiteRegistration;
using Nop.Data;
using MultiSite.Services;
using Nop.Services.Logging;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class PlansController : BaseController
    {
        #region Fields
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly CustomerSettings _customerSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly HttpContextBase _httpContext;
        private readonly ILogger _logger;

        private static string ShopfastAPIBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ShopfastAPIBaseUrl"];
        #endregion

        #region Ctor

        public PlansController(IStoreContext storeContext,
            IWorkContext workContext,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            ICustomerRegistrationService customerRegistrationService,
            CustomerSettings customerSettings,
            ILocalizationService localizationService,
            IStoreService storeService,
            ISettingService settingService,
            HttpContextBase httpContext,
            ILogger logger)
        {
            this._settingService = settingService;
            this._storeContext = storeContext;
            this._workContext = workContext;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._customerRegistrationService = customerRegistrationService;
            this._customerSettings = customerSettings;
            this._localizationService = localizationService;
            this._storeService = storeService;
            this._httpContext = httpContext;
            this._logger = logger;
        }
        #endregion

        /// <summary>
        /// Generate passwords
        /// </summary>
        /// <param name="passwordLength"></param>
        /// <param name="strongPassword"> </param>
        /// <returns></returns>
        private string PasswordGenerator(int passwordLength, bool strongPassword)
        {
            Random Random = new Random();
            int seed = Random.Next(1, int.MaxValue);
            const string allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
            const string specialCharacters = @"!#$%()*/^~?@_";

            var chars = new char[passwordLength];
            var rd = new Random(seed);

            for (var i = 0; i < passwordLength; i++)
            {
                // If we are to use special characters
                if (strongPassword && i % Random.Next(3, passwordLength) == 0)
                {
                    chars[i] = specialCharacters[rd.Next(0, specialCharacters.Length)];
                }
                else
                {
                    chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
                }
            }

            return new string(chars);
        }

        public ActionResult StorePlans()
        {
            ProductRespose productRespose = new ProductRespose();
            var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
            if (response.IsSuccessStatusCode)
            {
                var productsString = response.Content.ReadAsStringAsync().Result;
                JavaScriptSerializer js = new JavaScriptSerializer();
                var products = js.Deserialize<List<AppProductListModel>>(productsString);

                if (products != null && products.Any())
                {
                    products = products.Where(p => p.ProductSpecificationAttributes != null
                        && p.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "ispackage" && ps.ValueRaw.ToLower() == "yes")
                        ).ToList();
                    foreach (var product in products)
                    {
                        if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "monthly"))
                        {
                            if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "most_popular" && ps.ValueRaw.ToLower() == "yes"))
                            {
                                product.IsMostPopular = true;
                            }
                            productRespose.MonthlyPackageList.Add(product);
                        }
                        else if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "yearly"))
                        {
                            if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "most_popular" && ps.ValueRaw.ToLower() == "yes"))
                            {
                                product.IsMostPopular = true;
                            }
                            productRespose.YearlyPackageList.Add(product);
                        }
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/Pricing.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), productRespose);
        }

        public ActionResult StoreCheckout(int productId, string planType = "monthly")
        {
            StoreCheckoutModel checkoutModel = new StoreCheckoutModel();
            if (productId > 0)
            {
                checkoutModel.PlanType = planType;
                var client = new HttpClient();
                // Here Need to call GetProductById API, Need from Sanjay
                HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
                if (response.IsSuccessStatusCode)
                {
                    var productsString = response.Content.ReadAsStringAsync().Result;
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    var products = js.Deserialize<List<AppProductListModel>>(productsString);

                    if (products != null && products.Any())
                    {
                        checkoutModel.product = products.SingleOrDefault(p => p.Id == productId);
                        if (checkoutModel.product != null && checkoutModel.product.ProductAttributes != null
                            && checkoutModel.product.ProductAttributes.Any(pa => pa.Name.ToLower() == "subscription" && pa.AttributeControlType.ToLower() == "radiolist" && pa.Values != null && pa.Values.Any()))
                        {
                            checkoutModel.ProductAttributes = checkoutModel.product.ProductAttributes.ToList();
                        }
                    }
                    var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
                    var subdomain = MultisiteHelper.SubDomain;
                    if (_oRegisterStoreModel != null)
                    {
                        checkoutModel.ownerModel = _oRegisterStoreModel;                      
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/StoreCheckout.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), checkoutModel);
        }

        [HttpPost]
        public ActionResult StoreCheckout(StoreCheckoutModel model, string subscriptionRadio)
        {
            try
            {
                bool checkoutResult = false;
                var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
                if (_oRegisterStoreModel != null)
                {
                    _logger.Information("_oRegisterStoreModel is not null");
                    if (model.product.Id > 0 && !string.IsNullOrEmpty(model.PlanType))
                    {
                        #region Checkout Transaction by API
                        CheckoutTransaction request = new CheckoutTransaction();
                        // POST API
                        string month = "";
                        string year = "";
                        if (!string.IsNullOrEmpty(model.Expires))
                        {
                            string[] expires = model.Expires.Split('/');
                            if (expires != null && expires.Any())
                                month = expires[0].Trim();
                            if (expires.Count() > 1)
                                year = expires[1].Trim();
                        }
                        if (!string.IsNullOrEmpty(model.cardNumber))
                        {
                            model.cardNumber = model.cardNumber.Replace(" ", "");
                        }

                        double subscriptionPrice = 0;
                        string subscriptionId = string.Empty;

                        if (!string.IsNullOrEmpty(subscriptionRadio))
                        {
                            string[] subscription = subscriptionRadio.Split('~');
                            if (subscription != null && subscription.Any())
                            {
                                subscriptionId = subscription[0];
                                if (subscription.Count() > 1)
                                {
                                    subscriptionPrice = Convert.ToDouble(subscription[1]);
                                }
                            }

                        }
                        request.Products = model.product.Id.ToString();
                        request.Quantities = "1";
                        request.TotalAmount = Convert.ToDouble(model.product.Price) + subscriptionPrice;
                        request.Email = model.ownerModel.email;
                        request.CardType = "Visa";
                        request.CardName = "test";
                        request.CardNumber = model.cardNumber;
                        request.ExpiryMonth = month;
                        request.ExpiryYear = "20" + year;
                        request.VerifyCode = model.CVV;
                        request.TransactionType = "card";
                        request.UseRewardPoints = false;
                        request.Attributes = (!string.IsNullOrEmpty(subscriptionId)) ? subscriptionId : null;
                        request.IsWebOrder = true;

                        var jsonString = JsonConvert.SerializeObject(request);
                        var element = new JObject();
                        element["Data"] = jsonString;
                        byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                        byteData = Encoding.UTF8.GetBytes(element.ToString());

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            var client = new HttpClient();
                            var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                                if (checkoutResponse.CheckoutTransactionResult.Status)
                                {
                                    // If success then change store creted date based on selected package
                                    // Make store "Purchased" from "Trial" based on "IsOrder" field                        
                                    using (var dbContext = new Sites4Entities())
                                    {
                                        var site = dbContext.Sites.FirstOrDefault(s => s.Id == model.ownerModel.siteId);
                                        var siteupdate = site;
                                        if (site != null)
                                        {
                                            var owner = dbContext.Owners.FirstOrDefault(o => o.Id == site.Owner_Id);
                                            //site.CreationDate = DateTime.UtcNow.AddDays(days); // no need to update creation date for purchased store
                                            site.IsOrder = true;
                                            site.Owner = owner;
                                            dbContext.Entry(site).CurrentValues.SetValues(siteupdate);

                                            //Add this order to SiteOrders and make other orders IsActive to false for this store.
                                            var existingSiteOrders = dbContext.SiteOrders.Where(so => so.StoreName.ToLower() == site.StoreName.ToLower());
                                            if (existingSiteOrders != null && existingSiteOrders.Any())
                                            {
                                                foreach (var order in existingSiteOrders)
                                                {
                                                    var orderUpdate = order;
                                                    order.IsActive = false;
                                                    dbContext.Entry(order).CurrentValues.SetValues(orderUpdate);
                                                }
                                            }
                                            SiteOrders siteOrder = new SiteOrders()
                                            {
                                                StoreName = site.StoreName,
                                                PackageId = model.product.Id,
                                                PackageName = model.product.Name,
                                                OrderId = checkoutResponse.CheckoutTransactionResult.OrderId,
                                                IsActive = true,
                                                CreationDate = DateTime.UtcNow,
                                                PlanExpirationDate = (model.PlanType == "monthly") ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1) // this for yearly
                                            };
                                            dbContext.SiteOrders.Add(siteOrder);
                                            dbContext.SaveChanges();
                                            checkoutResult = true;
                                            _logger.Information("checkout success");
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                        if (checkoutResult)
                        {
                            #region Create Store and DB based on RegisterStore model
                            ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step1");
                            _logger.Information("step1 success");
                            string storeName;
                            _oRegisterStoreModel.storeName = _oRegisterStoreModel.storeName.SanitazeStoreName();

                            // Copy database and settings
                            SiteHelper.AddToSqlServer(_oRegisterStoreModel.storeName, _oRegisterStoreModel.industryType, out storeName);
                            ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step2");
                            _logger.Information("step2 success");

                            var customer = _workContext.CurrentCustomer;

                            // Setup store admin credentials and basic settings into database.
                            var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                            MultiSiteDataProvider.ConfigureStoreDatabase(_oRegisterStoreModel.storeName, storeDatabase, _oRegisterStoreModel.email, string.Empty, MultisiteHelper.DefaultTheme, null);
                            _logger.Information("configure database");
                            _oRegisterStoreModel.isOrder = true;

                            using (var dbContext = new Sites4Entities())
                            {
                                var owner = dbContext.Owners.Where(o => o.Id == _oRegisterStoreModel.OwnerId).FirstOrDefault();
                                if (owner != null)
                                {
                                    owner.Selling = _oRegisterStoreModel.Selling;
                                    owner.SomethingToSell = _oRegisterStoreModel.SomethingToSell;
                                    owner.HelpBusinessLogo = _oRegisterStoreModel.HelpBusinessLogo;
                                    owner.HelpBusinessBrainStorm = _oRegisterStoreModel.HelpBusinessBrainStorm;
                                    owner.HelpBusinessWebinar = _oRegisterStoreModel.HelpBusinessWebinar;
                                    owner.HelpBusinessProduct = _oRegisterStoreModel.HelpBusinessProduct;
                                    owner.SystemName = _oRegisterStoreModel.SystemName;
                                    owner.LaunchStore = _oRegisterStoreModel.LaunchStore;
                                    owner.WhatToSell = _oRegisterStoreModel.WhatToSell;
                                    owner.SellAtMarket = _oRegisterStoreModel.SellAtMarket;
                                    owner.SellAtRetailStore = _oRegisterStoreModel.SellAtRetailStore;
                                    owner.CurrentRevenue = _oRegisterStoreModel.CurrentRevenue;
                                    owner.StoreForCLient = _oRegisterStoreModel.StoreForCLient;

                                    owner.description = _oRegisterStoreModel.Description;
                                    owner.firstName = _oRegisterStoreModel.firstName;
                                    owner.LastName = _oRegisterStoreModel.lastName;
                                    owner.phone = _oRegisterStoreModel.phone;
                                    owner.starting = _oRegisterStoreModel.Starting;
                                    owner.Country = _oRegisterStoreModel.Country;
                                    owner.Website = _oRegisterStoreModel.Website;
                                    owner.StreetAddress = _oRegisterStoreModel.StreetAddress;
                                    owner.StreetAddress2 = _oRegisterStoreModel.StreetAddress2;
                                    owner.City = _oRegisterStoreModel.City;
                                    owner.ZipPostalCode = _oRegisterStoreModel.ZipPostalCode;
                                    owner.State = _oRegisterStoreModel.State;

                                    owner.AvgSaleAmout = _oRegisterStoreModel.AvgSaleAmout;
                                    owner.ProcessorName = _oRegisterStoreModel.ProcessorName;
                                    owner.ProcessorEmail = _oRegisterStoreModel.ProcessorEmail;
                                    owner.ProcessorPhoneNumber = _oRegisterStoreModel.ProcessorPhoneNumber;
                                    owner.SiteCategory = _oRegisterStoreModel.SiteCategory;
                                    owner.TeamPeople = _oRegisterStoreModel.TeamPeople;
                                    owner.Reason = _oRegisterStoreModel.Reason;
                                    owner.IsRegistered = true;

                                    dbContext.Entry(owner).CurrentValues.SetValues(owner);
                                    dbContext.SaveChanges();

                                    // Add host in plesk.
                                    _oRegisterStoreModel.password = PasswordGenerator(12, true);
                                    ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step3");
                                    _logger.Information("step 3 success");
                                    var hostResult = SiteHelper.AddPleskHost(_oRegisterStoreModel);
                                    _logger.Information("step 3 success");
                                    if (hostResult)
                                    {
                                        // Upload file in FTP server.
                                        var ftpUserName = _oRegisterStoreModel.email.Split('@')[0].ToString().Length > 15 ? _oRegisterStoreModel.email.Split('@')[0].Substring(0, 15) : _oRegisterStoreModel.email.Split('@')[0];

                                        SiteHelper.UploadFtpFile(_oRegisterStoreModel.storeName, ftpUserName, _oRegisterStoreModel.password);
                                        _logger.Information("UploadFtpFile");

                                        var _workflowMessageService = new MultisiteWorkflowMessageService();
                                        _workflowMessageService.SendTrialStoreCreatedCustomerNotification(_oRegisterStoreModel);
                                        _workflowMessageService.SendTrialStoreCreatedAdminNotification(_oRegisterStoreModel);

                                        ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step4");
                                        _logger.Information("CreateStoreProcess");

                                        return Json(new { storeUrl = string.Format(@"http://{0}.{1}/MerchantAdminAutoLogin?email={2}&owner_id={3}", _oRegisterStoreModel.storeName, MultisiteHelper.Domain, customer.Email,_oRegisterStoreModel.OwnerId) });
                                    }
                                }
                            }

                            #endregion
                        }
                        // if checkout API failed and trasaction not done
                        //{
                        // Rollback store which is created
                        // 1) delete registered customer from DB physically
                        // delete site and owner of that customer
                        // delete store and sub domain from PLESK
                        // delete DB of that store
                        //}            
                    }
                    else
                    {
                        return Json(new { error = "Error : Plan is not selected. Please select a plan" });
                    }

                }
                return Json(new { error = "Error while creating a store. Please try again." });
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return Json(new { error = "Error occurred while creating a store. Please try again." });
            }
        }

        // This method is ONLY used for LOCAL Env for testing purpose
        [HttpPost]
        public ActionResult StoreCheckoutLocal(StoreCheckoutModel model, string subscriptionRadio)
        {
            bool checkoutResult = false;
            var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
            if (_oRegisterStoreModel != null)
            {
                if (model.product.Id > 0 && !string.IsNullOrEmpty(model.PlanType))
                {
                    #region Checkout Transaction by API
                    CheckoutTransaction request = new CheckoutTransaction();
                    // POST API
                    string month = "";
                    string year = "";
                    if (!string.IsNullOrEmpty(model.Expires))
                    {
                        string[] expires = model.Expires.Split('/');
                        if (expires != null && expires.Any())
                            month = expires[0].Trim();
                        if (expires.Count() > 1)
                            year = expires[1].Trim();
                    }
                    if (!string.IsNullOrEmpty(model.cardNumber))
                    {
                        model.cardNumber = model.cardNumber.Replace(" ", "");
                    }

                    double subscriptionPrice = 0;
                    string subscriptionId = string.Empty;

                    if (!string.IsNullOrEmpty(subscriptionRadio))
                    {
                        string[] subscription = subscriptionRadio.Split('~');
                        if (subscription != null && subscription.Any())
                        {
                            subscriptionId = subscription[0];
                            if (subscription.Count() > 1)
                            {
                                subscriptionPrice = Convert.ToDouble(subscription[1]);
                            }
                        }

                    }
                    request.Products = model.product.Id.ToString();
                    request.Quantities = "1";
                    request.TotalAmount = Convert.ToDouble(model.product.Price) + subscriptionPrice;
                    request.Email = model.ownerModel.email;
                    request.CardType = "Visa";
                    request.CardName = "test";
                    request.CardNumber = model.cardNumber;
                    request.ExpiryMonth = month;
                    request.ExpiryYear = "20" + year;
                    request.VerifyCode = model.CVV;
                    request.TransactionType = "card";
                    request.UseRewardPoints = false;
                    request.Attributes = (!string.IsNullOrEmpty(subscriptionId)) ? subscriptionId : null;
                    request.IsWebOrder = true;

                    var jsonString = JsonConvert.SerializeObject(request);
                    var element = new JObject();
                    element["Data"] = jsonString;
                    byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                    byteData = Encoding.UTF8.GetBytes(element.ToString());

                    using (var contentPayment = new ByteArrayContent(byteData))
                    {
                        contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                        var client = new HttpClient();
                        var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                        if (responsePayment.IsSuccessStatusCode)
                        {
                            var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                            if (checkoutResponse.CheckoutTransactionResult.Status)
                            {
                                // If success then change store creted date based on selected package
                                // Make store "Purchased" from "Trial" based on "IsOrder" field                        
                                using (var dbContext = new Sites4Entities())
                                {
                                    var site = dbContext.Sites.FirstOrDefault(s => s.Id == model.ownerModel.siteId);
                                    var siteupdate = site;
                                    if (site != null)
                                    {
                                        var owner = dbContext.Owners.FirstOrDefault(o => o.Id == site.Owner_Id);
                                        //site.CreationDate = DateTime.UtcNow.AddDays(days); // no need to update creation date for purchased store
                                        site.IsOrder = true;
                                        site.Owner = owner;
                                        dbContext.Entry(site).CurrentValues.SetValues(siteupdate);

                                        //Add this order to SiteOrders and make other orders IsActive to false for this store.
                                        var existingSiteOrders = dbContext.SiteOrders.Where(so => so.StoreName.ToLower() == site.StoreName.ToLower());
                                        if (existingSiteOrders != null && existingSiteOrders.Any())
                                        {
                                            foreach (var order in existingSiteOrders)
                                            {
                                                var orderUpdate = order;
                                                order.IsActive = false;
                                                dbContext.Entry(order).CurrentValues.SetValues(orderUpdate);
                                            }
                                        }
                                        SiteOrders siteOrder = new SiteOrders()
                                        {
                                            StoreName = site.StoreName,
                                            PackageId = model.product.Id,
                                            PackageName = model.product.Name,
                                            OrderId = checkoutResponse.CheckoutTransactionResult.OrderId,
                                            IsActive = true,
                                            CreationDate = DateTime.UtcNow,
                                            PlanExpirationDate = (model.PlanType == "monthly") ? DateTime.UtcNow.AddDays(30) : DateTime.UtcNow.AddDays(365) // this for yearly
                                        };
                                        dbContext.SiteOrders.Add(siteOrder);
                                        dbContext.SaveChanges();
                                        checkoutResult = true;
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                    if (checkoutResult)
                    {
                        #region Create Store and DB based on RegisterStore model
                        //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step1");
                        string storeName;
                        _oRegisterStoreModel.storeName = _oRegisterStoreModel.storeName.SanitazeStoreName();

                        // Copy database and settings
                        SiteHelper.AddToSqlServer(_oRegisterStoreModel.storeName, _oRegisterStoreModel.industryType, out storeName);
                        //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step2");

                        var customer = _workContext.CurrentCustomer;

                        // Setup store admin credentials and basic settings into database.
                        var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                        MultiSiteDataProvider.ConfigureStoreDatabase(_oRegisterStoreModel.storeName, storeDatabase, _oRegisterStoreModel.email, string.Empty, MultisiteHelper.DefaultTheme, null);

                        _oRegisterStoreModel.isOrder = true;

                        using (var dbContext = new Sites4Entities())
                        {
                            var owner = dbContext.Owners.Where(o => o.Id == _oRegisterStoreModel.OwnerId).FirstOrDefault();
                            if (owner != null)
                            {
                                owner.Selling = _oRegisterStoreModel.Selling;
                                owner.SomethingToSell = _oRegisterStoreModel.SomethingToSell;
                                owner.HelpBusinessLogo = _oRegisterStoreModel.HelpBusinessLogo;
                                owner.HelpBusinessBrainStorm = _oRegisterStoreModel.HelpBusinessBrainStorm;
                                owner.HelpBusinessWebinar = _oRegisterStoreModel.HelpBusinessWebinar;
                                owner.HelpBusinessProduct = _oRegisterStoreModel.HelpBusinessProduct;
                                owner.SystemName = _oRegisterStoreModel.SystemName;
                                owner.LaunchStore = _oRegisterStoreModel.LaunchStore;
                                owner.WhatToSell = _oRegisterStoreModel.WhatToSell;
                                owner.SellAtMarket = _oRegisterStoreModel.SellAtMarket;
                                owner.SellAtRetailStore = _oRegisterStoreModel.SellAtRetailStore;
                                owner.CurrentRevenue = _oRegisterStoreModel.CurrentRevenue;
                                owner.StoreForCLient = _oRegisterStoreModel.StoreForCLient;

                                owner.description = _oRegisterStoreModel.Description;
                                owner.firstName = _oRegisterStoreModel.firstName;
                                owner.LastName = _oRegisterStoreModel.lastName;
                                owner.phone = _oRegisterStoreModel.phone;
                                owner.starting = _oRegisterStoreModel.Starting;
                                owner.Country = _oRegisterStoreModel.Country;
                                owner.Website = _oRegisterStoreModel.Website;
                                owner.StreetAddress = _oRegisterStoreModel.StreetAddress;
                                owner.StreetAddress2 = _oRegisterStoreModel.StreetAddress2;
                                owner.City = _oRegisterStoreModel.City;
                                owner.ZipPostalCode = _oRegisterStoreModel.ZipPostalCode;
                                owner.State = _oRegisterStoreModel.State;

                                owner.AvgSaleAmout = _oRegisterStoreModel.AvgSaleAmout;
                                owner.ProcessorName = _oRegisterStoreModel.ProcessorName;
                                owner.ProcessorEmail = _oRegisterStoreModel.ProcessorEmail;
                                owner.ProcessorPhoneNumber = _oRegisterStoreModel.ProcessorPhoneNumber;
                                owner.SiteCategory = _oRegisterStoreModel.SiteCategory;
                                owner.TeamPeople = _oRegisterStoreModel.TeamPeople;
                                owner.Reason = _oRegisterStoreModel.Reason;
                                owner.IsRegistered = true;

                                dbContext.Entry(owner).CurrentValues.SetValues(owner);
                                dbContext.SaveChanges();

                                // Add host in plesk.
                                _oRegisterStoreModel.password = PasswordGenerator(12, true);
                                //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step3");
                                //var hostResult = SiteHelper.AddPleskHost(_oRegisterStoreModel);
                                var hostResult = true;
                                if (hostResult)
                                {
                                    // Upload file in FTP server.
                                    //var ftpUserName = _oRegisterStoreModel.email.Split('@')[0].ToString().Length > 15 ? _oRegisterStoreModel.email.Split('@')[0].Substring(0, 15) : _oRegisterStoreModel.email.Split('@')[0];

                                    //SiteHelper.UploadFtpFile(_oRegisterStoreModel.storeName, ftpUserName, _oRegisterStoreModel.password);

                                    var _workflowMessageService = new MultisiteWorkflowMessageService();
                                    _workflowMessageService.SendTrialStoreCreatedCustomerNotification(_oRegisterStoreModel);
                                    _workflowMessageService.SendTrialStoreCreatedAdminNotification(_oRegisterStoreModel);

                                    //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step4");

                                    return Json(new { storeUrl = string.Format(@"http://{0}.{1}/MerchantAdminAutoLogin?email={2}&owner_id={3}", _oRegisterStoreModel.storeName, MultisiteHelper.Domain, customer.Email, _oRegisterStoreModel.OwnerId) });
                                }
                            }
                        }

                        #endregion
                    }
                    // if checkout API failed and trasaction not done
                    //{
                    // Rollback store which is created
                    // 1) delete registered customer from DB physically
                    // delete site and owner of that customer
                    // delete store and sub domain from PLESK
                    // delete DB of that store
                    //}            
                }
                else
                {
                    return Json(new { error = "Error : Plan is not selected. Please select a plan" });
                }

            }
            return Json(new { error = "Error while creating a store. Please try again." });
        }

        public ActionResult ApplyDiscountCoupon(string _pPrice, string _pCouponCode)
        {
            decimal checkoutPrice = 0;
            decimal.TryParse(_pPrice, out checkoutPrice);
            decimal finalPrice = checkoutPrice;
            // get all discount coupons from API            
            var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/sf_api/service.svc/json/getdiscounts").Result;
            if (response.IsSuccessStatusCode)
            {
                var discountsString = response.Content.ReadAsStringAsync().Result;
                JavaScriptSerializer js = new JavaScriptSerializer();
                var discounts = js.Deserialize<DiscountsResponse>(discountsString);
                if (discounts != null && discounts.GetDiscountsResult != null && discounts.GetDiscountsResult.Any())
                {
                    var discount = discounts.GetDiscountsResult.FirstOrDefault(d => d.Name.Equals(_pCouponCode, StringComparison.InvariantCultureIgnoreCase));
                    if (discount != null)
                    {
                        //check date range
                        DateTime now = DateTime.UtcNow;
                        if (discount.StartDateUtc.HasValue)
                        {
                            DateTime startDate = DateTime.SpecifyKind(discount.StartDateUtc.Value, DateTimeKind.Utc);
                            if (startDate.CompareTo(now) > 0)
                            {
                                return Json(new
                                {
                                    success = false,
                                    message = _localizationService.GetResource("ShoppingCart.Discount.NotStartedYet")
                                });
                            }
                        }
                        if (discount.EndDateUtc.HasValue)
                        {
                            DateTime endDate = DateTime.SpecifyKind(discount.EndDateUtc.Value, DateTimeKind.Utc);
                            if (endDate.CompareTo(now) < 0)
                            {
                                return Json(new
                                {
                                    success = false,
                                    message = _localizationService.GetResource("ShoppingCart.Discount.Expired")
                                });
                            }
                        }
                        if (discount.UsePercentag)
                        {
                            var discountPrice = (checkoutPrice * discount.DiscountPercentage) / 100;
                            finalPrice = checkoutPrice - discountPrice;
                        }
                        else
                        {
                            finalPrice = checkoutPrice - discount.DiscountAmount;
                        }
                        return Json(new
                        {
                            success = true,
                            finalprice = finalPrice,
                            finalpricestring = finalPrice.ToString("G29"),
                            message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied")
                        });
                    }
                }
            }
            return Json(new
            {
                success = false,
                message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount")
            });
        }
    }
}