using Nop.Data.Mapping;
using Nop.Plugin.Catalog.GBS.Domain;

namespace Nop.Plugin.Catalog.GBS.Data
{
    public partial class CategoryNavigationDataMap : NopEntityTypeConfiguration<CategoryNavigationData>
    {
        public CategoryNavigationDataMap()
        {
            this.ToTable("CategoryNavigationData");
            this.HasKey(tr => tr.Id);            
        }
    }
}