﻿using System.Web.Mvc;
using Nop.Web.Framework.Controllers;
using Nop.Plugin.Catalog.GBS.Models;
using System.Linq;
using Nop.Plugin.Catalog.GBS.Services;
using Nop.Plugin.Catalog.GBS.Domain;
using Nop.Services.Security;
using System.Collections.Generic;
using Nop.Services.Catalog;
using Nop.Plugin.Catalog.GBS.Extensions;
using System;
using Nop.Plugin.Catalog.GBS.Factories;

namespace Nop.Plugin.Catalog.GBS.Controllers
{
    public class WidgetsCategoryNavigationController : BaseController
    {
        private readonly ICategoryNavigationService _categoryNavigationServiceService;
        private readonly IPermissionService _permissionService;
        private readonly ICategoryService _categoryService;
        private readonly ICatalogModelFactoryCustom _catalogModelFactory;

        public WidgetsCategoryNavigationController(ICatalogModelFactoryCustom catalogModelFactory,
            ICategoryNavigationService categoryNavigationServiceService,
            IPermissionService permissionService,
            ICategoryService categoryService)
        {
            this._categoryNavigationServiceService = categoryNavigationServiceService;
            this._permissionService = permissionService;
            this._categoryService = categoryService;
            this._catalogModelFactory = catalogModelFactory;
        }


        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var categories = _categoryService.GetAllCategories();

            var categoryModelList = categories.Select(x =>
            {
                var categoryModel = x.ToModel();
                categoryModel.Breadcrumb = x.GetFormattedBreadCrumb(_categoryService);
                categoryModel.IsEnable = _categoryNavigationServiceService.IsExist(categoryModel.Id);
                return categoryModel;
            }).ToList();
            return View("~/Plugins/Nop.Plugin.Catalog.GBS/Views/Configure.cshtml", categoryModelList);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult Configure(List<CategoryModel> categoryModelList)
        {
            var categoryNavigationData = new List<CategoryNavigationData>();
            foreach (var item in categoryModelList.Where(c => c.IsEnable == true))
            {
                categoryNavigationData.Add(new CategoryNavigationData
                {
                    CategoryId = item.Id
                });
            }
            _categoryNavigationServiceService.ManageCategory(categoryNavigationData);
            return Configure();
        }

        [ChildActionOnly]
        public ActionResult CategoryNavigation(string widgetZone, object additionalData = null)
        {
            int currentCategoryId = 0;
            int currentProductId = 0;
            if (additionalData != null)
            {
                string[] data = additionalData.ToString().Split(',');
                if (data.Any())
                {
                    int.TryParse(data[0], out currentCategoryId);
                    if (data.Count() > 1)
                    {
                        int.TryParse(data[1], out currentProductId);
                    }
                }
            }
            var model = _catalogModelFactory.PrepareCategoryNavigationModel(currentCategoryId, currentProductId);
            //var categories = _categoryNavigationServiceService.GetAllCategories();
            //if (model.Categories.Any())
            //{
            //    // categories.Any(cn => cn.CategoryId == c.Id
            //    model.Categories = model.Categories.Where(c => categories.Any(cn => cn.CategoryId == c.Id &&
            //    categories.Any(cn2 => c.SubCategories.Any(sc => sc.Id == cn2.CategoryId)) &&                
            //    Convert.ToInt32(c.NumberOfProducts) != 0)).ToList();                
            //}
            return View("~/Plugins/Nop.Plugin.Catalog.GBS/Views/CategoryNavigation.cshtml", model);
        }
    }
}