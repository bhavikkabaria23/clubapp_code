﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Nop.Plugin.Catalog.GBS.Domain
{
    public class CategoryNavigationData : BaseEntity
    {
        public int CategoryId { get; set; }        
    }
}
