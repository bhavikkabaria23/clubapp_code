﻿using Nop.Core.Data;
using Nop.Services.Events;
using Nop.Plugin.Catalog.GBS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Catalog.GBS.Services
{
    public class CategoryNavigationService : ICategoryNavigationService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<CategoryNavigationData> _categoryNavigationRepository;
        #endregion

        public CategoryNavigationService(IEventPublisher eventPublisher,
           IRepository<CategoryNavigationData> categoryNavigationRepository)
        {
            this._eventPublisher = eventPublisher;
            this._categoryNavigationRepository = categoryNavigationRepository;            
        }     

        public virtual void ManageCategory(List<CategoryNavigationData> categories)
        {
            if (categories == null)
                throw new ArgumentNullException("categories");

            var categoryData = _categoryNavigationRepository.Table.ToList();
            if (categoryData.Any())
            {
                foreach (var category in categoryData)
                {
                    _categoryNavigationRepository.Delete(category);

                    //event notification
                    _eventPublisher.EntityDeleted(category);
                }
            }

            foreach (var category in categories)
            {
                _categoryNavigationRepository.Insert(category);

                //event notification
                _eventPublisher.EntityInserted(category);
            }                                    
        }

        public virtual IEnumerable<CategoryNavigationData> GetAllCategories()
        {
            return _categoryNavigationRepository.Table;
        }

        public virtual bool IsExist(int categoryId)
        {
            return _categoryNavigationRepository.Table.Any(c => c.CategoryId == categoryId);
        }

        public virtual void DeleteCategoryById(int Id)
        {
            if (Id > 0)
            {
                var category = _categoryNavigationRepository.Table.FirstOrDefault(d => d.Id == Id);
                _categoryNavigationRepository.Delete(category);

                //event notification
                _eventPublisher.EntityDeleted(category);
            }
        }
    }
}
