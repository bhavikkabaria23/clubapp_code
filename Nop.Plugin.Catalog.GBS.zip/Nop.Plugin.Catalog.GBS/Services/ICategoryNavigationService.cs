﻿using Nop.Plugin.Catalog.GBS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Catalog.GBS.Services
{
    public interface ICategoryNavigationService
    {
        void ManageCategory(List<CategoryNavigationData> categories);

        IEnumerable<CategoryNavigationData> GetAllCategories();

        bool IsExist(int categoryId);
        void DeleteCategoryById(int Id);
    }
}
