﻿using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure.Mapper;
using Nop.Plugin.Catalog.GBS.Models;

namespace Nop.Plugin.Catalog.GBS.Extensions
{
    public static class MappingExtensions
    {
        public static TDestination MapTo<TSource, TDestination>(this TSource source)
        {
            return AutoMapperConfiguration.Mapper.Map<TSource, TDestination>(source);
        }

        public static TDestination MapTo<TSource, TDestination>(this TSource source, TDestination destination)
        {
            return AutoMapperConfiguration.Mapper.Map(source, destination);
        }
        
        #region Category

        public static CategoryModel ToModel(this Category entity)
        {
            return entity.MapTo<Category, CategoryModel>();
        }

        //public static Category ToEntity(this CategoryModel model)
        //{
        //    return model.MapTo<CategoryModel, Category>();
        //}

        //public static Category ToEntity(this CategoryModel model, Category destination)
        //{
        //    return model.MapTo(destination);
        //}

        #endregion       

    }
}