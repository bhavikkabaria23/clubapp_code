$('.phone').mask('(000) 000-0000');
$('.percent').mask('##0 . 00%', {reverse: true});
$('.money').mask('$ 00,000,000,000,000,000 ');
$('.ssn').mask('000-00-0000');

// Signature------------------
$('.clearsign').click(function () {
    $('.signBox').signature('clear');
    $(this).siblings('input[type=text]').val('');
});

//$('.signBox').signature();
$('.signBox').signature({
    color: '#000000',    
    change: function (event, ui) {
        var cnt = $(this).data('signcount');        
        $('#hdnSignJSON' + cnt).val($(this).signature('toDataURL','images/png'));        
    }
});
//------------------------

$("#mailingaddresssameno").click(function(){
        $("#mailingaddresssameDiv").slideDown();
    });
     $("#mailingaddresssameyes").click(function(){
        $("#mailingaddresssameDiv").slideUp();
    });


    $("#PaymentCardsyes").click(function(){
        $("#cacceptingcard").slideDown();
    });
     $("#PaymentCardsno").click(function(){
        $("#cacceptingcard").slideUp();
    });

   
    $("#merchantPaymentCardsyes").click(function(){
        $("#macceptingcard").slideDown();
    });
     $("#merchantPaymentCardsno").click(function(){
        $("#macceptingcard").slideUp();
    });


     $("#Breachyes").click(function(){
        $("#securitybreach").slideDown();
    });
     $("#Breachno").click(function(){
        $("#securitybreach").slideUp();
    });

$("#LLC").click(function(){
    $("#llcstate").toggle();
});

$("#BusinessOther").click(function(){
    $("#NatureofBusiness").toggle();
});

$("#CardSwipes").click(function(){
    $("#cardswipe").toggle();
});

$("#KeyEntered").click(function(){
    $("#keyentered").toggle();
});

$("#Motos").click(function(){
    $("#moto").toggle();
});

$("#Internets").click(function(){
    $("#internet").toggle();
});

$("#URL").click(function(){
    $("#url").toggle();
});


$("#MailPercent").click(function(){
    $("#mailpercent").toggle();
});
$("#InternetPercent").click(function(){
    $("#internetpercent").toggle();
});
$("#TelephonePercent").click(function(){
    $("#telephonepercent").toggle();
});
$("#CardPresent").click(function(){
    $("#cardpresent").toggle();
});

$("#MailfaxPercent").click(function(){
    $("#mailpercentdiv").toggle();
});
$("#InternetPercentorders").click(function(){
    $("#internetpercentdiv").toggle();
});
$("#TelephonePercentorders").click(function(){
    $("#telephonepercentdiv").toggle();
});
$("#OtherPercentorders").click(function(){
    $("#otherpercentdiv").toggle();
});



    $("#merchantServicersyes").click(function(){
        $("#merchantServicerdiv").slideDown();
    });
     $("#merchantServicersno").click(function(){
        $("#merchantServicerdiv").slideUp();
    });

   
    $("#FulfillServicersyes").click(function(){
        $("#FulfillServicerdiv").slideDown();
    });
     $("#FulfillServicersno").click(function(){
        $("#FulfillServicerdiv").slideUp();
    });


     $("#personalServicersyes").click(function(){
        $("#personalServicerdiv").slideDown();
    });
     $("#personalServicersno").click(function(){
        $("#personalServicerdiv").slideUp();
    });

     $("#productstoreyes").click(function(){
        $("#productstorediv").slideUp();
    });
     $("#productstoreno").click(function(){
        $("#productstorediv").slideDown();
        
    });

     $("#retailLocationyes").click(function(){
         $("#retailLocationdiv").slideDown();
    });
     $("#retailLocationno").click(function(){
         $("#retailLocationdiv").slideUp();      
    });

      $("#othercompanyyes").click(function(){
        $("#othercompanydiv").slideDown();
    });
     $("#othercompanyno").click(function(){
        $("#othercompanydiv").slideUp();     
    });

     $("#seasonalmerchantyes").click(function(){
        $("#seasonalmerchantdiv").slideDown();
    });
     $("#seasonalmerchantno").click(function(){
        $("#seasonalmerchantdiv").slideUp();
    });

     $("#LLC").click(function(){
        $("#llcstate").slideDown();
    });
     $("#IndividualSole").click(function(){
        $("#llcstate").slideUp();
    });
     $("#Partnership").click(function(){
        $("#llcstate").slideUp();
    });
     $("#Corporation").click(function(){
        $("#llcstate").slideUp();
    });
     $("#NonProfit").click(function(){
        $("#llcstate").slideUp();
    });
      $("#Goverment").click(function(){
        $("#llcstate").slideUp();
    });
       $("#Private").click(function(){
        $("#llcstate").slideUp();
    });
        $("Publiclyt").click(function(){
        $("#llcstate").slideUp();
    });

        $("#LLC").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#IndividualSole").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#Partnership").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#Corporation").click(function(){
        $("#nonprofitdiv").slideUp();
    });
     $("#NonProfit").click(function(){
        $("#nonprofitdiv").slideDown();
    });
      $("#Goverment").click(function(){
        $("#nonprofitdiv").slideUp();
    });
       $("#Private").click(function(){
        $("#nonprofitdiv").slideUp();
    });
        $("#Publiclyt").click(function(){
        $("#nonprofitdiv").slideUp();
    });



$("#FederalTax").click(function(){
    $("#ssnid").slideUp();
    $("#fedid").slideDown();
});

$("#SSNID").click(function(){
    $("#ssnid").slideDown();
    $("#fedid").slideUp(); 
 });



 $("#Terminal").click(function(){
        $("#ifterminaldiv").slideDown();
        $("#ifsoftwarediv").slideUp();

    });
 $("#Software").click(function(){
        $("#ifterminaldiv").slideUp();
        $("#ifsoftwarediv").slideDown();

    });

 $("#SeasonalSalesyes").click(function(){
        $("#SeasonalSalesDiv").slideDown();
    });
     $("#SeasonalSalesno").click(function(){
        $("#SeasonalSalesDiv").slideUp();     
    });


/* equipment page*/

    
  $("#OtherGateway").click(function(){
    $("#OtherGatewayDiv").toggle();
});

    $("#OtherEBT").click(function(){
    $("#OthermerchantDiv").toggle();
});
    
     $("#AutoBatch").click(function(){
    $("#AutoBatchDiv").toggle();
});

      $("#Batchother").click(function(){
    $("#Batchotherdiv").toggle();
});


/*mo/to2*/
   $("#otherprocessorder").click(function(){
    $("#processorderdiv").toggle();
});

$("#otherentercreditinfo").click(function(){
    $("#entercreditinfodiv").toggle();
});

$("#sslyes").click(function(){
        $("#sslDiv").slideDown();
    });
     $("#sslno").click(function(){
        $("#sslDiv").slideUp();     
    });

     $("#productstoredno").click(function(){
        $("#productstoreddiv").slideDown();
    });
     $("#productstoredyes").click(function(){
        $("#productstoreddiv").slideUp();     
    });

     $("#usmail").click(function(){
    $("#productshippeddiv").slideUp();
});

$("#productshippedother").click(function(){
    $("#productshippeddiv").slideDown();
 });

$("#MarkOther").click(function(){
    $("#MarketingMethodDiv").toggle();
});

/*rates & fees*/

 $("#ProcessingCost").click(function(){
        $("#ProcessingCostdiv").slideDown();
        $("#TieredProcessingdiv").slideUp();

    });
 $("#TieredProcessing").click(function(){
        $("#ProcessingCostdiv").slideUp();
        $("#TieredProcessingdiv").slideDown();

    });

 $("#AmericanExpressOptQualified").click(function(){
        $("#AmericanExpressOptQualifieddiv").slideDown();
        $("#AmericanExpressOptInterchangediv").slideUp();

    });
 $("#AmericanExpressOptInterchange").click(function(){
        $("#AmericanExpressOptQualifieddiv").slideUp();
        $("#AmericanExpressOptInterchangediv").slideDown();

    });

 $("#PINDebitFlatRate").click(function(){
        $("#PINDebitFlatRatediv").slideDown();
        $("#PINDebitInterchangediv").slideUp();

    });
 $("#PINDebitInterchange").click(function(){
        $("#PINDebitFlatRatediv").slideUp();
        $("#PINDebitInterchangediv").slideDown();

 });

$('input[type=radio]:checked,input[type=checkbox]:checked').each(function () {
    $(this).trigger("click");
    if ($(this).prop('type') == "checkbox") {
        $(this).prop('checked', true);
    }
 });

$("#btnMerchantSubmit").click(function (event) {
    if ($("#msform").valid()) {
        $(this).attr("disabled", "disabled").addClass("previous").css("cursor", "not-allowed");
        //stop submit the form, we will post it manually.
        event.preventDefault();
        // Get form
        var form = $('#msform')[0];
        // Create an FormData object
        var data = new FormData(form);
        var url = $('#msform').attr('action');
        $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: url,
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (response) {
                if (response) {
                    $("#divMerchant").html(response)
                }
            },
            error: function (e) {
                alert("Something went wrong to post the form");
            }
        });
    }
});