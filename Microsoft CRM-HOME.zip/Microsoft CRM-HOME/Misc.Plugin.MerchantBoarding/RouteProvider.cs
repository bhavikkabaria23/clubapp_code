﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Misc.Plugin.MerchantBoarding
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.RegisterPartner",
                "RegisterPartner",
                new { controller = "MerchantBoarding", action = "RegisterPartner" },
                new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
           );
            routes.MapRoute("Plugin.MerchantBoarding",
                 "MerchantBoarding",
                 new { controller = "MerchantBoarding", action = "Register" },
                 new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.merchanthtml",
               "merchanthtml",
               new { controller = "MerchantBoarding", action = "merchanthtml" },
               new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.MerchantInformation",
             "MerchantInformation",
             new { controller = "MerchantBoarding", action = "MerchantInformation" },
             new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.LegalInformation",
          "LegalInformation",
          new { controller = "MerchantBoarding", action = "LegalInformation" },
          new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
           );
            routes.MapRoute("Plugin.BusinessInformation",
          "BusinessInformation",
          new { controller = "MerchantBoarding", action = "BusinessInformation" },
          new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
         );
            //routes.MapRoute("Plugin.ContactUs.List",
            //     "Plugin/ContactUs/List",
            //     new { controller = "ContactUs", action = "ConfigureContactUs"},
            //     new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            //);
            //routes.MapRoute("Plugin.ContactUsFormDetail",
            //     "ContactUsFormDetail/{Id}",
            //     new { controller = "ContactUs", action = "ContactUsFormDetail",Id= UrlParameter.Optional },
            //     new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            //);
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
