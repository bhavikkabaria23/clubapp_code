﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doctor.Service.Interfaces
{
    public interface IDoctorService
    {
        // All methods of DoctorService interfaces will be at here
    }
}
