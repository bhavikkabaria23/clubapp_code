﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doctor.Service.Services
{
    public class DoctorService
    {
        // All functions related to database and manager will be here.
        // We should use LINQ for database operation.
    }
}
