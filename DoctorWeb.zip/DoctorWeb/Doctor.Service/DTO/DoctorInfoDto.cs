﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doctor.Service.DTO
{
    public class DoctorInfoDto
    {
        // All doctor properties will be here
    }
}
