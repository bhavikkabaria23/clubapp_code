﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doctor.Service.Helper
{
    public class Mapper
    {
        //Automapper methods will be here. We can use Automapper dll to map properties of DTO and Entities
    }
}
