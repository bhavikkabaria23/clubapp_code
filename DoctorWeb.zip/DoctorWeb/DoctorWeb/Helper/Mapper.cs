﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorWeb.Helper
{
    public class Mapper
    {
        //Automapper methods will be here. We can use Automapper dll to map properties of Model and DTO
    }
}
