﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoctorWeb.Controllers
{
    public class DoctorController : Controller
    {
        // This controller can manage Doctor views and data and will call all methods of "DoctorService.cs"
        // via interface "IDoctorService.cs"
        // GET: Doctor
        public ActionResult Index()
        {
            return View();
        }
    }
}