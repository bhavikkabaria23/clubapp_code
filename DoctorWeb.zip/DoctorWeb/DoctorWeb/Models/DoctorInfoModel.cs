﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoctorWeb.Models
{
    public class DoctorInfoModel
    {
        // this model will be use for map all necessary properties of "Doctor" to show in View.
        // With Validations
    }
}