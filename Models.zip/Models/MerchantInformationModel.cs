﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantUri { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
    }
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        public bool IsTerminated { get; set; }
        public string Explanation { get; set; }
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranch { get; set; }

        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; }
    }

    public class BusinessInformation2Model : BaseInformationModel
    {
        public bool IsSeasonalSales { get; set; }
        public string ProductsOrServices { get; set; }
        public bool IsTerminal { get; set; } // if true then "Terminal" else "Software"
        public string TerminalType { get; set; } // if "Terminal"
        public string PaymentApplicationName { get; set; } // if "Software"
        public string PaymentApplicationVersion { get; set; } // if "Software"
        public bool IsDBAName { get; set; } // if true then "DBA Name" else "Legal Name"
    }

    public class Questionnaire : BaseInformationModel
    {
        public decimal BusinessPercentage { get; set; }
        public decimal PublicPercentage { get; set; }
        public bool IsRetailLocation { get; set; }
        public string PhysicalAddress { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalZip { get; set; }
        public bool IsProductAddress { get; set; }
        public string ProductAddress { get; set; }
        public string ProductCity { get; set; }
        public string ProductZip { get; set; }
        public bool IsOwnProduct { get; set; }
        public string CardBrandProcessor { get; set; }
        public int ChargeBacks { get; set; }
        public decimal ChargeBackAmount { get; set; } // price in dollar
        public bool IsOrderCharged { get; set; } // if tru then "Time of Order" else "Upon Shipment"
        public int DeliverDays { get; set; } // 1 -> "1-7 days", 2 -> "8-14 Days" and 3 -> 14+ Days
        public bool IsOtherCompany { get; set; }
        public string CompanyName { get; set; }
        public string CompanyTelephone { get; set; }
        public string CompanyAddress { get; set; }
        public string RefundPolicy { get; set; }
    }

}
