﻿using MultiSite.Data;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Seo;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Web.Models.Topics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    /// <summary>
    /// This filter is used for all URLs / actions for store owner (except main store).
    /// It will not accessed any page without store registration
    /// </summary>
    public class GlobalFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // get sub domain name from url
            // get site owner from subdomain
            // then check "IsRegistered" true or false
            // if true then no action
            // if false then redirect to specific page.            
            if (!MultisiteHelper.IsAdminSite)
            {
                var subdomain = MultisiteHelper.SubDomain;
                if (!string.IsNullOrEmpty(subdomain))
                {
                    using (var dbContext = new Sites4Entities())
                    {
                        var site = dbContext.Sites.FirstOrDefault(s => s.StoreName.ToLower() == subdomain.ToLower());
                        if(site != null)
                        {
                            var owner = site.Owner;
                            if(owner != null)
                            {
                                if(!owner.IsRegistered)
                                {
                                    filterContext.Result = new RedirectResult("/store-registration/?accountid="+site.Id);
                                }
                            }
                        }
                    }
                }                
            }            
        }
    }
}