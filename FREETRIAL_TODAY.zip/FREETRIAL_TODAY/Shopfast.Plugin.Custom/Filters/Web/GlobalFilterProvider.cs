﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class GlobalFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {

            return new[]
                {
                        new Filter(new GlobalFilterAttribute(), FilterScope.Action, null)
                    };
        }
    }
}