﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.MerchantAdmin
{
    public class CRMModel
    {
        public CRMModel()
        {
            ControlFieldList = new List<ControlField>();
            ControlOptionList = new List<ControlOption>();
            DropdownItemsList = new List<DropdownItems>();

            #region Control Options
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 1, ControlFieldId = 4, Label = "Creator/manufacturer" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 2, ControlFieldId = 4, Label = "Retailer" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 3, ControlFieldId = 4, Label = "Dropshipper" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 4, ControlFieldId = 5, Label = "Startup (less than 1 year)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 5, ControlFieldId = 5, Label = "Growth (1-5 years)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 6, ControlFieldId = 5, Label = "Maturity (5+ years)" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 7, ControlFieldId = 6, Label = "Once in a while" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 8, ControlFieldId = 6, Label = "Part-time" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 9, ControlFieldId = 6, Label = "Full-time" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 10, ControlFieldId = 6, Label = "24/7" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 11, ControlFieldId = 7, Label = "Female" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 12, ControlFieldId = 7, Label = "Male" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 13, ControlFieldId = 7, Label = "Other" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 14, ControlFieldId = 7, Label = "I'm not sure" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 15, ControlFieldId = 8, Label = "Under 17 years" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 16, ControlFieldId = 8, Label = "18-29 years" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 17, ControlFieldId = 8, Label = "30-44 years" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 18, ControlFieldId = 8, Label = "45-64 years" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 18, ControlFieldId = 8, Label = "65 and up" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 18, ControlFieldId = 8, Label = "I'm not sure" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 16, ControlFieldId = 9, Label = "Locally" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 17, ControlFieldId = 9, Label = "Regionally" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 18, ControlFieldId = 9, Label = "Nationally" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 19, ControlFieldId = 9, Label = "Internationally" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 20, ControlFieldId = 9, Label = "I'm not sure" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 21, ControlFieldId = 10, Label = "Price (spending as little as possible)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 22, ControlFieldId = 10, Label = "Timing (getting it done as soon as possible)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 23, ControlFieldId = 10, Label = "Quality (getting the best possible result)" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 24, ControlFieldId = 32, Label = "Remove background and make it white or transparent" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 25, ControlFieldId = 32, Label = "Resize images to square" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 26, ControlFieldId = 32, Label = "Add natural shadows" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 27, ControlFieldId = 32, Label = "Brighten the images" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 28, ControlFieldId = 32, Label = "Retouching: remove logo / remove reflection / remove imperfections" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 29, ControlFieldId = 32, Label = "Make all images the same size" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 30, ControlFieldId = 32, Label = "Make all product images consistent" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 31, ControlFieldId = 32, Label = "Add white space" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 32, ControlFieldId = 32, Label = "Other photo enhancements" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 33, ControlFieldId = 41, Label = "On my online store" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 34, ControlFieldId = 41, Label = "Social media" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 35, ControlFieldId = 41, Label = "Ads" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 36, ControlFieldId = 41, Label = "Other" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 37, ControlFieldId = 42, Label = "Custom graphics" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 38, ControlFieldId = 42, Label = "Illustrations" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 39, ControlFieldId = 42, Label = "Banners" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 40, ControlFieldId = 42, Label = "Videos" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 41, ControlFieldId = 42, Label = "Infographics" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 42, ControlFieldId = 42, Label = "Other" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 43, ControlFieldId = 43, Label = "6-10" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 44, ControlFieldId = 43, Label = "1-5" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 45, ControlFieldId = 43, Label = "11+" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 46, ControlFieldId = 43, Label = "I don't know" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 47, ControlFieldId = 44, Label = "Configure settings (shipping, payments)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 48, ControlFieldId = 44, Label = "Add or edit pages" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 49, ControlFieldId = 44, Label = "Install theme" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 50, ControlFieldId = 44, Label = "Choose and install apps" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 51, ControlFieldId = 44, Label = "Upload products" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 52, ControlFieldId = 44, Label = "Take photos of your products" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 53, ControlFieldId = 44, Label = "Set up custom domain" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 54, ControlFieldId = 44, Label = "Add sales channels (e.g. Facebook-Amazon etc.)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 55, ControlFieldId = 44, Label = "All of the above" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 56, ControlFieldId = 45, Label = "Visuals" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 57, ControlFieldId = 45, Label = "Structure" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 58, ControlFieldId = 45, Label = "Copywriting" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 59, ControlFieldId = 45, Label = "Product photography" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 60, ControlFieldId = 45, Label = "Ongoing work" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 61, ControlFieldId = 45, Label = "Other" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 63, ControlFieldId = 47, Label = "Navigation" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 64, ControlFieldId = 47, Label = "Pages" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 65, ControlFieldId = 47, Label = "Slideshow/carousel" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 66, ControlFieldId = 47, Label = "Settings" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 67, ControlFieldId = 47, Label = "Apps" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 68, ControlFieldId = 47, Label = "Sales channels" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 69, ControlFieldId = 47, Label = "Other" });

            ControlOptionList.Add(new ControlOption() { ControlOptionId = 70, ControlFieldId = 49, Label = "Product descriptions" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 71, ControlFieldId = 49, Label = "Category descriptions" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 72, ControlFieldId = 49, Label = "Brand descriptions" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 73, ControlFieldId = 49, Label = "Metadata (for SEO)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 74, ControlFieldId = 49, Label = "Title tags (for SEO)" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 75, ControlFieldId = 49, Label = "Buying guides" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 76, ControlFieldId = 49, Label = "Blog posts" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 77, ControlFieldId = 49, Label = "Website content" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 78, ControlFieldId = 49, Label = "Facebook posts" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 79, ControlFieldId = 49, Label = "Tweets" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 80, ControlFieldId = 49, Label = "Press releases" });
            ControlOptionList.Add(new ControlOption() { ControlOptionId = 81, ControlFieldId = 49, Label = "Make edits to existing copy" });            
            #endregion

            #region DropdownItems
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 1, ControlFieldId = 3, Text = "Adult", Value = "Adult" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 2, ControlFieldId = 3, Text = "Art and photography", Value = "Art and photography" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 3, ControlFieldId = 3, Text = "Automotive", Value = "Automotive" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 4, ControlFieldId = 3, Text = "Books and magazines", Value = "Books and magazines" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 5, ControlFieldId = 3, Text = "Construction and industrial", Value = "Construction and industrial" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 6, ControlFieldId = 3, Text = "Electronics and gadgets", Value = "Electronics and gadgets" });

            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 7, ControlFieldId = 46, Text = "Amazon", Value = "Amazon" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 8, ControlFieldId = 46, Text = "Big Cartel", Value = "Big Cartel" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 9, ControlFieldId = 46, Text = "BigCommerce", Value = "BigCommerce" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 10, ControlFieldId = 46, Text = "eBay", Value = "eBay" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 11, ControlFieldId = 46, Text = "Etsy", Value = "Etsy" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 12, ControlFieldId = 46, Text = "IndieGogo", Value = "IndieGogo" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 13, ControlFieldId = 46, Text = "Magento", Value = "Magento" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 14, ControlFieldId = 46, Text = "OpenCart", Value = "OpenCart" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 15, ControlFieldId = 46, Text = "Squarespace", Value = "Squarespace" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 16, ControlFieldId = 46, Text = "Volusion", Value = "Volusion" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 17, ControlFieldId = 46, Text = "Wix", Value = "Wix" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 18, ControlFieldId = 46, Text = "Wordpress", Value = "Wordpress" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 19, ControlFieldId = 46, Text = "WooCommerce", Value = "WooCommerce" });
            DropdownItemsList.Add(new DropdownItems() { DropdownItemsId = 20, ControlFieldId = 46, Text = "Other", Value = "Other" });
            #endregion

            #region Control fields - Brand and visual content
            #region Develop a brand strategy - Group -1
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 1,
                Group = 1,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = true,
                Label = "Examples of businesses that inspire you.",
                CRMField = "cf_1100",
                PlaceHolder = "e.g. www.apple.com"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 2,
                Group = 1,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "What have you already tried?",
                CRMField = "cf_1102"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 3,
                Group = 1,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 4,
                Group = 1,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 1,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 6,
                Group = 1,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 7,
                Group = 1,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What gender is your typical customer?",
                CRMField = "cf_1112",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 7).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 8,
                Group = 1,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "How old is your typical customer?",
                CRMField = "cf_1118",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 8).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 9,
                Group = 1,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Where are you targeting your customers?",
                CRMField = "cf_1120",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 9).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 1,
                Step = 4,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 1,
                Step = 4,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });
            #endregion
            #region Design a look and feel for your store - Group 2
            // call Develop a brand strategy - Group -1
            #endregion
            #region Professional photo editing - Group 3
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 31,
                Group = 3,
                Step = 1,
                Type = ControlType.Textbox,
                IsRequired = true,
                Label = "Link to your photos (e.g. Dropbox or Google Drive).",
                CRMField = "cf_1126",
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 32,
                Group = 3,
                Step = 1,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What type of photo editing do you want done? Select all that apply.",
                CRMField = "cf_1128",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 32).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 33,
                Group = 3,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = true,
                Label = "Describe the changes you would made to your photos.",
                CRMField = "cf_1130",
            });
            #endregion
            #region Create visual content - Group 4
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 41,
                Group = 4,
                Step = 1,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How will you use the content?",
                CRMField = "cf_1132",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 41).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 42,
                Group = 4,
                Step = 1,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What type of content are you interested in?",
                CRMField = "cf_1134",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 42).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 43,
                Group = 4,
                Step = 1,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How many visuals do you need?",
                CRMField = "cf_1136",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 43).ToList()
            });
            ControlFieldList.Add(new ControlField // common
            {
                ControlFieldId = 3,
                Group = 4,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField // common
            {
                ControlFieldId = 4,
                Group = 4,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 4,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField //common
            {
                ControlFieldId = 6,
                Group = 4,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 4,
                Step = 3,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 4,
                Step = 3,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });
            #endregion
            #endregion

            #region Control fields - Setup and design
            #region Set up a basic store - Group 5
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 44,
                Group = 5,
                Step = 1,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Select areas where you need help setting up your store.",
                CRMField = "cf_1138",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 44).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 2,
                Group = 5,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "What have you already tried?",
                CRMField = "cf_1102"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 3,
                Group = 5,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 4,
                Group = 5,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 5,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 6,
                Group = 5,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 7,
                Group = 5,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What gender is your typical customer?",
                CRMField = "cf_1112",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 7).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 8,
                Group = 5,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "How old is your typical customer?",
                CRMField = "cf_1118",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 8).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 9,
                Group = 5,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Where are you targeting your customers?",
                CRMField = "cf_1120",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 9).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 5,
                Step = 4,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 5,
                Step = 4,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });
            #endregion
            #region Set up a custom-designed store - Group 6
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 45,
                Group = 6,
                Step = 1,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What do you want to include in the design and build of your online store?",
                CRMField = "cf_1140",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 45).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 2,
                Group = 6,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "What have you already tried?",
                CRMField = "cf_1102"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 3,
                Group = 6,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 4,
                Group = 6,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 6,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 6,
                Group = 6,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 7,
                Group = 6,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What gender is your typical customer?",
                CRMField = "cf_1112",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 7).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 8,
                Group = 6,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "How old is your typical customer?",
                CRMField = "cf_1118",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 8).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 9,
                Group = 6,
                Step = 3,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Where are you targeting your customers?",
                CRMField = "cf_1120",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 9).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 6,
                Step = 4,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 6,
                Step = 4,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });
            #endregion
            #region Migrate store from another platform - Group 7
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 46,
                Group = 7,
                Step = 1,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "Which platform are you migrating from?",
                CRMField = "cf_1142",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 46).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 2,
                Group = 7,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "What have you already tried?",
                CRMField = "cf_1102"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 3,
                Group = 7,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 4,
                Group = 7,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 7,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 6,
                Group = 7,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 7,
                Step = 3,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 7,
                Step = 3,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });

            #endregion
            #region Make store tweaks - Group 8
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 47,
                Group = 8,
                Step = 1,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "What pages/areas of your store need tweaking?",
                CRMField = "cf_1144",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 47).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 48,
                Group = 8,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Provide additional details about what you need tweaked.",
                CRMField = "cf_1146"
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 3,
                Group = 8,
                Step = 2,
                Type = ControlType.Dropdown,
                IsRequired = true,
                Label = "What products or services do you sell?",
                CRMField = "cf_1104",
                DropdownItemsList = DropdownItemsList.Where(d => d.ControlFieldId == 3).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 4,
                Group = 8,
                Step = 2,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Which of these best describes your business?",
                CRMField = "cf_1106",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 4).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 5,
                Group = 8,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How established is your business?",
                CRMField = "cf_1108",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 5).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 6,
                Group = 8,
                Step = 2,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "How much time do you spend working on your business?",
                CRMField = "cf_1116",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 6).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 10,
                Group = 8,
                Step = 3,
                Type = ControlType.Radio,
                IsRequired = true,
                Label = "What is your highest priority in completing this work?",
                CRMField = "cf_1122",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 10).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 11,
                Group = 8,
                Step = 3,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Anything else you want to share with the experts?",
                CRMField = "cf_1124"
            });
            #endregion
            #region Professional photo editing - Group 9
            // Call Professional photo editing - Group 3
            #endregion
            #region Professional content writing - Group 10
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 49,
                Group = 10,
                Step = 1,
                Type = ControlType.Checkbox,
                IsRequired = true,
                Label = "Select the areas where you need content written.",
                CRMField = "cf_1148",
                ControlOptionList = ControlOptionList.Where(o => o.ControlFieldId == 49).ToList()
            });
            ControlFieldList.Add(new ControlField
            {
                ControlFieldId = 50,
                Group = 10,
                Step = 1,
                Type = ControlType.Textarea,
                IsRequired = false,
                Label = "Give us some more details on the content you're looking for.",
                PlaceHolder = "I'm looking for 500 product descriptions, 50 - 60 words each + metadata on pet products",
                CRMField = "cf_1150"
            });
            #endregion
            #endregion


        }
        public List<ControlField> ControlFieldList { get; set; }
        public List<ControlOption> ControlOptionList { get; set; }
        public List<DropdownItems> DropdownItemsList { get; set; }
        public int CurrentGroup { get; set; }
        public int Steps { get; set; }

    }
    public class ControlField
    {
        public ControlField()
        {
            ControlOptionList = new List<ControlOption>();
            DropdownItemsList = new List<DropdownItems>();
        }
        public int ControlFieldId { get; set; }
        public ControlType Type { get; set; }
        public string FieldValue { get; set; }
        public string Label { get; set; }
        public int Group { get; set; } // The li section from which it is clicked
        public int Step { get; set; } // 1. Job 2. Business 3. Customers 4. Preferences 5. Confirmation
        public bool IsRequired { get; set; }
        public string CRMField { get; set; }
        public string PlaceHolder { get; set; }
        public List<ControlOption> ControlOptionList { get; set; }
        public List<DropdownItems> DropdownItemsList { get; set; }
    }

    // This class is used for Checkbox and Radio buttons
    public class ControlOption
    {
        public int ControlOptionId { get; set; }
        public int ControlFieldId { get; set; }
        public int TargetControlFieldId { get; set; } // this is used to show/hide that control        
        public string Label { get; set; }
        public bool OptionValue { get; set; }
    }

    // This class is used for drop down items
    public class DropdownItems
    {
        public int DropdownItemsId { get; set; }
        public int ControlFieldId { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public int TargetControlFieldId { get; set; } // this is used to show/hide that control
    }

    public class VtigerCrmResult
    {
        public string token { get; set; }
        public string sessionName { get; set; }
        public string userId { get; set; }
        public string id { get; set; }
    }

    public class VtigerCrmResponse
    {
        public bool success { get; set; }
        public VtigerCrmResult result { get; set; }
    }

    public class SummaryReport
    {
        public string question { get; set; }
        public string answer { get; set; }
    }

    public enum ControlType
    {
        Textbox = 1,
        Checkbox = 2,
        Radio = 3,
        Dropdown = 4,
        Textarea = 5
    }
}