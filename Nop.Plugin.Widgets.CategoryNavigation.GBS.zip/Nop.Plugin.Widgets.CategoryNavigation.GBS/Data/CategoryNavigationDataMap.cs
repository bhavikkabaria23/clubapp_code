using Nop.Data.Mapping;
using Nop.Plugin.Widgets.CategoryNavigation.GBS.Domain;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS.Data
{
    public partial class CategoryNavigationDataMap : NopEntityTypeConfiguration<CategoryNavigationData>
    {
        public CategoryNavigationDataMap()
        {
            this.ToTable("CategoryNavigationData");
            this.HasKey(tr => tr.Id);            
        }
    }
}