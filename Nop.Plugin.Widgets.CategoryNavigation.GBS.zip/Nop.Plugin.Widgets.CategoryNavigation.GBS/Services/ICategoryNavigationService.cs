﻿using Nop.Plugin.Widgets.CategoryNavigation.GBS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS.Services
{
    public interface ICategoryNavigationService
    {
        void ManageCategory(List<CategoryNavigationData> categories);

        IEnumerable<CategoryNavigationData> GetAllCategories();
    }
}
