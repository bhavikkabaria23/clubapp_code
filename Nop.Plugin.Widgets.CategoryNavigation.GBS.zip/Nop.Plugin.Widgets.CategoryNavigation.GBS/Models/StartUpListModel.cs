﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS.Models
{
    public class StartUpListModel : BaseNopModel
    {
        [NopResourceDisplayName("Startup.Fields.Email")]
        [AllowHtml]
        public string SearchEmail { get; set; }
        [NopResourceDisplayName("Startup.Fields.ContactName")]
        [AllowHtml]
        public string SearchContactName { get; set; }
        [NopResourceDisplayName("Startup.Fields.CompanyName")]
        [AllowHtml]
        public string SearchCompanyName { get; set; }

    }
}
