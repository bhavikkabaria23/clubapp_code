﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //IPN
            routes.MapRoute("Plugin.StartupForm",
                 "start-application",
                 new { controller = "Startup", action = "StartupForm" },
                 new[] { "Nop.Plugin.Widgets.CategoryNavigation.GBS.Controllers" }
            );
            routes.MapRoute("Plugin.Startup.List",
                 "Plugin/Startup/List",
                 new { controller = "Startup", action = "ConfigureStartUp" },
                 new[] { "Nop.Plugin.Widgets.CategoryNavigation.GBS.Controllers" }
                 );
            routes.MapRoute("Plugin.StartupFormDetail",
                 "StartupFormDetail/{Id}",
                 new { controller = "Startup", action = "StartupFormDetail",Id= UrlParameter.Optional },
                 new[] { "Nop.Plugin.Widgets.CategoryNavigation.GBS.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
