﻿using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Plugin.Widgets.CategoryNavigation.GBS.Data;
using Nop.Plugin.Widgets.CategoryNavigation.GBS.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Web.Framework.Mvc;
using Nop.Data;
using Nop.Core.Data;
using Autofac.Core;
using Nop.Plugin.Widgets.CategoryNavigation.GBS.Domain;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS
{
    /// <summary>
    /// Dependency registrar
    /// </summary>
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<CategoryNavigationService>().As<ICategoryNavigationService>().InstancePerDependency();

            //data context
            this.RegisterPluginDataContext<CategoryNavigationObjectContext>(builder, "plugin_object_context_categorynavigation");

            //override required repository with our custom context
            builder.RegisterType<EfRepository<CategoryNavigationData>>()
                .As<IRepository<CategoryNavigationData>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_categorynavigation"))
                .InstancePerLifetimeScope();            
        }

        /// <summary>
        /// Order of this dependency registrar implementation
        /// </summary>
        public int Order
        {
            get { return 2; }
        }
    }
}
