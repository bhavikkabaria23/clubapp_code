﻿using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Plugin.Widgets.CategoryNavigation.GBS.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;

namespace Nop.Plugin.Widgets.CategoryNavigation.GBS
{
    public class CategoryNavigationProvider : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly CategoryNavigationObjectContext _objectContext;

        public CategoryNavigationProvider(CategoryNavigationObjectContext objectContext)
        {
            this._objectContext = objectContext;
        }
        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "Startup";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.Widgets.CategoryNavigation.GBS.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>  
        public override void Install()
        {
            //database objects
            _objectContext.Install();

            // Add "Startup" customer role if not exist
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerBySystemName("Startup") == null)
            {
                CustomerRole role = new CustomerRole();
                role.Name = "Startup";
                role.SystemName = "Startup";
                role.Active = true;
                EngineContext.Current.Resolve<ICustomerService>().InsertCustomerRole(role);
            }
            //--------------------------------

            //locales
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyName", "Company Name");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.RequestingMoney", "How much money are you requesting?");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PreviousFunding", "Previous Funding");


            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyDesc", "What does your company do?");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.ContactName", "Contact Name");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Email", "Email Address");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Traction_Revenue_Partnerships", "If You Have Traction/Revenue/Partnerships, Please Explain:");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Phone", "Phone");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.DevelopmentStage", "Stage of Development");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PressLinks", "Press Links");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyUrl", "Company URL");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Market", "Market / Industry");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.FinancingRound", "Terms of Financing Round");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Facebook", "Facebook");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Twitter", "Twitter");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Review", "Is there anything else we should consider in our review?");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.GooglePlus", "Google+");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.LinkedIn", "Linked In");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.MicroVentures", "How did you hear about MicroVentures?");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Founder", "Founder(s)");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Incubator", "Incubator");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Investor", "Notable Investor(s)");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PitchDeckFile", "Upload Your Pitch Deck");
            this.AddOrUpdatePluginLocaleResource("Startup.Menu.Title.Startup", "Startup - looking to invest");          
  

            // Validation Messages
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyName.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.RequestingMoney.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PreviousFunding.Required", "Required");


            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyDesc.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.ContactName.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Email.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Traction_Revenue_Partnerships.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Phone.Required", "Required");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.DevelopmentStage.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PressLinks.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.CompanyUrl.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Market.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.FinancingRound.Required", "Required");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Facebook.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Twitter.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Review.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.GooglePlus.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.LinkedIn.Required", "Required");

            this.AddOrUpdatePluginLocaleResource("Startup.Fields.MicroVentures.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Founder.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Incubator.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.Investor.Required", "Required");
            this.AddOrUpdatePluginLocaleResource("Startup.Fields.PitchDeckFile.Required", "Required");            

            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //database objects
            _objectContext.Uninstall();

            //locales
            this.DeletePluginLocaleResource("Startup.Fields.CompanyName");
            this.DeletePluginLocaleResource("Startup.Fields.RequestingMoney");
            this.DeletePluginLocaleResource("Startup.Fields.PreviousFunding");


            this.DeletePluginLocaleResource("Startup.Fields.CompanyDesc");
            this.DeletePluginLocaleResource("Startup.Fields.ContactName");
            this.DeletePluginLocaleResource("Startup.Fields.Email");
            this.DeletePluginLocaleResource("Startup.Fields.Traction_Revenue_Partnerships");
            this.DeletePluginLocaleResource("Startup.Fields.Phone");

            this.DeletePluginLocaleResource("Startup.Fields.DevelopmentStage");
            this.DeletePluginLocaleResource("Startup.Fields.PressLinks");
            this.DeletePluginLocaleResource("Startup.Fields.CompanyUrl");
            this.DeletePluginLocaleResource("Startup.Fields.Market");
            this.DeletePluginLocaleResource("Startup.Fields.FinancingRound");

            this.DeletePluginLocaleResource("Startup.Fields.Facebook");
            this.DeletePluginLocaleResource("Startup.Fields.Twitter");
            this.DeletePluginLocaleResource("Startup.Fields.Review");
            this.DeletePluginLocaleResource("Startup.Fields.GooglePlus");
            this.DeletePluginLocaleResource("Startup.Fields.LinkedIn");

            this.DeletePluginLocaleResource("Startup.Fields.MicroVentures");
            this.DeletePluginLocaleResource("Startup.Fields.Founder");
            this.DeletePluginLocaleResource("Startup.Fields.Incubator");
            this.DeletePluginLocaleResource("Startup.Fields.Investor");
            this.DeletePluginLocaleResource("Startup.Fields.PitchDeckFile");

            // Validation Messages
            this.DeletePluginLocaleResource("Startup.Fields.CompanyName.Required");
            this.DeletePluginLocaleResource("Startup.Fields.RequestingMoney.Required");
            this.DeletePluginLocaleResource("Startup.Fields.PreviousFunding.Required");


            this.DeletePluginLocaleResource("Startup.Fields.CompanyDesc.Required");
            this.DeletePluginLocaleResource("Startup.Fields.ContactName.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Email.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Traction_Revenue_Partnerships.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Phone.Required");

            this.DeletePluginLocaleResource("Startup.Fields.DevelopmentStage.Required");
            this.DeletePluginLocaleResource("Startup.Fields.PressLinks.Required");
            this.DeletePluginLocaleResource("Startup.Fields.CompanyUrl.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Market.Required");
            this.DeletePluginLocaleResource("Startup.Fields.FinancingRound.Required");

            this.DeletePluginLocaleResource("Startup.Fields.Facebook.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Twitter.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Review.Required");
            this.DeletePluginLocaleResource("Startup.Fields.GooglePlus.Required");
            this.DeletePluginLocaleResource("Startup.Fields.LinkedIn.Required");

            this.DeletePluginLocaleResource("Startup.Fields.MicroVentures.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Founder.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Incubator.Required");
            this.DeletePluginLocaleResource("Startup.Fields.Investor.Required");
            this.DeletePluginLocaleResource("Startup.Fields.PitchDeckFile.Required");  

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "Startup",
                Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Startup.Menu.Title.Startup"),
                Url = "/Plugin/Startup/List",
                Visible = true,
                IconClass = "fa-dot-circle-o"
            };
            var firstNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Customers");
            if (firstNode != null)
            {
                firstNode.ChildNodes.Insert(2, menuItem);
            }
            else
            {
                rootNode.ChildNodes.Add(menuItem);
            }
        }
    }
}
