﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.IssuerDocForm.Models
{
    public class VtigerCrmResponse
    {
        public bool success { get; set; }
        public VtigerCrmResult result { get; set; }
        public string id { get; set; }
    }

    public class VtigerCrmResult
    {
        public string token { get; set; }
        public string sessionName { get; set; }
        public string userId { get; set; }
    }

    public class VtigerCrmLoginPost
    {
        public string operation { get; set; }
        public string username { get; set; }
        public string accessKey { get; set; }
    }

}
