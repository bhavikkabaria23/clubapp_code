﻿using System.Web.Mvc;
using FluentValidation.Attributes;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.IssuerDocForm.Validation;
using System;

namespace Shopfast.Plugin.IssuerDocForm.Models
{
    [Validator(typeof(ContactUsValidator))]
    public partial class ContactUsModel : BaseNopModel
    {
        [AllowHtml]
        [NopResourceDisplayName("ContactUs.Email")]
        public string Email { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("ContactUs.Subject")]
        public string Subject { get; set; }        

        [AllowHtml]
        [NopResourceDisplayName("ContactUs.Enquiry")]
        public string Enquiry { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("ContactUs.FullName")]
        public string FullName { get; set; }

        [NopResourceDisplayName("ContactUs.Phone")]
        public string Phone { get; set; }        

        [NopResourceDisplayName("ContactUs.Investor")]
        public bool Investor { get; set; }

        [NopResourceDisplayName("ContactUs.Startup")]
        public bool Startup { get; set; }        

        [NopResourceDisplayName("ContactUs.General")]
        public bool General { get; set; }
        [NopResourceDisplayName("ContactUs.CreatedDate")]
        public DateTime CreatedDate { get; set; }

        public bool SuccessfullySent { get; set; }
        public string Result { get; set; }
        //public bool DisplayCaptcha { get; set; }
    }
}