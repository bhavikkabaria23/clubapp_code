﻿using Shopfast.Plugin.IssuerDocForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.IssuerDocForm.Models
{
    public class IssuerDocFormModel
    {
        public IssuerDocFormModel()
        {
            Questions = new List<QuestionsModel>();
        }
        public IEnumerable<IDF_Sections> Sections { get; set; }
        //public IEnumerable<IDF_Questions> Questions { get; set; }
        //public IEnumerable<IDF_Controls> Controls { get; set; }
         public IEnumerable<IDF_ControlItems> ControlItems { get; set; }


        public List<QuestionsModel> Questions { get; set; }
    }

    public class QuestionsModel
    {
        public QuestionsModel()
        {
            Controls = new List<ControlsModel>();
        }
        public int QuestionId { get; set; }
        public int SectionId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsDeleted { get; set; }
        public List<ControlsModel> Controls { get; set; }
    }

    public class ControlsModel
    {      
        public int ControlId { get; set; }
        public int QuestinoId { get; set; }
        public int Type { get; set; } // 1,2,3,4,5,6 (Textbox,Textarea,Picklist,Checkbox, Radio, Upload) - based on Enum
        public bool IsRequired { get; set; }
        public string Value { get; set; } // answer
        public string CRMField { get; set; }
        public bool IsDeleted { get; set; }
        public IEnumerable<IDF_ControlItems> ControlItems { get; set; }
    }

    public class ControlItemsModel
    {
        public int ControlItemId { get; set; }
        public int ControlId { get; set; }
        public string Value { get; set; }
        public string Text { get; set; }
        public bool IsDeleted { get; set; }
    }

    public enum ControlType
    {
        Textbox = 1,
        Textarea = 2,
        Picklist = 3,
        Checkbox = 4,
        Radio = 5,
        Upload = 6
    }
}
