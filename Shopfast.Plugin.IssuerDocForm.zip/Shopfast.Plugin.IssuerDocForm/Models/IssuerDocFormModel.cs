﻿using Shopfast.Plugin.IssuerDocForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.IssuerDocForm.Models
{
    public class IssuerDocFormModel
    {
        public IssuerDocFormModel()
        {
            Questions = new List<QuestionsModel>();
            Sections = new List<IDF_Sections>();
        }
        public List<IDF_Sections> Sections { get; set; }
        //public IEnumerable<IDF_Questions> Questions { get; set; }
        //public IEnumerable<IDF_Controls> Controls { get; set; }
         public IEnumerable<IDF_ControlItems> ControlItems { get; set; }


        public List<QuestionsModel> Questions { get; set; }
    }

    public class QuestionsModel
    {
        public QuestionsModel()
        {
            ApplicableList = new List<SelectListItem>();
            ApplicableList.Add(new SelectListItem()
            {
                Value = "1",
                Text = "Applicable"
            });
            ApplicableList.Add(new SelectListItem()
            {
                Value = "2",
                Text = "Not Applicable"
            });
        }
        public int QuestionId { get; set; }
        public int SectionId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsDeleted { get; set; }
        public ControlsModel Control { get; set; }
                public string ApplicableValue { get; set; }
        public List<SelectListItem> ApplicableList { get; set; }
    }

    public class ControlsModel
    {
        public ControlsModel()
        {
            ControlItems = new List<IDF_ControlItems>();
        }
        public int ControlId { get; set; }
        public int QuestinoId { get; set; }
        public int Type { get; set; } // 1,2,3,4,5,6 (Textbox,Textarea,Picklist,Checkbox, Radio, Upload) - based on Enum
        public bool IsRequired { get; set; }
        public string Value { get; set; } // answer
        public HttpPostedFileBase[] file { get; set; } // answer
        public string CRMField { get; set; }
        public bool IsDeleted { get; set; }
        public List<IDF_ControlItems> ControlItems { get; set; }
    }

    public class ControlItemsModel
    {
        public int ControlItemId { get; set; }
        public int ControlId { get; set; }
        public bool Value { get; set; }
        public string Text { get; set; }
        public bool IsDeleted { get; set; }
    }

    public enum ControlType
    {
        Textbox = 1,
        Textarea = 2,
        Picklist = 3,
        Checkbox = 4,
        Radio = 5,
        Upload = 6
    }
}
