﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Shopfast.Plugin.IssuerDocForm.Models
{
    public class ContactUsListModel : BaseNopModel
    {
        [NopResourceDisplayName("ContactUs.Email")]
        [AllowHtml]
        public string SearchEmail { get; set; }
        [NopResourceDisplayName("ContactUs.FullName")]
        [AllowHtml]
        public string SearchFullName { get; set; }
        [NopResourceDisplayName("ContactUs.Phone")]
        [AllowHtml]
        public string SearchPhone { get; set; }
    }
}
