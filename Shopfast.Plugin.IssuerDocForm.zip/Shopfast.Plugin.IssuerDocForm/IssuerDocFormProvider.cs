﻿using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Customers;
using Shopfast.Plugin.IssuerDocForm.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;

namespace Shopfast.Plugin.IssuerDocForm
{
    public class IssuerDocFormProvider : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly IssuerDocFormObjectContext _objectContext;

        public IssuerDocFormProvider(IssuerDocFormObjectContext objectContext)
        {
            this._objectContext = objectContext;
        }
        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "IssuerDocForm";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.IssuerDocForm.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>  
        public override void Install()
        {
            //database objects
            _objectContext.Install();

            //locales
            //this.AddOrUpdatePluginLocaleResource("", "");         


            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //database objects
            _objectContext.Uninstall();

            //locales
            //this.DeletePluginLocaleResource("");          

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            //var menuItem = new SiteMapNode()
            //{
            //    SystemName = "IssuerDocForm",
            //    Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource(""),
            //    Url = "/Plugin/ContactUs/List",
            //    Visible = true,
            //    IconClass = "fa-dot-circle-o"
            //};
            //var firstNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Customers");
            //if (firstNode != null)
            //{
            //    firstNode.ChildNodes.Insert(1, menuItem);
            //}
            //else
            //{
            //    rootNode.ChildNodes.Add(menuItem);
            //}
        }
    }
}
