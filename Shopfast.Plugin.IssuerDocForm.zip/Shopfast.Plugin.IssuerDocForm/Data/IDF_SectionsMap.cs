using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_SectionsMap : NopEntityTypeConfiguration<IDF_Sections>
    {
        public IDF_SectionsMap()
        {
            this.ToTable("IDF_Sections");
            this.HasKey(tr => tr.Id);            
        }
    }
}