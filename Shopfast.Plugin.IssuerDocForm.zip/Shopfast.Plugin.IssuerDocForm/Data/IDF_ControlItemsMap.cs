using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_ControlItemsMap : NopEntityTypeConfiguration<IDF_ControlItems>
    {
        public IDF_ControlItemsMap()
        {
            this.ToTable("IDF_ControlItems");
            this.HasKey(tr => tr.Id);            
        }
    }
}