using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_QuestionsMap : NopEntityTypeConfiguration<IDF_Questions>
    {
        public IDF_QuestionsMap()
        {
            this.ToTable("IDF_Questions");
            this.HasKey(tr => tr.Id);            
        }
    }
}