using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_CRMCustomerMap : NopEntityTypeConfiguration<IDF_CRMCustomer>
    {
        public IDF_CRMCustomerMap()
        {
            this.ToTable("IDF_CRMCustomer");
            this.HasKey(tr => tr.Id);            
        }
    }
}