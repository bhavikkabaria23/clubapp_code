using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_ControlsMap : NopEntityTypeConfiguration<IDF_Controls>
    {
        public IDF_ControlsMap()
        {
            this.ToTable("IDF_Controls");
            this.HasKey(tr => tr.Id);            
        }
    }
}