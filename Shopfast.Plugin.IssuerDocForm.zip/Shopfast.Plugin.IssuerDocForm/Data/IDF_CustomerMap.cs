using Nop.Data.Mapping;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class IDF_CustomerMap : NopEntityTypeConfiguration<IDF_Customer>
    {
        public IDF_CustomerMap()
        {
            this.ToTable("IDF_Customer");
            this.HasKey(tr => tr.Id);            
        }
    }
}