﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.IssuerDocForm.Domain
{
    public class IDF_CRMCustomer : BaseEntity
    {
        public int CustomerId { get; set; }        
        public string CRMId { get; set; }        
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
