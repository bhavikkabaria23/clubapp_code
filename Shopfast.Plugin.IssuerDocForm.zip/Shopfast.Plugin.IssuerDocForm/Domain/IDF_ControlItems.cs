﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.IssuerDocForm.Domain
{
    public class IDF_ControlItems : BaseEntity
    {
        public int ControlId { get; set; }
        public bool Value { get; set; }
        public string Text { get; set; }        
        public bool IsDeleted { get; set; }        
    }
}
