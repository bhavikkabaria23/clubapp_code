﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.IssuerDocForm.Models;
using System;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Common;
using System.Linq;
using System.Web;
using System.IO;
using Shopfast.Plugin.IssuerDocForm.Services;
using Shopfast.Plugin.IssuerDocForm.Domain;
using Nop.Web.Framework.Kendoui;
using Nop.Services.Security;
using System.Collections.Generic;
using Nop.Services.Catalog;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Configuration;
using System.Net;
using System.Collections.Specialized;
using System.Text;
using Newtonsoft.Json;
using System.Json;
using System.Security.Cryptography;
using Nop.Web.Framework.Security;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Framework;
using Nop.Core.Domain.Messages;
using Nop.Services.Messages;
using Nop.Services.Logging;
using Nop.Web.Framework.Mvc;
using Newtonsoft.Json.Linq;

namespace Shopfast.Plugin.IssuerDocForm.Controllers
{
    public class IssuerDocFormController : BaseController
    {
        private readonly ICustomerService _customerService;
        private readonly CustomerSettings _customerSettings;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IIssuerDocFormService _issuerDocFormService;
        private readonly IPermissionService _permissionService;
        private readonly IPriceFormatter _priceFormatter;

        private readonly CaptchaSettings _captchaSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreContext _storeContext;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly IWorkContext _workContext;


        public IssuerDocFormController(ICustomerService customerService,
            CustomerSettings customerSettings,
            IGenericAttributeService genericAttributeService,
            ICustomerRegistrationService customerRegistrationService,
            IIssuerDocFormService issuerDocFormService,
            IPermissionService permissionService,
            IPriceFormatter priceFormatter,
            IStoreContext storeContext,
            IQueuedEmailService queuedEmailService,
            IEmailAccountService emailAccountService,
            ICustomerActivityService customerActivityService,
            ILocalizationService localizationService,
            CaptchaSettings captchaSettings,
            EmailAccountSettings emailAccountSettings,
            IWorkContext workContext)
        {
            this._customerService = customerService;
            this._customerSettings = customerSettings;
            this._genericAttributeService = genericAttributeService;
            this._customerRegistrationService = customerRegistrationService;
            this._issuerDocFormService = issuerDocFormService;
            this._permissionService = permissionService;
            this._priceFormatter = priceFormatter;

            this._storeContext = storeContext;
            this._queuedEmailService = queuedEmailService;
            this._emailAccountService = emailAccountService;
            this._localizationService = localizationService;
            this._customerActivityService = customerActivityService;
            this._captchaSettings = captchaSettings;
            this._emailAccountSettings = emailAccountSettings;
            this._workContext = workContext;

        }

        //public ActionResult ConfigureContactUs()
        //{
        //    if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
        //        return Content("Access denied");
        //    return View("~/Plugins/CrowdPay.ContactUs/Views/ContactUs/Configure.cshtml");
        //}

        //[HttpPost]
        //public ActionResult Configure(DataSourceRequest command, ContactUsListModel searchModel)
        //{            
        //    var contactUsModels = _contactUsService.GetContactUsForms().OrderByDescending(c => c.CreatedDate).ToList();

        //    if (!string.IsNullOrEmpty(searchModel.SearchEmail))
        //    {
        //        contactUsModels = contactUsModels.Where(p => p.Email.ToLower().Contains(searchModel.SearchEmail.ToLower())).ToList();
        //    }
        //    if (!string.IsNullOrEmpty(searchModel.SearchFullName))
        //    {
        //        contactUsModels = contactUsModels.Where(p => p.FullName.ToLower().Contains(searchModel.SearchFullName.ToLower())).ToList();
        //    }
        //    if (!string.IsNullOrEmpty(searchModel.SearchPhone))
        //    {
        //        contactUsModels = contactUsModels.Where(p => p.Phone.ToLower().Contains(searchModel.SearchPhone.ToLower())).ToList();
        //    }

        //    var gridModel = new DataSourceResult
        //    {
        //        Data = contactUsModels,
        //        Total = contactUsModels.Count()
        //    };
        //    return Json(gridModel);
        //}

        //public ActionResult ContactUsFormDetail(int Id)
        //{
        //    if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
        //        return Content("Access denied");

        //    var contactUs = _contactUsService.GetContactUsFormById(Id);
        //    ContactUsModel model = new ContactUsModel();
        //    model.FullName = contactUs.FullName;
        //    model.Subject = contactUs.Subject;
        //    model.Enquiry = contactUs.Enquiry;
        //    model.Email = contactUs.Email;            
        //    model.Phone = contactUs.Phone;
        //    model.CreatedDate = contactUs.CreatedDate;

        //    model.Investor = contactUs.Investor;
        //    model.Startup = contactUs.Startup;
        //    model.General = contactUs.General;            

        //    return View("~/Plugins/CrowdPay.ContactUs/Views/ContactUs/ContactUsFormDetail.cshtml", model);
        //}

        private ControlsModel ConvertToControlModel(IDF_Controls con, IssuerDocFormModel model, IEnumerable<IDF_Customer> customerQuestions)
        {
            ControlsModel _control = new ControlsModel();
            var answer = customerQuestions.FirstOrDefault(c => c.QuestionId == con.QuestinoId)?.Answer;
            _control.ControlId = con.Id;
            _control.QuestinoId = con.QuestinoId;
            _control.Type = con.Type;
            _control.IsRequired = con.IsRequired;
            _control.Value = answer;
            _control.CRMField = con.CRMField;
            _control.ControlItems = model.ControlItems.Where(ci => ci.ControlId == con.Id).ToList();
            if (con.Type == Convert.ToInt32(ControlType.Upload))
            {
                if (!string.IsNullOrEmpty(_control.Value))
                    _control.FilePaths = _control.Value.Split('|').ToList();
            }
            if (con.Type == Convert.ToInt32(ControlType.Checkbox))
            {
                _control.ControlItems.ToList()
                    .ForEach(ci =>
                    {
                        if (answer.Contains(ci.Id.ToString()))
                        {
                            ci.Value = true;
                        }
                    });
            }

            return _control;
        }
        private string CalculateMD5Hash(string input)
        {
            // step 1, calculate MD5 hash from input
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString().ToLower();
        }
        private void PostToCRM(List<IDF_Customer> customers, IEnumerable<IDF_Controls> Controls)
        {
            string VtigerCrmApiUrl = "http://crm.shopfast.com/webservice.php";
            string CrmUsername = "bhavik";
            string accessKey = "OegHQRq5X1gPoqHs";
            JObject element = new JObject();

            element.Add("email", _workContext.CurrentCustomer.Email);
            element.Add("crm_customerid", _workContext.CurrentCustomer.Id);
            foreach (var cust in customers)
            {
                var control = Controls.FirstOrDefault(c => c.QuestinoId == cust.QuestionId);
                if (control != null)
                {                    
                    switch ((ControlType)control.Type)
                    {
                        case ControlType.Textbox:
                        case ControlType.Textarea:
                        case ControlType.Picklist:
                        case ControlType.Radio:
                            element.Add(control.CRMField, cust.Answer);
                            break;
                        case ControlType.Checkbox:
                            element.Add(control.CRMField, cust.Answer.Replace("|", " |##| "));
                            break;
                        case ControlType.Upload:
                            element.Add(control.CRMField, cust.Answer);
                            break;
                        default:
                            element.Add(control.CRMField, cust.Answer);
                            break;
                    }
                }
            }

            if (!string.IsNullOrEmpty(VtigerCrmApiUrl) && !string.IsNullOrEmpty(CrmUsername) && !string.IsNullOrEmpty(accessKey))
            {
                // Get Token
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(VtigerCrmApiUrl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var tokenResponse = client.GetAsync("?operation=getchallenge&username=" + CrmUsername).Result;
                    if (tokenResponse.IsSuccessStatusCode)
                    {
                        var tokenResult = tokenResponse.Content.ReadAsAsync<VtigerCrmResponse>().Result;
                        if (tokenResult.success)
                        {
                            using (var webclient = new WebClient())
                            {
                                webclient.UseDefaultCredentials = true;
                                webclient.Headers.Add("Content-Type:application/x-www-form-urlencoded");
                                webclient.Headers.Add("Accept:application/json");
                                var uri = new Uri(VtigerCrmApiUrl);

                                NameValueCollection loginParams = new NameValueCollection();
                                loginParams.Add("operation", "login");
                                loginParams.Add("username", CrmUsername);
                                loginParams.Add("accessKey", CalculateMD5Hash(tokenResult.result.token + accessKey));
                                var response = webclient.UploadValues(uri, "POST", loginParams);
                                string jsonResponse = string.Empty;
                                jsonResponse = Encoding.ASCII.GetString(response);
                                var loginResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
                                if (loginResult.success)
                                {
                                    // Reference
                                    // https://www.vtiger.com/docs/web-service-reference-manual#/Delete

                                    // http://vtiger_url/webservice.php?operation=delete&sessionName=[session_id]&id=[object_id]

                                    //// Retrive entry for already creted entry with id 31x9                                
                                    //var getResponse = client.GetAsync("?operation=retrieve&sessionName=" + loginResult.result.sessionName + "&id=31x9").Result;
                                    //if (getResponse.IsSuccessStatusCode)
                                    //{
                                    //    var getResult = getResponse.Content.ReadAsStringAsync().Result;                                      
                                    //    JObject code = JObject.Parse(getResult);
                                    //    var innerResult = code["result"];
                                    //    innerResult["cf_1092"] = "shopfast test field";
                                    //    string result = code.ToString();

                                    //    // Create project update
                                    //    //NameValueCollection projParams = new NameValueCollection();
                                    //    //projParams.Add("operation", "update");
                                    //    //projParams.Add("sessionName", loginResult.result.sessionName);
                                    //    //projParams.Add("elementType", "Project");
                                    //    //projParams.Add("element", result);
                                    //    //var responseProj = webclient.UploadValues(uri, "POST", projParams); // Here Access denied error is coming
                                    //    //jsonResponse = Encoding.ASCII.GetString(responseProj);
                                    //    //var projResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
                                    //}                                                              
                                    element.Add("assigned_user_id", loginResult.result.userId);

                                    NameValueCollection projParams = new NameValueCollection();
                                    projParams.Add("operation", "create");
                                    projParams.Add("sessionName", loginResult.result.sessionName);
                                    projParams.Add("elementType", "Lead");
                                    projParams.Add("element", element.ToString());
                                    var responseProj = webclient.UploadValues(uri, "POST", projParams);
                                    jsonResponse = Encoding.ASCII.GetString(responseProj);
                                    var projResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
                                }
                            }
                        }
                    }
                }
            }
        }

        public ActionResult Index()
        {
            var model = new IssuerDocFormModel();
            model.Sections = _issuerDocFormService.GetSections().ToList();
            var Questions = _issuerDocFormService.GetQuestions().ToList();
            var Controls = _issuerDocFormService.GetControls().ToList();
            model.ControlItems = _issuerDocFormService.GetControlItemss().ToList();
            var customerQuestions = _issuerDocFormService.GetCustomerData(_workContext.CurrentCustomer.Id);

            foreach (var que in Questions)
            {
                model.Questions.Add(new QuestionsModel()
                {
                    QuestionId = que.Id,
                    SectionId = que.SectionId,
                    Name = que.Name,
                    Description = que.Description,
                    Control = ConvertToControlModel(Controls.FirstOrDefault(c => c.QuestinoId == que.Id), model, customerQuestions),
                    ApplicableValue = (customerQuestions.Any(c => c.QuestionId == que.Id)) ? "1" : "2"
                });
            }

            return View("~/Plugins/Shopfast.Plugin.IssuerDocForm/Views/IssuerDocForm/IssuerDocForm.cshtml", model);
        }

        [HttpPost]
        public ActionResult Index(IssuerDocFormModel model)
        {
            int customerId = _workContext.CurrentCustomer.Id;
            string customerEmail = (!string.IsNullOrEmpty(_workContext.CurrentCustomer.Email)) ? _workContext.CurrentCustomer.Email : _workContext.CurrentCustomer.Username;
            List<IDF_Customer> customerList = new List<IDF_Customer>();
            foreach (var que in model.Questions)
            {
                if (que.ApplicableValue == "1")
                {
                    IDF_Customer customer = new IDF_Customer();
                    customer.CustomerId = customerId;
                    customer.QuestionId = que.QuestionId;
                    customer.ControlId = que.Control.ControlId;
                    customer.SectionId = que.SectionId;
                    customer.CreatedDate = DateTime.UtcNow;
                    customer.ModifiedDate = DateTime.UtcNow;

                    switch ((ControlType)que.Control.Type)
                    {
                        case ControlType.Textbox:
                        case ControlType.Textarea:
                        case ControlType.Picklist:
                        case ControlType.Radio:
                            customer.Answer = que.Control.Value;
                            break;
                        case ControlType.Checkbox:
                            customer.Answer = string.Join(",", que.Control.ControlItems.Where(c => c.Value).Select(c => c.Id).ToArray());
                            break;
                        case ControlType.Upload:
                            if (que.Control.file != null && que.Control.file.Any())
                            {
                                List<string> answers = new List<string>();
                                foreach (var file in que.Control.file)
                                {
                                    if (file != null && file.ContentLength > 0)
                                    {
                                        string _FileName = Path.GetFileName(file.FileName);
                                        string folderPath = "/Content/IssuerDocForms/" + customerEmail + "/Question_" + que.QuestionId;
                                        string _path = Path.Combine(folderPath, _FileName);
                                        if (!Directory.Exists(_path))
                                        {
                                            Directory.CreateDirectory(Server.MapPath("~" + folderPath));
                                        }
                                        answers.Add(_path);
                                        file.SaveAs(Server.MapPath("~" + _path));
                                    }
                                }
                                if (answers.Any())
                                {
                                    customer.Answer = string.Join("|", answers);
                                }
                            }
                            break;
                        default:
                            break;
                    }

                    // save  customer form
                    if (!string.IsNullOrEmpty(customer.Answer))
                    {
                        customerList.Add(customer);
                    }
                    //------------
                }
            }
            if (customerList != null && customerList.Any())
            {
                _issuerDocFormService.AddUpdateIssuerForm(customerList, customerId);
            }
            return RedirectToAction("Index");
        }

        //[HttpPost]
        //public ActionResult IssuerDocForm(ContactUsModel model, bool captchaValid)
        //{
        //    //validate CAPTCHA
        //    if (!captchaValid)
        //    {
        //        ModelState.AddModelError("", _captchaSettings.GetWrongCaptchaMessage(_localizationService));
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        InsertContactUsFormData(model);

        //        VTigerCRMIntegration(model);                

        //        #region Email notification
        //        string email = model.Email.Trim();
        //        string fullName = model.FullName;
        //        string subject = !string.IsNullOrEmpty(model.Subject) ?
        //            model.Subject :
        //            string.Format(_localizationService.GetResource("ContactUs.EmailSubject"), _storeContext.CurrentStore.GetLocalized(x => x.Name));

        //        var emailAccount = _emailAccountService.GetEmailAccountById(_emailAccountSettings.DefaultEmailAccountId);
        //        if (emailAccount == null)
        //            emailAccount = _emailAccountService.GetAllEmailAccounts().FirstOrDefault();
        //        if (emailAccount == null)
        //            throw new Exception("No email account could be loaded");

        //        string from;
        //        string fromName;
        //        string body = Nop.Core.Html.HtmlHelper.FormatText(model.Enquiry, false, true, false, false, false, false);
        //        //required for some SMTP servers
        //        from = emailAccount.Email;
        //        fromName = emailAccount.DisplayName;
        //        body = string.Format("<strong>From</strong>: {0} - {1}<br /><br />{2}",
        //            Server.HtmlEncode(fullName),
        //            Server.HtmlEncode(email), body);

        //        _queuedEmailService.InsertQueuedEmail(new QueuedEmail
        //        {
        //            From = from,
        //            FromName = fromName,
        //            To = emailAccount.Email,
        //            ToName = emailAccount.DisplayName,
        //            ReplyTo = email,
        //            ReplyToName = fullName,
        //            Priority = QueuedEmailPriority.High,
        //            Subject = subject,
        //            Body = body,
        //            CreatedOnUtc = DateTime.UtcNow,
        //            EmailAccountId = emailAccount.Id
        //        });
        //        #endregion

        //        model.SuccessfullySent = true;
        //        model.Result = _localizationService.GetResource("ContactUs.YourEnquiryHasBeenSent");

        //        //activity log
        //        _customerActivityService.InsertActivity("PublicStore.ContactUs", _localizationService.GetResource("ActivityLog.PublicStore.ContactUs"));                
        //    }            
        //    return View("~/Plugins/CrowdPay.ContactUs/Views/ContactUs/ContactUsForm.cshtml", model);           
        //}

        //[HttpPost]
        //public ActionResult DeleteContact(int id = 0)
        //{
        //    _contactUsService.DeleteContactById(id);
        //    return new NullJsonResult();
        //}

        //private void InsertContactUsFormData(ContactUsModel model)
        //{
        //    if (model != null)
        //    {
        //        ContactUs_FormData formData = new ContactUs_FormData();
        //        formData.FullName = model.FullName;
        //        formData.Subject = model.Subject;
        //        formData.Enquiry = model.Enquiry;
        //        formData.Email = model.Email;                
        //        formData.Phone = model.Phone;
        //        formData.Investor = model.Investor;
        //        formData.Startup = model.Startup;
        //        formData.General = model.General;
        //        formData.CreatedDate = DateTime.UtcNow;
        //        _contactUsService.InsertContactUsForm(formData);
        //    }
        //}

        //private void VTigerCRMIntegration(ContactUsModel model)
        //{
        //    string VtigerCrmApiUrl = System.Configuration.ConfigurationManager.AppSettings["VtigerCrmApiUrl"];
        //    string CrmUsername = System.Configuration.ConfigurationManager.AppSettings["CrmUsername"];
        //    string accessKey = System.Configuration.ConfigurationManager.AppSettings["accessKey"];
        //    if (!string.IsNullOrEmpty(VtigerCrmApiUrl) && !string.IsNullOrEmpty(CrmUsername) && !string.IsNullOrEmpty(accessKey))
        //    {
        //        // Get Token
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(VtigerCrmApiUrl);
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //            var tokenResponse = client.GetAsync("?operation=getchallenge&username=" + CrmUsername).Result;
        //            if (tokenResponse.IsSuccessStatusCode)
        //            {
        //                var tokenResult = tokenResponse.Content.ReadAsAsync<VtigerCrmResponse>().Result;
        //                if (tokenResult.success)
        //                {
        //                    using (var webclient = new WebClient())
        //                    {
        //                        webclient.UseDefaultCredentials = true;
        //                        webclient.Headers.Add("Content-Type:application/x-www-form-urlencoded");
        //                        webclient.Headers.Add("Accept:application/json");
        //                        var uri = new Uri(VtigerCrmApiUrl);

        //                        NameValueCollection loginParams = new NameValueCollection();
        //                        loginParams.Add("operation", "login");
        //                        loginParams.Add("username", CrmUsername);
        //                        loginParams.Add("accessKey", CalculateMD5Hash(tokenResult.result.token + accessKey));
        //                        var response = webclient.UploadValues(uri, "POST", loginParams);
        //                        string jsonResponse = string.Empty;
        //                        jsonResponse = Encoding.ASCII.GetString(response);
        //                        var loginResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
        //                        if (loginResult.success)
        //                        {
        //                            // // Create Leads entry                                
        //                            var element = new JsonObject();                                    
        //                            element.Add("firstname", model.FullName.Split(' ')[0]);
        //                            element.Add("lastname", (model.FullName.Split(' ').Count() > 1) ? model.FullName.Split(' ')[1] : model.FullName);
        //                            element.Add("email", model.Email);                                    
        //                            element.Add("phone", model.Phone);
        //                            element.Add("title", model.Subject);
        //                            element.Add("description", model.Enquiry);
        //                            element.Add("notify_owner", true);    
        //                            element.Add("assigned_user_id", loginResult.result.userId);

        //                            NameValueCollection leadParams = new NameValueCollection();
        //                            leadParams.Add("operation", "create");
        //                            leadParams.Add("sessionName", loginResult.result.sessionName);
        //                            leadParams.Add("elementType", "Contacts");
        //                            leadParams.Add("element", element.ToString());
        //                            var responseLead = webclient.UploadValues(uri, "POST", leadParams);
        //                            jsonResponse = Encoding.ASCII.GetString(responseLead);
        //                            var leadResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        //private string CalculateMD5Hash(string input)
        //{
        //    // step 1, calculate MD5 hash from input
        //    MD5 md5 = System.Security.Cryptography.MD5.Create();
        //    byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
        //    byte[] hash = md5.ComputeHash(inputBytes);
        //    // step 2, convert byte array to hex string
        //    StringBuilder sb = new StringBuilder();
        //    for (int i = 0; i < hash.Length; i++)
        //    {
        //        sb.Append(hash[i].ToString("X2"));
        //    }
        //    return sb.ToString().ToLower();
        //}


    }
}