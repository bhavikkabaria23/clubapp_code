﻿using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Shopfast.Plugin.IssuerDocForm.Data;
using Shopfast.Plugin.IssuerDocForm.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Web.Framework.Mvc;
using Nop.Data;
using Nop.Core.Data;
using Autofac.Core;
using Shopfast.Plugin.IssuerDocForm.Domain;

namespace Shopfast.Plugin.IssuerDocForm
{
    /// <summary>
    /// Dependency registrar
    /// </summary>
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<IssuerDocFormService>().As<IIssuerDocFormService>().InstancePerDependency();

            //data context
            this.RegisterPluginDataContext<IssuerDocFormObjectContext>(builder, "plugin_object_context_issuerdocform");

            //override required repository with our custom context
            builder.RegisterType<EfRepository<IDF_Sections>>()
                .As<IRepository<IDF_Sections>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
                .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<IDF_Questions>>()
               .As<IRepository<IDF_Questions>>()
               .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
               .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<IDF_Controls>>()
               .As<IRepository<IDF_Controls>>()
               .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
               .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<IDF_ControlItems>>()
               .As<IRepository<IDF_ControlItems>>()
               .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
               .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<IDF_Customer>>()
               .As<IRepository<IDF_Customer>>()
               .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
               .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<IDF_CRMCustomer>>()
               .As<IRepository<IDF_CRMCustomer>>()
               .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_issuerdocform"))
               .InstancePerLifetimeScope();
        }

        /// <summary>
        /// Order of this dependency registrar implementation
        /// </summary>
        public int Order
        {
            get { return 2; }
        }
    }
}
