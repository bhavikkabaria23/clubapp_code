﻿using Nop.Core.Data;
using Nop.Services.Events;
using Shopfast.Plugin.IssuerDocForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.IssuerDocForm.Services
{
    public class ContactUsFormService : IContactUsFormService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<ContactUs_FormData> _contactUsRepository;
        #endregion

        public ContactUsFormService(IEventPublisher eventPublisher,
           IRepository<ContactUs_FormData> contactUsRepository)
        {
            this._eventPublisher = eventPublisher;
            this._contactUsRepository = contactUsRepository;            
        }

        public virtual IEnumerable<ContactUs_FormData> GetContactUsForms()
        {
            return _contactUsRepository.Table;
        }

        public virtual ContactUs_FormData GetContactUsFormById(int Id)
        {
            return _contactUsRepository.Table.FirstOrDefault(s=> s.Id == Id);
        }

        public virtual void InsertContactUsForm(ContactUs_FormData contactUs)
        {
            if (contactUs == null)
                throw new ArgumentNullException("contactUs");

            _contactUsRepository.Insert(contactUs);

            //event notification
            _eventPublisher.EntityInserted(contactUs);
        }

        public virtual void UpdateContactUsForm(ContactUs_FormData contactUs)
        {
            if (contactUs == null)
                throw new ArgumentNullException("contactUs");

            _contactUsRepository.Update(contactUs);

            //event notification
            _eventPublisher.EntityUpdated(contactUs);
        }

        public virtual void DeleteContactById(int Id)
        {
            if (Id > 0)
            {
                var contact = _contactUsRepository.Table.FirstOrDefault(d => d.Id == Id);
                _contactUsRepository.Delete(contact);

                //event notification
                _eventPublisher.EntityDeleted(contact);
            }
        }
    }
}
