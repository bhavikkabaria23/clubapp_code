﻿using Nop.Core.Data;
using Nop.Services.Events;
using Shopfast.Plugin.IssuerDocForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.IssuerDocForm.Services
{
    public class IssuerDocFormService : IIssuerDocFormService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<IDF_Sections> _sectionRepository;
        private readonly IRepository<IDF_Questions> _questionRepository;
        private readonly IRepository<IDF_Controls> _controlRepository;
        private readonly IRepository<IDF_ControlItems> _controlItemRepository;
        private readonly IRepository<IDF_Customer> _customerRepository;
        #endregion

        public IssuerDocFormService(IEventPublisher eventPublisher,
           IRepository<IDF_Sections> sectionRepository,
            IRepository<IDF_Questions> questionRepository,
            IRepository<IDF_Controls> controlRepository,
            IRepository<IDF_ControlItems> controlItemRepository,
            IRepository<IDF_Customer> customerRepository
            )
        {
            this._eventPublisher = eventPublisher;
            this._sectionRepository = sectionRepository;            
            this._questionRepository = questionRepository;            
            this._controlRepository = controlRepository;            
            this._controlItemRepository = controlItemRepository;
            this._customerRepository = customerRepository;
        }

        public virtual IEnumerable<IDF_Sections> GetSections()
        {
            return _sectionRepository.Table;
        }

        public virtual IEnumerable<IDF_Questions> GetQuestions()
        {
            return _questionRepository.Table;
        }

        public virtual IEnumerable<IDF_Controls> GetControls()
        {
            return _controlRepository.Table;
        }

        public virtual IEnumerable<IDF_ControlItems> GetControlItemss()
        {
            return _controlItemRepository.Table;
        }

        public virtual void AddIssuerForm(IDF_Customer customer)
        {
            if (customer == null)
                throw new ArgumentNullException("customer");

            _customerRepository.Update(customer);

            //event notification
            _eventPublisher.EntityUpdated(customer);
        }

        //public virtual void InsertContactUsForm(ContactUs_FormData contactUs)
        //{
        //    if (contactUs == null)
        //        throw new ArgumentNullException("contactUs");

        //    _contactUsRepository.Insert(contactUs);

        //    //event notification
        //    _eventPublisher.EntityInserted(contactUs);
        //}

        //public virtual void UpdateContactUsForm(ContactUs_FormData contactUs)
        //{
        //    if (contactUs == null)
        //        throw new ArgumentNullException("contactUs");

        //    _contactUsRepository.Update(contactUs);

        //    //event notification
        //    _eventPublisher.EntityUpdated(contactUs);
        //}

        //public virtual void DeleteContactById(int Id)
        //{
        //    if (Id > 0)
        //    {
        //        var contact = _contactUsRepository.Table.FirstOrDefault(d => d.Id == Id);
        //        _contactUsRepository.Delete(contact);

        //        //event notification
        //        _eventPublisher.EntityDeleted(contact);
        //    }
        //}
    }
}
