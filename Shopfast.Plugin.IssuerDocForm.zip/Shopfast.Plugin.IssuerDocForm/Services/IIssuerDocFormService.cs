﻿using Shopfast.Plugin.IssuerDocForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.IssuerDocForm.Services
{
    public interface IIssuerDocFormService
    {
        IEnumerable<IDF_Sections> GetSections();

        IEnumerable<IDF_Questions> GetQuestions();

        IEnumerable<IDF_Controls> GetControls();

        IEnumerable<IDF_ControlItems> GetControlItemss();



    }
}
