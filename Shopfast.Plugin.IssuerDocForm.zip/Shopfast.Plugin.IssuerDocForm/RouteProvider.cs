﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.IssuerDocForm
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //IPN
            routes.MapRoute("Plugin.ContactUsForm",
                 "contact-us",
                 new { controller = "ContactUs", action = "ContactUsForm" },
                 new[] { "Shopfast.Plugin.IssuerDocForm.Controllers" }
            );
            routes.MapRoute("Plugin.ContactUs.List",
                 "Plugin/ContactUs/List",
                 new { controller = "ContactUs", action = "ConfigureContactUs"},
                 new[] { "Shopfast.Plugin.IssuerDocForm.Controllers" }
            );
            routes.MapRoute("Plugin.ContactUsFormDetail",
                 "ContactUsFormDetail/{Id}",
                 new { controller = "ContactUs", action = "ContactUsFormDetail",Id= UrlParameter.Optional },
                 new[] { "Shopfast.Plugin.IssuerDocForm.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
