﻿using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Customers;
using Shopfast.Plugin.IssuerDocForm.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;

namespace Shopfast.Plugin.IssuerDocForm
{
    public class ContactUsProvider : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly ContactUsObjectContext _objectContext;

        public ContactUsProvider(ContactUsObjectContext objectContext)
        {
            this._objectContext = objectContext;
        }
        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "ContactUs";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.IssuerDocForm.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>  
        public override void Install()
        {
            //database objects
            _objectContext.Install();

            //locales
            this.AddOrUpdatePluginLocaleResource("ContactUs.Phone", "Phone");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Phone.Hint", "Phone");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Phone.Required", "Phone is required");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Investor", "Investor");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Investor.Hint", "Investor");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Startup", "Startup");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Startup.Hint", "Startup");
            this.AddOrUpdatePluginLocaleResource("ContactUs.General", "General");
            this.AddOrUpdatePluginLocaleResource("ContactUs.General.Hint", "General");
            this.AddOrUpdatePluginLocaleResource("ContactUs.CreatedDate", "Date");
            this.AddOrUpdatePluginLocaleResource("ContactUs.CreatedDate.Hint", "CreatedDate");
            this.AddOrUpdatePluginLocaleResource("ContactUs.Menu.Title.ContactUs", "Contact Us");


            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //database objects
            _objectContext.Uninstall();

            //locales
            this.DeletePluginLocaleResource("ContactUs.Phone");
            this.DeletePluginLocaleResource("ContactUs.Phone.Required");
            this.DeletePluginLocaleResource("ContactUs.Phone.Hint");
            this.DeletePluginLocaleResource("ContactUs.Investor");
            this.DeletePluginLocaleResource("ContactUs.Investor.Hint");
            this.DeletePluginLocaleResource("ContactUs.Startup");
            this.DeletePluginLocaleResource("ContactUs.Startup.Hint");
            this.DeletePluginLocaleResource("ContactUs.General");
            this.DeletePluginLocaleResource("ContactUs.General.Hint");
            this.DeletePluginLocaleResource("ContactUs.CreatedDate");
            this.DeletePluginLocaleResource("ContactUs.CreatedDate.Hint");

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "ContactUs",
                Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("ContactUs.Menu.Title.ContactUs"),
                Url = "/Plugin/ContactUs/List",
                Visible = true,
                IconClass = "fa-dot-circle-o"
            };
            var firstNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Customers");
            if (firstNode != null)
            {
                firstNode.ChildNodes.Insert(1, menuItem);
            }
            else
            {
                rootNode.ChildNodes.Add(menuItem);
            }
        }
    }
}
