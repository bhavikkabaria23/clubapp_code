﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.IssuerDocForm.Domain
{
    public class IDF_Controls
    {
        public int Id { get; set; }
        public int QuestinoId { get; set; }
        public int Type { get; set; } // 1,2,3,4,5,6 (Textbox,Textarea,Picklist,Checkbox, Radio, Upload) - based on Enum
        public bool IsRequired { get; set; }
        public string Value { get; set; } // answer
        public string CRMField { get; set; }        
        public bool IsDeleted { get; set; }        
    }
}
