﻿using Shopfast.Plugin.IssuerDocForm.Domain;
using Shopfast.Plugin.IssuerDocForm.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Web;
using System.Web.Mvc;

namespace MVCTest.Controllers
{
    public class IssuerController : Controller
    {
        private ControlsModel ConvertToControlModel(IDF_Controls con, IssuerDocFormModel model)
        {
            ControlsModel _control = new ControlsModel();

            _control.ControlId = con.Id;
            _control.QuestinoId = con.QuestinoId;
            _control.Type = con.Type;
            _control.IsRequired = con.IsRequired;
            _control.Value = con.Value;
            _control.CRMField = con.CRMField;
            _control.ControlItems = model.ControlItems.Where(ci => ci.ControlId == con.Id).ToList();

            return _control;
        }
        // GET: Issuer
        public ActionResult Index()
        {
            var model = new IssuerDocFormModel();            

            List<IDF_Questions> Questions = new List<IDF_Questions>();
            List<IDF_Controls> Controls = new List<IDF_Controls>();
            for (int i = 1; i <= 6; i++)
            {
                Questions.Add(new IDF_Questions()
                {
                    Id = i,
                    SectionId = 1,
                    Name = "question "+i,
                    Description = "question "+i,
                    IsDeleted = false
                });
            }
            for (int i = 1; i <= 6; i++)
            {
                Controls.Add(new IDF_Controls()
                {
                    Id = i,
                    QuestinoId = i,
                    Type = i,
                    IsRequired = false,
                    CRMField = "crm_"+i,
                    IsDeleted = false
                });
            }
            for (int i = 3; i <= 5; i++)
            {
                for (int j = 1; j <= 3; j++)
                {
                    model.ControlItems.Add(new IDF_ControlItems()
                    {
                        Id = i + j,
                        ControlId = i,
                        Value = false,
                        Text = (i == 3) ? "Picklist_" + j : (i == 4) ? "Checkbox_" + j : (i == 5) ? "Radio_" + j : "no",
                        IsDeleted = false
                    });
                }
            }

            foreach (var que in Questions)
            {
                model.Questions.Add(new QuestionsModel()
                {
                    QuestionId = que.Id,
                    SectionId = que.SectionId,
                    Name = que.Name,
                    Description = que.Description,
                    Control = ConvertToControlModel(Controls.FirstOrDefault(c => c.QuestinoId == que.Id), model)
                });
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Index(IssuerDocFormModel model)
        {
            List<IDF_Customer> customerList = new List<IDF_Customer>();
            var guid = Guid.NewGuid().ToString();
            int customerId = 0; // use current customer id
            string customerEmail = "bhavik@olb.com";
            foreach (var que in model.Questions)
            {
                if (que.ApplicableValue == "1")
                {
                    IDF_Customer customer = new IDF_Customer();
                    customer.Guid = guid;
                    customer.CustomerId = customerId;
                    customer.QuestinoId = que.QuestionId;
                    customer.ControlId = que.Control.ControlId;
                    customer.CreatedDate = DateTime.UtcNow;
                    customer.ModifiedDate = DateTime.UtcNow;

                    switch ((ControlType)que.Control.Type)
                    {
                        case ControlType.Textbox:
                        case ControlType.Textarea:
                        case ControlType.Picklist:
                        case ControlType.Radio:
                            customer.Answer = que.Control.Value;
                            break;
                        case ControlType.Checkbox:
                            customer.Answer = string.Join(",", que.Control.ControlItems.Where(c => c.Value).Select(c => c.Text).ToArray());
                            break;
                        case ControlType.Upload:
                            if (que.Control.file != null && que.Control.file.ContentLength > 0)
                            {
                                string _FileName = Path.GetFileName(que.Control.file.FileName);
                                string folderPath = "~/Content/IssuerDocForms/" + customerEmail + "_" + guid + "/Question_" + que.QuestionId;
                                string _path = Path.Combine(Server.MapPath(folderPath), _FileName);
                                DirectorySecurity securityRules = new DirectorySecurity();
                                securityRules.AddAccessRule(new FileSystemAccessRule(_path, FileSystemRights.FullControl, AccessControlType.Allow));
                                if (!Directory.Exists(_path))
                                {
                                    Directory.CreateDirectory(_path);
                                }
                                customer.Answer = folderPath + _FileName;
                                que.Control.file.SaveAs(_path);
                            }
                            break;
                        default:
                            break;
                    }

                    // save  customer          
                    if (!string.IsNullOrEmpty(customer.Answer))
                    {
                        customerList.Add(customer);
                    }
                    //------------
                }
            }
            return RedirectToAction("Index");
        }
    }
}
