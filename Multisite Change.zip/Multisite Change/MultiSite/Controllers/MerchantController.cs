﻿using System;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using MultiSite.Data;
using MultiSite.Models;
using MultiSite.Services;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Authentication;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Web.Models.SiteRegistration;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Core;
using Nop.Services.Messages;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Common;
using System.IO;
using System.Xml;
using Nop.Web.Framework.Themes;

namespace Nop.Web.Controllers
{
    public class MerchantController : Controller
    {
        [HttpGet]
        public ActionResult Setup()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            //var mobileDeviceHelper = EngineContext.Current.Resolve<IMobileDeviceHelper>();
            var model = new SiteRegistrationModel { };
            //return View(!mobileDeviceHelper.IsShopFastPro(ControllerContext.HttpContext) ? "MerchantSetup1" : "MerchantSetup1.Mobile", model);
            return View("MerchantSetup1", model);
        }

        // Free trial integration in new page which is used for POSCLOUD domain\
        public ActionResult FreeTrialSetup1()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            return View();
        }

        // This is Common free trial
        public ActionResult FreeTrialCommonSetup1()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            ViewBag.IsCommonFreeTrial = "true";
            return View("FreeTrialSetup1");
        }

        [HttpPost]
        public ActionResult Setup(SiteRegistrationModel model)
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            //var mobileDeviceHelper = EngineContext.Current.Resolve<IMobileDeviceHelper>();            
            return View("MerchantSetup2", model);
        }

        [HttpPost]
        public ActionResult FreeTrialSetup2(SiteRegistrationModel model)
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();
            ModelState.Clear();
            return View("FreeTrialSetup2", model);
        }

        public ActionResult FreeTrialCommonSetup2()
        {
            return Redirect("/freetrial");
        }
        [HttpPost]
        public ActionResult FreeTrialCommonSetup2(SiteRegistrationModel model)
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            model.AvailableStoreThemes = EngineContext.Current.Resolve<IThemeProvider>()
                            .GetThemeConfigurations();
            ViewBag.IsCommonFreeTrial = "true";
            ModelState.Clear();
            return View("FreeTrialSetup2", model);
        }

        [HttpPost]
        public ActionResult SetupFinish(SiteRegistrationModel model, HttpPostedFileBase logo, bool isTrial = false, string isFreeTrialPage = "", string CreditCard = "")
        {
            try
            {
                if (!MultisiteHelper.IsAdminSite)
                    return HttpNotFound();
                if (!string.IsNullOrEmpty(isFreeTrialPage))
                {
                    if (string.IsNullOrEmpty(CreditCard))
                    {
                        ViewBag.CreditCardValidation = true;
                        return View("FreeTrialSetup2", model);
                    }
                    if (!string.IsNullOrEmpty(model.ActivationCode))
                    {
                        if (!VarifyActivationCode(model.ActivationCode))
                        {
                            ViewBag.ActivationValidation = true;
                            return View("FreeTrialSetup2", model);
                        }
                    }
                }
                bool result = StoreOwnerRegister(model);
                if (result)
                {
                    /* Copy database and settings */
                    string storeName;
                    model.storeName = model.storeName.SanitazeStoreName();
                    SiteHelper.AddToSqlServer(model.storeName, model.industryType, out storeName);

                    /* Setup store admin credentials and basic settings into database. */
                    var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                    MultiSiteDataProvider.ConfigureStoreDatabase(model.storeName, storeDatabase, model.email, model.password, MultisiteHelper.DefaultTheme, logo);
                    model.isOrder = !isTrial;
                    using (var dbContext = new Sites4Entities())
                    {
                        if (model.email != "(not changed)")
                        {
                            Site storeSite = new Site
                            {
                                StoreName = model.storeName,
                                CreationDate = DateTime.UtcNow,
                                IsOrder = model.isOrder,
                                deleted = false,
                                DbName = MultisiteHelper.GetDbName(storeName),
                                // For package details         
                                PackageProductId = model.PackageProductId,
                                //----------------------------------------
                                Owner = new Owner
                                {
                                    email = model.email,
                                    description = model.Description,
                                    firstName = model.firstName,
                                    industryType = model.industryType,
                                    LastName = model.lastName,
                                    phone = model.phone,
                                    starting = model.Starting,
                                    Country = model.Country,
                                    Website = model.Website,
                                    //Multisite_NewField_change
                                    StreetAddress = model.StreetAddress,
                                    City = model.City,
                                    ZipPostalCode = model.ZipPostalCode,
                                    State = model.State,
                                    // Free trial integration in new page
                                    AvgSaleAmout = model.AvgSaleAmout,
                                    ProcessorName = model.ProcessorName,
                                    ProcessorEmail = model.ProcessorEmail,
                                    ProcessorPhoneNumber = model.ProcessorPhoneNumber,
                                    SiteCategory = model.SiteCategory,
                                    TeamPeople = model.TeamPeople,
                                    Reason = model.Reason
                                    //-----------------------
                                    //--------------------------
                                }
                            };

                            dbContext.Sites.Add(storeSite);
                        }
                        else
                        {
                            #region upgrade existing site
                            /* var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var customer = _authenticationService.GetAuthenticatedCustomer();
                    var email = customer.Email;
                    var owner = dc.Owners.SingleOrDefault(x => x.email == email);
                    if (owner != null)
                    {
                        var site = owner.Site;
                        //site.IsOrder = true;
                    } */
                            #endregion
                        }
                        dbContext.SaveChanges();
                        MultisiteHelper.ResetSites();
                        SiteHelper.AddCloudFareDNS(storeName);
                    }
                    var _workflowMessageService = new MultisiteWorkflowMessageService();
                    if (isTrial)
                    {
                        _workflowMessageService.SendTrialStoreCreatedCustomerNotification(model, isTrial);
                        _workflowMessageService.SendTrialStoreCreatedAdminNotification(model, isTrial);
                    }
                    else
                    {
                        _workflowMessageService.SendTrialStoreCreatedCustomerNotification(model);
                        _workflowMessageService.SendTrialStoreCreatedAdminNotification(model);
                    }

                    //var mobileDeviceHelper = EngineContext.Current.Resolve<IMobileDeviceHelper>();
                    if (!string.IsNullOrEmpty(isFreeTrialPage))
                    {
                        //Merchant link for free trial
                        ViewBag.CreditCard = CreditCard;
                        //---------------------------
                        ViewBag.Layout = "FreeTrial";
                    }
                    return View("MerchantSetupFinish", model);
                }
                else
                {
                    return RedirectToRoute("HomePage");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool VarifyActivationCode(string activationCode)
        {
            var fileDirectory = new DirectoryInfo(Server.MapPath("/"));
            var activationCodeConfigFile = new FileInfo(Path.Combine(fileDirectory.FullName, "ActivationCodes.config"));
            if (activationCodeConfigFile.Exists)
            {
                var doc = new XmlDocument();
                doc.Load(activationCodeConfigFile.FullName);
                string activationCodeName = activationCodeConfigFile.Name;
                string FilePath = activationCodeConfigFile.FullName;
                var node = doc.SelectSingleNode("ActivationCodes");
                if (node != null)
                {
                    if (node.HasChildNodes)
                    {
                        for (int i = 0; i < node.ChildNodes.Count; i++)
                        {
                            var cNode = node.ChildNodes[i];
                            var attributeCode = cNode.Attributes["CodeValue"];
                            if (!string.IsNullOrEmpty(activationCode))
                            {
                                if (activationCode.Trim().ToLower().Equals(attributeCode.Value.ToLower().Trim()))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        //-----------------------------------
        public ActionResult SetupFinish()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            if (TempData["multisite"] != null)
                // Here Store is created with not trial but based on packages.
                return SetupFinish(TempData["multisite"] as SiteRegistrationModel, null);
            else
                return Redirect("/freetrial");
        }
        // For package details         
        public ActionResult UpgradeFinish()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            if (TempData["multisite"] != null)
                return UpgradeFinish(TempData["multisite"] as SiteRegistrationModel);
            else
                return HttpNotFound();
        }

        [HttpPost]
        public ActionResult UpgradeFinish(SiteRegistrationModel model)
        {
            try
            {
                if (!MultisiteHelper.IsAdminSite)
                    return HttpNotFound();

                ///* Copy database and settings */
                //string storeName;
                //model.storeName = model.storeName.SanitazeStoreName();
                //SiteHelper.AddToSqlServer(model.storeName, model.industryType, out storeName);

                ///* Setup store admin credentials and basic settings into database. */
                //var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                //MultiSiteDataProvider.ConfigureStoreDatabase(model.storeName, storeDatabase, model.email, model.password, MultisiteHelper.DefaultTheme, logo);
                using (var dbContext = new Sites4Entities())
                {
                    var sites = dbContext.Sites.Single(s => s.StoreName == model.storeName);
                    sites.PackageProductId = model.PackageProductId;

                    dbContext.SaveChanges();
                    MultisiteHelper.ResetSites();
                }
                //model.isOrder = !isTrial;
                //var _workflowMessageService = new MultisiteWorkflowMessageService();
                //if (isTrial)
                //{
                //    _workflowMessageService.SendTrialStoreCreatedCustomerNotification(model);
                //    _workflowMessageService.SendTrialStoreCreatedAdminNotification(model);
                //}

                //var mobileDeviceHelper = EngineContext.Current.Resolve<IMobileDeviceHelper>();
                return View("UpgradeFinish");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------
        // This is no more use use because website Logo is already implemented built in from 3.80 from "@Html.Action("Logo", "Common")"
        // So please look at the method of Custom Plugin -> CustomWebController -> Logo Action
        //public FileContentResult Logo()
        //{            
        //    var imgLogo = MultiSiteDataProvider.GetLogo(MultisiteHelper.CurrentConnectionString);

        //    return File(imgLogo.PictureBinary, imgLogo.MimeType);
        //}
        // For print Logo
        public FileContentResult PrintLogo()
        {
            var imgLogo = MultiSiteDataProvider.GetPrintLogo(MultisiteHelper.CurrentConnectionString);

            return File(imgLogo.PictureBinary, imgLogo.MimeType);
        }
        //-----------------------------------------
             
        public ActionResult Expired(bool? popupMode, int? daysLeft, string StoreName)
        {
            if (popupMode.HasValue && popupMode.Value)
            {
                ViewBag.StoreName = StoreName;
                return View("ExpiredPopup", daysLeft.Value);
            }
            else
            {
                ViewBag.StoreName = string.Format("{0}.{1}", StoreName, MultisiteHelper.Domain);

                // This is return to "Merchant -> Expired page. whic is now no more use"
                //return View();
                // This is return to plans and pricing page
                return RedirectToRoute("Package", new { expired = "true" });
            }
        }

        //if passed domain name, returns true if it is registered and belongs to current customer
        //otherwise returns true if name is not registered
        [HttpGet]
        public JsonResult TestStoreName(string storeName)
        {
            //storeName = storeName.Trim();
            if (string.IsNullOrWhiteSpace(storeName))
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            using (var dc = new Sites4Entities())
            {
                bool alreadyRegistred = true;
                if (storeName.Contains('.'))
                { //domain name
                    var subdomain = storeName.SanitazeStoreName();
                    var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var customer = _authenticationService.GetAuthenticatedCustomer();
                    if (customer != null)
                    {
                        var isOwn = dc.Sites.Include("Owner")
                            .Any(s => s.StoreName == subdomain && s.Owner.email == customer.Email && !(s.IsOrder ?? false));
                        alreadyRegistred = !isOwn;
                    }
                }
                else
                {
                    alreadyRegistred = MultisiteHelper.MainStoreName.Equals(storeName, StringComparison.InvariantCultureIgnoreCase)
                        || dc.Sites.Any(s => s.StoreName.ToLower() == storeName.ToLower());
                }
                return Json(!alreadyRegistred, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult CheckEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerByEmail(email.Trim()) != null)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RenderLogo()
        {
            var isLogoNew = MultiSiteDataProvider.IsLogoExists(MultisiteHelper.CurrentConnectionString);
            ViewData["isLogoNew"] = isLogoNew ? "new" : "old";
            return PartialView();
        }

        // For print Logo
        public ActionResult RenderPrintLogo()
        {
            var isLogoNew = MultiSiteDataProvider.IsPrintLogoExists(MultisiteHelper.CurrentConnectionString);
            ViewData["isPrintLogoNew"] = isLogoNew ? "new" : "old";
            return PartialView();
        }
        //--------------------------------------
        [HttpPost]
        public ActionResult GetStoresForEmail(string email)
        {
            using (var dc = new Sites4Entities())
            {
                var stores = dc.Sites.Include("Owner")
                    .Where(s => s.Owner.email == email)
                    .ToList()
                    .Select(s => MultisiteHelper.ExpandStoreNameToUrl(s.StoreName));
                return Json(stores);
            }
        }

        //Admin menu based on super admin and user - add "adminType" parameter
        public ActionResult TmpAdmin(Guid guid, string adminType = "")
        //-----------------------
        {
            StringBuilder log = new StringBuilder();
            try
            {
                //anti-forgery
                if (MultisiteHelper.TempLoginGuids.ContainsKey(guid) && MultisiteHelper.TempLoginGuids[guid].StoreName == MultisiteHelper.SubDomain)
                {
                    MultisiteHelper.TempLoginGuids.Remove(guid);
                    var _customerService = new MultisiteCustomerService();
                    var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
                    var adminCustomer = _customerService.GetFirstAdminCustomer();
                    if (adminCustomer == null)
                    {
                        //find superadmin user
                        var username = string.Format("{0}@{1}", "superadmin", MultisiteHelper.Domain);
                        var sadmin = _customerService.GetCustomerByUsername(username);
                        //not found
                        if (sadmin == null)
                        {
                            //register
                            var _customerRegistrationService = EngineContext.Current.Resolve<ICustomerRegistrationService>();
                            sadmin = _customerService.InsertAdminCustomer(username);
                            var registrationRequest = new CustomerRegistrationRequest(sadmin, username,
                                username, Guid.NewGuid().ToString(), PasswordFormat.Hashed, _storeContext.CurrentStore.Id, true);
                            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
                            log.AppendFormat("User {0} registered at {1} with status {2}", username, MultisiteHelper.SubDomain, registrationResult.Success);
                        }
                        //var _logger = EngineContext.Current.Resolve<ILogger>();
                        try
                        {
                            using (var dc = new MultisiteObjectContext(MultisiteHelper.CurrentConnectionString, true))
                            {

                                var affectedRows = dc.Database.ExecuteSqlCommand(string.Format(
                                    "insert into dbo.Customer_CustomerRole_Mapping(CustomerRole_Id, Customer_Id) select 1, Id from dbo.Customer where Email = '{0}'",
                                    username));
                                if (affectedRows == 1)
                                {
                                    log.AppendFormat("User {0} got admin rights OK. ", username);
                                }
                                else
                                {
                                    log.AppendFormat("Unexpected number of rows: {0}", affectedRows);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            log.AppendFormat("User {0} at {1} registration exception: {2}", username, MultisiteHelper.SubDomain, ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");

                        }
                        _authenticationService.SignIn(sadmin, true);
                    }
                    else
                    {
                        _authenticationService.SignIn(adminCustomer, true);
                    }
                    if (!string.IsNullOrWhiteSpace(log.ToString()))
                    {
                        MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                    }

                    //Admin menu based on super admin and user
                    if (!string.IsNullOrEmpty(adminType))
                    {
                        return Redirect("/admin?type=" + adminType);
                    }
                    else
                    {
                        return Redirect("/admin");
                    }
                    //-------------------------------



                    //if (sadmin != null && !sadmin.IsAdmin()) {
                    //    log.AppendLine("TmpAdmin: 'superadmin' is not admin");
                    //    //_customerService.DeleteCustomer(sadmin);
                    //    using (var dc = new MultisiteObjectContext(MultisiteHelper.currentConnStr, true)) {
                    //        var admin = dc.Set<Customer>().Single(c => c.Id == sadmin.Id);
                    //        if (admin != null) {
                    //            dc.Set<Customer>().Remove(admin);
                    //            dc.SaveChanges();
                    //        }
                    //    }
                    //    sadmin = null;
                    //}

                    //var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    //_authenticationService.SignIn(sadmin, true);
                    //MultiSiteDataProvider.LogToAdminDB(log.ToString());
                    //return Redirect("/admin");
                }
                else
                {
                    log.AppendLine("TmpAdmin: Guid not found");
                    MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                }
            }
            catch (Exception ex)
            {
                log.AppendFormat("TmpAdmin: {0} {1}", ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");
                MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
            }

            return HttpNotFound();
        }

        public ActionResult TmpLogin(Guid guid)
        {
            StringBuilder log = new StringBuilder();
            try
            {
                //anti-forgery
                if (MultisiteHelper.TempLoginGuids.ContainsKey(guid)
                    && MultisiteHelper.TempLoginGuids[guid].StoreName == MultisiteHelper.SubDomain)
                {
                    var email = MultisiteHelper.TempLoginGuids[guid].Email;
                    var returnUrl = MultisiteHelper.TempLoginGuids[guid].ReturnUrl;
                    MultisiteHelper.TempLoginGuids.Remove(guid);
                    try
                    {
                        var _customerService = new MultisiteCustomerService();

                        //find user
                        var user = _customerService.GetCustomerByUsername(email);

                        if (user.IsAdmin() && Nop.Data.MultiSiteDataProvider.IsTrial())
                        {
                            var daysLeft = Nop.Data.MultiSiteDataProvider.GetLeftDaysOfTrial();
                            if (daysLeft <= 0)
                            {
                                return Redirect(string.Format("{0}/Merchant/Expired/?StoreName={1}", Nop.Core.Data.MultisiteHelper.FullAdminStoreAddress, Nop.Core.Data.MultisiteHelper.SubDomain));
                            }
                        }

                        var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                        _authenticationService.SignIn(user, true);
                    }
                    catch (Exception ex)
                    {
                        log.AppendFormat("User {0} at {1} login exception: {2}", email, MultisiteHelper.SubDomain, ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");
                    }
                    if (!string.IsNullOrWhiteSpace(log.ToString()))
                    {
                        MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                    }
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    return RedirectToRoute("HomePage");



                }
                else
                {
                    log.AppendLine("TmpLogin: Guid not found");
                    MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                }
            }
            catch (Exception ex)
            {
                log.AppendFormat("TmpLogin: {0} {1}", ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");
                MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
            }

            return HttpNotFound();
        }

        [NonAction]
        public ActionResult Extra(int id)
        {
            if (id == 4)
            {
            }
            return HttpNotFound();
        }

        //Multisite_NewField_change
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetStatesByCountryName(string countryName, bool addEmptyStateIfRequired)
        {
            //this action method gets called via an ajax request
            if (String.IsNullOrEmpty(countryName))
                throw new ArgumentNullException("countryName");

            // string cacheKey = string.Format(Nop.Web.in ModelCacheEventConsumer.STATEPROVINCES_BY_COUNTRY_MODEL_KEY, countryId, addEmptyStateIfRequired, _workContext.WorkingLanguage.Id);
            //var cacheModel = _cacheManager.Get(cacheKey, () =>
            //{
            //var country = EngineContext.Current.Resolve<ICountryService>().GetAllCountries(Convert.ToInt32(countryId));
            var _stateProvinceService = new MultisiteStateProvinceService();

            var states = _stateProvinceService.GetStateProvincesByCountryName(countryName).ToList();
            var result = (from s in states
                          select new { id = s.Id, name = s.GetLocalized(x => x.Name) })
                          .ToList();

            if (addEmptyStateIfRequired && result.Count == 0)
                result.Insert(0, new { id = 0, name = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Address.OtherNonUS") });
            //return result.ToList();

            //});

            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //---------------------------------

        //3.1        
        //My Account Module - Add store owner as a Customer.        
        public bool StoreOwnerRegister(SiteRegistrationModel model)
        {
            var _countryService = EngineContext.Current.Resolve<ICountryService>();
            var _stateProvinceService = EngineContext.Current.Resolve<IStateProvinceService>();
            var _workContext = EngineContext.Current.Resolve<IWorkContext>();
            var _customerSettings = EngineContext.Current.Resolve<CustomerSettings>();
            var _customerRegistrationService = EngineContext.Current.Resolve<ICustomerRegistrationService>();
            var _addressService = EngineContext.Current.Resolve<IAddressService>();
            var _localizationSettings = EngineContext.Current.Resolve<LocalizationSettings>();
            var _genericAttributeService = EngineContext.Current.Resolve<IGenericAttributeService>();
            var _workflowMessageService = EngineContext.Current.Resolve<IWorkflowMessageService>();
            var _customerService = EngineContext.Current.Resolve<ICustomerService>();
            var _storeContext = EngineContext.Current.Resolve<IStoreContext>();


            //model.firstName = siteModel.firstName;
            //model.lastName = siteModel.lastName;
            //model.email = siteModel.email;
            //model.password = siteModel.password;
            //model.phone = siteModel.phone;
            //model.ZipPostalCode = siteModel.ZipPostalCode;
            //model.City = siteModel.City;
            model.CountryId = _countryService.GetAllCountries().Where(c => c.Name == model.Country).Select(c => c.Id).FirstOrDefault();
            model.StateProvinceId = _stateProvinceService.GetStateProvincesByCountryId(model.CountryId).Where(s => s.Name == model.storeName)
                .Select(s => s.Id).FirstOrDefault();
            //model.StreetAddress = siteModel.StreetAddress;
            model.Company = model.Website;
            //model.StateProvinceId = siteModel.st


            //check whether registration is allowed
            //if (_customerSettings.UserRegistrationType == UserRegistrationType.Disabled)
            //    return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.Disabled });

            //if (_workContext.CurrentCustomer.IsRegistered())
            //{
            //    //Already registered customer. 
            //    _authenticationService.SignOut();

            //    //Save a new record
            //    _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            //}
            //
            //var customer = _workContext.CurrentCustomer;

            //validate CAPTCHA
            //if (_captchaSettings.Enabled && _captchaSettings.ShowOnRegistrationPage && !captchaValid)
            //{
            //    ModelState.AddModelError("", _localizationService.GetResource("Common.WrongCaptcha"));
            //}            
            //if (ModelState.IsValid)
            //{
            //if (_customerSettings.UsernamesEnabled && model.Username != null)
            //{
            //    model.Username = model.Username.Trim();
            //}

            //3.1
            /* Customer Geolocation  */
            HttpCookie CountryName = Request.Cookies["countryName"];
            HttpCookie StateName = Request.Cookies["regionName"];
            HttpCookie CityName = Request.Cookies["cityName"];
            HttpCookie ipAddress = Request.Cookies["ipAddress"];
            HttpCookie countryCode = Request.Cookies["countryCode"];
            HttpCookie latitude = Request.Cookies["latitude"];
            HttpCookie longitude = Request.Cookies["longitude"];
            HttpCookie timeZone = Request.Cookies["timeZone"];

            string location = "";
            if (CountryName != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(CountryName.Value) ? CountryName.Value : "-");
            }
            if (StateName != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(StateName.Value) ? StateName.Value : "-");
            }
            if (CityName != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(CityName.Value) ? CityName.Value : "-");
            }
            if (ipAddress != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(ipAddress.Value) ? ipAddress.Value : "-");
            }
            if (countryCode != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(countryCode.Value) ? countryCode.Value : "-");
            }
            if (latitude != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(latitude.Value) ? latitude.Value : "-");
            }
            if (longitude != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(longitude.Value) ? longitude.Value : "-");
            }
            if (timeZone != null)
            {
                location = location + "," + (!string.IsNullOrEmpty(timeZone.Value) ? timeZone.Value : "-");
            }
            model.Geolocation = location.Trim(',');
            //--------------------------

            //bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
            bool isApproved = true;
            //3.1
            var customer = new Customer()
            {
                CustomerGuid = Guid.NewGuid(),
                //Email = model.email,
                Active = true,
                CreatedOnUtc = DateTime.UtcNow,
                LastActivityDateUtc = DateTime.UtcNow,
            };
            _customerService.InsertCustomer(customer);
            var registrationRequest = new CustomerRegistrationRequest(customer, model.email, model.email, model.password, _customerSettings.DefaultPasswordFormat, _storeContext.CurrentStore.Id,
                    isApproved);
            //--------------------------------
            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
            if (registrationResult.Success)
            {
                ////properties
                //if (_dateTimeSettings.AllowCustomersToSetTimeZone)
                //{
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.TimeZoneId, model.TimeZoneId);
                //}
                ////VAT number
                //if (_taxSettings.EuVatEnabled)
                //{
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.VatNumber, model.VatNumber);

                //    string vatName = "";
                //    string vatAddress = "";
                //    var vatNumberStatus = _taxService.GetVatNumberStatus(model.VatNumber, out vatName, out vatAddress);
                //    _genericAttributeService.SaveAttribute(customer,
                //        SystemCustomerAttributeNames.VatNumberStatusId,
                //        (int)vatNumberStatus);
                //    //send VAT number admin notification
                //    if (!String.IsNullOrEmpty(model.VatNumber) && _taxSettings.EuVatEmailAdminWhenNewVatSubmitted)
                //        _workflowMessageService.SendNewVatSubmittedStoreOwnerNotification(customer, model.VatNumber, vatAddress, _localizationSettings.DefaultAdminLanguageId);

                //}

                //form fields
                //if (_customerSettings.GenderEnabled)
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Gender, model.Gender);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, model.firstName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, model.lastName);

                //3.1
                /* Customer Geolocation */
                //_genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Geolocation, model.Geolocation);
                //-------------------------------

                //if (_customerSettings.DateOfBirthEnabled)
                //{
                //    DateTime? dateOfBirth = null;
                //    try
                //    {
                //        dateOfBirth = new DateTime(model.DateOfBirthYear.Value, model.DateOfBirthMonth.Value, model.DateOfBirthDay.Value);
                //    }
                //    catch { }
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.DateOfBirth, dateOfBirth);
                //}
                //if (_customerSettings.CompanyEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, model.Company);
                //if (_customerSettings.StreetAddressEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress, model.StreetAddress);
                //if (_customerSettings.StreetAddress2Enabled)
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress2, model.StreetAddress2);
                //if (_customerSettings.ZipPostalCodeEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.ZipPostalCode, model.ZipPostalCode);
                //if (_customerSettings.CityEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.City, model.City);
                //if (_customerSettings.CountryEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CountryId, model.CountryId);
                //if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);
                //if (_customerSettings.PhoneEnabled)
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.phone);
                //if (_customerSettings.FaxEnabled)
                //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Fax, model.Fax);

                //newsletter
                //if (_customerSettings.NewsletterEnabled)
                //{
                //    //save newsletter value
                //    var newsletter = _newsLetterSubscriptionService.GetNewsLetterSubscriptionByEmail(model.Email);
                //    if (newsletter != null)
                //    {
                //        if (model.Newsletter)
                //        {
                //            newsletter.Active = true;
                //            _newsLetterSubscriptionService.UpdateNewsLetterSubscription(newsletter);
                //        }
                //        //else
                //        //{
                //        //When registering, not checking the newsletter check box should not take an existing email address off of the subscription list.
                //        //_newsLetterSubscriptionService.DeleteNewsLetterSubscription(newsletter);
                //        //}
                //    }
                //    else
                //    {
                //        if (model.Newsletter)
                //        {
                //            _newsLetterSubscriptionService.InsertNewsLetterSubscription(new NewsLetterSubscription()
                //            {
                //                NewsLetterSubscriptionGuid = Guid.NewGuid(),
                //                Email = model.Email,
                //                Active = true,
                //                CreatedOnUtc = DateTime.UtcNow
                //            });
                //        }
                //    }
                //}

                //login customer now
                //if (isApproved)
                //    _authenticationService.SignIn(customer, true);

                //associated with external account (if possible)
                //TryAssociateAccountWithExternalAccount(customer);

                //insert default address (if possible)
                var defaultAddress = new Address()
                {
                    FirstName = customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                    LastName = customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName),
                    Email = customer.Email,
                    Company = customer.GetAttribute<string>(SystemCustomerAttributeNames.Company),
                    CountryId = customer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId) > 0 ?
                        (int?)customer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId) : null,
                    StateProvinceId = customer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId) > 0 ?
                        (int?)customer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId) : null,
                    City = customer.GetAttribute<string>(SystemCustomerAttributeNames.City),
                    Address1 = customer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress),
                    Address2 = customer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2),
                    ZipPostalCode = customer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode),
                    PhoneNumber = customer.GetAttribute<string>(SystemCustomerAttributeNames.Phone),
                    FaxNumber = customer.GetAttribute<string>(SystemCustomerAttributeNames.Fax),
                    CreatedOnUtc = customer.CreatedOnUtc
                };
                if (_addressService.IsAddressValid(defaultAddress))
                {
                    //some validation
                    if (defaultAddress.CountryId == 0)
                        defaultAddress.CountryId = null;
                    if (defaultAddress.StateProvinceId == 0)
                        defaultAddress.StateProvinceId = null;
                    //set default address
                    customer.Addresses.Add(defaultAddress);
                    customer.BillingAddress = defaultAddress;
                    customer.ShippingAddress = defaultAddress;
                    _customerService.UpdateCustomer(customer);
                }

                //notifications
                if (_customerSettings.NotifyNewCustomerRegistration)
                    _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                //switch (_customerSettings.UserRegistrationType)
                //{
                //    case UserRegistrationType.EmailValidation:
                //        {
                //            //email validation message
                //            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                //            // here last parameter is "true" for to show demosite link in activation page.
                //            _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id, true);

                //            //result
                //            //return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });                            
                //            return RedirectToRoute("HomePage", new { ShowDemoSitePopup = "yes" });
                //        }
                //    case UserRegistrationType.AdminApproval:
                //        {
                //            //return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                //            return RedirectToRoute("HomePage");
                //        }
                //    case UserRegistrationType.Standard:
                //        {
                //            //send customer welcome message
                //            _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);
                //            //3.1
                //            if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
                //            //-------------------------------
                //            var redirectUrl = Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                //            if (!String.IsNullOrEmpty(returnUrl))
                //                redirectUrl = _webHelper.ModifyQueryString(redirectUrl, "returnurl=" + HttpUtility.UrlEncode(returnUrl), null);
                //            //return Redirect(redirectUrl);
                //            return RedirectToRoute("HomePage");
                //        }
                //    default:
                //        {
                //            return RedirectToRoute("HomePage");
                //        }
                //}
            }
            else
            {
                return false;
            }
            //}

            //If we got this far, something failed, redisplay form
            //model.AllowCustomersToSetTimeZone = _dateTimeSettings.AllowCustomersToSetTimeZone;
            //foreach (var tzi in _dateTimeHelper.GetSystemTimeZones())
            //    model.AvailableTimeZones.Add(new SelectListItem() { Text = tzi.DisplayName, Value = tzi.Id, Selected = (tzi.Id == _dateTimeHelper.DefaultStoreTimeZone.Id) });
            //            model.DisplayVatNumber = _taxSettings.EuVatEnabled;
            //form fields
            //model.GenderEnabled = _customerSettings.GenderEnabled;
            //model.DateOfBirthEnabled = _customerSettings.DateOfBirthEnabled;
            //model.CompanyEnabled = _customerSettings.CompanyEnabled;
            //model.CompanyRequired = _customerSettings.CompanyRequired;
            //model.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;
            //model.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            //model.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;
            //model.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            //model.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;
            //model.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            //model.CityEnabled = _customerSettings.CityEnabled;
            //model.CityRequired = _customerSettings.CityRequired;
            //model.CountryEnabled = _customerSettings.CountryEnabled;
            //model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;
            //model.PhoneEnabled = _customerSettings.PhoneEnabled;
            //model.PhoneRequired = _customerSettings.PhoneRequired;
            //model.FaxEnabled = _customerSettings.FaxEnabled;
            //model.FaxRequired = _customerSettings.FaxRequired;
            //model.NewsletterEnabled = _customerSettings.NewsletterEnabled;
            //model.AcceptPrivacyPolicyEnabled = _customerSettings.AcceptPrivacyPolicyEnabled;
            //model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            //model.CheckUsernameAvailabilityEnabled = _customerSettings.CheckUsernameAvailabilityEnabled;
            //model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnRegistrationPage;
            //if (_customerSettings.CountryEnabled)
            //{
            //    model.AvailableCountries.Add(new SelectListItem() { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });
            //    foreach (var c in _countryService.GetAllCountries())
            //    {
            //        model.AvailableCountries.Add(new SelectListItem() { Text = c.GetLocalized(x => x.Name), Value = c.Id.ToString(), Selected = (c.Id == model.CountryId) });
            //    }


            //    if (_customerSettings.StateProvinceEnabled)
            //    {
            //        //states
            //        var states = _stateProvinceService.GetStateProvincesByCountryId(model.CountryId).ToList();
            //        if (states.Count > 0)
            //        {
            //            foreach (var s in states)
            //                model.AvailableStates.Add(new SelectListItem() { Text = s.GetLocalized(x => x.Name), Value = s.Id.ToString(), Selected = (s.Id == model.StateProvinceId) });
            //        }
            //        else
            //            model.AvailableStates.Add(new SelectListItem() { Text = _localizationService.GetResource("Address.OtherNonUS"), Value = "0" });

            //    }
            //}

            return true;
        }

        //temporary not in used, just for page setup
        public ActionResult setupfinishTest()
        {
            MultiSite.Models.SiteRegistrationModel model = new MultiSite.Models.SiteRegistrationModel();
            ViewBag.Layout = "FreeTrial";
            return View("MerchantSetupFinish", model);
        }
        //-----------------------------------------

        public ActionResult FillAllDbNames()
        {
            try
            {
                MultisiteHelper.FillAllDbNames();
                return Content("OK");
            }
            catch (Exception ex)
            {
                return Content(ex.ExpandMessage());
            }
        }

        //3.1
        //Video popup - Currently it is usedd for video Link at "MerchantSetupFinish.cshtml".
        //[ChildActionOnly]
        public string RenderVideoIcon(string keyword)
        {
            string VideoUrl = GetVideoUrlByPageUrl("", keyword);
            return VideoUrl;
        }
        public string GetVideoUrlByPageUrl(string requestedPageUrl, string keyword)
        {
            var themeDirectory = new DirectoryInfo(Server.MapPath("/"));
            var videoConfigFile = new FileInfo(Path.Combine(themeDirectory.FullName, "Video.config"));
            if (videoConfigFile.Exists)
            {
                var doc = new XmlDocument();
                doc.Load(videoConfigFile.FullName);

                string VideoName = videoConfigFile.Name;
                string FilePath = videoConfigFile.FullName;
                var node = doc.SelectSingleNode("Video");
                if (node != null)
                {
                    if (node.HasChildNodes)
                    {
                        //string pageUrl = string.Empty;
                        //string vidoeUrl = string.Empty;
                        for (int i = 0; i < node.ChildNodes.Count; i++)
                        {
                            var cNode = node.ChildNodes[i];
                            var attributePage = cNode.Attributes["pageUrlOrKeyword"];
                            // for requested page url
                            if (!string.IsNullOrEmpty(requestedPageUrl))
                            {
                                if (requestedPageUrl.Contains(Convert.ToString(attributePage.Value).ToLower().Trim()))
                                {
                                    var attributeVideo = cNode.Attributes["vidoeUrl"];
                                    if (!string.IsNullOrEmpty(attributeVideo.Value))
                                    {
                                        return attributeVideo.Value;
                                    }
                                    return "#";
                                }
                            }
                            // for keyword
                            else if (!string.IsNullOrEmpty(keyword))
                            {
                                if (keyword.ToLower().Equals(Convert.ToString(attributePage.Value).ToLower().Trim()))
                                {
                                    var attributeVideo = cNode.Attributes["vidoeUrl"];
                                    if (!string.IsNullOrEmpty(attributeVideo.Value))
                                    {
                                        return attributeVideo.Value;
                                    }
                                    return "#";
                                }
                            }
                            else
                            {
                                return "#";
                            }
                        }
                    }
                }
            }
            return "#";
        }
    }
}
