﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantId { get; set; }
        public string MerchantUri { get; set; }
        public string BankUri { get; set; }
        public string BankName { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public int SelectedState1 { get; set; }
        public int SelectedState2 { get; set; }
        public int SelectedState3 { get; set; }
        public int SelectedState4 { get; set; }
        public int SelectedState5 { get; set; }
        public int MCCCode { get; set; }
        public string FileName { get; set; }
        public string FileBase64 { get; set; }
        public string FileName2 { get; set; }
        public string FileBase642 { get; set; }
        public string FileName3 { get; set; }
        public string FileBase643 { get; set; }
    }

    public class NoteEntityModel
    {
        public string notetext { get; set; }
        public string subject { get; set; }
        public string filename { get; set; }
        public string mimetype { get; set; }
        public string documentbody { get; set; }
        public string LookupEntity { get; set; }
        public string entityId { get; set; }
    }

    #region Merchant Information
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        public bool IsTerminated { get; set; }
        public string AcceptCardExplanation { get; set; }
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranchExplanation { get; set; }
        public string LatestProofOfPCIDDSComplianceFile { get; set; }

        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }
        public string NonProfitFile { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; }
    }

    public class BusinessInformation2Model : BaseInformationModel
    {
        public BusinessInformation2Model()
        {
            NatureOfBusiness = new List<bool>();
            for (int i = 1; i <= 14; i++)
            {
                NatureOfBusiness.Add(false);
            }
            VolumeMonths = new List<bool>();
            for (int i = 1; i <= 12; i++)
            {
                VolumeMonths.Add(false);
            }
            MethodOfAcceptance = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                MethodOfAcceptance.Add(false);
            }
        }
        public List<bool> NatureOfBusiness { get; set; } //new_natureofbusinesscsv -> 1 - 14
        public bool IsSeasonalSales { get; set; }
        public List<bool> VolumeMonths { get; set; }// new_pleaseselecthighvolumemonthscsv -> Month wise
        public string ProductsOrServices { get; set; }
        public bool MerchantUse { get; set; } // if true then "Software" else "Terminal"
        public string TerminalType { get; set; } // if "Terminal"
        public string PaymentApplicationName { get; set; } // if "Software"
        public string PaymentApplicationVersion { get; set; } // if "Software"
        public bool MerchantNameAppear { get; set; } // if false then "DBA Name" else "Legal Name"
        public List<bool> MethodOfAcceptance { get; set; } // new_methodofacceptancetotalstoequal100csv -> 1 - Card Swipe,2 - MO/TO %, 3 - Key Entered %, 4 - Internet %
    }

    public class QuestionnaireModel : BaseInformationModel
    {
        public QuestionnaireModel()
        {
            DoYouSell1 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell1.Add(false);
            }
            PercentageOfSale = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfSale.Add(false);
            }
            DoYouSell2 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell2.Add(false);
            }
            Advertise = new List<bool>();
            for (int i = 1; i <= 5; i++)
            {
                Advertise.Add(false);
            }
        }
        public string BusinessPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public string PublicPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public bool IsRetailLocation { get; set; }
        public List<bool> DoYouSell1 { get; set; }// new_doyousellaserviceorproductscsv -> S,P
        public string DecribeProduct { get; set; }
        public List<bool> PercentageOfSale { get; set; } // new_whatpercentageofsaleswillbefromcsv -> M,T,I,C
        public string PhysicalAddress { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalZip { get; set; }
        public bool IsProductAddress { get; set; }
        public string ProductAddress { get; set; }
        public string ProductCity { get; set; }
        public string ProductZip { get; set; }
        public bool IsOwnProduct { get; set; }
        public List<bool> DoYouSell2 { get; set; }// new_doyousellcheckallthatapplycsv -> L,N
        public string CardBrandProcessor { get; set; }
        public decimal ChargeBacks { get; set; }
        public string ChargeBackAmount { get; set; } // price in dollar $ amount
        public int WhenCharged { get; set; } // if 0 then "Time of Order", if 1 then "Upon Shipment"...................
        public int DeliverDays { get; set; } // 0 -> "1-7 days", 1 -> "8-14 Days" and 2 -> 14+ Days
        public bool IsOtherCompany { get; set; }
        public string CompanyName { get; set; }
        public string CompanyTelephone { get; set; }
        public string CompanyAddress { get; set; }
        public List<bool> Advertise { get; set; }// new_howdoyouadvertisecsv -> C,M,T,I,O
        public string RefundPolicy { get; set; }
    }

    public class Questionnaire2Model : BaseInformationModel
    {
        public Questionnaire2Model()
        {
            MethodOfMarketing = new List<bool>();
            for (int i = 1; i <= 6; i++)
            {
                MethodOfMarketing.Add(false);
            }
            PercentageOfProducts = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfProducts.Add(false);
            }
            WhoProcessOrder = new List<bool>();
            for (int i = 1; i <= 3; i++)
            {
                WhoProcessOrder.Add(false);
            }
            WhoEnterCreditCard = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                WhoEnterCreditCard.Add(false);
            }
        }
        public string BusinessPercentage { get; set; }
        public string IndividualPercentage { get; set; }
        public List<bool> MethodOfMarketing { get; set; }// new_methodofmarketingcsv -> n,t,i,d,o,other
        public List<bool> PercentageOfProducts { get; set; }// new_percentageofproductssoldviacsv -> m,t,i,o
        public List<bool> WhoProcessOrder { get; set; }// new_whoprocessestheordercsv -> m,f,o
        public List<bool> WhoEnterCreditCard { get; set; }// new_whoenterscreditcardinformationintothecsv -> m,f,c,o
        public bool IsCreditCardPayment { get; set; }
        public string MerchantCertiNumber { get; set; }
        public string Issuer { get; set; }
        public string ExpDate { get; set; }
        public bool IsProduct { get; set; }
        public bool IsProductLocationSame { get; set; }
        public string ProductLocation { get; set; }
        public int ProductShipDays { get; set; }
        public int WhoShipProduct { get; set; } // 0 - Merchant, 1- Fullfillment Center
        public int ProductShippedBy { get; set; } // 0 - U.S. Mail , 1 - Other
        public string OtherShippedBy { get; set; }
        public bool IsDeliveryReceipt { get; set; }
    }

    public class ProcessingDetailsModel : BaseInformationModel
    {
        public string PaymentCardMonthly { get; set; } // $ amount
        public string AmericanExpressMonthly { get; set; } // $ amount        
        public string AvgTicket { get; set; }
        public string HighestTicket { get; set; }
        public bool IsServicer { get; set; }
        public string ServicerName { get; set; }
        public string ServicerContactNumber { get; set; }
        public bool IsFulfillmentHouse { get; set; }
        public string HouseName { get; set; }
        public string HouseContactNumber { get; set; }
        public bool IsBankruptcy { get; set; }
        public string BankruptcyExplain { get; set; }
        public bool IsSeasonalMerchant { get; set; }
        public int MonthsSeason { get; set; }
    }

    public class BaseOwnershipInformation : BaseInformationModel
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string SSN { get; set; }
        public string OwnershipPercent { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string HomePhone { get; set; }
        public string EmailAddress { get; set; }
        public int DLState { get; set; }
        public bool ControllingInterest { get; set; }
    }
    public class OwnershipInformation : BaseInformationModel
    {
        public OwnershipInformation()
        {
            Owner1 = new BaseOwnershipInformation();
            Owner2 = new BaseOwnershipInformation();
            ControllingOwner = new BaseOwnershipInformation();
        }
        public BaseOwnershipInformation Owner1 { get; set; }
        public BaseOwnershipInformation Owner2 { get; set; }
        public BaseOwnershipInformation ControllingOwner { get; set; }
    }

    public class SiteInspectionModel : BaseInformationModel
    {
        public bool OperateBusiness { get; set; } // new_baseduponisosreviewdoesmerchanthavetheap
        public string Comment { get; set; } // new_comment
        public string InspectorName { get; set; }// new_inspectorname
        public DateTime InspectorDate { get; set; } // new_inspectiondate
    }

    public class EquipmentInformationModel : BaseInformationModel
    {
    }
    #endregion

    #region Bank Information
    public class BankDisclosureModel : BaseInformationModel
    {
        public string Description { get; set; }
    }
    public class BankingInformationModel : BaseInformationModel
    {
        public string AccountBankName { get; set; } // update to Merchant Info -> new_bankname
        public string Transit { get; set; }// update to Merchant Info -> new_transitabarouting
        public string Account { get; set; } // update to Merchant Info -> new_accountdda
        public string AccountContact { get; set; } // update to Merchant Info -> new_contact
        public string AccountPhone { get; set; } // update to Merchant Info -> new_phone
        public string GuarantorDescription { get; set; } // get from bank template -> HTML -> new_continuingpersonalguarantyprovision
        public string Owner1Name { get; set; } // get from Merchant Info -> OwnershipInformation - Owner 1 title,Firstname,Middle name,Lastname
        public string Owner2Name { get; set; } // get from Merchant Info ->  OwnershipInformation - Owner 2 title,Firstname,Middle name,Lastname
    }
    public class ImportantInformationModel : BaseInformationModel
    {
        public string NewAccountDescription { get; set; } // get from bank template -> HTML -> new_merchantapplicationandagreementacceptance
        public string CertificationDescription { get; set; } // get from bank template -> HTML -> new_certificationofbeneficialowners
    }
    public class RatesFeesModel : BaseInformationModel
    {
        public string MonthlyMinimum { get; set; }// new_monthlyminimum
        public string MonthlyPciFee { get; set; }// new_monthlypcifee
        public string TransactionFee { get; set; }// new_visamcdiscovertransactionfee
        public string MonthlyCustomerSvsFee { get; set; }// new_monthlycustomersvsfee
        public string NonPciComplianceFee { get; set; } // new_nonpcicompliancefee
        public string AmexFee { get; set; }// new_amextransactionfee
        public string RegulatoryFee { get; set; }// new_irsregulatoryfee
        public string PinDebitFee { get; set; }// new_pindebittransactionfee
        public string AnualFee { get; set; }// new_annualfee
        public string NonEmvCompliance { get; set; }// new_nonemvcompliance
        public string VoicePerAuthFee { get; set; }// new_voiceperauthfee
        public string MerchantReporting { get; set; }// new_merchantonlineportalreporting
        public string EarlyTerminationFee { get; set; }// new_earlyterminationfee
        public string EmvTransaction { get; set; }//new_emvtransactionperdevice
        public string G2Monitoring { get; set; }//new_g2monitoring
        public string ApplicationFee { get; set; }//new_applicationfee
        public string BatchFee { get; set; }//new_batchsettlementfee
        public string ExcessiveHelpDeskCall { get; set; }//new_excessivehelpdeskcalls
        public string AvsFee { get; set; }// new_avsfeeaddressverificationservice
        public string EmvRecidencyFee { get; set; }// new_emvresidencyfee
        public string MerlinkChargeBack { get; set; }//new_merlinkchargeback             
        public bool IsMerlinkChargeBack { get; set; }//new_merlinkchargebackbool             
    }
    public class RecurringFeesModel : BaseInformationModel
    {
        public string MultipassSetupFee { get; set; }//new_multipasssetupfee
        public string MultipassGatewayFee { get; set; }//new_multipassgatewaymonthlyfee        
        public string MultipassPerTransFee { get; set; }//new_multipasspertransfee
        public string EnsureBillSetupFee { get; set; }//new_ensurebillsetupfee
        public string EnsureBillMonthlyFee { get; set; }//new_ensurebillmonthlyfee
        public string EnsureBillItemFee { get; set; }//new_ensurebillupdateperitemfee
        public string MobileSetupFee { get; set; }//new_wirelessmobilesetupfee
        public string MonthlyMobileFee { get; set; }// new_monthlywirelessmobilefee
        public string MobilePerTransFee { get; set; }//new_wirelessmobilepertransfee
        public string GatewaySetupFee { get; set; }//new_gatewaysetupfee
        public string GatewayMonthlyFee { get; set; }//new_gatewaymonthlyfee
        public string GatewayPerTransFee { get; set; }//new_gatewaypertransfee

        // Other fees
        public string ChargebackPer { get; set; }//new_chargebackperchargeback
        public string ChargebackReversals { get; set; }//new_chargebackreversalsperreversal
        public string ChargebackRetrieval { get; set; }//new_chargebackretrievalperretrieval
        public string ChargebackPreArbitration { get; set; }//new_chargebackprearbitrationprearbitration
        public string PerAchRejectFee { get; set; }//new_perachrejectfee
        public string FANF { get; set; }//new_visafixedacquirernetworkfeefanf

    }
    #endregion

    #region Partner (ISO/Bank) Information
    public class CompanyInformationModel : BaseInformationModel
    {   
        public string DBAName { get; set; }
        //new_dbaname
        //Contact Name -> get ContactName from BaseInformationModel
        //new_contactname
        //Address ->  get LocationAddress, City, Zip, SelectedState1 from BaseInformationModel
        //new_address,new_city, new_zipcode, new_state
        public string TaxId { get; set; }
        // new_federaltaxid
        public int CorporationType { get; set; }
        //new_corporationtype

        //For LLC:State drop down Use SelectedState2 from BaseInformationModel
        //new_state1

        //File upload for Non Profit
        //new_nonprofitevidence
    }

    public class PrincipleInformationModel : BaseInformationModel
    {
        public string FullName { get; set; }
        //new_fullname
        public string Title { get; set; }
        //new_title
        // HOME ADDRESS ->  get LocationAddress, City, Zip, SelectedState1 from BaseInformationModel
        //new_homeaddress, new_city1, new_zipcode1, new_state2
        //HOME PHONE  -> get TelePhoneNumber from BaseInformationModel
        //new_homephone
        public string MobilePhone { get; set; }
        //new_mobilephone
        public string SSN { get; set; } // Social Security #
        //new_socialsecurity
        public DateTime BirthDate { get; set; }
        //new_dateofbirth
    }

    public class AuthorizationModel : BaseInformationModel
    {
        public string AuthorizationDescription { get; set; } // only get from CRM
        //new_authorizationtemplate
        public string SSN { get; set; } // only get from PrincipleInformationModel
        //new_socialsecurity
        public string BirthDate { get; set; }// only get from PrincipleInformationModel
        //new_dateofbirth
        //Residence Street Address: ->  use LocationAddress, City, Zip, SelectedState1 from BaseInformationModel, // only get from PrincipleInformationModel
        ////new_address,new_city, new_zipcode, new_state
        public string SignImageBase64 { get; set; }
        // new_authorization_signature
    }

    public class AgreementModel : BaseInformationModel
    {
        public string SignImageBase64 { get; set; }// only get from CRM
        //new_signatureprincipal
        public string AgreementDescription { get; set; }
        //new_agreementtemplate
    }

    public class AppendixAModel : BaseInformationModel
    {
        // All Fee proprties -> only get from CRM
        public string SignImageBase64 { get; set; }
    }

    public class AppendixBModel : BaseInformationModel
    {
        public string EthicsStatementDesciption { get; set; } // -> only get from CRM
        //new_appendixbtemplate
        public string SignImageBase64 { get; set; }
        //new_appendixb_signature
    }

    public class PaymentInformationModel : BaseInformationModel
    {
        public string ApplicantName { get; set; }
        //new_applicantsname
        public string DBACompanyName { get; set; }
        //new_dbacompanyname
        // Address -> use LocationAddress from BaseInformationModel
        //new_address1

        // Bank Name -> use BankName from BaseInformationModel
        //new_bankname

        // Bank Phone -> use TelePhoneNumber from BaseInformationModel
        //new_bankphone
        public string RoutingNumber { get; set; }
        //new_routingnumber
        public string AccountNumber { get; set; }
        //new_accountnumber
        public string SignImageBase64 { get; set; }
        //new_paymentinfo_signature

        // COPY OF DRIVER’S LICENSE -> use FileName, FileBase64 from BaseInformationModel
        //new_copyofdriverslicense

        // COPY OF PRE PRINTED VOIDED CHECK FOR DEPOSITS -> use FileName2, FileBase642 from BaseInformationModel
        // new_copyofpreprintedvoidedcheckfordeposits

        // COPY OF W9 FORM -> use FileName3, FileBase643 from BaseInformationModel
        //new_copyofw9form
    }
    #endregion

}
