﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using MultiSite.Services;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Shopfast.Plugin.MerchantManagement.Controllers;
using Shopfast.Plugin.MerchantManagement.Services;
using Nop.Core.Configuration;

namespace Shopfast.Plugin.MerchantManagement
{
    public class DependencyRegistrar : IDependencyRegistrar
    {

        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<SiteService>().As<SiteService>().InstancePerLifetimeScope();
            //builder.RegisterType<MultisiteWorkflowMessageService>().As<MultisiteWorkflowMessageService>().InstancePerLifetimeScope();
        }

        public int Order
        {
            get { return 1; }
        }

    }
}
