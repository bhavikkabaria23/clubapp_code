﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.MerchantManagement
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.MerchantList.Index", "MerchantList",
               new { controller = "MerchantManagement", action = "List" },
               new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }   
               ).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteList", "Plugins/Merchants/SiteList",
                new { controller = "MerchantManagement", action = "List" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }
            ).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteList.SuperAdmin", "Plugins/Merchants/SiteListsa",
             new { controller = "MerchantManagement", action = "List" },
             new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }
            ).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteSelect", "Plugins/Merchants/SiteSelect",
                new { controller = "MerchantManagement", action = "SiteSelect" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteSelectChild", "Plugins/Merchants/SiteSelectChild",
             new { controller = "MerchantManagement", action = "SiteSelectChild" },
             new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteCreate", "Plugins/Merchants/SiteCreate/{Id}",
                new { controller = "MerchantManagement", action = "SiteCreate", id = UrlParameter.Optional},
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.MerchantList.DefaultSettings", "Plugins/Merchants/DefaultSettings",
                new { controller = "ConfigMerchantList", action = "DefaultSettings" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.MerchantList.AjaxLoadCustomers", "Plugins/Merchants/LoadCustomers",
                new { controller = "MerchantManagement", action = "AjaxLoadCustomers" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteDetails", "Plugins/Merchants/SiteDetails/{Id}",
                new { controller = "MerchantManagement", action = "SiteDetails", id = UrlParameter.Optional},
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteTheme", "Plugins/Merchants/SiteTheme/{Id}",
                new { controller = "MerchantManagement", action = "SiteTheme", id = UrlParameter.Optional },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.SiteAdmin", "Plugins/Merchants/SiteAdmin/{Id}",
                new { controller = "MerchantManagement", action = "GoSiteAdmin", id = UrlParameter.Optional},
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.TmpAdmin", "Plugins/Merchants/TmpAdmin",
                new { controller = "MerchantManagement", action = "TmpAdmin"},
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");
                        

            routes.MapRoute("Plugin.MerchantList.FilterPlugin", "Plugins/Merchants/FilterPlugin/{id}", 
                new { controller = "PluginFilter", action = "PluginList", id = UrlParameter.Optional },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");
                        
            routes.MapRoute("Plugin.MerchantList.PluginListSelect", "Plugins/Merchants/PluginListSelect", 
                new { controller = "PluginFilter", action = "PluginListSelect" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");
                        
            routes.MapRoute("Plugin.MerchantList.FilterSelected", "Plugins/Merchants/FilterSelected", 
                new { controller = "PluginFilter", action = "FilterSelected" },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Plugin.MerchantList.DeleteSite", "Plugins/Merchants/TestDeleteSite/{Id}",
                new { controller = "MerchantManagement", action = "DeleteSite", id = UrlParameter.Optional },
                new[] { "Shopfast.Plugin.MerchantManagement.Controllers" }).DataTokens.Add("area", "admin");
        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
