﻿using System.Collections;
using System.Collections.Generic;
using Kendo.Mvc.Infrastructure;

namespace Shopfast.Plugin.MerchantManagement.Models.Kendoui
{
    public class TreeDataSourceResult
    {
        //Methods
        public TreeDataSourceResult()
        {
            AggregateResults = new Dictionary<string, IEnumerable<AggregateResult>>();
        }

        //Properties
        public  IDictionary<string, IEnumerable<AggregateResult>> AggregateResults { get; set; }
        public IEnumerable Data { get; set; } 
        public object Errors { get; set; }
    }
}
