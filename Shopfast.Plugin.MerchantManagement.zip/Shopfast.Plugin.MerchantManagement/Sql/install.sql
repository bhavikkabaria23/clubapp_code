﻿IF COL_LENGTH('Sites', 'ParentId') IS NULL
BEGIN
    ALTER TABLE Sites
    ADD ParentId INT
END;
GO

IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'GetAssociatedSites')
                    AND type IN ( N'P', N'PC' ) ) 
BEGIN
DROP PROCEDURE GetAssociatedSites
END

GO
CREATE PROCEDURE GetAssociatedSites
(
    @SiteId int
)
AS
BEGIN
    SET NOCOUNT ON;
	IF NULLIF(@SiteId, '') IS NULL
	BEGIN
        SELECT T1.*,O1.Email as customerEmail FROM Sites as T1
			INNER JOIN [Owners] as O1 on T1.Owner_Id = O1.Id
	END
	ELSE
	BEGIN
		WITH cte AS
		( 
			SELECT T1.* FROM Sites as T1
			WHERE ParentId = @SiteId
			UNION ALL
			SELECT T2.* FROM Sites as T2
			INNER JOIN cte AS C on T2.ParentId = C.Id
		)
		SELECT *,O1.Email as customerEmail FROM cte
			INNER JOIN [Owners] as O1 on cte.Owner_Id = O1.Id;
	END
END
GO
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'sp_GetOrderDetailsOfAllSites')
                    AND type IN ( N'P', N'PC' ) ) 
BEGIN
DROP PROCEDURE sp_GetOrderDetailsOfAllSites
END

GO
CREATE PROCEDURE [dbo].[sp_GetOrderDetailsOfAllSites]
	@ParentSiteId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	SET NOCOUNT ON;

   DECLARE @siteDbName nvarchar(50)
	DECLARE @siteId int
	DECLARE @FINALQUERY nVARCHAR(1000)
	DECLARE @today nVARCHAR(1000)
	DECLARE @week nVARCHAR(1000)
	DECLARE @month nVARCHAR(1000)
	DECLARE @year nVARCHAR(1000)
	DECLARE @all nVARCHAR(1000)
	DECLARE @avgOrder nVARCHAR(1000)
	DECLARE @allTotal decimal(18,0)
	DECLARE @temp nVARCHAR(1000)
	DECLARE @orderCount nVARCHAR(1000)

	create table #tempSite
	(
	siteid int,
	dbname nvarchar(50),
	todayTotal decimal(18,0),
	weekTotal decimal(18,0),
	monthTotal decimal(18,0),
	yearTotal decimal(18,0),
	allTotal decimal(18,0),
	avgOrder decimal(18,0),
	orderCount int
	)

	IF NULLIF(@ParentSiteId, '') IS NULL
	BEGIN
        DECLARE site_cursor CURSOR FOR 
		select id,DbName from Sites

		OPEN site_cursor
		FETCH NEXT FROM site_cursor INTO @siteId,@siteDbName

		WHILE @@FETCH_STATUS = 0
		BEGIN

		Select @temp = @siteDbName
		Set @orderCount = 'select count(*) from [' + @temp + ']..[Order]'
		Set @today = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) = 0' 
		Set @week = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 7' 
		Set @month = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 30' 
		Set @year = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 365' 
		Set @all = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order]'
		Set @avgOrder = 'Select ISNULL(AVG(OrderTotal),0) from [' + @temp + ']..[Order]'
		print @avgOrder
		set @FINALQUERY = 'Select top(1) '''+CONVERT(varchar, @siteId)+''' ,('+@today+') as today, ('+@week+') as week,('+@month+') as month,('+@year+') as year,('+@all+') as Alltime,
		('+@avgOrder+') as AvgOrder,('+@orderCount+') as OrderTotal,
		'''+ @temp + ''' from [' + @temp + ']..[Order]'


		insert into #tempSite(siteid,todayTotal,weekTotal,monthTotal,yearTotal,allTotal,avgOrder,orderCount,dbname) Exec (@finalQuery)

		FETCH NEXT FROM site_cursor INTO @siteId,@siteDbName
		END

		CLOSE site_cursor
		DEALLOCATE site_cursor
	END
	ELSE
	BEGIN
		DECLARE site_cursor CURSOR FOR 
		
		WITH cte AS
		( 
			SELECT T1.* FROM Sites as T1
			WHERE ParentId = @SiteId
			UNION ALL
			SELECT T2.* FROM Sites as T2
			INNER JOIN cte AS C on T2.ParentId = C.Id
		)
		SELECT id,DbName FROM cte

		OPEN site_cursor
		FETCH NEXT FROM site_cursor INTO @siteId,@siteDbName

		WHILE @@FETCH_STATUS = 0
		BEGIN

		Select @temp = @siteDbName
		Set @orderCount = 'select count(*) from [' + @temp + ']..[Order]'
		Set @today = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) = 0' 
		Set @week = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 7' 
		Set @month = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 30' 
		Set @year = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order] 
		where datediff(d,CreatedOnUtc,getdate()) <= 365' 
		Set @all = 'Select ISNULL(SUM(OrderTotal),0) from [' + @temp + ']..[Order]'
		Set @avgOrder = 'Select ISNULL(AVG(OrderTotal),0) from [' + @temp + ']..[Order]'
		print @avgOrder
		set @FINALQUERY = 'Select top(1) '''+CONVERT(varchar, @siteId)+''' ,('+@today+') as today, ('+@week+') as week,('+@month+') as month,('+@year+') as year,('+@all+') as Alltime,
		('+@avgOrder+') as AvgOrder,('+@orderCount+') as OrderTotal,
		'''+ @temp + ''' from [' + @temp + ']..[Order]'


		insert into #tempSite(siteid,todayTotal,weekTotal,monthTotal,yearTotal,allTotal,avgOrder,orderCount,dbname) Exec (@finalQuery)

		FETCH NEXT FROM site_cursor INTO @siteId,@siteDbName
		END

		CLOSE site_cursor
		DEALLOCATE site_cursor

	END
	

	select * from #tempSite 
	drop table #tempSite
END
GO
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'sp_GetAvailableDomains')
                    AND type IN ( N'P', N'PC' ) ) 
BEGIN
DROP PROCEDURE sp_GetAvailableDomains
END
GO
CREATE PROCEDURE [dbo].[sp_GetAvailableDomains]
AS
BEGIN
	
	DECLARE @siteDbName nvarchar(50)
	DECLARE @siteId int
	DECLARE @storeName nvarchar(4000)
	DECLARE @FINALQUERY nVARCHAR(1000)
	DECLARE @temp nVARCHAR(1000)

	create table #tempSite
	(
	siteid int,
	StoreName nvarchar(4000),
	dbname nvarchar(50),
	Hosts nvarchar(1000)
	)

    DECLARE site_cursor CURSOR FOR 
	select id,StoreName,DbName from Sites

	OPEN site_cursor
	FETCH NEXT FROM site_cursor INTO @siteId,@storeName,@siteDbName

	WHILE @@FETCH_STATUS = 0
	BEGIN

	Select @temp = @siteDbName
	set @FINALQUERY = 'Select  '''+CONVERT(varchar, @siteId)+''' as siteid, Hosts,
	'''+ @storeName + ''' as name, '''+ @temp + '''  as dbname from [' + @temp + ']..[Store]'


	insert into #tempSite(siteid, Hosts, StoreName, dbname) Exec (@finalQuery)

	FETCH NEXT FROM site_cursor INTO @siteId,@storeName, @siteDbName
	END

	CLOSE site_cursor
	DEALLOCATE site_cursor
	

	select * from #tempSite 
	drop table #tempSite
END
GO
DECLARE @siteDbName nvarchar(50)
DECLARE @siteId int
DECLARE @storeName nvarchar(4000)
DECLARE @FINALQUERY nVARCHAR(1000)
DECLARE @temp nVARCHAR(1000)


DECLARE site_cursor CURSOR FOR 
select id,StoreName,DbName from Sites

OPEN site_cursor
FETCH NEXT FROM site_cursor INTO @siteId,@storeName,@siteDbName

WHILE @@FETCH_STATUS = 0
BEGIN

Select @temp = @siteDbName
set @FINALQUERY = 'update [' + @temp + ']..[Store]
set hosts=''yourstorename.com, www.yourstorename.com'''

Exec (@finalQuery)

FETCH NEXT FROM site_cursor INTO @siteId,@storeName, @siteDbName
END

CLOSE site_cursor
DEALLOCATE site_cursor


