﻿using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public class BD_OfferingNDAMap : NopEntityTypeConfiguration<BD_OfferingNDA>
    {
        public BD_OfferingNDAMap()
        {
            this.ToTable("BD_OfferingNDA");
            this.HasKey(tr => tr.Id);            
        }
    }
}
