﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiSite.Data
{
    [Table("SiteOrders")]
    public class SiteOrders
    {
        public int Id { get; set; }

        public string StoreName { get; set; }

        public int PackageId { get; set; } // product id as a package

        public int OrderId { get; set; }

        public bool IsActive { get; set; } // indicate active package for a store. only one should active per store                

        public DateTime CreationDate { get; set; }
        public DateTime PlanExpirationDate { get; set; }

    }
}
