﻿using Nop.Core;
using Nop.Web.Controllers;
using Shopfast.Plugin.Custom.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class ErrorController : BasePublicController
    {
        private readonly IWorkflowMessageServiceCustom _workflowMessageServiceCustom;
        private readonly IWorkContext _workContext;
        public ErrorController(IWorkflowMessageServiceCustom workflowMessageServiceCustom,IWorkContext workContext)
        {
            this._workContext = workContext;
            this._workflowMessageServiceCustom = workflowMessageServiceCustom;
        }
        public ActionResult ErrorPage()
        {
            string domain = Request.ServerVariables["SERVER_NAME"];
            string ErrorUrl = "http://" + domain + Request["aspxerrorpath"];

            _workflowMessageServiceCustom.SendErrorHandingMessage(ErrorUrl, _workContext.WorkingLanguage.Id);
            if (HttpContext.Request.IsAjaxRequest())
            {
                var Result = new JsonResult
                {
                    Data = new
                    {
                        // put whatever data you want which will be sent
                        // to the client
                        success = false,
                        error = "Timeout error",
                        message = "sorry, but you were logged out"
                    },
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
                HttpContext.Response.StatusCode = 404;
            }
            return Redirect("/maintanence.html");
        }
    }
}