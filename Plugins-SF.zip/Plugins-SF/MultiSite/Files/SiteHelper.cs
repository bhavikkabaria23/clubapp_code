﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Configuration;
using System.Web.Hosting;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Data;
using MultiSite.Data;
using System.Net.Http;
using System.Net.Http.Headers;
using MultiSite.Models;

namespace Nop.Web.Models.SiteRegistration
{
    public class SiteHelper
    {
        #region Fields

        public static readonly string settingsFilename = "Settings.txt";

        public static readonly string dbFilename = "Nop.Db.sdf";

        public static readonly string App_data_path = HostingEnvironment.MapPath("~/App_Data/");

        public static readonly string templateSettingsFilename =
            Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "TemplateSettings.txt");

        public static readonly string templateDbFilename =
            Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template.sdf");

        public static readonly string defautTemplateMdf =
            Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template.mdf");

        public static readonly string defautTemplateLdf =
            Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template_log.ldf");

        #endregion

        #region Methods

        static string GetTemplateMdf(string templateName)
        {
            return Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), string.Format("{0}.mdf", templateName));
        }

        static string GetTemplateLdf(string templateName)
        {
            return Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), string.Format("{0}_log.ldf", templateName));
        }

        public static void AddToSqlServer(string storeName, string industryType, out string csStoreName)
        {
            if (!string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["templatePath"]) &&
               !string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["newDBPath"]))
            {
                #region New Mehtod of Creasting sub domain DB
                var dbTemplateName = MultisiteHelper.GetDatabaseTemplateName(industryType);
                var templateMdf = GetTemplateMdf(dbTemplateName);
                var templateLdf = GetTemplateLdf(dbTemplateName);
                //if (!File.Exists(templateMdf) || !File.Exists(templateLdf))
                //{
                //    MultiSiteDataProvider.LogToAdminDatabase(string.Format("One of files ({0}) or ({1}) not found. Using default template.", templateMdf, templateLdf));
                //    templateMdf = defautTemplateMdf;
                //    templateLdf = defautTemplateLdf;
                //}

                /* Delete settings file if exists */
                var newStoreSettingsFilename = Path.Combine(App_data_path, string.Format("{0}{1}", storeName, settingsFilename));
                if (File.Exists(newStoreSettingsFilename))
                {
                    File.Delete(newStoreSettingsFilename);
                }

                //var index = 0;
                var backupStoreName = storeName;

                /* Copy template data file (.mdf) */
                //string newMdf;
                //do
                //{
                //    newMdf = Path.Combine(App_data_path, MultisiteHelper.GetDbName(storeName) + ".mdf");
                //    if (File.Exists(newMdf))
                //    {
                //        storeName = string.Format("{0}.{1}", backupStoreName, ++index);
                //    }
                //    else
                //    {
                //        File.Copy(templateMdf, newMdf, true);
                //        break;
                //    }
                //} while (true);

                csStoreName = storeName;

                /* copy template log file (.ldf)*/
                //var newLdf = newMdf.Replace(".mdf", "_log.ldf");
                //File.Copy(templateLdf, newLdf, true);

                using (var dbContext = new Sites4Entities())
                {
                    //var command = dbContext.Database.Connection.CreateCommand();
                    //command.CommandText = "sp_RestoreDatabase_Template";
                    //command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.Add(new SqlParameter("@templatePath", "F:\\websites\\SF_DemoSiteDB\\SF_demo.bak"));
                    //command.Parameters.Add(new SqlParameter("@templateDBLogicalName", "NOP3_70"));
                    //command.Parameters.Add(new SqlParameter("@newDBPath","F:\\websites\\SF_DemoSiteDB"));
                    //command.Parameters.Add(new SqlParameter("@newDBName", "TestDb_db9"));

                    //dbContext.Database.Connection.Open();
                    //var reader = command.ExecuteReader();
                    //string storename = reader[0].ToString();

                    if (!string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["templatePath"]) &&
                       !string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["newDBPath"]))
                    {
                        var result = dbContext.Database.SqlQuery<string>("sp_RestoreDatabase_Template @templatePath,@templateDBLogicalName,@newDBPath,@newDBName",
                                         new SqlParameter("@templatePath", System.Configuration.ConfigurationManager.AppSettings["templatePath"] + dbTemplateName + ".bak"),
                                    new SqlParameter("@templateDBLogicalName", dbTemplateName),
                                    new SqlParameter("@newDBPath", System.Configuration.ConfigurationManager.AppSettings["newDBPath"]),
                                    new SqlParameter("@newDBName", MultisiteHelper.ApplicationName + "_" + storeName)
                                    ).FirstOrDefault();
                        string[] arr = result.Split(new char[] { '_' }, 2);
                        storeName = arr[1];
                    }
                }

                /* Attach new store database (GRANT CREATE ANY DATABASE to MasterCatalog) */
                //            var masterConnectionString = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                //            using (var dbConnection = new SqlConnection(masterConnectionString))
                //            {
                //                dbConnection.Open();
                //                var dbCommand = new SqlCommand(string.Format(@"CREATE DATABASE [{0}_{1}] ON 
                //                        ( FILENAME = N'{2}' ),
                //                        ( FILENAME = N'{3}' )
                //                         FOR ATTACH", MultisiteHelper.ApplicationName, storeName, newMdf, newLdf), dbConnection);
                //                dbCommand.ExecuteNonQuery();
                //                dbConnection.Close();
                //            }

                var settings = CreateStoreSettings(storeName);

                File.WriteAllText(newStoreSettingsFilename, settings);
                #endregion
            }
            else
            {
                #region Old Mehtod of Creasting sub domain DB
                var dbTemplateName = MultisiteHelper.GetDatabaseTemplateName(industryType);
                var templateMdf = GetTemplateMdf(dbTemplateName);
                var templateLdf = GetTemplateLdf(dbTemplateName);
                if (!File.Exists(templateMdf) || !File.Exists(templateLdf))
                {
                    MultiSiteDataProvider.LogToAdminDatabase(string.Format("One of files ({0}) or ({1}) not found. Using default template.", templateMdf, templateLdf));
                    templateMdf = defautTemplateMdf;
                    templateLdf = defautTemplateLdf;
                }

                /* Delete settings file if exists */
                var newStoreSettingsFilename = Path.Combine(App_data_path, string.Format("{0}{1}", storeName, settingsFilename));
                if (File.Exists(newStoreSettingsFilename))
                {
                    File.Delete(newStoreSettingsFilename);
                }

                var index = 0;
                var backupStoreName = storeName;

                /* Copy template data file (.mdf) */
                string newMdf;
                do
                {
                    newMdf = Path.Combine(App_data_path, MultisiteHelper.GetDbName(storeName) + ".mdf");
                    if (File.Exists(newMdf))
                    {
                        storeName = string.Format("{0}.{1}", backupStoreName, ++index);
                    }
                    else
                    {
                        File.Copy(templateMdf, newMdf, true);
                        break;
                    }
                } while (true);

                csStoreName = storeName;

                /* copy template log file (.ldf)*/
                var newLdf = newMdf.Replace(".mdf", "_log.ldf");
                File.Copy(templateLdf, newLdf, true);

                /* Attach new store database (GRANT CREATE ANY DATABASE to MasterCatalog) */
                var masterConnectionString = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                using (var dbConnection = new SqlConnection(masterConnectionString))
                {
                    dbConnection.Open();
                    var dbCommand = new SqlCommand(string.Format(@"CREATE DATABASE [{0}_{1}] ON 
                        ( FILENAME = N'{2}' ),
                        ( FILENAME = N'{3}' )
                         FOR ATTACH", MultisiteHelper.ApplicationName, storeName, newMdf, newLdf), dbConnection);
                    dbCommand.ExecuteNonQuery();
                    dbConnection.Close();
                }

                var settings = CreateStoreSettings(storeName);

                File.WriteAllText(newStoreSettingsFilename, settings);
                #endregion
            }
        }
        public static string GetConnectionString(string storeName)
        {
            return string.Format(@"Data Source={0}{1}{2}; Persist Security Info=False", App_data_path, storeName, dbFilename);
        }

        public static string GetStoreConnectionString(string storeName)
        {
            return string.Format(WebConfigurationManager.ConnectionStrings["StoreCatalog"].ConnectionString, MultisiteHelper.ApplicationName, storeName);
        }

        static string CreateStoreSettings(string storeName)
        {
            return string.Format("DataProvider: sqlserver{0}DataConnectionString: {1}", Environment.NewLine,
                string.Format(WebConfigurationManager.ConnectionStrings["StoreCatalog"].ConnectionString, MultisiteHelper.ApplicationName, storeName));
        }

        public static int AddCloudFareDNS(string storeName)
        {
            try
            {
                string CloudflareApiUrl = System.Configuration.ConfigurationManager.AppSettings["CloudflareApiUrl"];
                string AuthEmail = System.Configuration.ConfigurationManager.AppSettings["AuthEmail"];
                string AuthKey = System.Configuration.ConfigurationManager.AppSettings["AuthKey"];
                string ZoneId = System.Configuration.ConfigurationManager.AppSettings["ZoneId"];
                string DNSContent = System.Configuration.ConfigurationManager.AppSettings["DNSContent"];
                if (!string.IsNullOrEmpty(CloudflareApiUrl) &&
                    !string.IsNullOrEmpty(AuthEmail) &&
                    !string.IsNullOrEmpty(AuthKey) &&
                    !string.IsNullOrEmpty(ZoneId) &&
                    !string.IsNullOrEmpty(DNSContent))
                {
                    using (var client = new HttpClient())
                    {
                        DNSRecord dns = new DNSRecord { type = "A", name = storeName, content = DNSContent,proxied = true };
                        client.BaseAddress = new Uri(CloudflareApiUrl);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Add("X-Auth-Email", AuthEmail);
                        client.DefaultRequestHeaders.Add("X-Auth-Key", AuthKey);
                        var response = client.PostAsJsonAsync("zones/" + ZoneId + "/dns_records", dns).Result;
                        if (response.IsSuccessStatusCode)
                        {
                            return 1;
                        }
                        else
                            return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Remove sub domain from cloud flare using API
        public static int DeleteCloudFareDNS(string storeName)
        {
            try
            {
                string CloudflareApiUrl = System.Configuration.ConfigurationManager.AppSettings["CloudflareApiUrl"];
                string AuthEmail = System.Configuration.ConfigurationManager.AppSettings["AuthEmail"];
                string AuthKey = System.Configuration.ConfigurationManager.AppSettings["AuthKey"];
                string ZoneId = System.Configuration.ConfigurationManager.AppSettings["ZoneId"];
                string DNSContent = System.Configuration.ConfigurationManager.AppSettings["DNSContent"];
                if (!string.IsNullOrEmpty(CloudflareApiUrl) &&
                    !string.IsNullOrEmpty(AuthEmail) &&
                    !string.IsNullOrEmpty(AuthKey) &&
                    !string.IsNullOrEmpty(ZoneId) &&
                    !string.IsNullOrEmpty(DNSContent))
                {
                    using (var client = new HttpClient())
                    {                        
                        client.BaseAddress = new Uri(CloudflareApiUrl);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Add("X-Auth-Email", AuthEmail);
                        client.DefaultRequestHeaders.Add("X-Auth-Key", AuthKey);
                        var response = client.GetAsync("zones/" + ZoneId + "/dns_records").Result;
                        if (response.IsSuccessStatusCode)
                        {
                            var dnsRecords = response.Content.ReadAsAsync<DNSResult>().Result.result;
                            var dns = dnsRecords.SingleOrDefault(r => r.name.ToLower() == storeName.ToLower()+"."+MultisiteHelper.Domain);
                            if(dns != null)
                            {
                                var response2 = client.DeleteAsync("zones/" + ZoneId + "/dns_records/"+dns.id).Result;
                                if (response.IsSuccessStatusCode)
                                {
                                    return 1;
                                }
                            }
                            return 0;
                        }
                        else
                            return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        #endregion







        /*
                internal static void SaveCustomizedTheme(string themeName, string cssCode, bool overwrite, string storeUrl) {
                    //new or edited?
                    var themeProvider = EngineContext.Current.Resolve<Nop.Web.Framework.Themes.IThemeProvider>();
                    var themeContext = EngineContext.Current.Resolve<Nop.Web.Framework.Themes.IThemeContext>();
                    var currentTheme = themeProvider.GetThemeConfiguration(themeContext.WorkingDesktopTheme);
                    var possibleSavedTheme = themeProvider.GetThemeConfigurations()
                        //do not display themes for mobile devices
                        .Where(x => !x.MobileTheme)
                        .Where(x => x.Stores.Split(',').Select(s => s.Trim().ToLower()).Contains(MultisiteHelper.currentUrl.ToLower()))
                        .Where(x => x.ThemeTitle.Equals(themeName, StringComparison.InvariantCultureIgnoreCase));

                    var themeIsNew = !possibleSavedTheme.Any();
                    //!string.Equals(themeName, currentThemeName, StringComparison.InvariantCultureIgnoreCase);

                    //find/create dirs
                    var newName = "";
                    var dirTheme = themeIsNew ?
                        HostingEnvironment.MapPath("~/Themes/" + 
                         (newName = CreateUniqueThemeName(themeName, MultisiteHelper.currentUrl))
                        )
                        : possibleSavedTheme.First().Path;
                    var dirContent = string.Format("{0}\\Content", dirTheme);
                    var dirViews = string.Format("{0}\\Views", dirTheme);
                    var dirViewsShared = string.Format("{0}\\Views\\Shared", dirTheme);
                    //var dirCurrentTheme = string.Format("{0}/Views/Shared", dirTheme);
                    //if (Directory.Exists(dirTheme) && !overwrite) {
                    //    throw new ApplicationException("Theme already exists");
                    //}
                    //if (!Directory.Exists(dirCurrentTheme)) {
                    //    throw new ApplicationException(string.Format("Theme {0} not found", currentThemeName));
                    //}
                    foreach (var dir in new[] { dirTheme, dirContent, dirViews, dirViewsShared }) {
                        if (!Directory.Exists(dir)) {
                            Directory.CreateDirectory(dir);
                        }
                    }

                    //write css
                    File.WriteAllText(dirContent + "\\styles.css", cssCode);

                    if (themeIsNew) {
                        //write theme.config
                        var baseTheme = currentTheme.BaseTheme;
                        var dirBaseTheme = "";
                        if (string.IsNullOrEmpty(baseTheme)) { //current theme is a base theme
                            baseTheme = Path.GetFileName(currentTheme.Path);
                            dirBaseTheme = string.Format(@"~/Themes/{0}", Path.GetFileName(currentTheme.Path));
                        }
                        else {
                            dirBaseTheme = string.Format(@"~/Themes/{0}", baseTheme);
                        }

                        File.WriteAllText(dirTheme + "\\theme.config", string.Format(@"<?xml version='1.0' encoding='utf-8' ?>
        <Theme title='{0}'
               supportRTL='false'
               mobileTheme='false'
               previewText='This is the ""{0}"" site theme.'
               stores='{1}' baseTheme='{2}' > 
        </Theme>", themeName, storeUrl, baseTheme));

                        //write Head.cshtml
                        File.WriteAllText(dirViewsShared + "\\Head.cshtml", string.Format(@"@using Nop.Web.Framework;
        @{{
            Html.AppendCssFileParts(Url.Content(""~/Themes/{0}/Content/styles.css""));
            Html.AppendCssFileParts(Url.Content(""{1}/Content/styles.css""));
        }}", newName, dirBaseTheme));

                        //write web.config
                        File.Copy(Path.Combine(currentTheme.Path, "Views", "web.config"), 
                            Path.Combine(dirViews, "web.config"));
                    }

                }
                */

        //internal static void SaveCustomizedTheme(string themeName, string cssCode, bool overwrite, string storeUrl) {
        //    throw new NotImplementedException();
        //}        
    }
}