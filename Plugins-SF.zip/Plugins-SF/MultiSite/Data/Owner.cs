﻿namespace MultiSite.Data
{
    public class Owner
    {
        public int Id { get; set; }

        public string email { get; set; }

        public string industryType { get; set; }

        public string firstName { get; set; }

        public string LastName { get; set; }

        public string phone { get; set; }

        public string description { get; set; }

        public string starting { get; set; }

        public string Country { get; set; }

        public string Website { get; set; }

        //Multisite_NewField_change        
        public string StreetAddress { get; set; }
        
        public string City { get; set; }
        
        public string ZipPostalCode { get; set; }
        
        public string State { get; set; }

        // Free trial integration in new page
        public string AvgSaleAmout { get; set; }

        public string ProcessorName { get; set; }

        public string ProcessorEmail { get; set; }

        public string ProcessorPhoneNumber { get; set; }
        //------------------------------------

        //--------------------------------------
    }
}
