﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace MultiSite.Data
{
    public class Sites4Entities : DbContext
    {
        public Sites4Entities() : base("MultisiteCatalog") { }

        public DbSet<Site> Sites { get; set; }

        public DbSet<Owner> Owners { get; set; }

        public DbSet<Package> Packages { get; set; }

        public DbSet<SitesTheme> SitesThemes { get; set; }

        public DbSet<SitesPlugins> SitesPlugins { get; set; }        

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
        }
    }
}
