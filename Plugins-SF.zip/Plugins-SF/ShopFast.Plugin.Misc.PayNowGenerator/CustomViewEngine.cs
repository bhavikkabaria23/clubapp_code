﻿using Nop.Web.Framework.Themes;

namespace Nop.Plugin.Misc.PayNowGenerator
{
    public class CustomViewEngine : ThemeableRazorViewEngine
    {
        public CustomViewEngine()
        {
            ViewLocationFormats = new[] { "~/Plugins/Misc.PayNowGenerator/Views/MiscPayNowGenerator/{0}.cshtml" };
            PartialViewLocationFormats = new[] { "~/Plugins/Misc.PayNowGenerator/Views/MiscPayNowGenerator/{0}.cshtml" };
           
        }
    }
}
