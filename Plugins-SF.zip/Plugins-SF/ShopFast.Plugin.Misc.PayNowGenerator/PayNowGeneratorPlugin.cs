﻿using System.Collections.Generic;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Localization;
using System.Web.Routing;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.PayNowGenerator
{
    public class PayNowGeneratorPlugin : BasePlugin, IMiscPlugin
    {
        #region Fileds
        private readonly ILocalizationService _localizationService;
        private readonly ILanguageService _languageService;
        #endregion

        #region Constructor
        public PayNowGeneratorPlugin(ILocalizationService localizationService, ILanguageService languageService)
        {
            this._localizationService = localizationService;
            this._languageService = languageService;
        }
        #endregion 
        
        #region Methods
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "MiscPayNowGenerator";
            routeValues = new RouteValueDictionary()
            {
                { "Namespaces", "Nop.Plugin.Misc.PayNowGenerator.Controllers" }, 
                { "area", null }
            };
        }

        public bool Authenticate()
        {
            return true;
        }

        public static void SetDefaultSettings()
        {
            foreach (var localeResource in GetLocaleResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localeResource.Key, localeResource.Value);
            }
        }

        private static Dictionary<string, string> GetLocaleResources()
        {
            return new Dictionary<string, string>
            {
                {"Plugin.Misc.PayNowGenerator", "Pay Now Generator"},
                {"Plugin.Misc.PayNowGenerator.ButtonGenerator", "Button generator"},
                {"Plugin.Misc.PayNowGenerator.PayNow", "Pay now"},
                {"Plugin.Misc.PayNowGenerator.Title", "Here you can create shortcodes for payment buttons."},
                {"Plugin.Misc.PayNowGenerator.ButtonDesign", "Button design: "},
                {"Plugin.Misc.PayNowGenerator.ButtonText", "Button text: "},
                {"Plugin.Misc.PayNowGenerator.ShowPrice", "Show price: "},
                {"Plugin.Misc.PayNowGenerator.GenerateButton", "Generate button"},
                {"Plugin.Misc.PayNowGenerator.ReadyButton", "Select button style"},
                {"Plugin.Misc.PayNowGenerator.SelectBackgroundColor", "Select background color"},
                {"Plugin.Misc.PayNowGenerator.SelectTextColor", "Select text color"},
                {"Plugin.Misc.PayNowGenerator.SelectButtonSize", "Select button size"},
                {"Plugin.Misc.PayNowGenerator.SelectButtonStyle", "Select button style"},
                {"Plugin.Misc.PayNowGenerator.Icon", "Icon"},
                {"Plugin.Misc.PayNowGenerator.Icons", "Icons"},
                {"Plugin.Misc.PayNowGenerator.Position", "Position"},
                {"Plugin.Misc.PayNowGenerator.Left", "Left"},
                {"Plugin.Misc.PayNowGenerator.Right", "Right"},
                {"Plugin.Misc.PayNowGenerator.Preview", "Preview: "},
                {"Plugin.Misc.PayNowGenerator.ClickToCopy", "Click to copy"},
                {"Plugin.Misc.PayNowGenerator.DefaultSettings", "Default Settings"},
            };
        }

        public override void Install()
        {
            SetDefaultSettings();

            base.Install();
        }

        public override void Uninstall()
        {
            foreach (var localeResource in GetLocaleResources())
            {
                this.DeletePluginLocaleResource(localeResource.Key);
            }

            base.Uninstall();
        }
        #endregion
    }
}
