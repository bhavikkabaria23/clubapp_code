﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Seo;
using Nop.Core.Domain.Vendors;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Seo;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Services.Vendors;
using Nop.Web.Controllers;
using Nop.Web.Framework.Controllers;

namespace ShopFast.Plugin.Misc.PayNowGenerator.Controllers
{
    /// <summary>
    /// Class MiscPayNowGenerator
    /// Class contains methods for generating Pay Now button 
    /// and adding products to cart
    /// </summary>
    [AdminAuthorize]
    public class MiscPayNowGeneratorController : BasePluginController
    {
        #region Fileds
        private readonly IProductService _productService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IShoppingCartService _shoppingCartService;

        #endregion

        #region Constructor
        public MiscPayNowGeneratorController(IProductService productService,
            IStoreContext storeContext,
            IWorkContext workContext,
            IShoppingCartService shoppingCartService
           )
        {
            this._productService = productService;
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._shoppingCartService = shoppingCartService;
            this._productService = productService;
            this._workContext = workContext;
            this._storeContext = storeContext;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Contain configuration for the plugin
        /// </summary>
        /// <returns>Configuration for the plugin</returns>
        public ActionResult Configure()
        {
            return View("~/Plugins/ShopFast.Misc.PayNowGenerator/Views/MiscPayNowGenerator/Configure.cshtml");
        }

        [HttpPost, ActionName("Configure")]
        [ChildActionOnly]
        [FormValueRequired("default-settings")]
        public ActionResult DefaultSettings()
        {
            PayNowGeneratorPlugin.SetDefaultSettings();
            return Configure();
        }

        /// <summary>
        /// Generate Pay Now button
        /// </summary>
        /// <returns>Workspace for generating Pay Now button</returns>
        public ActionResult Generate()
        {
            ViewBag.Url = TabstripEvent.GetAddress();
            return View("~/Plugins/ShopFast.Misc.PayNowGenerator/Views/MiscPayNowGenerator/Generate.cshtml");

        }

        /// <summary>
        /// Add a concrete product to the cart after clicking on Pay Now Button
        /// </summary>
        /// <param name="productId">The identifier of the product</param>
        /// <returns>Shopping cart, or the page with the product's attributes if it has attributes</returns>
     
        public ActionResult AddToCart(int productId)
        {
            var product = _productService.GetProductById(productId);

            decimal customerEnteredPriceConverted = decimal.Zero;
            DateTime? rentalStartDate = null;
            DateTime? rentalEndDate = null;
            var warnings = _shoppingCartService.AddToCart(_workContext.CurrentCustomer,
                                           product, ShoppingCartType.ShoppingCart, _storeContext.CurrentStore.Id,
                                           null, customerEnteredPriceConverted,
                                           rentalStartDate, rentalEndDate, 1, true);
         if (warnings.Count != 0)
         {
             var seName = product.GetSeName();
        
             return RedirectToRoute("Product", new { SeName = seName });
         }
            return RedirectToRoute("ShoppingCart");
        }

        protected virtual ActionResult InvokeHttp404()
        {
            // Call target Controller and pass the routeData.
            IController errorController = EngineContext.Current.Resolve<CommonController>();

            var routeData = new RouteData();
            routeData.Values.Add("controller", "Common");
            routeData.Values.Add("action", "PageNotFound");

            errorController.Execute(new RequestContext(this.HttpContext, routeData));

            return new EmptyResult();
        }
        #endregion
    }
}