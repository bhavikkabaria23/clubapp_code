﻿using System;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Web.Framework.Events;

namespace ShopFast.Plugin.Misc.PayNowGenerator
{
    internal class TabstripEvent : IConsumer<AdminTabStripCreated>
    {
        public static string address;
        private readonly ILocalizationService _localizationService;

        public TabstripEvent(ILocalizationService localizationService)
        {
            this._localizationService = localizationService;
        }

        public void HandleEvent(AdminTabStripCreated eventMessage)
        {
            if (eventMessage.TabStripName == "product-edit")
            {
                string url = "/MiscPayNowGeneratorController/Generate";
                string tabName = _localizationService.GetResource("Plugin.Misc.PayNowGenerator");

                var sb = new StringBuilder();

                int id = Convert.ToInt32(System.Web.HttpContext.Current.Request.RequestContext.RouteData.Values["ID"]);
                address = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + "/product?productId=" + id;
                sb.Append("<script src=\"/Plugins/ShopFast.Misc.PayNowGenerator/Script/angular.min.js\" type=\"text/javascript\"></script>");
                sb.Append("<link href=\"/Plugins/ShopFast.Misc.PayNowGenerator/Content/style.css\" rel=\"stylesheet\" />");
                sb.Append("<link href=\"/Plugins/ShopFast.Misc.PayNowGenerator/Content/buttons.css\" rel=\"stylesheet\" />");
                sb.Append("<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css\" rel=\"stylesheet\" />");
                sb.Append("<script language=\"javascript\" type=\"text/javascript\">");
                sb.Append(Environment.NewLine);

                var tabTitle =
                    $@"<li class=""""><a data-tab-name=""tab-paynow-generator""data-toggle=""tab"" href=""#tab-paynow-generator"" aria-expanded=""false"">{tabName}</a></li>";
                var tabContent = @"<div class=""tab-pane"" id=""tab-paynow-generator""></div>";
                //{ text: """ + tabName + @""", contentUrl: """ + url + @""" }

                sb.Append("$(document).ready(function () {");
                sb.Append(Environment.NewLine);
                //sb.Append("var kTabs = $('#product-edit').data('kendoTabStrip');");
                //sb.Append(Environment.NewLine);
                //sb.Append(" kTabs.append({ text: \"" + tabName + "\", contentUrl: \"" + url + "\" });");
                //sb.Append(Environment.NewLine);
                //sb.Append(" $('.k-link').css('font-weight','bold');");
                //sb.Append(Environment.NewLine);
                sb.Append($"$('#product-edit>ul.nav-tabs').append('{tabTitle}')");
                sb.Append(Environment.NewLine);
                sb.Append($"$('#product-edit>.tab-content').append('{tabContent}')");
                sb.Append(Environment.NewLine);

                sb.Append("$.get('" + url + "', function(result) {");
                sb.Append(Environment.NewLine);
                sb.Append("$('#tab-paynow-generator').append(result);");
                sb.Append(Environment.NewLine);
                sb.Append("});");
                sb.Append(Environment.NewLine);

                sb.Append("});");
                sb.Append(Environment.NewLine);
                sb.Append("</script>");
                sb.Append(Environment.NewLine);
                eventMessage.BlocksToRender.Add(MvcHtmlString.Create(sb.ToString()));
            }
        }

        public static string GetAddress()
        {
            return address;
        }

    }
}
