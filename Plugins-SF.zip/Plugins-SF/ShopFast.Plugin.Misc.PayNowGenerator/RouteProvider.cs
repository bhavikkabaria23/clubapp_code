﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace ShopFast.Plugin.Misc.PayNowGenerator
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.Misc.PayNowGenerator.Generate",
                 "MiscPayNowGeneratorController/Generate",
                 new { controller = "MiscPayNowGenerator", action = "Generate" },
                 new[] { "Nop.Plugin.Misc.PayNowGenerator.Controllers" }
            );

            routes.MapRoute("Plugin.Misc.PayNowGenerator.Configure",
                   "PayNowGenerator/Configure",
                   new { controller = "MiscPayNowGenerator", action = "Configure" },
                   new[] { "Nop.Plugin.Misc.PayNowGenerator.Controllers" }
              );

            routes.MapRoute("Plugin.Misc.PayNowGenerator.AddToCart",
                   "product/{productId}",
                   new
                   {
                       controller = "MiscPayNowGenerator",
                       action = "AddToCart",
                       productId = UrlParameter.Optional
                   },
                   new[] { "Nop.Plugin.Misc.PayNowGenerator.Controllers" }
              );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
