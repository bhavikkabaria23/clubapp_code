﻿using Nop.Core.Configuration;

namespace Shopfast.Plugin.Widget.Donation
{
    public class DonationSettings : ISettings
    {
        public string WidgetZone { get; set; }

        public bool AddressEnabled { get; set; }

        public bool FaxPhoneEnabled { get; set; }
    }
}
