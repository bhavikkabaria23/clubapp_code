﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.Widget.Donation
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Shopfast.Plugin.Widget.Donation.Configure",
                           "Plugins/WidgetDonation/Configure",
                           new { controller = "WidgetDonation", action = "Configure" },
                           new[] { "Shopfast.Plugin.Widget.Donation.Controllers" }
                      );

            routes.MapRoute("Shopfast.Plugin.Widget.Donation.AjaxOrderSummary",
               "Donation/Ajax/AjaxOrderSummary",
               new { controller = "WidgetDonation", action = "AjaxOrderSummary" },
               new[] { "Shopfast.Plugin.Widget.Donation.Controllers" });

            routes.MapRoute("Shopfast.Plugin.Widget.Donation.AjaxGetStatesByCountryId",
               "Donation/Ajax/AjaxGetStatesByCountryId",
               new { controller = "WidgetDonation", action = "AjaxGetStatesByCountryId" },
               new[] { "Shopfast.Plugin.Widget.Donation.Controllers" });
            
            ViewEngines.Engines.Insert(0, new CustomViewEngine());
        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
