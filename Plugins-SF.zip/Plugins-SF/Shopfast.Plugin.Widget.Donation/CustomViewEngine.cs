﻿using Nop.Web.Framework.Themes;

namespace Shopfast.Plugin.Widget.Donation
{
    public class CustomViewEngine : ThemeableRazorViewEngine
    {
        public CustomViewEngine()
        {
            ViewLocationFormats = new[] { "~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/{0}.cshtml" };
            PartialViewLocationFormats = new[] {"~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/{0}.cshtml"};
        }
    }
}
