﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Widget.Donation.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugin.Widget.Donation.WidgetZone")]
        public string WidgetZone { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Donation.Address")]
        public bool AddressEnabled { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Donation.FaxPhone")]
        public bool FaxPhoneEnabled { get; set; }
    }
}
