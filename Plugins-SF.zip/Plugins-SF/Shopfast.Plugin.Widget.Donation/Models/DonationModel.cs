﻿using System.Collections.Generic;
using Nop.Admin.Models.Orders;
using Nop.Web.Models.Common;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using Nop.Web.Models.ShoppingCart;

namespace Shopfast.Plugin.Widget.Donation.Models
{
    public class DonationModel : BaseNopModel
    {
        public DonationModel()
        {
            ShippingMethods = new List<CheckoutShippingMethodModel.ShippingMethodModel>();
            ExistingBillingAddresses = new List<AddressModel>();
            ExistingShippingAddresses = new List<AddressModel>();

            Warnings = new List<string>();
            WarningsPayment = new List<string>();
            WarningsShipping = new List<string>();

            ProductAttributes = new List<Nop.Web.Models.Catalog.ProductDetailsModel.ProductAttributeModel>();
        }

        public ShoppingCartModel ShoppingCart { get; set; }

        public string GetViewPath(string viewname)
        {
            // todo
            return "~/Plugins/Misc.QuickCheckout/Views/QuickCheckout/" + viewname + ".cshtml";
        }

        public int CyclePeriodId { get; set; }
        public bool IsRecurringPayment { get; set; }
        public ProductDetailsModel.AddToCartModel AddToCart { get; set; }
        public int ProductId { get; set; }

        [NopResourceDisplayName("Plugin.Widget.DonationDetails.Sum")]
        public decimal Sum { get; set; }
       
        public AddressModel BillingAddress { get; set; }
        public AddressModel ShippingAddress { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.ShippingOption")]
        public string Shippingoption { get; set; }

        public IList<CheckoutShippingMethodModel.ShippingMethodModel> ShippingMethods { get; set; }
        public IList<CheckoutPaymentMethodModel.PaymentMethodModel> PaymentMethods { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.WidgetDonation.ExistingBillingAddresses")]
        public IList<AddressModel> ExistingBillingAddresses { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.WidgetDonation.ExistingShippingAddresses")]
        public IList<AddressModel> ExistingShippingAddresses { get; set; }

        public bool ShowProductImages { get; set; }
        public bool IsEditable { get; set; }
        public bool IsArsUa { get; set; }
        public bool IsGuest { get; set; }
        public bool IsShowHint { get; set; }
        public bool IsAllowCustomerToWriteComment { get; set; }
        public bool TermsOfServiceOnOrderConfirmPage { get; set; }
        public bool isPaymentWorkflowRequired { get; set; }
        public bool RequiresShipping { get; set; }
        public bool AllowUseBillingAddress { get; set; }
        public bool AllowToSelectTheAddress { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.WidgetDonation.CustomerComment")]
        public string CustomerComment { get; set; }
        public string MinOrderTotalWarning { get; set; }
        public string CheckoutAttributeInfo { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.WidgetDonation.UseDifferentAddressForBilling")]
        public bool UseDifferentAddressForBilling { get; set; }
        public bool UseRewardPoints { get; set; }

        public IList<string> Warnings { get; set; }
        public IList<string> WarningsPayment { get; set; }
        public IList<string> WarningsShipping { get; set; }
        public bool DisplayRewardPoints { get; set; }
        public string RewardPointsAmount { get; set; }
        //nop3.7 upgrade begin
        //public int RewardPointsBalance { get; set; }
        //nop3.7 upgrade end

        [NopResourceDisplayName("ShopFast.Plugins.WidgetDonation.PaymentMethod")]
        public string Paymentmethod { get; set; }

        public IList<Nop.Web.Models.Catalog.ProductDetailsModel.ProductAttributeModel> ProductAttributes { get; set; }

        public class FixedAdressModel : BaseNopModel
        {
            public string Name { get; set; }
            public bool Selected { get; set; }
        }

    }
}
