﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Extensions;
using Nop.Web.Framework.Controllers;
using Nop.Web.Models.Common;
using Nop.Web.Models.ShoppingCart;
using Shopfast.Plugin.Widget.Donation.Models;
using ShopFast.Plugin.Misc.Core.Services;
using MappingExtensions = Nop.Admin.Extensions.MappingExtensions;
using Nop.Web.Controllers;
using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;

namespace Shopfast.Plugin.Widget.Donation.Controllers
{
    public class WidgetDonationController : BasePluginController
    {
        #region Fields
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ILocalizationService _localizationService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IPaymentService _paymentService;
        private readonly IPluginFinder _pluginFinder;
        private readonly ILogger _logger;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IAddressAttributeFormatter _addressAttributeFormatter;

        private readonly OrderSettings _orderSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly PaymentSettings _paymentSettings;
        private readonly AddressSettings _addressSettings;
        private readonly PrepareCheckoutModels _prepareCheckoutModels;
        private readonly PrepareShoppingCartModels _prepareShoppingCartModels;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly IProductService _productService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IWebHelper _webHelper;
        private readonly IPermissionService _permissionService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IOrderService _orderService;
        private readonly IRepository<RecurringPayment> _recurringPaymentRepository;
        //nop3.7 upgrade begin
        private readonly IRewardPointService _rewardPointService;
        //nop3.7 upgrade end

        #endregion

        #region Constr
        public WidgetDonationController(IWorkContext workContext,
            IStoreContext storeContext,
            ILocalizationService localizationService,
            IOrderProcessingService orderProcessingService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            ICurrencyService currencyService,
            IPaymentService paymentService,
            IPluginFinder pluginFinder,
            ILogger logger,
            IAddressAttributeParser addressAttributeParser,
            IAddressAttributeService addressAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            OrderSettings orderSettings,
            RewardPointsSettings rewardPointsSettings,
            PaymentSettings paymentSettings,
            AddressSettings addressSettings,
            PrepareCheckoutModels prepareCheckoutModels,
            PrepareShoppingCartModels prepareShoppingCartModels,
            IStoreService storeService,
            ISettingService settingService,
            IProductService producrService,
            IShoppingCartService shoppingCartService,
            IWebHelper webHelper,
            IPermissionService permissionService,
            ICurrencyService currencyService1,
            IPriceFormatter priceFormatter, 
            IOrderService orderService, 
            IRepository<RecurringPayment> recurringPaymentRepository, 
            IRewardPointService rewardPointService)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _orderProcessingService = orderProcessingService;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _paymentService = paymentService;
            _pluginFinder = pluginFinder;
            _logger = logger;
            _addressAttributeParser = addressAttributeParser;
            _addressAttributeService = addressAttributeService;
            _addressAttributeFormatter = addressAttributeFormatter;

            _orderSettings = orderSettings;
            _rewardPointsSettings = rewardPointsSettings;
            _paymentSettings = paymentSettings;
            _addressSettings = addressSettings;
            _settingService = settingService;
            _storeService = storeService;
            _prepareCheckoutModels = prepareCheckoutModels;
            _prepareShoppingCartModels = prepareShoppingCartModels;
            _productService = producrService;
            _shoppingCartService = shoppingCartService;
            _webHelper = webHelper;
            _permissionService = permissionService;
            _currencyService = currencyService1;
            _priceFormatter = priceFormatter;
            _orderService = orderService;
            _recurringPaymentRepository = recurringPaymentRepository;
            _rewardPointService = rewardPointService;
        }

        #endregion

        #region Utilites

        //[NonAction]
        //protected Product GetDonationProduct()
        //{
        //    var product = _productService.GetProductBySku("ShopFast.Plugins.Widget.Donation.DonationProduct");
        //    if (product == null)
        //        _logger.Warning("Donation: product couldn't be found");
        //    return product;
        //}

        [NonAction]
        protected IList<ShoppingCartItem> GetShoppingCart(int? productId = null)
        {
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci =>
                    sci.ShoppingCartType == ShoppingCartType.ShoppingCart
                    && (!productId.HasValue || sci.ProductId == productId))
                .LimitPerStore(_storeContext.CurrentStore.Id * 2)
                .ToList();
            return cart;
        }

        #endregion

        #region Configure

        [AdminAuthorize]
        public ActionResult Configure()
        {
            var storeScope = GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var settings = _settingService.LoadSetting<DonationSettings>(storeScope);

            var model = new ConfigurationModel()
            {
                WidgetZone = settings.WidgetZone,
                AddressEnabled = settings.AddressEnabled,
                FaxPhoneEnabled = settings.FaxPhoneEnabled
            };

            return View("~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [FormValueRequired("save-settings")]
        public ActionResult Configure(ConfigurationModel model)
        {
            var storeScope = GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var pluginSettings = _settingService.LoadSetting<DonationSettings>(storeScope);

            pluginSettings.WidgetZone = model.WidgetZone;
            _settingService.SaveSetting(pluginSettings, t => t.WidgetZone);

            pluginSettings.AddressEnabled = model.AddressEnabled;
            _settingService.SaveSetting(pluginSettings, t => t.AddressEnabled);

            pluginSettings.FaxPhoneEnabled = model.FaxPhoneEnabled;
            _settingService.SaveSetting(pluginSettings, t => t.FaxPhoneEnabled);

            _settingService.ClearCache();
            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }

        [HttpPost, ActionName("Configure")]
        [AdminAuthorize]
        [ChildActionOnly]
        [FormValueRequired("default-settings")]
        public ActionResult DefaultSettings()
        {
            DonationPlugin.SetDefaultSettings();
            return Configure();
        }

        #endregion

        #region Method_for_donation

        public ActionResult PublicInfo(string widgetZone, ProductDetailsModel additionalData = null)
        {
            try
            {
                var model = PrepareDonationModel(Convert.ToInt32(additionalData.Id));
                model.ProductAttributes = additionalData.ProductAttributes;
                UpdateForm(model);
                return View("~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/DonationPublicInfo.cshtml", model);
            }
            catch (Exception exc)
            {

            }
            return null;
        }

        [HttpPost]
        public ActionResult PublicInfo(DonationModel model, FormCollection form)
        {
            try
            {
                if (SaveAddress(form) == null)
                {
                    throw new Exception("Address is empty");
                }

                if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                {
                    model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.DonationPayment.AnonymousNotAllowed"));
                    throw new Exception("Anonymous checkout is not allowed");
                }

                var product = _productService.GetProductById(model.ProductId);

                //prevent 2 orders being placed within an X seconds time frame
                if (!_prepareCheckoutModels.IsMinimumOrderPlacementIntervalValid(_workContext.CurrentCustomer))
                {
                    model.Warnings.Add(_localizationService.GetResource("Checkout.MinOrderPlacementInterval"));
                    throw new Exception(_localizationService.GetResource("Checkout.MinOrderPlacementInterval"));
                }

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(model.Paymentmethod);
                if (paymentMethod == null)
                {
                    model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.DonationPayment.PaymentMethodNotSelected"));
                    throw new Exception("Payment method is not selected");
                }

                var paymentControllerType = paymentMethod.GetControllerType();
                var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as BasePaymentController;
                if (paymentController == null)
                    throw new Exception("Payment controller cannot be loaded");

                var warnings = paymentController.ValidatePaymentForm(form);
                foreach (var warning in warnings)
                    ModelState.AddModelError("DonationPaymentInfo", warning);

                model.WarningsPayment = warnings;

                if (warnings.Count > 0)
                {
                    model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.DonationPayment.IncorrectPaymentInfo"));
                    throw new Exception("Payment information is not entered correctly");
                }

                // place order
                var cart = GetShoppingCart(model.ProductId);

                var processPaymentRequest = paymentController.GetPaymentInfo(form);

                if (processPaymentRequest == null)
                {
                    //Check whether payment workflow is required
                    if (_prepareCheckoutModels.IsPaymentWorkflowRequired(cart))
                    {
                        model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.DonationPayment.NotEnteredPaymentInfo"));
                        throw new Exception("Payment information is not entered");
                    }
                    processPaymentRequest = new ProcessPaymentRequest();
                }

                processPaymentRequest.RecurringCyclePeriod = (RecurringProductCyclePeriod)model.CyclePeriodId;
                processPaymentRequest.RecurringTotalCycles = model.IsRecurringPayment ? product.RecurringTotalCycles : 1;
                processPaymentRequest.RecurringCycleLength = product.RecurringCycleLength;
                processPaymentRequest.StoreId = _storeContext.CurrentStore.Id * 2;
                processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
                processPaymentRequest.PaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                    SystemCustomerAttributeNames.SelectedPaymentMethod,
                    _genericAttributeService, _storeContext.CurrentStore.Id);
                processPaymentRequest.OrderTotal = model.Sum;
                //processPaymentRequest.IsRecurringPayment = model.IsRecurringPayment;

                foreach (var cartItem in cart)
                {
                    _shoppingCartService.DeleteShoppingCartItem(cartItem);
                }

                AddToCart(model.Sum, model.ProductId);
                var placeOrderResult = _orderProcessingService.PlaceOrder(processPaymentRequest);

                if (placeOrderResult.Success)
                {
                    var postProcessPaymentRequest = new PostProcessPaymentRequest
                    {
                        Order = placeOrderResult.PlacedOrder
                    };

                    var recurringPayment = _recurringPaymentRepository.Table
                        .FirstOrDefault(rc => rc.InitialOrderId == placeOrderResult.PlacedOrder.Id);
                    if (recurringPayment != null)
                    {
                        recurringPayment.CyclePeriodId = model.CyclePeriodId;
                        switch (model.CyclePeriodId)
                        {
                            case 0: //Daily
                                recurringPayment.CyclePeriodId = 0;
                                recurringPayment.CycleLength = 1;
                                break;
                            case 10://Monthly
                                recurringPayment.CyclePeriodId = 20;
                                recurringPayment.CycleLength = 1;
                                break;
                            case 20: //Quarterly
                                recurringPayment.CyclePeriodId = 20;
                                recurringPayment.CycleLength = 3;
                                break;
                            case 30: //Annually
                                recurringPayment.CyclePeriodId = 30;
                                recurringPayment.CycleLength = 1;
                                break;
                            default:
                                recurringPayment.CycleLength = 1;
                                break;
                        }

                        _orderService.UpdateRecurringPayment(recurringPayment);
                    }

                    if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                    {
                        //redirect
                        CompleteRedirectionPayment(placeOrderResult.PlacedOrder);
                    }

                    _paymentService.PostProcessPayment(postProcessPaymentRequest);

                    var checkoutModel = new CheckoutCompletedModel
                   {
                       OrderId = postProcessPaymentRequest.Order.Id
                   };

                    return View("~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/DonationConfirm.cshtml", checkoutModel);
                }

                // error
                foreach (var error in placeOrderResult.Errors)
                    model.Warnings.Add(error);

                model = PrepareDonationModel(model.ProductId, model.Warnings, model.WarningsPayment, model.WarningsShipping);
                UpdateForm(model);
                return View("DonationPublicInfo", model);
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);

                model.Warnings.Add(exc.Message);
                model = PrepareDonationModel(model.ProductId, model.Warnings, model.WarningsPayment, model.WarningsShipping);
                UpdateForm(model);
                return View("DonationPublicInfo", model);
            }
        }

        public ActionResult CompleteRedirectionPayment(Order order)
        {
            try
            {
                if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                    return new HttpUnauthorizedResult();

                if (order == null)
                    return RedirectToRoute("HomePage");

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(order.PaymentMethodSystemName);
                if (paymentMethod == null)
                    return RedirectToRoute("HomePage");
                if (paymentMethod.PaymentMethodType != PaymentMethodType.Redirection)
                    return RedirectToRoute("HomePage");

                //Redirection will not work on one page checkout page because it's AJAX request.
                //That's why we process it here
                var postProcessPaymentRequest = new PostProcessPaymentRequest
                {
                    Order = order
                };

                _paymentService.PostProcessPayment(postProcessPaymentRequest);

                if (_webHelper.IsRequestBeingRedirected || _webHelper.IsPostBeingDone)
                {
                    //redirection or POST has been done in PostProcessPayment
                    return Content("Redirected");
                }

                //if no redirection has been done (to a third-party payment page)
                //theoretically it's not possible
                var checkoutModel = new CheckoutCompletedModel
                {
                    OrderId = order.Id
                };

                return View("DonationConfirm", checkoutModel);
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Content(exc.Message);
            }
        }

        #endregion

        #region Prepare model
        protected void PrepareAvailableCountriesAndStates(AddressModel address, string type)
        {
            if (_addressSettings.CountryEnabled)
            {
                IList<Country> countries = new List<Country>();
                if (_localizationService == null)
                    throw new ArgumentNullException("localizationService");

                switch (type.ToLower())
                {
                    case "billing":
                        countries = _countryService.GetAllCountriesForBilling();
                        break;
                    case "shipping":
                        countries = _countryService.GetAllCountriesForBilling();
                        break;
                }

                address.AvailableCountries.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectCountry"),
                    Value = "0"
                });
                foreach (var country in countries)
                {
                    address.AvailableCountries.Add(new SelectListItem
                    {
                        Text = country.GetLocalized(x => x.Name),
                        Value = country.Id.ToString(),
                        Selected = country.Id == address.CountryId
                    });
                }

                if (_addressSettings.StateProvinceEnabled)
                {
                    //states
                    if (_stateProvinceService == null)
                        throw new ArgumentNullException("stateProvinceService");

                    var states = _stateProvinceService
                        .GetStateProvincesByCountryId(address.CountryId.HasValue ? address.CountryId.Value : 0)
                        .ToList();
                    if (states.Count > 0)
                    {
                        address.AvailableStates.Add(new SelectListItem
                        {
                            Text = _localizationService.GetResource("Address.SelectState"),
                            Value = "0"
                        });

                        foreach (var s in states)
                        {
                            address.AvailableStates.Add(new SelectListItem
                            {
                                Text = s.GetLocalized(x => x.Name),
                                Value = s.Id.ToString(),
                                Selected = (s.Id == address.StateProvinceId)
                            });
                        }
                    }
                    else
                    {
                        bool anyCountrySelected = address.AvailableCountries.Any(x => x.Selected);
                        address.AvailableStates.Add(new SelectListItem
                        {
                            Text =
                                _localizationService.GetResource(anyCountrySelected
                                    ? "Address.OtherNonUS"
                                    : "Address.SelectState"),
                            Value = "0"
                        });
                    }
                }
            }
        }

        protected DonationModel PrepareDonationModel(int productId,
            IList<string> warnings = null,
            IList<string> warningsPayment = null,
            IList<string> warningsShipping = null)
        {
            var cart = GetShoppingCart();

            var cartModel = new ShoppingCartModel();

            _prepareShoppingCartModels.PrepareShoppingCartModel(cartModel, cart);


            int customerid = _workContext.CurrentCustomer.Id;
            var address = _customerService.GetCustomerById(customerid);

            var billingAddress = new AddressModel();
            billingAddress.PrepareModel(
                address: address.BillingAddress,
                excludeProperties: false,
                addressSettings: _addressSettings,
                addressAttributeFormatter: _addressAttributeFormatter);
            PrepareAvailableCountriesAndStates(billingAddress, "Billing");

            var shippingAddress = new AddressModel();
            shippingAddress.PrepareModel(
                address: address.ShippingAddress,
                excludeProperties: false,
                addressSettings: _addressSettings,
                addressAttributeFormatter: _addressAttributeFormatter);
            PrepareAvailableCountriesAndStates(shippingAddress, "Shipping");

            #region AddToCartModel

            var product = _productService.GetProductById(productId);
            var addToCartModel = new ProductDetailsModel.AddToCartModel();

            addToCartModel.ProductId = product.Id;
            addToCartModel.UpdatedShoppingCartItemId = 0;

            //quantity
            addToCartModel.EnteredQuantity = 1;

            //'add to cart', 'add to wishlist' buttons
            addToCartModel.DisableBuyButton = product.DisableBuyButton || !_permissionService.Authorize(StandardPermissionProvider.EnableShoppingCart);
            addToCartModel.DisableWishlistButton = product.DisableWishlistButton || !_permissionService.Authorize(StandardPermissionProvider.EnableWishlist);
            if (!_permissionService.Authorize(StandardPermissionProvider.DisplayPrices))
            {
                addToCartModel.DisableBuyButton = true;
                addToCartModel.DisableWishlistButton = true;
            }
            //pre-order
            if (product.AvailableForPreOrder)
            {
                addToCartModel.AvailableForPreOrder = !product.PreOrderAvailabilityStartDateTimeUtc.HasValue ||
                    product.PreOrderAvailabilityStartDateTimeUtc.Value >= DateTime.UtcNow;
                addToCartModel.PreOrderAvailabilityStartDateTimeUtc = product.PreOrderAvailabilityStartDateTimeUtc;
            }
            //rental
            addToCartModel.IsRental = product.IsRental;

            //customer entered price
            addToCartModel.CustomerEntersPrice = product.CustomerEntersPrice;
            if (addToCartModel.CustomerEntersPrice)
            {
                decimal minimumCustomerEnteredPrice = _currencyService.ConvertFromPrimaryStoreCurrency(product.MinimumCustomerEnteredPrice,
                    _workContext.WorkingCurrency);
                decimal maximumCustomerEnteredPrice = _currencyService.ConvertFromPrimaryStoreCurrency(product.MaximumCustomerEnteredPrice,
                    _workContext.WorkingCurrency);

                addToCartModel.CustomerEnteredPrice = minimumCustomerEnteredPrice;
                addToCartModel.CustomerEnteredPriceRange = string.Format(_localizationService.GetResource("Products.EnterProductPrice.Range"),
                    _priceFormatter.FormatPrice(minimumCustomerEnteredPrice, false, false),
                    _priceFormatter.FormatPrice(maximumCustomerEnteredPrice, false, false));
            }
            //allowed quantities
            //nop3.7 upgrade begin
            var allowedQuantities = product.ParseAllowedQuantities();
            //nop3.7 upgrade end
            foreach (var qty in allowedQuantities)
            {
                addToCartModel.AllowedQuantities.Add(new SelectListItem
                {
                    Text = qty.ToString(),
                    Value = qty.ToString()
                });
            }

            #endregion

            var model = new DonationModel
            {
                BillingAddress = billingAddress,
                ShippingAddress = shippingAddress,

                ShowProductImages = false,
                UseDifferentAddressForBilling = true,
                IsGuest = address.IsGuest(),
                IsAllowCustomerToWriteComment = false,
                TermsOfServiceOnOrderConfirmPage = true,//cartModel.TermsOfServiceOnOrderConfirmPage,
                //isPaymentWorkflowRequired = _prepareCheckoutModels.IsPaymentWorkflowRequired(cart),
                isPaymentWorkflowRequired = true,
                RequiresShipping = false,
                AllowToSelectTheAddress = true,


                //CheckoutAttributeInfo = cartModel.CheckoutAttributeInfo,
                RewardPointsAmount = _rewardPointsSettings.PointsForPurchases_Amount.ToString(),
                Shippingoption = null,
                //nop3.7 upgrade begin
                //RewardPointsBalance =
                //nop3.7 upgrade end
                Paymentmethod = SystemCustomerAttributeNames.SelectedPaymentMethod,
                DisplayRewardPoints = _rewardPointsSettings.Enabled,
                UseRewardPoints = _rewardPointsSettings.Enabled,

                IsRecurringPayment = false,
                ProductId = product.Id,
                CyclePeriodId = 0,
                AddToCart = addToCartModel,

                Sum = product.CustomerEntersPrice
                    ? product.MinimumCustomerEnteredPrice
                    : product.Price
            };
            
            if (warnings != null)
            {
                model.Warnings = warnings;
            }

            if (warningsPayment != null)
            {
                model.WarningsPayment = warningsPayment;
            }

            if (warningsShipping != null)
            {
                model.WarningsShipping = warningsShipping;
            }

            //Set Shipping Methods
            ITPPreparePaymentMethodModel(cart, model);

            return model;
        }

        private void ITPPreparePaymentMethodModel(IList<ShoppingCartItem> cart, DonationModel model)
        {
            //filter by country
            int filterByCountryId = 0;
            if (_addressSettings.CountryEnabled &&
                _workContext.CurrentCustomer.BillingAddress != null &&
                _workContext.CurrentCustomer.BillingAddress.Country != null)
            {
                filterByCountryId = _workContext.CurrentCustomer.BillingAddress.Country.Id;
            }

            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentMethodModel(cart, filterByCountryId);
            model.PaymentMethods = paymentInfoModel.PaymentMethods;
            var activePaymentMethods = _paymentService.LoadActivePaymentMethods();

            foreach (var paymentMethod in activePaymentMethods)
            {
                if (paymentMethod.RecurringPaymentType == RecurringPaymentType.NotSupported)
                {
                    var method = paymentInfoModel.PaymentMethods.FirstOrDefault(p => p.PaymentMethodSystemName
                        == MappingExtensions.ToModel(paymentMethod).SystemName);
                    if (method != null)
                        model.PaymentMethods.Remove(method);
                }
            }

            model.DisplayRewardPoints = paymentInfoModel.DisplayRewardPoints;
            model.RewardPointsAmount = paymentInfoModel.RewardPointsAmount;
        }


        [NonAction]
        protected Address SaveAddress(FormCollection form)
        {
            var model = new AddressModel();
            TryUpdateModel(model, "ShippingAddress");

            var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
            var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
            foreach (var error in customAttributeWarnings)
            {
                ModelState.AddModelError("", error);
            }

            //validate model
            TryValidateModel(model);
            if (!ModelState.IsValid)
            {
                return null;
            }

            var address = _workContext.CurrentCustomer.Addresses.ToList().FindAddress(
                model.FirstName, model.LastName, model.PhoneNumber,
                model.Email, model.FaxNumber, model.Company,
                model.Address1, model.Address2, model.City,
                model.StateProvinceId, model.ZipPostalCode,
                model.CountryId, customAttributes);
            if (address == null)
            {
                //address is not found. let's create a new one
                address = model.ToEntity();
                address.CustomAttributes = customAttributes;
                address.CreatedOnUtc = DateTime.UtcNow;
                //some validation
                if (address.CountryId == 0)
                    address.CountryId = null;
                if (address.StateProvinceId == 0)
                    address.StateProvinceId = null;
                if (address.CountryId.HasValue && address.CountryId.Value > 0)
                {
                    address.Country = _countryService.GetCountryById(address.CountryId.Value);
                }
                _workContext.CurrentCustomer.Addresses.Add(address);
            }
            //_workContext.CurrentCustomer.ShippingAddress = address;
            _workContext.CurrentCustomer.BillingAddress = address;
            _customerService.UpdateCustomer(_workContext.CurrentCustomer);
            return address;
        }

        [NonAction]

        public void AddToCart(decimal sum, int productId)
        {
            var storeScope = GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var settings = _settingService.LoadSetting<DonationSettings>(storeScope);

            var product = _productService.GetProductById(productId);

            product.IsShipEnabled = false;
            product.Price = sum;
            decimal customerEnteredPriceConverted = sum;
            DateTime? rentalStartDate = null;
            DateTime? rentalEndDate = null;
            var warnings = _shoppingCartService.AddToCart(_workContext.CurrentCustomer,
                                           product, ShoppingCartType.ShoppingCart, _storeContext.CurrentStore.Id * 2,
                                           null, customerEnteredPriceConverted,
                                           rentalStartDate, rentalEndDate, 1, true);

        }

        public void UpdateForm(DonationModel model)
        {
            model.ShippingAddress.StreetAddress2Enabled = _settingService.LoadSetting<DonationSettings>().AddressEnabled;
            model.ShippingAddress.FaxEnabled = _settingService.LoadSetting<DonationSettings>().FaxPhoneEnabled;
        }
        #endregion

        #region AJAX

        [HttpPost]
        public ActionResult AjaxOrderSummary(string paymentmethod)
        {
            #region Set Payment Method

            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            if (paymentMethodInst == null ||
                !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
                !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
                throw new Exception("Selected payment method can't be parsed");

            _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                SystemCustomerAttributeNames.SelectedPaymentMethod, paymentmethod, _storeContext.CurrentStore.Id);

            #endregion

            return new NullJsonResult();
            //return PartialView("~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/OrderSummary.cshtml");
        }

            
        [HttpPost]
        public ActionResult AjaxPaymentInfo(string paymentmethod)
        {
            var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentInfoModel(paymentMethod);

            return PartialView("~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/DonationPaymentInfo.cshtml", paymentInfoModel);
            //return Json(RenderPartialViewToString(GetViewname("PaymentInfo"), paymentInfoModel));
        }

        [HttpPost]
        public ActionResult AjaxPaymentMethod(DonationModel model, FormCollection form)
        {
            var cart = GetShoppingCart();

            ITPPreparePaymentMethodModel(cart, model);

            return Json(model.PaymentMethods);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AjaxGetStatesByCountryId(string countryId, bool addSelectStateItem = true)
        {
            var country = _countryService.GetCountryById(Convert.ToInt32(countryId));
            var states = _stateProvinceService.GetStateProvincesByCountryId(country != null ? country.Id : 0).ToList();
            var result = (from s in states
                          select new { id = s.Id, name = s.GetLocalized(x => x.Name) })
                          .ToList();

            if (country == null)
            {
                //country is not selected ("choose country" item)
                if (addSelectStateItem)
                {
                    result.Insert(0, new { id = 0, name = _localizationService.GetResource("Address.SelectState") });
                }
                else
                {
                    result.Insert(0, new { id = 0, name = _localizationService.GetResource("Address.OtherNonUS") });
                }
            }
            else
            {
                //some country is selected
                if (result.Count == 0)
                {
                    //country does not have states
                    result.Insert(0, new { id = 0, name = _localizationService.GetResource("Address.OtherNonUS") });
                }
                else
                {
                    //country has some states
                    if (addSelectStateItem)
                    {
                        result.Insert(0, new { id = 0, name = _localizationService.GetResource("Address.SelectState") });
                    }
                }
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #endregion

    }
}

