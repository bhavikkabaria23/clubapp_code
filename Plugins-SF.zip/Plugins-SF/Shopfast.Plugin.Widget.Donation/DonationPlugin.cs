﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.Routing;
using System.IO;
using System.Linq;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Data;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Shopfast.Plugin.Widget.Donation.Models;
using ShopFast.Plugin.Misc.Core.Services;

namespace Shopfast.Plugin.Widget.Donation
{
    class DonationPlugin : BasePlugin, IWidgetPlugin
    {
        #region Fields

        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly ITPProductTemplateService _productTemplateService;

        #endregion

        #region Constructor
        public DonationPlugin(ISettingService _settingService, IStoreContext _storeContext, ITPProductTemplateService productTemplateService)
        {
            this._settingService = _settingService;
            this._storeContext = _storeContext;
            _productTemplateService = productTemplateService;
        }

        #endregion

        #region Widget Settings
        public IList<string> GetWidgetZones()
        {
            var pluginSettings = _settingService.LoadSetting<DonationSettings>(_storeContext.CurrentStore.Id);
            return !String.IsNullOrEmpty(pluginSettings.WidgetZone) ? new List<string> { pluginSettings.WidgetZone } : null;
        }

        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "WidgetDonation";
            routeValues = new RouteValueDictionary { { "Namespaces", "Shopfast.Plugin.Widget.Donation.Controllers" }, { "area", null } };
        }

        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName,
            out RouteValueDictionary routeValues)
        {
            actionName = "PublicInfo";
            controllerName = "WidgetDonation";
            routeValues = new RouteValueDictionary
            {
                {"Namespaces", "Shopfast.Plugin.Widget.Donation.Controllers"},
                {"area", null},
                {"widgetZone", widgetZone}
            };
        }
        #endregion

        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();
            ITPProductTemplateService productTemplateService = EngineContext.Current.Resolve<ITPProductTemplateService>();

            var template = productTemplateService.GetAllTemplatesByViewPath("Donation").FirstOrDefault();

            if (template == null)
            {
                productTemplateService.InsertProductTemplate(new ProductTemplate
                {
                    DisplayOrder = 0,
                    Name = "Product Donation",
                    ViewPath = "~/Plugins/ShopFast.Widget.Donation/Views/WidgetDonation/ProductTemplate.Donation.cshtml"
                });
                template = productTemplateService.GetAllProductTemplates().FirstOrDefault(x => x.Name == "Product Donation");
            }

            CreateProduct(template.Id);

            var settings = new DonationSettings()
            {
                WidgetZone = "donation_productdetails_overview_bottom",
                AddressEnabled = true,
                FaxPhoneEnabled = false
            };

            settingService.SaveSetting(settings);
        }

        public override void Install()
        {
            SetDefaultSettings();

            base.Install();
        }

        public override void Uninstall()
        {
            DeleteProduct();
            _settingService.DeleteSetting<DonationSettings>();
            base.Uninstall();
        }

        public bool Authenticate()
        {
            return true;
        }

        #region Donation Product
        private static void CreateProduct(int templateId)
        {
            //var connectionString = new DataSettingsManager().LoadSettings().DataConnectionString;
            //var script = File.ReadAllText(HttpContext.Current.Server.MapPath("~/Plugins/ShopFast.Widget.Donation/SQL/create_donation_product.sql"));
            //script = script.Replace("@paramTemplateID", templateId.ToString());
            //var conn = new SqlConnection(connectionString);
            //var command = new SqlCommand(script, conn);
            //conn.Open();
            //var productId = command.ExecuteScalar();
            //conn.Close();
            //return Convert.ToInt32(productId);

            string script = File.ReadAllText(HttpContext.Current
                .Server.MapPath("~/Plugins/ShopFast.Widget.Donation/SQL/create_donation_product.sql"));
            script = script.Replace("@paramTemplateID", templateId.ToString());
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(script);
        }

        public void DeleteProduct()
        {
            //var settings = _settingService.LoadSetting<DonationSettings>();
            //var connectionString = new DataSettingsManager().LoadSettings().DataConnectionString;
            //var script = "DELETE From Product Where Sku=N'ShopFast.Plugins.Widget.Donation.DonationProduct'";
            //var conn = new SqlConnection(connectionString);
            //var command = new SqlCommand(script, conn);
            //conn.Open();
            //command.ExecuteScalar();
            //conn.Close();

            //var product = _productService.GetProductBySku("ShopFast.Plugins.Widget.Donation.DonationProduct");
            //if (product != null)
            //{
            //    _productService.DeleteProduct(product);
            //}

            string script =
                "UPDATE [dbo].[Product] set [Deleted] = 1 where Sku = N'ShopFast.Plugins.Widget.Donation.DonationProduct'";
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(script);
        }

        #endregion
    }
}
