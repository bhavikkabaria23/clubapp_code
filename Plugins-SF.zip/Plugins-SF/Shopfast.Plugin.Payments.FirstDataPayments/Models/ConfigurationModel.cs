﻿using System.Web.Mvc;
using System.Collections.Generic;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Payments.FirstDataPayments.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.UseSandbox")]
        public bool UseSandbox { get; set; }

        public int TransactModeId { get; set; }
        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.TransactModeValues")]
        public SelectList TransactModeValues { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.HMAC")]
        public string HMAC { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.GatewayID")]
        public string GatewayID { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.Password")]
        public string Password { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.KeyID")]
        public string KeyID { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.EnableRecurringPayments")]
        public bool EnableRecurringPayments { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.EnableCardSaving")]
        public bool EnableCardSaving { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.EnablePurchaseOrderNumber")]
        public bool EnablePurchaseOrderNumber { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Fields.LicenseKey")]
        public IList<StoreLicenseKeyModel> LicenseKeys { get; set; }

        public bool SavedSuccessfully { get; set; }

        public string SaveMessage { get; set; }
    }
}