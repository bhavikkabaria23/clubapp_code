﻿using System.Web.Mvc;
using System.Collections.Generic;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Payments.FirstDataPayments.Models
{
    public class StoreLicenseKeyModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.LicenseKey.Fields.LicenseKey")]
        public string LicenseKey { get; set; }
        public string Type { get; set; }

        public string Host { get; set; }
    }
}