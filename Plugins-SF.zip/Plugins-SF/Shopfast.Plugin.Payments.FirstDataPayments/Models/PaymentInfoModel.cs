﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Payments.FirstDataPayments.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
        public PaymentInfoModel()
        {
            CreditCardTypes = new List<SelectListItem>();
            ExpireMonths = new List<SelectListItem>();
            ExpireYears = new List<SelectListItem>();
            SavedCards = new List<SavedCardModel>();
        }

        [NopResourceDisplayName("Payment.SelectCreditCard")]
        [AllowHtml]
        public string CreditCardType { get; set; }
        [NopResourceDisplayName("Payment.SelectCreditCard")]
        public IList<SelectListItem> CreditCardTypes { get; set; }

        [NopResourceDisplayName("Payment.CardholderName")]
        [AllowHtml]
        public string CardholderName { get; set; }

        [NopResourceDisplayName("Payment.CardNumber")]
        [AllowHtml]
        public string CardNumber { get; set; }

        [NopResourceDisplayName("Payment.ExpirationDate")]
        [AllowHtml]
        public string ExpireMonth { get; set; }
        [NopResourceDisplayName("Payment.ExpirationDate")]
        [AllowHtml]
        public string ExpireYear { get; set; }
        public IList<SelectListItem> ExpireMonths { get; set; }
        public IList<SelectListItem> ExpireYears { get; set; }

        [NopResourceDisplayName("Payment.CardCode")]
        [AllowHtml]
        public string CardCode { get; set; }

        public string ExpiryDate
        {
            get
            {
                return ExpireMonth.PadLeft(2, '0') + ExpireYear;
            }
        }

        public bool EnablePurchaseOrderNumber { get; set; }
        [NopResourceDisplayName("order.purchaseordernumber")]
        [AllowHtml]
        public string PurchaseOrderNumber { get; set; }

        public bool EnableCardSaving { get; set; }
        [NopResourceDisplayName("Shopfast.Plugin.FirstDataPayments.Payment.SaveCard")]
        public bool SaveCard { get; set; }
        public int SavedCardId { get; set; }
        public string SavedCardsLabel { get; set; }
        public string NewCardLabel { get; set; }

        public bool IsOnePageCheckout { get; set; }

        public IList<SavedCardModel> SavedCards { get; set; }
    }
}