using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Shopfast.Plugin.Payments.FirstDataPayments.Data;
using Shopfast.Plugin.Payments.FirstDataPayments.Domain;
using Shopfast.Plugin.Payments.FirstDataPayments.Services;

namespace Shopfast.Plugin.Payments.FirstDataPayments
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<SavedCardService>().As<ISavedCardService>().InstancePerLifetimeScope();

            //data layer
            var dataSettingsManager = new DataSettingsManager();
            var dataProviderSettings = dataSettingsManager.LoadSettings();

            if (dataProviderSettings != null && dataProviderSettings.IsValid())
            {
                //register named context
                builder.Register<IDbContext>(c => new FirstDataPaymentsObjectContext(dataProviderSettings.DataConnectionString))
                    .Named<IDbContext>("nop_object_context_shopfast_firstdata")
                    .InstancePerLifetimeScope();

                builder.Register<FirstDataPaymentsObjectContext>(c => new FirstDataPaymentsObjectContext(dataProviderSettings.DataConnectionString))
                    .InstancePerLifetimeScope();
            }
            else
            {
                //register named context
                builder.Register<IDbContext>(c => new FirstDataPaymentsObjectContext(c.Resolve<DataSettings>().DataConnectionString))
                    .Named<IDbContext>("nop_object_context_shopfast_firstdata")
                    .InstancePerLifetimeScope();

                builder.Register<FirstDataPaymentsObjectContext>(c => new FirstDataPaymentsObjectContext(c.Resolve<DataSettings>().DataConnectionString))
                    .InstancePerLifetimeScope();
            }

            //override required repository with our custom context
            builder.RegisterType<EfRepository<SavedCard>>()
                .As<IRepository<SavedCard>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("nop_object_context_shopfast_firstdata"))
                .InstancePerLifetimeScope();
        }

        public int Order
        {
            get { return 1; }
        }
    }
}
