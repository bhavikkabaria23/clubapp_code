using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Net;
using System.Text;
using System.Web.Routing;
using System.Web.Security;
using System.Security.Cryptography;
using System.Xml.XPath;
using System.ServiceModel.Channels;
using System.IO;
using System.Xml;
using System.Web;
using Nop.Core;
using Nop.Core.Domain;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Plugins;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Shopfast.Plugin.Payments.FirstDataPayments.Domain;
using Shopfast.Plugin.Payments.FirstDataPayments.Controllers;
using Shopfast.Plugin.Payments.FirstDataPayments.Data;
using Shopfast.Plugin.Payments.FirstDataPayments.Services;

namespace Shopfast.Plugin.Payments.FirstDataPayments
{
    /// <summary>
    /// FirstDataPayments payment processor
    /// </summary>
    public class FirstDataPaymentsPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly FirstDataPaymentsSettings _firstDataSettings;
        private readonly ISettingService _settingService;
        private readonly ICurrencyService _currencyService;
        private readonly ICustomerService _customerService;
        private readonly CurrencySettings _currencySettings;
        private readonly IWebHelper _webHelper;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly StoreInformationSettings _storeInformationSettings;
        private readonly IWorkContext _workContext;
        private readonly IEncryptionService _encryptionService;
        private readonly ILocalizationService _localizationService;
        private readonly ILogger _logger;
        private readonly ISavedCardService _savedCardService;
        private readonly IOrderService _orderService;
        private readonly FirstDataPaymentsObjectContext _objectContext;

        #endregion

        #region Ctor

        public FirstDataPaymentsPaymentProcessor(FirstDataPaymentsSettings firstDataSettings,
            ISettingService settingService, ICurrencyService currencyService,
            ICustomerService customerService, CurrencySettings currencySettings,
            IWebHelper webHelper, IOrderTotalCalculationService orderTotalCalculationService,
            StoreInformationSettings storeInformationSettings, IWorkContext workContext,
            IEncryptionService encryptionService, ILocalizationService localizationService,
            ILogger logger,
            ISavedCardService savedCardService, IOrderService orderService,
            FirstDataPaymentsObjectContext objectContext)
        {
            this._firstDataSettings = firstDataSettings;
            this._settingService = settingService;
            this._currencyService = currencyService;
            this._customerService = customerService;
            this._currencySettings = currencySettings;
            this._webHelper = webHelper;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._storeInformationSettings = storeInformationSettings;
            this._workContext = workContext;
            this._encryptionService = encryptionService;
            this._localizationService = localizationService;
            this._logger = logger;
            this._savedCardService = savedCardService;
            this._orderService = orderService;
            this._objectContext = objectContext;
        }

        #endregion

        #region Utilities

        private XmlNode SendFDRequest(string transaction)
        {
            //SHA1 hash on XML string
            UTF8Encoding encoder = new UTF8Encoding();
            byte[] xml_byte = encoder.GetBytes(transaction);
            SHA1CryptoServiceProvider sha1_crypto = new SHA1CryptoServiceProvider();
            string hash = BitConverter.ToString(sha1_crypto.ComputeHash(xml_byte)).Replace("-", "");
            string hashed_content = hash.ToLower();

            //assign values to hashing and header variables
            string method = "POST\n";
            string type = "application/xml\n";//REST XML
            string time = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
            string url = "/transaction/v12";
            string keyID = _encryptionService.DecryptText(_firstDataSettings.KeyID);//key ID
            string key = _encryptionService.DecryptText(_firstDataSettings.HMAC);//Hmac key
            string hash_data = method + type + hashed_content + "\n" + time + "\n" + url;
            //hmac sha1 hash with key + hash_data
            HMAC hmac_sha1 = new HMACSHA1(Encoding.UTF8.GetBytes(key)); //key
            byte[] hmac_data = hmac_sha1.ComputeHash(Encoding.UTF8.GetBytes(hash_data)); //data
            //base64 encode on hmac_data
            string base64_hash = Convert.ToBase64String(hmac_data);

            //begin HttpWebRequest // use  for production
            string destination = (_firstDataSettings.UseSandbox ? "https://api.demo.globalgatewaye4.firstdata.com/transaction/v12" : "https://api.globalgatewaye4.firstdata.com/transaction/v12");
            HttpWebRequest web_request = (HttpWebRequest)WebRequest.Create(destination);
            web_request.Method = "POST";
            web_request.Accept = "application/xml";
            web_request.Headers.Add("x-gge4-date", time);
            web_request.Headers.Add("x-gge4-content-sha1", hashed_content);
            web_request.ContentLength = Encoding.UTF8.GetByteCount(transaction);
            web_request.ContentType = "application/xml";
            web_request.Headers["Authorization"] = "GGE4_API " + keyID + ":" + base64_hash;

            // send request as stream
            StreamWriter xml = null;
            xml = new StreamWriter(web_request.GetRequestStream());
            xml.Write(transaction);
            xml.Flush();
            xml.Close();

            //get response and read into string
            string response_string;
            try
            {
                HttpWebResponse web_response = (HttpWebResponse)web_request.GetResponse();
                using (StreamReader response_stream = new StreamReader(web_response.GetResponseStream()))
                {
                    response_string = response_stream.ReadToEnd();
                    response_stream.Close();
                }
                //load xml
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.LoadXml(response_string);
                XmlNodeList nodelist = xmldoc.SelectNodes("TransactionResult");

                return nodelist[0];
            }
            catch (System.Net.WebException ex)
            {
                using (StreamReader response_stream = new StreamReader(ex.Response.GetResponseStream()))
                {
                    response_string = response_stream.ReadToEnd();
                    response_stream.Close();
                    throw new Exception(response_string);
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();

            var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
            var cardNumber = processPaymentRequest.CreditCardNumber.Split('|')[0];
            bool saveCard = (processPaymentRequest.CreditCardNumber.Contains("|") ? Convert.ToBoolean(processPaymentRequest.CreditCardNumber.Split('|')[1]) : false);
            bool useSavedCard = (processPaymentRequest.CreditCardNumber.StartsWith("T"));

            StringBuilder nullFinder = new StringBuilder();
            StringBuilder string_builder = new StringBuilder();
            try
            {
                using (StringWriter string_writer = new StringWriter(string_builder))
                {
                    using (XmlTextWriter xml_writer = new XmlTextWriter(string_writer))
                    {     //build XML string
                        xml_writer.Formatting = Formatting.Indented;
                        xml_writer.WriteStartElement("Transaction");
                        xml_writer.WriteElementString("ExactID", _encryptionService.DecryptText(_firstDataSettings.GatewayID));//Gateway ID
                        nullFinder.Append("ExactID, ");
                        xml_writer.WriteElementString("Password", _encryptionService.DecryptText(_firstDataSettings.Password));//Password
                        nullFinder.Append("Password, ");
                        xml_writer.WriteElementString("Transaction_Type", (_firstDataSettings.TransactionMode == TransactMode.Authorize ? TransactionType.PreAuth : TransactionType.Purchase));  //check settings
                        nullFinder.Append("Type, ");
                        xml_writer.WriteElementString("DollarAmount", processPaymentRequest.OrderTotal.ToString());
                        nullFinder.Append("DollarAmount, ");

                        if (useSavedCard)
                        {
                            int savedCardId = Convert.ToInt32(processPaymentRequest.CreditCardNumber.Substring(1));
                            SavedCard card = _savedCardService.GetById(savedCardId);
                            if (card == null)
                            {
                                throw new NullReferenceException("Saved Card #" + savedCardId.ToString() + " is null");
                            }

                            xml_writer.WriteElementString("CardHoldersName", card.CardholderName);
                            xml_writer.WriteElementString("TransarmorToken", card.Token);
                            xml_writer.WriteElementString("CardType", card.CardType);
                            xml_writer.WriteElementString("Expiry_Date", card.ExpireMonth.ToString("00") + card.ExpireYear.ToString().Substring(2, 2));
                        }
                        else
                        {
                            xml_writer.WriteElementString("Expiry_Date", processPaymentRequest.CreditCardExpireMonth.ToString("00") + processPaymentRequest.CreditCardExpireYear.ToString().Substring(2, 2));
                            nullFinder.Append("Expire, ");
                            xml_writer.WriteElementString("CardHoldersName", processPaymentRequest.CreditCardName);
                            nullFinder.Append("CC Name, ");
                            xml_writer.WriteElementString("Card_Number", cardNumber);
                            nullFinder.Append("CC Number, ");
                            xml_writer.WriteElementString("VerificationStr1", customer.BillingAddress.Address1 ?? "" + "|"
                                                                            + customer.BillingAddress.ZipPostalCode ?? "" + "|"
                                                                            + (customer.BillingAddress.StateProvince != null ? customer.BillingAddress.StateProvince.Name : "") + "|"
                                                                            + customer.BillingAddress.Country.ThreeLetterIsoCode);
                            nullFinder.Append("Verification Str 1, ");
                            xml_writer.WriteElementString("VerificationStr2", processPaymentRequest.CreditCardCvv2);
                            nullFinder.Append("Verification Str 2, ");
                            xml_writer.WriteElementString("CVD_Presence_Ind", "1");
                        }

                        xml_writer.WriteElementString("Client_Email", customer.Email);
                        nullFinder.Append("Email, ");
                        xml_writer.WriteElementString("Currency", _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId).CurrencyCode);
                        nullFinder.Append("Currency, ");
                        xml_writer.WriteElementString("Customer_Ref", customer.CustomerGuid.ToString());
                        nullFinder.Append("Customer Ref, ");
                        xml_writer.WriteElementString("Reference_No", processPaymentRequest.OrderGuid.ToString());
                        nullFinder.Append("Reference, ");
                        xml_writer.WriteElementString("Client_IP", _webHelper.GetCurrentIpAddress());
                        nullFinder.Append("IP, ");
                        xml_writer.WriteElementString("ZipCode", customer.BillingAddress.ZipPostalCode ?? "");
                        nullFinder.Append("Zip Code, ");
                        xml_writer.WriteEndElement();
                        String xml_string = string_builder.ToString();

                        try
                        {
                            var response = SendFDRequest(xml_string);
                            if (response.SelectSingleNode("Transaction_Approved").InnerText == "true")
                            {
                                result.AuthorizationTransactionId = response.SelectSingleNode("Authorization_Num").InnerText + "|" + response.SelectSingleNode("Transaction_Tag").InnerText;
                                result.AuthorizationTransactionResult = string.Format("Approved ({0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText);
                                if (_firstDataSettings.TransactionMode == TransactMode.AuthorizeAndCapture)
                                {
                                    result.CaptureTransactionId = response.SelectSingleNode("Authorization_Num").InnerText + "|" + response.SelectSingleNode("Transaction_Tag").InnerText;
                                }

                                // PurchaseOrderNumber is n ot now in 3.5
                                //if (_firstDataSettings.EnablePurchaseOrderNumber)
                                //{
                                //    result.AuthorizationTransactionId += "|PO:" + processPaymentRequest.PurchaseOrderNumber;
                                //}

                                result.AvsResult = response.SelectSingleNode("AVS").InnerText;
                                result.AllowStoringCreditCardNumber = false;

                                result.NewPaymentStatus = (_firstDataSettings.TransactionMode == TransactMode.Authorize ? PaymentStatus.Authorized : PaymentStatus.Paid);

                                if (saveCard && !useSavedCard)
                                {
                                    var token = response.SelectSingleNode("TransarmorToken").InnerText;

                                    var existingCard = _savedCardService.GetByToken(customer.Id, token);
                                    if (existingCard == null) //don't save the same card twice
                                    {
                                        SavedCard card = new SavedCard();
                                        card.BillingAddress_Id = customer.BillingAddress.Id;
                                        card.CardholderName = processPaymentRequest.CreditCardName;
                                        card.CardType = response.SelectSingleNode("CardType").InnerText;
                                        card.Customer_Id = customer.Id;
                                        card.ExpireMonth = processPaymentRequest.CreditCardExpireMonth;
                                        card.ExpireYear = processPaymentRequest.CreditCardExpireYear;
                                        card.Token = token;
                                        _savedCardService.Insert(card);
                                    }
                                }
                            }
                            else
                            {
                                result.AddError(string.Format("Error {0}: {1}", response.SelectSingleNode("Bank_Resp_Code").InnerText, response.SelectSingleNode("Bank_Message").InnerText));
                            }
                        }
                        catch (Exception ex)
                        {
                            result.AddError(_localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.TechnicalError"));
                            _logger.Error("Error processing payment", ex, _workContext.CurrentCustomer);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.TechnicalError"));
                _logger.Error("Error processing payment.  Null Check: " + nullFinder.ToString(), ex, _workContext.CurrentCustomer);
            }

            return result;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            var result = this.CalculateAdditionalFee(_orderTotalCalculationService, cart,
                _firstDataSettings.AdditionalFee, _firstDataSettings.AdditionalFeePercentage);
            return result;
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();

            StringBuilder string_builder = new StringBuilder();
            using (StringWriter string_writer = new StringWriter(string_builder))
            {
                using (XmlTextWriter xml_writer = new XmlTextWriter(string_writer))
                {     //build XML string
                    xml_writer.Formatting = Formatting.Indented;
                    xml_writer.WriteStartElement("Transaction");
                    xml_writer.WriteElementString("ExactID", _encryptionService.DecryptText(_firstDataSettings.GatewayID));//Gateway ID
                    xml_writer.WriteElementString("Password", _encryptionService.DecryptText(_firstDataSettings.Password));//Password
                    xml_writer.WriteElementString("Transaction_Type", TransactionType.TaggedPreAuthCompletion);
                    xml_writer.WriteElementString("DollarAmount", capturePaymentRequest.Order.OrderTotal.ToString());
                    xml_writer.WriteElementString("Authorization_Num", capturePaymentRequest.Order.AuthorizationTransactionId.Split(new char[] { '|' })[0]);
                    xml_writer.WriteElementString("Transaction_Tag", capturePaymentRequest.Order.AuthorizationTransactionId.Split(new char[] { '|' })[1]);
                    xml_writer.WriteEndElement();
                    String xml_string = string_builder.ToString();

                    try
                    {
                        var response = SendFDRequest(xml_string);
                        if (response.SelectSingleNode("Transaction_Approved").InnerText == "true")
                        {
                            result.CaptureTransactionId = response.SelectSingleNode("Authorization_Num").InnerText + "|" + response.SelectSingleNode("Transaction_Tag").InnerText;
                            result.CaptureTransactionResult = string.Format("Approved ({0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText);
                            result.NewPaymentStatus = PaymentStatus.Paid;
                        }
                        else
                        {
                            result.AddError(string.Format("Error {0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText));
                        }
                    }
                    catch (Exception ex)
                    {
                        result.AddError(ex.Message);
                        _logger.Error("Error capturing payment", ex, capturePaymentRequest.Order.Customer);
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();

            StringBuilder string_builder = new StringBuilder();

            using (StringWriter string_writer = new StringWriter(string_builder))
            {
                using (XmlTextWriter xml_writer = new XmlTextWriter(string_writer))
                {     //build XML string
                    xml_writer.Formatting = Formatting.Indented;
                    xml_writer.WriteStartElement("Transaction");
                    xml_writer.WriteElementString("ExactID", _encryptionService.DecryptText(_firstDataSettings.GatewayID));//Gateway ID
                    xml_writer.WriteElementString("Password", _encryptionService.DecryptText(_firstDataSettings.Password));//Password
                    xml_writer.WriteElementString("Transaction_Type", TransactionType.TaggedRefund);
                    xml_writer.WriteElementString("DollarAmount", refundPaymentRequest.AmountToRefund.ToString());
                    xml_writer.WriteElementString("Authorization_Num", refundPaymentRequest.Order.CaptureTransactionId.Split(new char[] { '|' })[0]);
                    xml_writer.WriteElementString("Transaction_Tag", refundPaymentRequest.Order.CaptureTransactionId.Split(new char[] { '|' })[1]);
                    xml_writer.WriteEndElement();
                    String xml_string = string_builder.ToString();

                    try
                    {
                        var response = SendFDRequest(xml_string);
                        if (response.SelectSingleNode("Transaction_Approved").InnerText == "true")
                        {
                            result.NewPaymentStatus = PaymentStatus.Refunded;
                        }
                        else
                        {
                            result.AddError(string.Format("Error {0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText));
                        }
                    }
                    catch (Exception ex)
                    {
                        result.AddError(ex.Message);
                        _logger.Error("Error refunding payment", ex, refundPaymentRequest.Order.Customer);
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();

            StringBuilder string_builder = new StringBuilder();
            using (StringWriter string_writer = new StringWriter(string_builder))
            {
                using (XmlTextWriter xml_writer = new XmlTextWriter(string_writer))
                {     //build XML string
                    xml_writer.Formatting = Formatting.Indented;
                    xml_writer.WriteStartElement("Transaction");
                    xml_writer.WriteElementString("ExactID", _encryptionService.DecryptText(_firstDataSettings.GatewayID));//Gateway ID
                    xml_writer.WriteElementString("Password", _encryptionService.DecryptText(_firstDataSettings.Password));//Password
                    xml_writer.WriteElementString("Transaction_Type", TransactionType.TaggedVoid);
                    xml_writer.WriteElementString("DollarAmount", voidPaymentRequest.Order.OrderTotal.ToString());
                    xml_writer.WriteElementString("Authorization_Num", voidPaymentRequest.Order.AuthorizationTransactionId.Split(new char[] { '|' })[0]);
                    xml_writer.WriteElementString("Transaction_Tag", voidPaymentRequest.Order.AuthorizationTransactionId.Split(new char[] { '|' })[1]);
                    xml_writer.WriteEndElement();
                    String xml_string = string_builder.ToString();

                    try
                    {
                        var response = SendFDRequest(xml_string);
                        if (response.SelectSingleNode("Transaction_Approved").InnerText == "true")
                        {
                            result.NewPaymentStatus = PaymentStatus.Voided;
                        }
                        else
                        {
                            result.AddError(string.Format("Error {0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText));
                        }
                    }
                    catch (Exception ex)
                    {
                        result.AddError(ex.Message);
                        _logger.Error("Error voiding payment", ex, voidPaymentRequest.Order.Customer);
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();

            var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
            var cardNumber = processPaymentRequest.CreditCardNumber.Split('|')[0];
            bool useSavedCard = (processPaymentRequest.CreditCardNumber.StartsWith("T"));

            StringBuilder string_builder = new StringBuilder();
            try
            {
                using (StringWriter string_writer = new StringWriter(string_builder))
                {
                    using (XmlTextWriter xml_writer = new XmlTextWriter(string_writer))
                    {     //build XML string
                        xml_writer.Formatting = Formatting.Indented;
                        xml_writer.WriteStartElement("Transaction");
                        xml_writer.WriteElementString("ExactID", _encryptionService.DecryptText(_firstDataSettings.GatewayID));//Gateway ID
                        xml_writer.WriteElementString("Password", _encryptionService.DecryptText(_firstDataSettings.Password));//Password
                        xml_writer.WriteElementString("Transaction_Type", (_firstDataSettings.TransactionMode == TransactMode.Authorize ? TransactionType.PreAuth : TransactionType.Purchase));  //check settings
                        xml_writer.WriteElementString("DollarAmount", processPaymentRequest.OrderTotal.ToString());

                        //if(!processPaymentRequest.IsRecurringPayment)
                        //{
                        //    if (useSavedCard)
                        //    {
                        //        int savedCardId = Convert.ToInt32(processPaymentRequest.CreditCardNumber.Substring(1));
                        //        SavedCard card = _savedCardService.GetById(savedCardId);
                        //        if (card == null)
                        //        {
                        //            throw new NullReferenceException("Saved Card #" + savedCardId.ToString() + " is null");
                        //        }
                        //        result.SubscriptionTransactionId = "T" + card.Id.ToString();
                        //        xml_writer.WriteElementString("CardHoldersName", card.CardholderName);
                        //        xml_writer.WriteElementString("TransarmorToken", card.Token);
                        //        xml_writer.WriteElementString("CardType", card.CardType);
                        //        xml_writer.WriteElementString("Expiry_Date", card.ExpireMonth.ToString("00") + card.ExpireYear.ToString().Substring(2, 2));
                        //    }
                        //    else
                        //    {
                        //        xml_writer.WriteElementString("Expiry_Date", processPaymentRequest.CreditCardExpireMonth.ToString("00") + processPaymentRequest.CreditCardExpireYear.ToString().Substring(2, 2));
                        //        xml_writer.WriteElementString("CardHoldersName", processPaymentRequest.CreditCardName);
                        //        xml_writer.WriteElementString("Card_Number", cardNumber);
                        //        xml_writer.WriteElementString("VerificationStr1", customer.BillingAddress.Address1 ?? "" + "|"
                        //                                                        + customer.BillingAddress.ZipPostalCode ?? "" + "|"
                        //                                                        + (customer.BillingAddress.StateProvince != null ? customer.BillingAddress.StateProvince.Name : "") + "|"
                        //                                                        + customer.BillingAddress.Country.ThreeLetterIsoCode);
                        //        xml_writer.WriteElementString("VerificationStr2", processPaymentRequest.CreditCardCvv2);
                        //        xml_writer.WriteElementString("CVD_Presence_Ind", "1");
                        //    }
                        //}
                        //else
                        //{
                        var initialOrder = _orderService.GetOrderById(processPaymentRequest.InitialOrderId);
                        int savedCardId = Convert.ToInt32(initialOrder.SubscriptionTransactionId.Substring(1));
                        SavedCard save_card = _savedCardService.GetById(savedCardId);
                        if (save_card == null)
                        {
                            throw new NullReferenceException("Saved Card #" + savedCardId.ToString() + " is null");
                        }

                        xml_writer.WriteElementString("CardHoldersName", save_card.CardholderName);
                        xml_writer.WriteElementString("TransarmorToken", save_card.Token);
                        xml_writer.WriteElementString("CardType", save_card.CardType);
                        xml_writer.WriteElementString("Expiry_Date", save_card.ExpireMonth.ToString("00") + save_card.ExpireYear.ToString().Substring(2, 2));
                        //}

                        xml_writer.WriteElementString("Client_Email", customer.Email);
                        xml_writer.WriteElementString("Currency", _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId).CurrencyCode);
                        xml_writer.WriteElementString("Customer_Ref", customer.CustomerGuid.ToString());
                        xml_writer.WriteElementString("Reference_No", processPaymentRequest.OrderGuid.ToString());
                        xml_writer.WriteElementString("Client_IP", _webHelper.GetCurrentIpAddress());
                        xml_writer.WriteElementString("ZipCode", customer.BillingAddress.ZipPostalCode ?? "");
                        xml_writer.WriteEndElement();
                        String xml_string = string_builder.ToString();

                        try
                        {
                            var response = SendFDRequest(xml_string);
                            if (response.SelectSingleNode("Transaction_Approved").InnerText == "true")
                            {
                                result.AuthorizationTransactionId = response.SelectSingleNode("Authorization_Num").InnerText + "|" + response.SelectSingleNode("Transaction_Tag").InnerText;
                                result.AuthorizationTransactionResult = string.Format("Approved ({0}: {1})", response.SelectSingleNode("EXact_Resp_Code").InnerText, response.SelectSingleNode("EXact_Message").InnerText);
                                if (_firstDataSettings.TransactionMode == TransactMode.AuthorizeAndCapture)
                                {
                                    result.CaptureTransactionId = response.SelectSingleNode("Authorization_Num").InnerText + "|" + response.SelectSingleNode("Transaction_Tag").InnerText;
                                }

                                result.AvsResult = response.SelectSingleNode("AVS").InnerText;
                                result.AllowStoringCreditCardNumber = false;

                                result.NewPaymentStatus = (_firstDataSettings.TransactionMode == TransactMode.Authorize ? PaymentStatus.Authorized : PaymentStatus.Paid);

                                if (!useSavedCard)
                                {
                                    var token = response.SelectSingleNode("TransarmorToken").InnerText;

                                    var existingCard = _savedCardService.GetByToken(customer.Id, token);
                                    if (existingCard == null) //don't save the same card twice
                                    {
                                        SavedCard card = new SavedCard();
                                        card.BillingAddress_Id = customer.BillingAddress.Id;
                                        card.CardholderName = processPaymentRequest.CreditCardName;
                                        card.CardType = response.SelectSingleNode("CardType").InnerText;
                                        card.Customer_Id = customer.Id;
                                        card.ExpireMonth = processPaymentRequest.CreditCardExpireMonth;
                                        card.ExpireYear = processPaymentRequest.CreditCardExpireYear;
                                        card.Token = token;
                                        _savedCardService.Insert(card);

                                        result.SubscriptionTransactionId = "T" + card.Id.ToString();
                                    }
                                }
                            }
                            else
                            {
                                result.AddError(string.Format("Error {0}: {1}", response.SelectSingleNode("Bank_Resp_Code").InnerText, response.SelectSingleNode("Bank_Message").InnerText));
                            }
                        }
                        catch (Exception ex)
                        {
                            result.AddError(_localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.TechnicalError"));
                            _logger.Error("Error processing payment", ex, _workContext.CurrentCustomer);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.TechnicalError"));
                _logger.Error("Error processing payment", ex, _workContext.CurrentCustomer);
            }

            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            var result = new CancelRecurringPaymentResult();
            //nothing special needed from First Data
            return result;
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "FirstDataPayments";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.Payments.FirstDataPayments.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "FirstDataPayments";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.Payments.FirstDataPayments.Controllers" }, { "area", null } };
        }

        public Type GetControllerType()
        {
            return typeof(FirstDataPaymentsController);
        }

        public override void Install()
        {
            //settings
            var settings = new FirstDataPaymentsSettings()
            {
                UseSandbox = true,
                TransactionMode = TransactMode.AuthorizeAndCapture
            };
            _settingService.SaveSetting(settings);

            //database objects
            _objectContext.Install();

            //locales
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Notes", "If you're using this gateway, ensure that your primary store currency is supported by FirstDataPayments Global Gateway e4.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.UseSandbox", "Use Sandbox");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.UseSandbox.Hint", "Check to enable Sandbox (testing environment).");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.TransactModeValues", "Transaction mode");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.TransactModeValues.Hint", "Choose transaction mode");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.HMAC", "HMAC");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.HMAC.Hint", "The HMAC for your terminal");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.GatewayID", "Gateway ID");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.GatewayID.Hint", "Specify gateway identifier.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.Password", "Password");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.Password.Hint", "Specify terminal password.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.KeyID", "Key ID");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.KeyID.Hint", "Specify key identifier.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFee", "Additional fee");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFeePercentage", "Additinal fee. Use percentage");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.ExpiryDateError", "Card expired");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.LicenseKey", "License Keys");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.LicenseKey.Hint", "The license key should have been emailed to you after your purchase.  If not, contact support@bitshiftweb.com");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.UnlicensedError", "This plugin is not licensed for this URL.  Purchase a license at http://www.bitshiftweb.com");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.TechnicalError", "There has been an unexpected error while processing your payment.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.SaveCard", "Save Card");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.SaveCard.Hint", "Save card for future use.  Your card number is tokenized on First Data's servers and not stored on our site.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableRecurringPayments", "Enable Recurring Payments");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableRecurringPayments.Hint", "Allows manual recurring payments by using the TransArmor Token");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableCardSaving", "Enable Card Saving");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableCardSaving.Hint", "Allows customers to choose to save a card when they use it.  The TransArmor Token is saved instead of the CC number");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.UseCardLabel", "Use");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.CardDescription", "{0} ending in {1}");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpirationDescription", "Expires {0}/{1}");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpiredLabel", "Expired");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.SavedCardsLabel", "Saved Cards");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.NewCardLabel", "Enter new card");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnablePurchaseOrderNumber", "Enable Purchase Order Number");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnablePurchaseOrderNumber.Hint", "Will optionally capture a purchase order number and append it to the Authorization Transaction ID in the Order Details");

            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<FirstDataPaymentsSettings>();

            //locales
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Notes");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.UseSandbox");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.UseSandbox.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.TransactModeValues");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.TransactModeValues.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.HMAC");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.HMAC.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.GatewayID");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.GatewayID.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.Password");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.Password.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.KeyID");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.KeyID.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFee");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFee.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFeePercentage");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.AdditionalFeePercentage.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.ExpiryDateError");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.LicenseKey");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.LicenseKey.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.TechnicalError");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.UnlicensedError");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.SaveCard");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableRecurringPayments");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableRecurringPayments.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableCardSaving");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnableCardSaving.Hint");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.UseCardLabel");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.CardDescription");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpirationDescription");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpiredLabel");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.SavedCardsLabel");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Payment.NewCardLabel");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnablePurchaseOrderNumber");
            this.DeletePluginLocaleResource("Shopfast.Plugin.FirstDataPayments.Fields.EnablePurchaseOrderNumber.Hint");

            _objectContext.Uninstall();

            base.Uninstall();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                if (_firstDataSettings.EnableRecurringPayments)
                {
                    return RecurringPaymentType.Manual;
                }
                else
                {
                    return RecurringPaymentType.NotSupported;
                }
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        #endregion
    }
}
