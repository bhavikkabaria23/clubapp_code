﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.Payments.FirstDataPayments
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Shopfast.Plugin.Payments.FirstDataPayments.Configure",
                 "Plugins/ShopFast.FirstDataPayments/Configure",
                 new { controller = "FirstDataPayments", action = "Configure" },
                 new[] { "Shopfast.Plugin.Payments.FirstDataPayments.Controllers" }
            );

            routes.MapRoute("Shopfast.Plugin.Payments.FirstDataPayments.PaymentInfo",
                 "Plugins/ShopFast.FirstDataPayments/PaymentInfo",
                 new { controller = "FirstDataPayments", action = "PaymentInfo" },
                 new[] { "Shopfast.Plugin.Payments.FirstDataPayments.Controllers" }
            );
        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
