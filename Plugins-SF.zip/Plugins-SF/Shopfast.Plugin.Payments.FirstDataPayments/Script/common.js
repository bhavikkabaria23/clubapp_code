﻿var cardDetail = [{
    "CardType": "DCI",
    "Length": 16,
    "Start": 3000000,
    "End": 3059999,
    "BRange": 7
},
{
    "CardType": "DCI",
    "Length": 16,
    "Start": 3095000,
    "End": 3095999,
    "BRange": 7
},
{
    "CardType": "JCB",
    "Length": 16,
    "Start": 3528000,
    "End": 3589999,
    "BRange": 7
},
{
    "CardType": "DCI",
    "Length": 14,
    "Start": 3600000,
    "End": 3699999,
    "BRange": 7
},
{
    "CardType": "DCI",
    "Length": 16,
    "Start": 3800000,
    "End": 3999999,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6011000,
    "End": 6011099,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6011200,
    "End": 6011499,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6011740,
    "End": 6011749,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6011770,
    "End": 6011799,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6011860,
    "End": 6011999,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6221260,
    "End": 6229259,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6240000,
    "End": 6269999,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6282000,
    "End":   6288999,
    "BRange": 7
},
{
    "CardType": "Discover",
    "Length": 16,
    "Start": 6440000,
    "End":   6599999,
    "BRange": 7
},
{
    "CardType": "JCB",
    "Length": 16,
    "Start": 352800,
    "End": 358999,
    "BRange": 5
},
{
    "CardType": "VISA",
    "Length": 16,
    "Start": 4,
    "End": 4,
    "BRange": 1
},
{
    "CardType": "MASTERCARD",
    "Length": 16,
    "Start": 5,
    "End": 5,
    "BRange": 1
},
{
    "CardType": "AMERICAN EXPRESS",
    "Length": 15,
    "Start": 37,
    "End": 37,
    "BRange": 2
},
{
    "CardType": "AMERICAN EXPRESS",
    "Length": 15,
    "Start": 34,
    "End": 34,
    "BRange": 2
}]
