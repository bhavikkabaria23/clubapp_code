﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Payments.FirstDataPayments.Domain
{
    public static class Constants
    {
        public const string LicenseKeySeed = "firstdatab718aec1fb";
    }
}
