﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Shopfast.Plugin.Payments.FirstDataPayments.Domain;
using Shopfast.Plugin.Payments.FirstDataPayments.Models;
using Shopfast.Plugin.Payments.FirstDataPayments.Validators;
using Shopfast.Plugin.Payments.FirstDataPayments.Services;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Services;

namespace Shopfast.Plugin.Payments.FirstDataPayments.Controllers
{
    public class FirstDataPaymentsController : BasePaymentController
    {
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;
        private readonly FirstDataPaymentsSettings _firstDataSettings;
        private readonly ISavedCardService _savedCardService;
        private readonly IEncryptionService _encryptionService;
        private readonly IWorkContext _workContext;
        private readonly OrderSettings _orderSettings;

        public FirstDataPaymentsController(ISettingService settingService, ILocalizationService localizationService, 
            FirstDataPaymentsSettings firstDataSettings, IEncryptionService encryptionService, ISavedCardService savedCardService,
            IWorkContext workContext, OrderSettings orderSettings)
        {
            this._settingService = settingService;
            this._localizationService = localizationService;
            this._firstDataSettings = firstDataSettings;
            this._encryptionService = encryptionService;
            this._savedCardService = savedCardService;
            this._workContext = workContext;
            this._orderSettings = orderSettings;
        }
        
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = new ConfigurationModel();
            model.UseSandbox = _firstDataSettings.UseSandbox;
            model.TransactModeId = Convert.ToInt32(_firstDataSettings.TransactionMode);
            if(!string.IsNullOrEmpty(_firstDataSettings.HMAC))
                model.HMAC = _encryptionService.DecryptText(_firstDataSettings.HMAC);
            if (!string.IsNullOrEmpty(_firstDataSettings.GatewayID)) 
                model.GatewayID = _encryptionService.DecryptText(_firstDataSettings.GatewayID);
            if (!string.IsNullOrEmpty(_firstDataSettings.Password)) 
                model.Password = _encryptionService.DecryptText(_firstDataSettings.Password);
            if (!string.IsNullOrEmpty(_firstDataSettings.KeyID)) 
                model.KeyID = _encryptionService.DecryptText(_firstDataSettings.KeyID);
            model.AdditionalFee = _firstDataSettings.AdditionalFee;
            model.AdditionalFeePercentage = _firstDataSettings.AdditionalFeePercentage;
            model.EnableRecurringPayments = _firstDataSettings.EnableRecurringPayments;
            model.EnableCardSaving = _firstDataSettings.EnableCardSaving;
            model.EnablePurchaseOrderNumber = _firstDataSettings.EnablePurchaseOrderNumber;
            
            model.TransactModeValues = _firstDataSettings.TransactionMode.ToSelectList();
            
            return View("~/Plugins/Payments.FirstDataPayments/Views/PaymentFirstData/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            model.SavedSuccessfully = true;
            if (ModelState.IsValid)
            {
                try
                {
                    _firstDataSettings.UseSandbox = model.UseSandbox;
                    _firstDataSettings.TransactionMode = (TransactMode)model.TransactModeId;
                    _firstDataSettings.HMAC = _encryptionService.EncryptText(model.HMAC);
                    _firstDataSettings.GatewayID = _encryptionService.EncryptText(model.GatewayID);
                    _firstDataSettings.Password = _encryptionService.EncryptText(model.Password);
                    _firstDataSettings.KeyID = _encryptionService.EncryptText(model.KeyID);
                    _firstDataSettings.AdditionalFee = model.AdditionalFee;
                    _firstDataSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;
                    _firstDataSettings.EnableRecurringPayments = model.EnableRecurringPayments;
                    _firstDataSettings.EnableCardSaving = model.EnableCardSaving;
                    _firstDataSettings.EnablePurchaseOrderNumber = model.EnablePurchaseOrderNumber;
                    _settingService.SaveSetting(_firstDataSettings);

                    model.SaveMessage = "Settings saved";
                }
                catch (Exception ex)
                {
                    model.SavedSuccessfully = false;
                    model.SaveMessage = ex.Message;
                }
            }
            else
            {
                model.SavedSuccessfully = false;
                model.SaveMessage = ModelState.Values.First().Errors.First().ErrorMessage;
            }

            model.TransactModeValues = _firstDataSettings.TransactionMode.ToSelectList();

            return View("~/Plugins/Payments.FirstDataPayments/Views/PaymentFirstData/Configure.cshtml", model);
        }

        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();
            
            //CC types
            model.CreditCardTypes.Add(new SelectListItem()
                {
                    Text = "Visa",
                    Value = "Visa",
                });
            model.CreditCardTypes.Add(new SelectListItem()
            {
                Text = "Master card",
                Value = "MasterCard",
            });
            model.CreditCardTypes.Add(new SelectListItem()
            {
                Text = "Discover",
                Value = "Discover",
            });
            model.CreditCardTypes.Add(new SelectListItem()
            {
                Text = "Amex",
                Value = "Amex",
            });
            
            //years
            for (int i = 0; i < 15; i++)
            {
                string year = Convert.ToString(DateTime.Now.Year + i);
                model.ExpireYears.Add(new SelectListItem()
                {
                    Text = year,
                    Value = year,
                });
            }

            //months
            for (int i = 1; i <= 12; i++)
            {
                string text = (i < 10) ? "0" + i.ToString() : i.ToString();
                model.ExpireMonths.Add(new SelectListItem()
                {
                    Text = text,
                    Value = i.ToString(),
                });
            }

            model.EnableCardSaving = _firstDataSettings.EnableCardSaving;
            model.EnablePurchaseOrderNumber = _firstDataSettings.EnablePurchaseOrderNumber;
            model.SavedCardsLabel = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.SavedCardsLabel");
            model.NewCardLabel = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.NewCardLabel");
            model.IsOnePageCheckout = _orderSettings.OnePageCheckoutEnabled;

            var savedCards = _savedCardService.GetByCustomer(_workContext.CurrentCustomer.Id);
            foreach (var savedCard in savedCards)
            {
                SavedCardModel savedCardModel = new SavedCardModel();

                savedCardModel.Id = savedCard.Id;
                savedCardModel.CardholderName = savedCard.CardholderName;
                savedCardModel.Last4Digits = savedCard.Token.Substring(savedCard.Token.Length - 4);
                savedCardModel.ExpireMonth = savedCard.ExpireMonth;
                savedCardModel.ExpireYear = savedCard.ExpireYear;
                savedCardModel.CardType = savedCard.CardType;
                savedCardModel.IsExpired = (DateTime.Now > new DateTime(savedCard.ExpireYear, savedCard.ExpireMonth, 1).AddMonths(1));
                savedCardModel.CardDescription = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.CardDescription");
                savedCardModel.ExpirationDescription = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpirationDescription");
                savedCardModel.ExpiredLabel = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.ExpiredLabel");
                savedCardModel.UseCardLabel = _localizationService.GetResource("Shopfast.Plugin.FirstDataPayments.Payment.UseCardLabel");

                model.SavedCards.Add(savedCardModel);
            }

            //set postback values
            var form = this.Request.Form;
            model.CardholderName = form["CardholderName"];
            model.CardNumber = form["CardNumber"];
            model.CardCode = form["CardCode"];
            model.SaveCard = (form["SaveCard"] != null ? Convert.ToBoolean(form["SaveCard"]) : false);
            var selectedCcType = model.CreditCardTypes.Where(x => x.Value.Equals(form["CreditCardType"], StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (selectedCcType != null)
                selectedCcType.Selected = true;
            var selectedMonth = model.ExpireMonths.Where(x => x.Value.Equals(form["ExpireMonth"], StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (selectedMonth != null)
                selectedMonth.Selected = true;
            var selectedYear = model.ExpireYears.Where(x => x.Value.Equals(form["ExpireYear"], StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (selectedYear != null)
                selectedYear.Selected = true;

            return View("~/Plugins/Payments.FirstDataPayments/Views/PaymentFirstData/PaymentInfo.cshtml", model);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();

            int savedCardId = 0;
            if (form["savedCardId"] != null && int.TryParse(form["savedCardId"], out savedCardId))
            {
                return warnings;
            }

            //validate
            var validator = new PaymentInfoValidator(_localizationService);
            var model = new PaymentInfoModel()
            {
                CardholderName = form["CardholderName"],
                CardNumber = form["CardNumber"],
                CardCode = form["CardCode"],
                ExpireMonth = form["ExpireMonth"],
                ExpireYear = form["ExpireYear"],
            };
            var validationResult = validator.Validate(model);
            if (!validationResult.IsValid)
                foreach (var error in validationResult.Errors)
                    warnings.Add(error.ErrorMessage);
            return warnings;
        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
            paymentInfo.CreditCardType = form["hdnselectCard"];
            //paymentInfo.CreditCardType = form["CreditCardType"];
            paymentInfo.CreditCardName = form["CardholderName"];
            paymentInfo.CreditCardNumber = form["CardNumber"];
            paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            paymentInfo.CreditCardCvv2 = form["CardCode"];

            // PurchaseOrderNumber is not used in 3.5
            //if (_firstDataSettings.EnablePurchaseOrderNumber)
            //{
            //    paymentInfo.PurchaseOrderNumber = form["PurchaseOrderNumber"];
            //}

            if (form["SaveCard"] != null)
            {
                paymentInfo.CreditCardNumber += "|" + form["SaveCard"].Split(',')[0].ToString();
            }

            int savedCardId = 0;
            if (form["savedCardId"] != null && int.TryParse(form["savedCardId"], out savedCardId))
            {
                paymentInfo.CreditCardNumber = "T" + savedCardId.ToString();
            }

            return paymentInfo;
        }
    }
}