﻿using System;
using Nop.Core;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Infrastructure;
using Nop.Services.Localization;
using Nop.Services.Orders;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public interface IITPOrderService : IOrderService
    {
        IPagedList<Order> SearchOrdersByGenericAttribute(int storeId = 0,
            int vendorId = 0, int customerId = 0,
            int productId = 0, int affiliateId = 0, int warehouseId = 0,
            DateTime? createdFromUtc = null, DateTime? createdToUtc = null,
            OrderStatus? os = null, PaymentStatus? ps = null, ShippingStatus? ss = null,
            string billingEmail = null, string orderGuid = null,
            int pageIndex = 0, int pageSize = int.MaxValue, string key = null, string value = null);

        /// <summary>
        /// Search recurring payment by order Id in recurring payments table or, if couldn't find anything, in recurring payments history
        /// </summary>
        /// <param name="storeId">The store identifier; 0 to load all records</param>
        /// <param name="orderId">The order identifier</param>
        /// <returns>Recurring payment collection</returns>
        RecurringPayment GetRecurringPaymentByOrderId(int storeId, int orderId);
    }
}
