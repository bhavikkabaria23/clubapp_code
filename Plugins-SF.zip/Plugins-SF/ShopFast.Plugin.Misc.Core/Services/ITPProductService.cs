﻿using System;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Security;
using Nop.Core.Domain.Stores;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Services.Stores;
using ShopFast.Plugin.Misc.Core.Extensions;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPProductService : ProductService
    {
        private readonly WeightAttributeParser _weightAttributeParser;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly WeightProductTemplateService _productWeightTemplateService;
        //nop3.7 upgrade begin
        public ITPProductService(ICacheManager cacheManager,
            IRepository<Product> productRepository,
            IRepository<RelatedProduct> relatedProductRepository,
            IRepository<CrossSellProduct> crossSellProductRepository,
            IRepository<TierPrice> tierPriceRepository,
            IRepository<ProductPicture> productPictureRepository,
            IRepository<LocalizedProperty> localizedPropertyRepository,
            IRepository<AclRecord> aclRepository,
            IRepository<StoreMapping> storeMappingRepository,
            IRepository<ProductSpecificationAttribute> productSpecificationAttributeRepository,
            IRepository<ProductReview>  productReviewRepository,
            IRepository<ProductWarehouseInventory> productWarehouseInventoryRepository,
            IRepository<SpecificationAttributeOption> specificationAttributeOptionRepository,
            IProductAttributeService productAttributeService,
            IProductAttributeParser productAttributeParser,
            ILanguageService languageService,
            IWorkflowMessageService workflowMessageService,
            IDataProvider dataProvider, 
            IDbContext dbContext,
            IWorkContext workContext,
            LocalizationSettings localizationSettings, 
            CommonSettings commonSettings,
            CatalogSettings catalogSettings,
            IEventPublisher eventPublisher,
            IAclService aclService,
            IStoreMappingService storeMappingService,
            //nop3.7 upgrade end
            //nop3.8 upgrade begin

            //nop3.8 upgrade begin
            WeightAttributeParser weightAttributeParser, 
            IGenericAttributeService genericAttributeService, 
            WeightProductTemplateService productWeightTemplateService
            )
            //nop3.8 upgrade begin
            : base(cacheManager, productRepository, relatedProductRepository, crossSellProductRepository, tierPriceRepository,
            productPictureRepository, localizedPropertyRepository, aclRepository, storeMappingRepository, 
            productSpecificationAttributeRepository, productReviewRepository, productWarehouseInventoryRepository, 
            specificationAttributeOptionRepository,
            productAttributeService, productAttributeParser, languageService, workflowMessageService, dataProvider, dbContext,
            workContext, localizationSettings, commonSettings, catalogSettings, eventPublisher, aclService, storeMappingService)
            //nop3.8 upgrade end
        {
            _weightAttributeParser = weightAttributeParser;
            _genericAttributeService = genericAttributeService;
            _productWeightTemplateService = productWeightTemplateService;
        }

        #region Inventory management methods
        /// <summary>
        /// Adjust inventory
        /// </summary>
        /// <param name="product">Product</param>
        /// <param name="quantityToChange">Quantity to increase or descrease</param>
        /// <param name="attributesXml">Attributes in XML format</param>
        public override void AdjustInventory(Product product, int quantityToChange, string attributesXml = "")
        {
            if (product == null)
                throw new ArgumentNullException("product");
            if (product.ManageInventoryMethod == ManageInventoryMethod.ManageStock && _productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId))
            {
                var value = _weightAttributeParser.ParseProductAttributeValue(attributesXml);
                decimal decimalValue;
                if (decimal.TryParse(value, out decimalValue) && decimalValue > 0)
                {
                    var weight = product.GetAttribute<decimal>(SystemCustomerAttributeNames.Weight);
                    weight -= decimalValue;
                    _genericAttributeService.SaveAttribute(product, SystemCustomerAttributeNames.Weight, weight);
                }                
            }
            base.AdjustInventory(product, quantityToChange, attributesXml);
        }
        #endregion
    }
}
