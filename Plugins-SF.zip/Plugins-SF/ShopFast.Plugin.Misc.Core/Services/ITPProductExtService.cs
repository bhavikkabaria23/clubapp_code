﻿using System.Collections.Generic;
using System.Linq;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPProductExtService
    {
        private readonly IRepository<Product> _productRepository;
        private readonly IRepository<ProductAttributeMapping> _productAttributeMappingRepository;
        private readonly IRepository<ProductTemplate> _productTemplateRepository;
        public ITPProductExtService(
            IRepository<Product> productRepository,
            IRepository<ProductAttributeMapping> productAttributeMappingRepository,
            IRepository<ProductTemplate> productTemplateRepository
            )
        {
            _productRepository = productRepository;
            _productAttributeMappingRepository = productAttributeMappingRepository;
            _productTemplateRepository = productTemplateRepository;
        }

        public List<Product> GetProductsWithAtt()
        {
            var query = from p in _productRepository.Table
                        join pt in _productTemplateRepository.Table
                        on p.ProductTemplateId equals pt.Id
                        join pm in _productAttributeMappingRepository.Table
                        on p.Id equals pm.ProductId into pam
                        from subp in pam.DefaultIfEmpty()
                        orderby p.DisplayOrder, p.Name
                        where p.Published && !p.Deleted &&(p.IsGiftCard || subp !=null || pt.ViewPath.Contains("ProductWeight"))
                        select p;
            var products = query.Distinct().ToList();
            return products;
        }
            
    }
}
