﻿using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Infrastructure;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public interface IITPPaymentService : IPaymentService
    {

    }
}
