﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Xml;
using Nop.Core.Domain.Catalog;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class WeightAttributeParser
    {
        private const string AttributeNodeName = "Attributes";
        private const string VariantAttributeNodeName = "ProductVariantAttribute";
        private const string VariantAttributeValueNodeName = "ProductVariantAttributeValue";
        /// <summary>
        /// Adds an attribute
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="productAttributeMapping">Product attribute mapping</param>
        /// <param name="value">Value</param>
        /// <returns>Attributes</returns>
        public virtual string AddProductAttribute(string attributesXml, ProductAttributeMapping productAttributeMapping,
            string value)
        {
            int productAttributeMappingId = productAttributeMapping.Id;

            string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                
                if (String.IsNullOrEmpty(attributesXml))
                {
                    var attributesExt = xmlDoc.CreateElement(AttributeNodeName);
                    xmlDoc.AppendChild(attributesExt);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//" + AttributeNodeName);

                if (rootElement == null)
                {
                    var attributesExt = xmlDoc.CreateElement(AttributeNodeName);
                    xmlDoc.AppendChild(attributesExt);
                    rootElement = attributesExt;    
                }
                
                XmlElement attributeElement = null;
                //find existing
                var productVariantAttributes = xmlDoc.SelectNodes(@"//" + AttributeNodeName + "/" + VariantAttributeNodeName);
                foreach (XmlNode productVariantAttribute in productVariantAttributes)
                {
                    if (productVariantAttribute.Attributes != null && productVariantAttribute.Attributes["ID"] != null)
                    {
                        string str1 = productVariantAttribute.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == productAttributeMappingId)
                            {
                                attributeElement = (XmlElement)productVariantAttribute;
                                break;
                            }
                        }
                    }
                }

                //create new one if not found
                if (attributeElement == null)
                {
                    attributeElement = xmlDoc.CreateElement(VariantAttributeNodeName);
                    attributeElement.SetAttribute("ID", productAttributeMappingId.ToString());
                    rootElement.AppendChild(attributeElement);
                }

                
                var attributeValueElement = xmlDoc.CreateElement(VariantAttributeValueNodeName);
                attributeElement.AppendChild(attributeValueElement);

                var attributeValueValueElement = xmlDoc.CreateElement("Value");
                attributeValueValueElement.InnerText = value;
                attributeValueElement.AppendChild(attributeValueValueElement);

                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

        /// <summary>
        /// Gets selected product attribute mapping identifiers
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <returns>Selected product attribute mapping identifiers</returns>
        public virtual IList<int> ParseProductAttributeMappingIds(string attributesXml)
        {
            var ids = new List<int>();
            if (String.IsNullOrEmpty(attributesXml))
                return ids;

            try
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(attributesXml);

                var nodeList1 = xmlDoc.SelectNodes(@"//" + AttributeNodeName + "/"+ VariantAttributeNodeName);
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            ids.Add(id);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return ids;
        }
        /// <summary>
        /// Get product attribute values
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <returns>Product attribute values</returns>
        public virtual string ParseProductAttributeValue(string attributesXml)
        {
            var attribute = new ProductAttributeMapping{Id = 1};

            var valuesStr = ParseValues(attributesXml, attribute.Id);

            return valuesStr.FirstOrDefault();
        }

        /// <summary>
        /// Gets selected product attribute values
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="productAttributeMappingId">Product attribute mapping identifier</param>
        /// <returns>Product attribute values</returns>
        public virtual IList<string> ParseValues(string attributesXml, int productAttributeMappingId)
        {
            var selectedValues = new List<string>();
            try
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(attributesXml);

                var nodeList1 = xmlDoc.SelectNodes(@"//" +AttributeNodeName + "/" + VariantAttributeNodeName);
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == productAttributeMappingId)
                            {
                                var nodeList2 = node1.SelectNodes(VariantAttributeValueNodeName+@"/Value");
                                foreach (XmlNode node2 in nodeList2)
                                {
                                    string value = node2.InnerText.Trim();
                                    selectedValues.Add(value);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return selectedValues;
        }



        /// <summary>
        /// Are attributes equal
        /// </summary>
        /// <param name="attributesXml1">The attributes of the first product</param>
        /// <param name="attributesXml2">The attributes of the second product</param>
        /// <returns>Result</returns>
        public virtual bool AreProductAttributesEqual(string attributesXml1, string attributesXml2)
        {
            bool attributesEqual = true;
            if (ParseProductAttributeMappingIds(attributesXml1).Count == ParseProductAttributeMappingIds(attributesXml2).Count)
            {
                var values1Str = ParseProductAttributeValue(attributesXml1);
                var values2Str = ParseProductAttributeValue(attributesXml2);
                if(values1Str.Trim() != values2Str.Trim())
                    attributesEqual = false;
            }
            else
            {
                attributesEqual = false;
            }

            return attributesEqual;
        }
    }
}
