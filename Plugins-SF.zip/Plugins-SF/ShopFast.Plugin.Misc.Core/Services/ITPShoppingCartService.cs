﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Events;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Stores;
using SystemCustomerAttributeNames = ShopFast.Plugin.Misc.Core.Extensions.SystemCustomerAttributeNames;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPShoppingCartService : ShoppingCartService
    {
        private readonly WeightAttributeParser _weightAttributeParser;
        private readonly ILocalizationService _localizationService2;
        private readonly WeightProductTemplateService _productWeightTemplateService;
        private TipsCheckoutAttributeParser _tipsCheckoutAttributeParser;

        //nop3.7 upgrade begin
        public ITPShoppingCartService(IRepository<ShoppingCartItem> sciRepository, 
            IWorkContext workContext, 
            IStoreContext storeContext, 
            ICurrencyService currencyService, 
            IProductService productService, 
            ILocalizationService localizationService, 
            IProductAttributeParser productAttributeParser, 
            ICheckoutAttributeService checkoutAttributeService, 
            ICheckoutAttributeParser checkoutAttributeParser, 
            IPriceFormatter priceFormatter, 
            ICustomerService customerService, 
            ShoppingCartSettings shoppingCartSettings, 
            IEventPublisher eventPublisher, 
            IPermissionService permissionService, 
            IAclService aclService, 
            IStoreMappingService storeMappingService, 
            IGenericAttributeService genericAttributeService, 
            IProductAttributeService productAttributeService, 
            WeightAttributeParser weightAttributeParser, 
            WeightProductTemplateService productWeightTemplateService, 
            TipsCheckoutAttributeParser tipsCheckoutAttributeParser, 
            IDateTimeHelper dateTimeHelper)
            : base(sciRepository, workContext, storeContext, currencyService, productService, localizationService,
            productAttributeParser, checkoutAttributeService, checkoutAttributeParser, priceFormatter, customerService,
            shoppingCartSettings, eventPublisher, permissionService, aclService, storeMappingService, genericAttributeService,
            productAttributeService, dateTimeHelper)
        //nop3.7 upgrade end
        {
            _weightAttributeParser = weightAttributeParser;
            _localizationService2 = localizationService;
            _productWeightTemplateService = productWeightTemplateService;
            _tipsCheckoutAttributeParser = tipsCheckoutAttributeParser;
        }

        //nop3.7 upgrade begin
        /// <summary>
        /// Validates shopping cart item attributes
        /// </summary>
        /// <param name="customer">Customer</param>
        /// <param name="shoppingCartType">Shopping cart type</param>
        /// <param name="product">Product</param>
        /// <param name="quantity">Quantity</param>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="ignoreNonCombinableAttributes">A value indicating whether we should ignore non-combinable attributes</param>
        /// <returns>Warnings</returns>
        public override IList<string> GetShoppingCartItemAttributeWarnings(Customer customer,
            ShoppingCartType shoppingCartType,
            Product product,
            int quantity = 1,
            string attributesXml = "",
            bool ignoreNonCombinableAttributes = false)
        //nop3.7 upgrade end
        {
            if (product == null)
                throw new ArgumentNullException("product");

            var warnings = base.GetShoppingCartItemAttributeWarnings(customer, shoppingCartType, product, quantity, attributesXml);

            if (_productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId))
            {
                //validate required weight product attribute (whether they're entered)
                var value = _weightAttributeParser.ParseProductAttributeValue(attributesXml);
                decimal decimalValue;
                if (!decimal.TryParse(value, out decimalValue) || decimalValue <= 0)
                {
                    var notFoundWarning =
                        string.Format(
                            _localizationService2.GetResource(
                                "ShopFast.Plugins.Control.ProductWeight.ShoppingCart.RequiredStringAttribute"),
                            _localizationService2.GetResource("ShopFast.Plugins.Control.ProductWeight.Weight"));
                    warnings.Add(notFoundWarning);
                }
            }
            return warnings;
        }

        /// <summary>
        /// Finds a shopping cart item in the cart
        /// </summary>
        /// <param name="shoppingCart">Shopping cart</param>
        /// <param name="shoppingCartType">Shopping cart type</param>
        /// <param name="product">Product</param>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="customerEnteredPrice">Price entered by a customer</param>
        /// <param name="rentalStartDate">Rental start date</param>
        /// <param name="rentalEndDate">Rental end date</param>
        /// <returns>Found shopping cart item</returns>
        public override ShoppingCartItem FindShoppingCartItemInTheCart(IList<ShoppingCartItem> shoppingCart,
            ShoppingCartType shoppingCartType,
            Product product,
            string attributesXml = "",
            decimal customerEnteredPrice = decimal.Zero,
            DateTime? rentalStartDate = null,
            DateTime? rentalEndDate = null)
        {
            if (shoppingCart == null)
                throw new ArgumentNullException("shoppingCart");

            if (product == null)
                throw new ArgumentNullException("product");

            var sci = base.FindShoppingCartItemInTheCart(shoppingCart, shoppingCartType, product, attributesXml,
                customerEnteredPrice, rentalStartDate, rentalEndDate);
            if (_productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId) && sci != null)
            {
                bool attributesEqual = _weightAttributeParser.AreProductAttributesEqual(sci.AttributesXml, attributesXml);
                if (attributesEqual)
                    return sci;
            }
            return sci;
        }

        /// <summary>
        /// Validates a product for standard properties
        /// </summary>
        /// <param name="customer">Customer</param>
        /// <param name="shoppingCartType">Shopping cart type</param>
        /// <param name="product">Product</param>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="customerEnteredPrice">Customer entered price</param>
        /// <param name="quantity">Quantity</param>
        /// <returns>Warnings</returns>
        public override IList<string> GetStandardWarnings(Customer customer, ShoppingCartType shoppingCartType,
            Product product, string attributesXml, decimal customerEnteredPrice,
            int quantity)
        {
            var warnings = base.GetStandardWarnings(customer, shoppingCartType, product, attributesXml, customerEnteredPrice,
                quantity);
            if (_productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId))
            {
                switch (product.ManageInventoryMethod)
                {
                    case ManageInventoryMethod.DontManageStock:
                    {
                        //do nothing
                    }
                        break;
                    case ManageInventoryMethod.ManageStock:
                    {

                        var value = _weightAttributeParser.ParseProductAttributeValue(attributesXml);
                        decimal decimalValue;
                        if (decimal.TryParse(value, out decimalValue) && decimalValue > 0)
                        {
                            var maximumQuantityCanBeAdded =
                                product.GetAttribute<decimal>(SystemCustomerAttributeNames.Weight);
                            if (maximumQuantityCanBeAdded < decimalValue)
                            {
                                    

                                if (maximumQuantityCanBeAdded <= 0)
                                    warnings.Add(_localizationService2.GetResource("ShoppingCart.OutOfStock"));
                                else
                                    warnings.Add(
                                        string.Format(
                                            _localizationService2.GetResource(
                                                "ShopFast.Plugins..Control.ProductWeight.ShoppingCart.WeightExceedsStock"),
                                            maximumQuantityCanBeAdded));
                            }
                        }

                    }
                        break;
                }
            }
            return warnings;
        }


        /// <summary>
        /// Validates whether this shopping cart is valid
        /// </summary>
        /// <param name="shoppingCart">Shopping cart</param>
        /// <param name="checkoutAttributesXml">Checkout attributes in XML format</param>
        /// <param name="validateCheckoutAttributes">A value indicating whether to validate checkout attributes</param>
        /// <returns>Warnings</returns>
        public override IList<string> GetShoppingCartWarnings(IList<ShoppingCartItem> shoppingCart,
            string checkoutAttributesXml, bool validateCheckoutAttributes)
        {
            var warnings = base.GetShoppingCartWarnings(shoppingCart, checkoutAttributesXml, validateCheckoutAttributes);
            {
                //validate tip attribute (whether they're entered)
                var value = _tipsCheckoutAttributeParser.ParseAmountValues(checkoutAttributesXml).FirstOrDefault();
                decimal decimalValue;
                if (!String.IsNullOrEmpty(value) && (!decimal.TryParse(value, out decimalValue) || decimalValue < 0))
                {
                    var notFoundWarning =
                        string.Format(
                            _localizationService2.GetResource(
                                            "ShopFast.Plugins.Widget.QuickShoppingCart.ValidNumber"),
                            _localizationService2.GetResource("ShopFast.Plugins.Widget.QuickShoppingCart.Tip"));
                    warnings.Add(notFoundWarning);
                }
            }
            return warnings;
        }
    }
}
