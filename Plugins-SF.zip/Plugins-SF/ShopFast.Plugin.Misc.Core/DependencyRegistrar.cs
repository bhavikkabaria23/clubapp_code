﻿using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Shipping;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.Core
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        //nop3.7 upgrade begin
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<WeightAttributeParser>().As<WeightAttributeParser>().InstancePerHttpRequest();
            builder.RegisterType<WeightProductTemplateService>().As<WeightProductTemplateService>().InstancePerHttpRequest();
            builder.RegisterType<ITPProductService>().As<IProductService>().InstancePerHttpRequest();
            builder.RegisterType<ITPPriceCalculationService>().As<IPriceCalculationService>().InstancePerHttpRequest();
            builder.RegisterType<ITPShippingService>().As<IShippingService>().InstancePerHttpRequest();
            builder.RegisterType<ITPProductAttributeFormatter>().As<IProductAttributeFormatter>().InstancePerHttpRequest();
            builder.RegisterType<TipsCheckoutAttributeParser>().As<TipsCheckoutAttributeParser>().InstancePerLifetimeScope();
            builder.RegisterType<ITPCheckoutAttributeFormatter>().As<ICheckoutAttributeFormatter>().InstancePerLifetimeScope();
            builder.RegisterType<ITPInvoiceTotalCalculationService>().As<IITPInvoiceTotalCalculationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPInvoiceTotalCalculationService>().As<IOrderTotalCalculationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPShoppingCartService>().As<IShoppingCartService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPLocalizationService>().As<ITPLocalizationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductExtService>().As<ITPProductExtService>().InstancePerLifetimeScope();
            builder.RegisterType<PrepareShoppingCartModels>().As<PrepareShoppingCartModels>().InstancePerLifetimeScope();
            builder.RegisterType<PrepareCheckoutModels>().As<PrepareCheckoutModels>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductTemplateService>().As<ITPProductTemplateService>().InstancePerHttpRequest();
            builder.RegisterType<ITPOrderService>().As<IOrderService>().InstancePerHttpRequest();
            builder.RegisterType<ITPOrderService>().As<IITPOrderService>().InstancePerHttpRequest();
            builder.RegisterType<InvoiceItemAttributeParser>().As<InvoiceItemAttributeParser>().InstancePerHttpRequest();
            builder.RegisterType<ITPCustomerService>().As<IITPCustomerService>().InstancePerHttpRequest();
            builder.RegisterType<InvoiceCartService>().As<IInvoiceCartService>().InstancePerHttpRequest();
            builder.RegisterType<InvoiceCartService>().As<IShoppingCartService>().InstancePerHttpRequest();
            builder.RegisterType<ITPMessageTokenProvider>().As<IITPMessageTokenProvider>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPartialPaymentService>().As<IITPPartialPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPOrderProcessingService>().As<IITPOrderProcessingService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPaymentService>().As<IPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPaymentService>().As<IITPPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPdfService>().As<IPdfService>().InstancePerLifetimeScope();
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 100500; }
        }

    }
}
