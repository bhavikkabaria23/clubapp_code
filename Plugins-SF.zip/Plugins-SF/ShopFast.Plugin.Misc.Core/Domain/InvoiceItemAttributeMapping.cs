using System.Collections.Generic;
using System.Numerics;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;

namespace ShopFast.Plugin.Misc.Core.Domain
{
    /// <summary>
    /// Represents a product attribute mapping
    /// </summary>
    public partial class InvoiceItemAttributeMapping : BaseEntity, ILocalizedEntity
    {
        /// <summary>
        /// Gets or sets the invoice identifier
        /// </summary>
        public int InvoiceId { get; set; }

        /// <summary>
        /// Gets or sets the custom Description of InvoiceItem
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Taxable property
        /// </summary>
        public bool Taxable { get; set; }

        /*public static bool operator ==(InvoiceItemAttributeMapping c1, InvoiceItemAttributeMapping c2)
        {
            if (c1 == null || c2 == null)
                return false;
            return (c1.InvoiceId == c2.InvoiceId) && (c1.Description == c2.Description) && (c1.Taxable == c2.Taxable);
        }

        public static bool operator !=(InvoiceItemAttributeMapping c1, InvoiceItemAttributeMapping c2)
        {
            if (c1 == null || c2 == null)
                return false;
            return !(c1 == c2);
        }*/
    }

}
