using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Messages;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Messages;
using ShopFast.Plugin.Misc.Core.Events;
using Nop.Services.Customers;
using Nop.Services.Logging;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.Core.Domain
{
    public partial class ITPMessageSentEventConsumer :
        //invoices
        IConsumer<InvoiceInserted>,
        IConsumer<InvoiceUpdated>,
        IConsumer<EstimateAccepted>,
    IConsumer<ITPEntityImported<Order>>
    {
        private readonly ICacheManager _cacheManager;
        private readonly IStoreContext _storeContext;
        private readonly IMessageTemplateService _messageTemplateService;
        private readonly ILocalizationService _localizationService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IITPMessageTokenProvider _messageTokenProvider;
        private readonly ITokenizer _tokenizer;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly IITPOrderService _orderService;
        private readonly ILogger _logger;

        public ITPMessageSentEventConsumer(IStoreContext storeContext, 
            IMessageTemplateService messageTemplateService, 
            ILocalizationService localizationService, 
            IEmailAccountService emailAccountService, 
            EmailAccountSettings emailAccountSettings, 
            LocalizationSettings localizationSettings, 
            IITPMessageTokenProvider messageTokenProvider,
            ITokenizer tokenizer, 
            IQueuedEmailService queuedEmailService, 
            IITPOrderService orderService, 
            ILogger logger)
        {
            _storeContext = storeContext;
            _messageTemplateService = messageTemplateService;
            _localizationService = localizationService;
            _emailAccountService = emailAccountService;
            _emailAccountSettings = emailAccountSettings;
            _localizationSettings = localizationSettings;
            _messageTokenProvider = messageTokenProvider;
            _tokenizer = tokenizer;
            _queuedEmailService = queuedEmailService;
            _orderService = orderService;
            _logger = logger;
            this._cacheManager = EngineContext.Current.ContainerManager.Resolve<ICacheManager>("nop_cache_static");
        }

        #region Utilites

        protected void SendEmailToCustomer(Customer receiver, Order invoice, string templateName)
        {
            var store = _storeContext.CurrentStore;

            try
            {
                var emailTemplate = _messageTemplateService.GetMessageTemplateByName(templateName, store.Id);

                if (receiver == null)
                    throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmptyReceiver"));
                if (String.IsNullOrWhiteSpace(receiver.Email))
                    throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmailEmpty"));
                if (!CommonHelper.IsValidEmail(receiver.Email))
                    throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmailNotValid"));
                if (emailTemplate == null)
                    throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.TemplateNotFound"));

                var emailAccount = _emailAccountService.GetEmailAccountById(_emailAccountSettings.DefaultEmailAccountId) ??
                                   _emailAccountService.GetAllEmailAccounts().FirstOrDefault();
                if (emailAccount == null)
                    throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.AccountNotLoaded"));

                var languageId = _localizationSettings.DefaultAdminLanguageId;

                var tokens = new List<Token>();
                _messageTokenProvider.AddStoreTokens(tokens, store, emailAccount);
                _messageTokenProvider.AddOrderTokens(tokens, invoice, languageId);
                _messageTokenProvider.AddCustomerTokens(tokens, invoice.Customer);

                var recurringPayment = _orderService.GetRecurringPaymentByOrderId(invoice.Id);
                if (recurringPayment != null)
                {
                    _messageTokenProvider.AddRecurringPaymentTokens(tokens, recurringPayment);
                }

                var subjectReplaced = _tokenizer.Replace(emailTemplate.Subject, tokens, false);
                var bodyReplaced = _tokenizer.Replace(emailTemplate.Body, tokens, true);

                var email = new QueuedEmail
                {
                    Priority = QueuedEmailPriority.High,
                    EmailAccountId = emailAccount.Id,
                    FromName = emailAccount.DisplayName,
                    From = emailAccount.Email,
                    ToName = receiver.GetFullName(),
                    To = receiver.Email,
                    Subject = subjectReplaced,
                    Body = bodyReplaced,
                    CreatedOnUtc = DateTime.UtcNow,
                };
                _queuedEmailService.InsertQueuedEmail(email);
            }
            catch (Exception exc)
            {
                throw;
            }
        }

        #endregion

        public void HandleEvent(InvoiceInserted eventMessage)
        {
            //_logger.Information("ITPMessageSentEventConsumer: Invoice Created");
            SendEmailToCustomer(eventMessage.Entity.Customer, eventMessage.Entity, "ShopFast.Plugin.Misc.Invoices.InvoiceCreated");
        }

        public void HandleEvent(InvoiceUpdated eventMessage)
        {
            //_logger.Information("ITPMessageSentEventConsumer: Invoice Updated");
            SendEmailToCustomer(eventMessage.Entity.Customer, eventMessage.Entity, "ShopFast.Plugin.Misc.Invoices.InvoiceUpdated");
        }

        public void HandleEvent(EstimateAccepted eventMessage)
        {
            //_logger.Information("ITPMessageSentEventConsumer: Estimate Accepted");
            SendEmailToCustomer(eventMessage.Entity.Customer, eventMessage.Entity, "ShopFast.Plugin.Misc.Invoices.InvoiceCreated");
        }

        public void HandleEvent(ITPEntityImported<Order> eventMessage)
        {
            //_logger.Information("ITPMessageSentEventConsumer: Order Imported");
            SendEmailToCustomer(eventMessage.Entity.Customer, eventMessage.Entity, "ShopFast.Plugin.Misc.BulkImport.OrderImported");
        }
        
    }
}
