﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Payments.ProtectPay.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        public int TransactModeId { get; set; }
        public bool TransactModeId_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.TransactModeValues")]
        public SelectList TransactModeValues { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.MerchantAccountId")]
        public string MerchantAccountId { get; set; }
        public bool MerchantAccountId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.MerchantProfileId")]
        public string MerchantProfileId { get; set; }
        public bool MerchantProfileId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFee_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        public bool AdditionalFeePercentage_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.PaymentMethods")]
        public string PaymentMethods { get; set; }
        public bool PaymentMethods_OverrideForStore { get; set; }
        public IList<SelectListItem> AvailablePaymentMethods { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.SplitPayment")]
        public bool SplitPayment { get; set; }
        public bool SplitPayment_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.SecondaryAccountId")]
        public string SecondaryAccountId { get; set; }
        public bool SecondaryAccountId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.ProtectPay.Fields.SplitPercentage")]
        public decimal SplitPercentage { get; set; }
        public bool SplitPercentage_OverrideForStore { get; set; }
    }
}