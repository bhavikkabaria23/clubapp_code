﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Payments.ProtectPay.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
        public PaymentInfoModel()
        {
            PaymentMethods = new List<SelectListItem>();
            // eCheck
            BankAccountTypes = new List<SelectListItem>();
            AccountTypes = new List<SelectListItem>();
        }

        [AllowHtml]
        public string PaymentMethod { get; set; }
        public IList<SelectListItem> PaymentMethods { get; set; }

        #region - Credit Card -

        [AllowHtml]
        [NopResourceDisplayName("Payment.CardNumber")]
        public string CardNumber { get; set; }

        [AllowHtml]
        public string CardType { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.ExpirationDate")]
        public string ExpirationDate { get; set; }
        [AllowHtml]
        public string ExpireMonth { get; set; }
        [AllowHtml]
        public string ExpireYear { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.CardCode")]
        public string CardCode { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.NameOnCard")]
        public string NameOnCard { get; set; }

        #endregion

        #region - eCheck -

        [AllowHtml]
        [NopResourceDisplayName("Payment.AccountType")]
        public string BankAccountType { get; set; }
        public IList<SelectListItem> BankAccountTypes { get; set; }

        [AllowHtml]
        public string AccountType { get; set; }
        public IList<SelectListItem> AccountTypes { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.RoutingNumber")]
        public string RoutingNumber { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.AccountNumber")]
        public string AccountNumber { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Payment.NameOnAccount")]
        public string NameOnAccount { get; set; }

        #endregion
    }
}