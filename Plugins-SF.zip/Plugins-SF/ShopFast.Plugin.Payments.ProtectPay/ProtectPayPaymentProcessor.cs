﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Routing;
using System.Xml;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Plugins;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using ShopFast.Plugin.Payments.ProtectPay.Controllers;

namespace ShopFast.Plugin.Payments.ProtectPay
{
    /// <summary>
    /// ProPay's ProtectPay processor.
    /// </summary>
    public class ProtectPayPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly ProtectPayPaymentSettings _protectPayPaymentSettings;
        private readonly ISettingService _settingService;
        private readonly ICurrencyService _currencyService;
        private readonly ICustomerService _customerService;
        private readonly CurrencySettings _currencySettings;
        private readonly IWebHelper _webHelper;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ILogger _logger;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Constructors

        public ProtectPayPaymentProcessor(ProtectPayPaymentSettings protectPayPaymentSettings,
            ISettingService settingService,
            ICurrencyService currencyService,
            ICustomerService customerService,
            CurrencySettings currencySettings, IWebHelper webHelper,
            IOrderTotalCalculationService orderTotalCalculationService,
            ILogger logger, ILocalizationService localizationService)
        {
            this._protectPayPaymentSettings = protectPayPaymentSettings;
            this._settingService = settingService;
            this._currencyService = currencyService;
            this._customerService = customerService;
            this._currencySettings = currencySettings;
            this._webHelper = webHelper;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._logger = logger;
            this._localizationService = localizationService;
        }

        #endregion

        #region Utilities

        /// <summary>
        /// Executes a request of ProtectPay's SOAP API.
        /// </summary>
        /// <param name="methodName">Method name.</param>
        /// <param name="requestXml">Request xml.</param>
        /// <returns>Response xml.</returns>
        private string ExecuteRequest(string methodName, string requestXml)
        {
            string responseXml = string.Empty;

            //create a web request using a service URL
            var webRequest = WebRequest.Create("https://protectpaytest.propay.com/API/SPS.svc");
            //set the SOAPAction header to the web request to call appropriate service method
            webRequest.Headers.Add("SOAPAction", string.Format("http://propay.com/SPS/contracts/SPSService/{0}", methodName));
            //set the Method property of the web request to POST data
            webRequest.Method = "POST";


            //create SOAP envelope
            var xmlBuilder = new StringBuilder();
            xmlBuilder.Append(string.Format("<soapenv:Envelope xmlns:soapenv=\"{0}\" xmlns:con=\"{1}\" xmlns:typ=\"{2}\"{3}{4}>",
                "http://schemas.xmlsoap.org/soap/envelope/", "http://propay.com/SPS/contracts", "http://propay.com/SPS/types",
                (requestXml.Contains("prop:") ? string.Format(" xmlns:prop{0}=\"{1}\"", (methodName == "ProcessSplitPayTransaction" ? "1" : string.Empty),
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.SPS.External") : string.Empty),
                (methodName == "ProcessSplitPayTransaction" ? string.Format(" xmlns:prop=\"{0}\"",
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.FraudDetection") : string.Empty)));
            xmlBuilder.Append("<soapenv:Header/>");
            xmlBuilder.Append("<soapenv:Body>");
            xmlBuilder.Append(requestXml);
            xmlBuilder.Append("</soapenv:Body>");
            xmlBuilder.Append("</soapenv:Envelope>");

            //convert a request xml to byte array
            byte[] byteArray = Encoding.UTF8.GetBytes(xmlBuilder.ToString());
            //set the ContentType property of the web request
            webRequest.ContentType = "text/xml";
            //set the ContentLength property of the web request
            webRequest.ContentLength = byteArray.Length;

            //get the request stream to write data
            var dataStream = webRequest.GetRequestStream();
            //write the request xml byte array to the request stream
            dataStream.Write(byteArray, 0, byteArray.Length);
            //close the request stream object
            dataStream.Close();


            //get the response
            var webResponse = webRequest.GetResponse();
            //get the response stream containing response returned by the ProtectPay
            dataStream = webResponse.GetResponseStream();
            //open the response stream using a StreamReader for easy access
            var streamReader = new StreamReader(dataStream);
            //get the response xml string
            responseXml = streamReader.ReadToEnd();

            //clean up the stream objects
            streamReader.Close();
            dataStream.Close();
            webResponse.Close();

            //returns response
            return responseXml;
        }

        /// <summary>
        /// Returns the payer account identifier for specified customer.
        /// </summary>
        /// <param name="customerId">Customer identifier.</param>
        /// <param name="customerEmail">Customer email.</param>
        /// <param name="customerName">Customer full name.</param>
        /// <returns>Payer account identifier.</returns>
        private string GetPayerAccount(int customerId, string customerEmail, string customerName)
        {
            string payerAccountId = string.Empty;

            try
            {
                //prepares get payer request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:GetPayers>");

                //sets the identification elements
                requestXml.Append("<con:billerId>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:billerId>");

                //sets the criteria elements
                requestXml.Append("<con:criteria>");
                requestXml.Append(string.Format("<typ:EmailAddress>{0}</typ:EmailAddress>", customerEmail));
                requestXml.Append(string.Format("<typ:ExternalId1>{0}</typ:ExternalId1>", customerId));
                requestXml.Append(string.Format("<typ:Name>{0}</typ:Name>", customerName));
                requestXml.Append("</con:criteria>");

                //sets the common elements
                requestXml.Append("</con:GetPayers>");


                //executes the get payers request
                var responseXml = ExecuteRequest("GetPayers", requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:GetPayersResponse/c:GetPayersResult/";
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //check for, is payer exists for specified criteria
                            if (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:Payers"), xmlnsManager).ChildNodes.Count == 1)
                            {
                                //sets the payer account identifier
                                payerAccountId = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:Payers/a:PayerInfo/a:payerAccountId"), xmlnsManager).InnerText;
                            }
                            else
                            {
                                //creates the new payer account in ProtectPay
                                payerAccountId = CreatePayerAccount(customerId, customerEmail, customerName);
                            }

                            break;
                        }
                    case "FAILURE":
                        {
                            _logger.Warning(string.Format("Failure occurred while executing the '{0}' method. FailureMessage: {1}", "ProtectPay-GetPayers",
                               xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-GetPayerAccount", ex.Message), ex);
            }

            return payerAccountId;
        }

        /// <summary>
        /// Creates the payer account in ProtectPay for specified customer.
        /// </summary>
        /// <param name="customerId">Customer identifier.</param>
        /// <param name="customerEmail">Customer email.</param>
        /// <param name="customerName">Customer full name.</param>
        /// <returns>Payer account identifier.</returns>
        private string CreatePayerAccount(int customerId, string customerEmail, string customerName)
        {
            string payerAccountId = string.Empty;

            try
            {
                //prepares the create payer request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:CreatePayerWithData>");

                //sets the identification elements
                requestXml.Append("<con:identification>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:identification>");

                //sets the data elements
                requestXml.Append("<con:data>");
                requestXml.Append(string.Format("<typ:EmailAddress>{0}</typ:EmailAddress>", customerEmail));
                requestXml.Append(string.Format("<typ:ExternalId1>{0}</typ:ExternalId1>", customerId));
                requestXml.Append(string.Format("<typ:Name>{0}</typ:Name>", customerName));
                requestXml.Append("</con:data>");

                //sets the common elements
                requestXml.Append("</con:CreatePayerWithData>");


                //executes the create payer request
                var responseXml = ExecuteRequest("CreatePayerWithData", requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:CreatePayerWithDataResponse/c:CreatePayerWithDataResult/";
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets the newly created payer account identifier
                            payerAccountId = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:ExternalAccountID"), xmlnsManager).InnerText;

                            break;
                        }
                    case "FAILURE":
                        {
                            _logger.Warning(string.Format("Failure occurred while executing the '{0}' method. FailureMessage: {1}", "ProtectPay-CreatePayerWithData",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-CreatePayerAccount", ex.Message), ex);
            }

            return payerAccountId;
        }

        /// <summary>
        /// Returns the credit card type based on number.
        /// </summary>
        /// <param name="creditCardNumber">The credit card number.</param>
        /// <returns>Credit card type.</returns>
        public string GetCreditCardType(string creditCardNumber)
        {
            var regexVisa = new Regex("^4[0-9]{12}(?:[0-9]{3})?$");
            var regexMasterCard = new Regex("^5[1-5][0-9]{14}$");
            var regexAmericanExpress = new Regex("^3[47][0-9]{13}$");
            var regexDinersClub = new Regex("^3(?:0[0-5]|[68][0-9])[0-9]{11}$");
            var regexDiscover = new Regex("^6(?:011|5[0-9]{2})[0-9]{12}$");
            var regexJCB = new Regex("^(?:2131|1800|35\\d{3})\\d{11}$");

            if (regexVisa.IsMatch(creditCardNumber))
                return "Visa";
            else if (regexMasterCard.IsMatch(creditCardNumber))
                return "MasterCard";
            else if (regexAmericanExpress.IsMatch(creditCardNumber))
                return "AMEX";
            else if (regexDinersClub.IsMatch(creditCardNumber))
                return "DinersClub";
            else if (regexDiscover.IsMatch(creditCardNumber))
                return "Discover";
            else if (regexJCB.IsMatch(creditCardNumber))
                return "JCB";
            else
                return string.Empty;
        }

        /// <summary>
        /// Returns the payment method identifier based on Credit Card or eCheck information.
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for a payment method creation.</param>
        /// <param name="customer">Customer object.</param>
        /// <param name="payerAccountId">Payer account identifier.</param>
        /// <returns>Payment method identifier.</returns>
        private string GetPaymentMethod(ProcessPaymentRequest processPaymentRequest, Customer customer, string payerAccountId)
        {
            string paymentMethodId = string.Empty;

            try
            {
                //prepares the create payment method request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:CreatePaymentMethod>");

                //sets the identification elements
                requestXml.Append("<con:identification>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:identification>");

                requestXml.Append("<con:pmAdd>");
                //sets the eCheck elements
                if (processPaymentRequest.CustomValues.Count > 0)
                {
                    requestXml.Append(string.Format("<typ:AccountCountryCode>{0}</typ:AccountCountryCode>",
                        _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId).CurrencyCode));
                    requestXml.Append(string.Format("<typ:AccountName>{0}</typ:AccountName>", processPaymentRequest.CustomValues["Name on account"]));
                    requestXml.Append(string.Format("<typ:AccountNumber>{0}</typ:AccountNumber>", processPaymentRequest.CustomValues["Account number"]));
                    requestXml.Append(string.Format("<typ:BankNumber>{0}</typ:BankNumber>", processPaymentRequest.CustomValues["Routing number"]));
                }
                else //sets the credit card elements
                {
                    requestXml.Append(string.Format("<typ:AccountName>{0}</typ:AccountName>", processPaymentRequest.CreditCardName));
                    requestXml.Append(string.Format("<typ:AccountNumber>{0}</typ:AccountNumber>", processPaymentRequest.CreditCardNumber));
                }

                //sets the billing elements
                requestXml.Append("<typ:BillingInformation>");
                if (customer.BillingAddress != null)
                {
                    requestXml.Append(string.Format("<typ:Address1>{0}</typ:Address1>", customer.BillingAddress.Address1));
                    requestXml.Append(string.Format("<typ:Address2>{0}</typ:Address2>", customer.BillingAddress.Address2));
                    requestXml.Append(string.Format("<typ:City>{0}</typ:City>", customer.BillingAddress.City));
                    requestXml.Append(string.Format("<typ:Country>{0}</typ:Country>",
                        customer.BillingAddress.Country != null ? customer.BillingAddress.Country.ThreeLetterIsoCode : string.Empty));
                    requestXml.Append(string.Format("<typ:Email>{0}</typ:Email>", customer.Email));
                    requestXml.Append(string.Format("<typ:State>{0}</typ:State>", customer.BillingAddress.StateProvince != null ?
                        customer.BillingAddress.StateProvince.Abbreviation : string.Empty));
                    requestXml.Append(string.Format("<typ:TelephoneNumber>{0}</typ:TelephoneNumber>", customer.BillingAddress.PhoneNumber));
                    requestXml.Append(string.Format("<typ:ZipCode>{0}</typ:ZipCode>", customer.BillingAddress.ZipPostalCode));
                    requestXml.Append("</typ:BillingInformation>");
                }

                //sets the other elements
                requestXml.Append(string.Format("<typ:Description>{0}</typ:Description>",
                    processPaymentRequest.CreditCardName.Substring(processPaymentRequest.CreditCardName.Length - 4, 4)));
                requestXml.Append("<typ:DuplicateAction>ReturnDup</typ:DuplicateAction>");

                //sets the credit card elements
                requestXml.Append(string.Format("<typ:ExpirationDate>{0}{1}</typ:ExpirationDate>", processPaymentRequest.CreditCardExpireMonth.ToString("00"),
                    processPaymentRequest.CreditCardExpireYear.ToString().Substring(2, 2))); //MMYY

                //sets the payer account elements
                requestXml.Append(string.Format("<typ:PayerAccountId>{0}</typ:PayerAccountId>", payerAccountId));

                //sets the credit card elements
                requestXml.Append(string.Format("<typ:PaymentMethodType>{0}</typ:PaymentMethodType>", !string.IsNullOrEmpty(processPaymentRequest.CreditCardType) ?
                    processPaymentRequest.CreditCardType : GetCreditCardType(processPaymentRequest.CreditCardNumber)));

                //sets the common elements
                requestXml.Append("</con:pmAdd>");
                requestXml.Append("</con:CreatePaymentMethod>");


                //executes the create payment method request
                var responseXml = ExecuteRequest("CreatePaymentMethod", requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:CreatePaymentMethodResponse/c:CreatePaymentMethodResult/";
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets the payment method identifier
                            paymentMethodId = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:PaymentMethodId"), xmlnsManager).InnerText;

                            break;
                        }
                    case "FAILURE":
                        {
                            _logger.Warning(string.Format("Failure occurred while executing the '{0}' method. FailureMessage: {1}", "ProtectPay-CreatePaymentMethod",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-GetPaymentMethod", ex.Message), ex);
            }

            return paymentMethodId;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Process a payment.
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing.</param>
        /// <returns>Process payment result.</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();

            try
            {
                //gets the customer's payer account identifier
                string payerAccountId = string.Empty;
                var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
                if (customer != null)
                    payerAccountId = GetPayerAccount(customer.Id, customer.Email, customer.GetFullName());

                //gets the payment method identifier based on Credit Card or eCheck information
                string paymentMethodId = GetPaymentMethod(processPaymentRequest, customer, payerAccountId);

                //gets the order total in pennies
                int orderTotal = (int)(Math.Round(processPaymentRequest.OrderTotal, 2) * 100);
                
                
                
                //prepares the process payment request xml
                var requestXml = new StringBuilder();

                //check for, split payment
                if (_protectPayPaymentSettings.SplitPayment == false)
                {
                    if (_protectPayPaymentSettings.TransactMode == TransactMode.Authorize)
                        requestXml.Append("<con:AuthorizePaymentMethodTransaction>");
                    else
                        requestXml.Append("<con:ProcessPaymentMethodTransaction>");
                }
                else
                {
                    requestXml.Append("<con:ProcessSplitPayTransaction>");
                }

                //sets the identification elements
                requestXml.Append("<con:id>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:id>");

                //sets the request and/or transaction elements
                if (_protectPayPaymentSettings.SplitPayment == false)
                {
                    requestXml.Append("<con:transaction>");
                }
                else
                {
                    requestXml.Append("<con:request>");
                    requestXml.Append("<typ:InitialTransaction>");
                }

                //sets the purchase amount elements
                requestXml.Append(string.Format("<typ:Amount>{0}</typ:Amount>", orderTotal));
                requestXml.Append(string.Format("<typ:CurrencyCode>{0}</typ:CurrencyCode>",
                    _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId).CurrencyCode));

                //sets the order related elements
                requestXml.Append(string.Format("<typ:Invoice>{0}</typ:Invoice>", processPaymentRequest.OrderGuid.ToString()));

                //sets the elements, if split payment not enabled
                if (_protectPayPaymentSettings.SplitPayment == false)
                {
                    //sets the merchant profile and payer account elements
                    requestXml.Append(string.Format("<typ:MerchantProfileId>{0}</typ:MerchantProfileId>", _protectPayPaymentSettings.MerchantProfileId));
                    requestXml.Append(string.Format("<typ:PayerAccountId>{0}</typ:PayerAccountId>", payerAccountId));

                    //sets the transaction elements
                    requestXml.Append("</con:transaction>");

                    //sets the payment method elements
                    requestXml.Append(string.Format("<con:paymentMethodID>{0}</con:paymentMethodID>", paymentMethodId));
                }

                //sets the optional payment info elements
                if (_protectPayPaymentSettings.SplitPayment == false)
                    requestXml.Append("<con:optionalPaymentInfoOverrides>");
                else
                    requestXml.Append("<typ:OptionalOverrides>");

                //sets the credit card payment info elements
                requestXml.Append("<prop:CreditCard>");
                //sets the billing elements
                if (customer.BillingAddress != null)
                {
                    requestXml.Append("<prop:Billing>");
                    requestXml.Append(string.Format("<typ:Address1>{0}</typ:Address1>", customer.BillingAddress.Address1));
                    requestXml.Append(string.Format("<typ:Address2>{0}</typ:Address2>", customer.BillingAddress.Address2));
                    requestXml.Append(string.Format("<typ:City>{0}</typ:City>", customer.BillingAddress.City));
                    requestXml.Append(string.Format("<typ:Country>{0}</typ:Country>",
                        customer.BillingAddress.Country != null ? customer.BillingAddress.Country.ThreeLetterIsoCode : string.Empty));
                    requestXml.Append(string.Format("<typ:Email>{0}</typ:Email>", customer.Email));
                    requestXml.Append(string.Format("<typ:State>{0}</typ:State>", customer.BillingAddress.StateProvince != null ?
                        customer.BillingAddress.StateProvince.Abbreviation : string.Empty));
                    requestXml.Append(string.Format("<typ:TelephoneNumber>{0}</typ:TelephoneNumber>", customer.BillingAddress.PhoneNumber));
                    requestXml.Append(string.Format("<typ:ZipCode>{0}</typ:ZipCode>", customer.BillingAddress.ZipPostalCode));
                    requestXml.Append("</prop:Billing>");
                }
                //sets the credit card elements
                requestXml.Append(string.Format("<prop:CVV>{0}</prop:CVV>", processPaymentRequest.CreditCardCvv2));
                requestXml.Append(string.Format("<prop:ExpirationDate>{0}{1}</prop:ExpirationDate>", processPaymentRequest.CreditCardExpireMonth.ToString("00"),
                    processPaymentRequest.CreditCardExpireYear.ToString().Substring(2, 2))); //MMYY
                requestXml.Append(string.Format("<prop:FullName>{0}</prop:FullName>", processPaymentRequest.CreditCardName));
                requestXml.Append("</prop:CreditCard>");

                //sets payer's IP address
                requestXml.Append("<prop:Payer>");
                requestXml.Append(string.Format("<prop:IpAddress>{0}</prop:IpAddress>", _webHelper.GetCurrentIpAddress()));
                requestXml.Append("</prop:Payer>");

                //sets the optional payment info elements
                if (_protectPayPaymentSettings.SplitPayment == false)
                    requestXml.Append("</con:optionalPaymentInfoOverrides>");
                else
                    requestXml.Append("</typ:OptionalOverrides>");

                //sets the elements, if split payment enabled
                if (_protectPayPaymentSettings.SplitPayment == true)
                {
                    //sets the payer account and payment method elements
                    requestXml.Append(string.Format("<typ:PayerAccountId>{0}</typ:PayerAccountId>", payerAccountId));
                    requestXml.Append(string.Format("<typ:PaymentMethodId>{0}</typ:PaymentMethodId>", paymentMethodId));

                    //sets the transaction elements
                    requestXml.Append("</typ:InitialTransaction>");

                    //sets the merchant profile elements
                    requestXml.Append(string.Format("<typ:MerchantProfileId>{0}</typ:MerchantProfileId>", _protectPayPaymentSettings.MerchantProfileId));

                    //sets the secondary transaction elements
                    requestXml.Append("<typ:SecondaryTransaction>");
                    requestXml.Append(string.Format("<prop1:Amount>{0}</prop1:Amount>",
                        (int)(Math.Round((orderTotal * _protectPayPaymentSettings.SplitPercentage) / 100, 2))));
                    requestXml.Append(string.Format("<prop1:OriginatingAccountId>{0}</prop1:OriginatingAccountId>", _protectPayPaymentSettings.MerchantAccountId));
                    requestXml.Append(string.Format("<prop1:ReceivingAccountId>{0}</prop1:ReceivingAccountId>", _protectPayPaymentSettings.SecondaryAccountId));
                    requestXml.Append("</typ:SecondaryTransaction>");
                    requestXml.Append("</con:request>");
                }

                //sets the common elements
                if (_protectPayPaymentSettings.SplitPayment == false)
                {
                    if (_protectPayPaymentSettings.TransactMode == TransactMode.Authorize)
                        requestXml.Append("</con:AuthorizePaymentMethodTransaction>");
                    else
                        requestXml.Append("</con:ProcessPaymentMethodTransaction>");
                }
                else
                {
                    requestXml.Append("</con:ProcessSplitPayTransaction>");
                }



                //gets the transaction method
                string transactionMethod = string.Format("{0}Transaction", _protectPayPaymentSettings.SplitPayment == false ?
                    (_protectPayPaymentSettings.TransactMode == TransactMode.Authorize ? "AuthorizePaymentMethod" : "ProcessPaymentMethod") : "ProcessSplitPay");

                //executes the process payment request
                var responseXml = ExecuteRequest(transactionMethod, requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", _protectPayPaymentSettings.SplitPayment == false ? "http://propay.com/SPS/types" :
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.SPS.External");
                if(_protectPayPaymentSettings.SplitPayment == true)
                {
                    xmlnsManager.AddNamespace("i", "http://www.w3.org/2001/XMLSchema-instance");
                    xmlnsManager.AddNamespace("b", "http://propay.com/SPS/types");
                }

                //check for, status of request
                string resultXmlPath = string.Format("/s:Envelope/s:Body/c:{0}Response/c:{0}Result/", transactionMethod);
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, string.Format("a:RequestResult/{0}:ResultValue",
                    _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets the transaction information
                            result.AuthorizationTransactionCode = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                string.Format("a:Transaction/{0}:AuthorizationCode", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText;
                            result.AuthorizationTransactionId = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                string.Format("a:Transaction/{0}:TransactionHistoryId", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText;
                            result.AuthorizationTransactionResult = string.Format("{0}{1}", xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                    string.Format("a:Transaction/{0}:TransactionId", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText,
                                _protectPayPaymentSettings.SplitPayment == false ? string.Empty : string.Format("|{0}",
                                    xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:SecondaryTransactionId"), xmlnsManager).InnerText));
                            result.AvsResult = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                string.Format("a:Transaction/{0}:AVSCode", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText;

                            //sets new payment status
                            if (_protectPayPaymentSettings.SplitPayment == false)
                            {
                                if (_protectPayPaymentSettings.TransactMode == TransactMode.Authorize)
                                    result.NewPaymentStatus = PaymentStatus.Authorized;
                                else
                                    result.NewPaymentStatus = PaymentStatus.Paid;
                            }
                            else
                            {
                                result.NewPaymentStatus = PaymentStatus.Paid;
                            }

                            break;
                        }
                    case "FAILURE":
                        {
                            result.AddError(string.Format("{0} ({1})", xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                    string.Format("a:Transaction/{0}:TransactionResult", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText,
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, string.Format("a:RequestResult/{0}:ResultMessage",
                                    _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText));

                            _logger.Warning(string.Format("Failure occurred while executing the 'ProtectPay-{0}' method. FailureMessage: {1}", transactionMethod,
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, string.Format("a:RequestResult/{0}:ResultMessage",
                                _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Plugins.Payments.ProtectPay.TechnicalError"));
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-ProcessPayment", ex.Message), ex);
            }

            return result;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL).
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing.</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }

        /// <summary>
        /// Gets additional handling fee.
        /// </summary>
        /// <param name="cart">Shoping cart.</param>
        /// <returns>Additional handling fee.</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            var result = this.CalculateAdditionalFee(_orderTotalCalculationService, cart,
                _protectPayPaymentSettings.AdditionalFee, _protectPayPaymentSettings.AdditionalFeePercentage);
            return result;
        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout.
        /// </summary>
        /// <param name="cart">Shoping cart.</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Captures payment.
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request.</param>
        /// <returns>Capture payment result.</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();

            try
            {
                //prepares capture payment request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:CapturePaymentV2>");

                //sets the identification elements
                requestXml.Append("<con:id>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:id>");

                requestXml.Append("<con:request>");
                //sets the capture amount elements
                requestXml.Append(string.Format("<prop:Amount>{0}</prop:Amount>", (int)(Math.Round(capturePaymentRequest.Order.OrderTotal, 2) * 100)));
                //sets the merchant account elements
                requestXml.Append(string.Format("<prop:MerchantProfileId>{0}</prop:MerchantProfileId>", _protectPayPaymentSettings.MerchantProfileId));
                //sets the authorize transaction elements
                requestXml.Append(string.Format("<prop:OriginalTransactionId>{0}</prop:OriginalTransactionId>", capturePaymentRequest.Order.AuthorizationTransactionResult));
                requestXml.Append(string.Format("<prop:TransactionHistoryId>{0}</prop:TransactionHistoryId>", capturePaymentRequest.Order.AuthorizationTransactionId));

                //sets the common elements
                requestXml.Append("</con:request>");
                requestXml.Append("</con:CapturePaymentV2>");


                //executes the capture payment request
                var responseXml = ExecuteRequest("CapturePaymentV2", requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:CapturePaymentV2Response/c:CapturePaymentV2Result/";
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets the transaction information
                            result.CaptureTransactionId = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:Transaction/a:TransactionHistoryId"), xmlnsManager).InnerText;
                            result.CaptureTransactionResult = xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:Transaction/a:TransactionId"), xmlnsManager).InnerText;

                            //sets new payment status
                            result.NewPaymentStatus = PaymentStatus.Paid;

                            break;
                        }
                    case "FAILURE":
                        {
                            result.AddError(string.Format("Capture failed: {0}",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            _logger.Warning(string.Format("Failure occurred while executing the '{0}'method. FailureMessage: {1}", "CapturePaymentV2",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Plugins.Payments.ProtectPay.TechnicalError"));
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-Capture", ex.Message), ex);
            }

            return result;
        }

        /// <summary>
        /// Refunds a payment.
        /// </summary>
        /// <param name="refundPaymentRequest">Request.</param>
        /// <returns>Result.</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();

            try
            {
                //prepares refund payment request xml
                var requestXml = new StringBuilder();
                
                //check for, split payment
                if (_protectPayPaymentSettings.SplitPayment == false)
                    requestXml.Append("<con:RefundPaymentV2>");
                else
                    requestXml.Append("<con:ReverseSplitPayTransaction>");

                //sets the identification elements
                requestXml.Append("<con:id>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:id>");

                requestXml.Append("<con:request>");
                //sets the refund elements
                if (_protectPayPaymentSettings.SplitPayment == false)
                {
                    //sets the refund amount elements
                    requestXml.Append(string.Format("<prop:Amount>{0}</prop:Amount>", refundPaymentRequest.Order.OrderTotal != refundPaymentRequest.AmountToRefund ?
                        (int)(Math.Round(refundPaymentRequest.AmountToRefund, 2) * 100) : 0));
                    //sets the merchant account elements
                    requestXml.Append(string.Format("<prop:MerchantProfileId>{0}</prop:MerchantProfileId>", _protectPayPaymentSettings.MerchantProfileId));
                    //sets the transaction elements
                    requestXml.Append(string.Format("<prop:originalTransactionID>{0}</prop:originalTransactionID>",
                        !string.IsNullOrEmpty(refundPaymentRequest.Order.CaptureTransactionResult) ?
                            refundPaymentRequest.Order.CaptureTransactionResult : refundPaymentRequest.Order.AuthorizationTransactionResult));
                    requestXml.Append(string.Format("<prop:TransactionHistoryId>{0}</prop:TransactionHistoryId>",
                        !string.IsNullOrEmpty(refundPaymentRequest.Order.CaptureTransactionId) ?
                            refundPaymentRequest.Order.CaptureTransactionId : refundPaymentRequest.Order.AuthorizationTransactionId));
                }
                else //sets the split pay reverse elements
                {
                    //gets the amount to refund in pennies
                    var amountToRefund = (int)(Math.Round(refundPaymentRequest.AmountToRefund, 2) * 100);

                    //sets the credit card refund amount elements
                    requestXml.Append(string.Format("<prop:CreditCardReversalAmount>{0}</prop:CreditCardReversalAmount>", amountToRefund));

                    //sets the secondary transaction elements
                    requestXml.Append(string.Format("<prop:PropayToPropayAccountId>{0}</prop:PropayToPropayAccountId>", _protectPayPaymentSettings.SecondaryAccountId));
                    requestXml.Append(string.Format("<prop:PropayToPropayReversalAmount>{0}</prop:PropayToPropayReversalAmount>",
                        (int)(Math.Round((amountToRefund * _protectPayPaymentSettings.SplitPercentage) / 100, 2))));
                    requestXml.Append("<prop:RequireCreditCardRefund>true</prop:RequireCreditCardRefund>");
                    requestXml.Append(string.Format("<prop:TransactionId>{0}</prop:TransactionId>", refundPaymentRequest.Order.AuthorizationTransactionResult.Split('|')[1]));
                }

                //sets the common elements
                requestXml.Append("</con:request>");
                if (_protectPayPaymentSettings.SplitPayment == false)
                    requestXml.Append("</con:RefundPaymentV2>");
                else
                    requestXml.Append("</con:ReverseSplitPayTransaction>");


                //gets the refund method
                string refundMethod = _protectPayPaymentSettings.SplitPayment == false ? "RefundPaymentV2" : "ReverseSplitPayTransaction";

                //executes the refund payment request
                var responseXml = ExecuteRequest(refundMethod, requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", _protectPayPaymentSettings.SplitPayment == false ? "http://propay.com/SPS/types" :
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.SPS.External");
                if (_protectPayPaymentSettings.SplitPayment == true)
                {
                    xmlnsManager.AddNamespace("i", "http://www.w3.org/2001/XMLSchema-instance");
                    xmlnsManager.AddNamespace("b", "http://propay.com/SPS/types");
                }

                //check for, status of request
                string resultXmlPath = string.Format("/s:Envelope/s:Body/c:{0}Response/c:{0}Result/", refundMethod);
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, string.Format("a:RequestResult/{0}:ResultValue",
                    _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets new payment status
                            result.NewPaymentStatus = refundPaymentRequest.Order.OrderTotal > refundPaymentRequest.AmountToRefund ?
                                PaymentStatus.PartiallyRefunded : PaymentStatus.Refunded;

                            break;
                        }
                    case "FAILURE":
                        {
                            result.AddError(string.Format("Refund failed: {0}", xmlDocument.SelectSingleNode(string.Concat(resultXmlPath,
                                string.Format("a:RequestResult/{0}:ResultMessage", _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText));

                            _logger.Warning(string.Format("Failure occurred while executing the '{0}'method. FailureMessage: {1}", refundMethod,
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, string.Format("a:RequestResult/{0}:ResultMessage",
                                    _protectPayPaymentSettings.SplitPayment == false ? "a" : "b")), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Plugins.Payments.ProtectPay.TechnicalError"));
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-Refund", ex.Message), ex);
            }

            return result;
        }

        /// <summary>
        /// Voids a payment.
        /// </summary>
        /// <param name="voidPaymentRequest">Request.</param>
        /// <returns>Result.</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();

            try
            {
                //prepares void payment request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:VoidPaymentV2>");

                //sets the identification elements
                requestXml.Append("<con:id>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", _protectPayPaymentSettings.AuthenticationToken));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", _protectPayPaymentSettings.BillerAccountId));
                requestXml.Append("</con:id>");

                requestXml.Append("<con:request>");
                //sets the merchant account elements
                requestXml.Append(string.Format("<prop:MerchantProfileId>{0}</prop:MerchantProfileId>", _protectPayPaymentSettings.MerchantProfileId));
                //sets the transaction elements
                requestXml.Append(string.Format("<prop:OriginalTransactionId>{0}</prop:OriginalTransactionId>", voidPaymentRequest.Order.AuthorizationTransactionResult));
                requestXml.Append(string.Format("<prop:TransactionHistoryId>{0}</prop:TransactionHistoryId>", voidPaymentRequest.Order.AuthorizationTransactionId));

                //sets the common elements
                requestXml.Append("</con:request>");
                requestXml.Append("</con:VoidPaymentV2>");


                //executes the void payment request
                var responseXml = ExecuteRequest("VoidPaymentV2", requestXml.ToString());
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(responseXml);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:VoidPaymentV2Response/c:VoidPaymentV2Result/";
                switch (xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            //sets new payment status
                            result.NewPaymentStatus = PaymentStatus.Voided;

                            break;
                        }
                    case "FAILURE":
                        {
                            result.AddError(string.Format("Void failed: {0}",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            _logger.Warning(string.Format("Failure occurred while executing the '{0}'method. FailureMessage: {1}", "VoidPaymentV2",
                                xmlDocument.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/a:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                result.AddError(_localizationService.GetResource("Plugins.Payments.ProtectPay.TechnicalError"));
                _logger.Error(string.Format("Error occurred while executing the '{0}' method. ErrorMessage: {1}", "ProtectPay-Void", ex.Message), ex);
            }

            return result;
        }

        /// <summary>
        /// Process recurring payment.
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing.</param>
        /// <returns>Process payment result.</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            throw new NotSupportedException("Recurring payment is not supported.");
        }

        /// <summary>
        /// Cancels a recurring payment.
        /// </summary>
        /// <param name="cancelPaymentRequest">Request.</param>
        /// <returns>Result.</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            throw new NotSupportedException("Cancel recurring payment is not supported.");
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods).
        /// </summary>
        /// <param name="order">Order.</param>
        /// <returns>Result.</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Gets a route for provider configuration.
        /// </summary>
        /// <param name="actionName">Action name.</param>
        /// <param name="controllerName">Controller name.</param>
        /// <param name="routeValues">Route values.</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "PaymentProtectPay";
            routeValues = new RouteValueDictionary { { "Namespaces", "ShopFast.Plugin.Payments.ProtectPay.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info.
        /// </summary>
        /// <param name="actionName">Action name.</param>
        /// <param name="controllerName">Controller name.</param>
        /// <param name="routeValues">Route values.</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "PaymentProtectPay";
            routeValues = new RouteValueDictionary { { "Namespaces", "ShopFast.Plugin.Payments.ProtectPay.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a controller type for payment gateway configuration and payment information view.
        /// </summary>
        /// <returns>PaymentProtectPay controller type.</returns>
        public Type GetControllerType()
        {
            return typeof(PaymentProtectPayController);
        }

        /// <summary>
        /// Installs plugin.
        /// </summary>
        public override void Install()
        {
            //settings
            var settings = new ProtectPayPaymentSettings
            {
                TransactMode = TransactMode.Sale,
                AuthenticationToken = "5fb2f7b6-0f2f-4410-bd30-60a8c93418e2",
                BillerAccountId = "4263543208491909"
            };
            _settingService.SaveSetting(settings);

            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.TransactModeValues", "Transaction mode");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.TransactModeValues.Hint", "Choose transaction mode.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantAccountId", "Merchant Account ID");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantAccountId.Hint", "Specify a merchant account identifier, which will be use as originating account in split payment.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantProfileId", "Merchant Profile ID");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantProfileId.Hint", "Specify a merchant profile identifier.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFee", "Additional fee");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.PaymentMethods", "Payment methods");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.PaymentMethods.Hint", "Choose payment methods, which should available to the customer for order payment.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPayment", "Split payment");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPayment.Hint", "Determines whether to split an order total amount into secondary account. If not enabled, a split will not perform.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SecondaryAccountId", "Secondary Account ID");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SecondaryAccountId.Hint", "Specify a secondary account identifier, which will be use as receiving account in split payment.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPercentage", "Split percentage");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPercentage.Hint", "Enter percentage of order total, which will be split into secondary account.");
            this.AddOrUpdatePluginLocaleResource("Payment.AccountType", "Account type");
            this.AddOrUpdatePluginLocaleResource("Payment.AccountType.Required", "Select account type");
            this.AddOrUpdatePluginLocaleResource("Payment.RoutingNumber", "Routing number");
            this.AddOrUpdatePluginLocaleResource("Payment.RoutingNumber.Wrong", "Wrong routing number");
            this.AddOrUpdatePluginLocaleResource("Payment.AccountNumber", "Account number");
            this.AddOrUpdatePluginLocaleResource("Payment.AccountNumber.Wrong", "Wrong account number");
            this.AddOrUpdatePluginLocaleResource("Payment.NameOnAccount", "Name on account");
            this.AddOrUpdatePluginLocaleResource("Payment.NameOnAccount.Required", "Enter name on account");
            this.AddOrUpdatePluginLocaleResource("Payment.ExpirationDate", "Expiration date");
            this.AddOrUpdatePluginLocaleResource("Payment.ExpirationDate.Wrong", "Wrong expiration date");
            this.AddOrUpdatePluginLocaleResource("Payment.NameOnCard", "Name on credit card");
            this.AddOrUpdatePluginLocaleResource("Payment.NameOnCard.Required", "Enter name on credit card");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.ProtectPay.TechnicalError", "We're sorry, an internal error has occurred while processing the request. Please try again later.");

            base.Install();
        }

        /// <summary>
        /// Uninstalls plugin.
        /// </summary>
        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<ProtectPayPaymentSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.TransactModeValues");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.TransactModeValues.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantAccountId");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantAccountId.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantProfileId");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.MerchantProfileId.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFee");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFee.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFeePercentage");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.AdditionalFeePercentage.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.PaymentMethods");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.PaymentMethods.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPayment");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPayment.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SecondaryAccountId");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SecondaryAccountId.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPercentage");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.Fields.SplitPercentage.Hint");
            this.DeletePluginLocaleResource("Payment.AccountType");
            this.DeletePluginLocaleResource("Payment.AccountType.Required");
            this.DeletePluginLocaleResource("Payment.RoutingNumber");
            this.DeletePluginLocaleResource("Payment.RoutingNumber.Wrong");
            this.DeletePluginLocaleResource("Payment.AccountNumber");
            this.DeletePluginLocaleResource("Payment.AccountNumber.Wrong");
            this.DeletePluginLocaleResource("Payment.NameOnAccount");
            this.DeletePluginLocaleResource("Payment.NameOnAccount.Required");
            this.DeletePluginLocaleResource("Payment.ExpirationDate");
            this.DeletePluginLocaleResource("Payment.ExpirationDate.Wrong");
            this.DeletePluginLocaleResource("Payment.NameOnCard");
            this.DeletePluginLocaleResource("Payment.NameOnCard.Required");
            this.DeletePluginLocaleResource("Plugins.Payments.ProtectPay.TechnicalError");

            base.Uninstall();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported.
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported.
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported.
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported.
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method.
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Manual;
            }
        }

        /// <summary>
        /// Gets a payment method type.
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin.
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        #endregion
    }
}
