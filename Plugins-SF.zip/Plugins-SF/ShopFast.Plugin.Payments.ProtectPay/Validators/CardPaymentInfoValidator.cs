﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.Payments.ProtectPay.Models;

namespace ShopFast.Plugin.Payments.ProtectPay.Validators
{
    public class CardPaymentInfoValidator : BaseNopValidator<PaymentInfoModel>
    {
        public CardPaymentInfoValidator(ILocalizationService localizationService)
        {
            //useful links:
            //http://fluentvalidation.codeplex.com/wikipage?title=Custom&referringTitle=Documentation&ANCHOR#CustomValidator
            //http://benjii.me/2010/11/credit-card-validator-attribute-for-asp-net-mvc-3/
            RuleFor(x => x.CardNumber).IsCreditCard().WithMessage(localizationService.GetResource("Payment.CardNumber.Wrong"));
            RuleFor(x => x.ExpirationDate).Matches(@"^[0-9]{4}$").WithMessage(localizationService.GetResource("Payment.ExpirationDate.Wrong"));
            RuleFor(x => x.CardCode).Matches(@"^[0-9]{3,4}$").WithMessage(localizationService.GetResource("Payment.CardCode.Wrong"));
            RuleFor(x => x.NameOnCard).NotEmpty().WithMessage(localizationService.GetResource("Payment.NameOnCard.Required"));
        }
    }
}