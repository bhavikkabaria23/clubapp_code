﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.Payments.ProtectPay.Models;

namespace ShopFast.Plugin.Payments.ProtectPay.Validators
{
    public class AccountPaymentInfoValidator : BaseNopValidator<PaymentInfoModel>
    {
        public AccountPaymentInfoValidator(ILocalizationService localizationService)
        {
            //useful links:
            //http://fluentvalidation.codeplex.com/wikipage?title=Custom&referringTitle=Documentation&ANCHOR#CustomValidator
            //http://benjii.me/2010/11/credit-card-validator-attribute-for-asp-net-mvc-3/

            RuleFor(x => x.BankAccountType).NotEmpty().WithMessage(localizationService.GetResource("Payment.AccountType.Required"));
            RuleFor(x => x.AccountType).NotEmpty().WithMessage(localizationService.GetResource("Payment.AccountType.Required"));
            RuleFor(x => x.RoutingNumber).Matches("^[0-9]{9}$").WithMessage(localizationService.GetResource("Payment.RoutingNumber.Wrong"));
            RuleFor(x => x.AccountNumber).Matches("^[0-9]{4,17}$").WithMessage(localizationService.GetResource("Payment.AccountNumber.Wrong"));
            RuleFor(x => x.NameOnAccount).NotEmpty().WithMessage(localizationService.GetResource("Payment.NameOnAccount.Required"));
        }
    }
}