﻿namespace ShopFast.Plugin.Payments.ProtectPay
{
    /// <summary>
    /// Represents payment processor transaction mode.
    /// </summary>
    public enum TransactMode
    {
        /// <summary>
        /// Authorize Only.
        /// </summary>
        Authorize = 1,

        /// <summary>
        /// Sale (Authorize and capture).
        /// </summary>
        Sale = 2
    }
}
