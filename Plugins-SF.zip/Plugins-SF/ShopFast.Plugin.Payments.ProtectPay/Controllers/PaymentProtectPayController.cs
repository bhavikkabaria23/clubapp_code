﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using FluentValidation.Results;
using Nop.Core;
using Nop.Services;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using ShopFast.Plugin.Payments.ProtectPay.Models;
using ShopFast.Plugin.Payments.ProtectPay.Validators;

namespace ShopFast.Plugin.Payments.ProtectPay.Controllers
{
    public class PaymentProtectPayController : BasePaymentController
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Constructors

        public PaymentProtectPayController(IWorkContext workContext,
            IStoreContext storeContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._localizationService = localizationService;
        }

        #endregion

        #region Methods

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var protectPayPaymentSettings = _settingService.LoadSetting<ProtectPayPaymentSettings>(storeScope);

            var model = new ConfigurationModel();
            model.TransactModeId = Convert.ToInt32(protectPayPaymentSettings.TransactMode);
            model.MerchantAccountId = protectPayPaymentSettings.MerchantAccountId;
            model.MerchantProfileId = protectPayPaymentSettings.MerchantProfileId;
            model.AdditionalFee = protectPayPaymentSettings.AdditionalFee;
            model.AdditionalFeePercentage = protectPayPaymentSettings.AdditionalFeePercentage;
            model.PaymentMethods = protectPayPaymentSettings.PaymentMethods;
            model.SplitPayment = protectPayPaymentSettings.SplitPayment;
            model.SecondaryAccountId = protectPayPaymentSettings.SecondaryAccountId;
            model.SplitPercentage = protectPayPaymentSettings.SplitPercentage;
            model.TransactModeValues = protectPayPaymentSettings.TransactMode.ToSelectList();
            model.AvailablePaymentMethods = new List<SelectListItem>
            {
                new SelectListItem { Value = "CreditCard", Text = "Credit Card", Selected = model.PaymentMethods.Split(',').Contains("CreditCard") },
                new SelectListItem { Value = "eCheck", Text = "eCheck", Selected = model.PaymentMethods.Split(',').Contains("eCheck") }
            };

            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.TransactModeId_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.TransactMode, storeScope);
                model.MerchantAccountId_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.MerchantAccountId, storeScope);
                model.MerchantProfileId_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.MerchantProfileId, storeScope);
                model.AdditionalFee_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.AdditionalFeePercentage, storeScope);
                model.PaymentMethods_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.PaymentMethods, storeScope);
                model.SplitPayment_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.SplitPayment, storeScope);
                model.SecondaryAccountId_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.SecondaryAccountId, storeScope);
                model.SplitPercentage_OverrideForStore = _settingService.SettingExists(protectPayPaymentSettings, x => x.SplitPercentage, storeScope);
            }

            return View("~/Plugins/ShopFast.Payments.ProtectPay/Views/PaymentProtectPay/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var protectPayPaymentSettings = _settingService.LoadSetting<ProtectPayPaymentSettings>(storeScope);

            //save settings
            protectPayPaymentSettings.TransactMode = (TransactMode)model.TransactModeId;
            protectPayPaymentSettings.MerchantAccountId = model.MerchantAccountId;
            protectPayPaymentSettings.MerchantProfileId = model.MerchantProfileId;
            protectPayPaymentSettings.AdditionalFee = model.AdditionalFee;
            protectPayPaymentSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;
            protectPayPaymentSettings.PaymentMethods = model.PaymentMethods;
            protectPayPaymentSettings.SplitPayment = model.SplitPayment;
            protectPayPaymentSettings.SecondaryAccountId = model.SecondaryAccountId;
            protectPayPaymentSettings.SplitPercentage = model.SplitPercentage;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared
             * and loaded from database after each update */
            if (model.TransactModeId_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.TransactMode, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.TransactMode, storeScope);

            if (model.MerchantAccountId_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.MerchantAccountId, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.MerchantAccountId, storeScope);

            if (model.MerchantProfileId_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.MerchantProfileId, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.MerchantProfileId, storeScope);

            if (model.AdditionalFee_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.AdditionalFee, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.AdditionalFee, storeScope);

            if (model.AdditionalFeePercentage_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.AdditionalFeePercentage, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.AdditionalFeePercentage, storeScope);

            if (model.PaymentMethods_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.PaymentMethods, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.PaymentMethods, storeScope);

            if (model.SplitPayment_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.SplitPayment, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.SplitPayment, storeScope);

            if (model.SecondaryAccountId_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.SecondaryAccountId, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.SecondaryAccountId, storeScope);

            if (model.SplitPercentage_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(protectPayPaymentSettings, x => x.SplitPercentage, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(protectPayPaymentSettings, x => x.SplitPercentage, storeScope);

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Configuration.Updated"));

            return Configure();
        }


        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();
            var form = this.Request.Form;

            //payment methods
            var protectPayPaymentSettings = _settingService.LoadSetting<ProtectPayPaymentSettings>(_storeContext.CurrentStore.Id);
            if (protectPayPaymentSettings.PaymentMethods.Contains(","))
            {
                model.PaymentMethods.Add(new SelectListItem { Value = "CreditCard", Text = "Credit Card", Selected = true });
                model.PaymentMethods.Add(new SelectListItem { Value = "eCheck", Text = "eCheck" });
            }
            model.PaymentMethod = protectPayPaymentSettings.PaymentMethods;

            #region - Credit Card -

            if (model.PaymentMethod.Split(',').Contains("CreditCard"))
            {
                //set postback values
                model.CardNumber = form["CardNumber"];
                model.CardType = form["CardType"];
                model.ExpirationDate = form["ExpirationDate"];
                model.CardCode = form["CardCode"];
                model.NameOnCard = form["NameOnCard"];
            }

            #endregion

            #region - eCheck -

            if (model.PaymentMethod.Split(',').Contains("eCheck"))
            {
                //bank account types
                model.BankAccountTypes.Add(new SelectListItem { Value = "Business", Text = "Business", Selected = true });
                model.BankAccountTypes.Add(new SelectListItem { Value = "Personal", Text = "Personal" });

                //account types
                model.AccountTypes.Add(new SelectListItem { Value = "Checking", Text = "Checking", Selected = true });
                model.AccountTypes.Add(new SelectListItem { Value = "Savings", Text = "Savings" });

                //set postback values
                model.BankAccountType = form["BankAccountType"];
                model.AccountType = form["AccountType"];
                model.RoutingNumber = form["RoutingNumber"];
                model.AccountNumber = form["AccountNumber"];
                model.NameOnAccount = form["NameOnAccount"];
            }

            #endregion

            return View("~/Plugins/ShopFast.Payments.ProtectPay/Views/PaymentProtectPay/PaymentInfo.cshtml", model);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();
            ValidationResult validationResult = null;

            var model = new PaymentInfoModel();
            if (form["PaymentMethod"] == "CreditCard")
            {
                model.CardNumber = form["CardNumber"];
                model.ExpirationDate = form["ExpirationDate"];
                model.CardCode = form["CardCode"];
                model.NameOnCard = form["NameOnCard"];

                var validator = new CardPaymentInfoValidator(_localizationService);
                validationResult = validator.Validate(model);
            }
            else if (form["PaymentMethod"] == "eCheck")
            {
                model.BankAccountType = form["BankAccountType"];
                model.AccountType = form["AccountType"];
                model.RoutingNumber = form["RoutingNumber"];
                model.AccountNumber = form["AccountNumber"];
                model.NameOnAccount = form["NameOnAccount"];

                var validator = new AccountPaymentInfoValidator(_localizationService);
                validationResult = validator.Validate(model);
            }

            if (!validationResult.IsValid)
                foreach (var error in validationResult.Errors)
                    warnings.Add(error.ErrorMessage);

            return warnings;
        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();

            if (form["PaymentMethod"] == "CreditCard")
            {
                paymentInfo.CreditCardNumber = form["CardNumber"];
                paymentInfo.CreditCardType = form["CardType"];
                paymentInfo.CreditCardExpireMonth = !string.IsNullOrEmpty(form["ExpirationDate"]) && form["ExpirationDate"].Length == 4 ?
                    int.Parse(form["ExpirationDate"].Substring(0, 2)) : 0;
                paymentInfo.CreditCardExpireYear = !string.IsNullOrEmpty(form["ExpirationDate"]) && form["ExpirationDate"].Length == 4 ?
                    int.Parse(string.Concat("20", form["ExpirationDate"].Substring(2, 2))) : 0;
                paymentInfo.CreditCardCvv2 = form["CardCode"];
                paymentInfo.CreditCardName = form["NameOnCard"];
            }
            else if (form["PaymentMethod"] == "eCheck")
            {
                paymentInfo.CustomValues.Add("Account type", string.Format("{0} - {1}", form["BankAccountType"], form["AccountType"]));
                paymentInfo.CustomValues.Add("Routing number", form["RoutingNumber"]);
                paymentInfo.CustomValues.Add("Account number", form["AccountNumber"]);
                paymentInfo.CustomValues.Add("Name on account", form["NameOnAccount"]);
            }

            return paymentInfo;
        }

        #endregion
    }
}