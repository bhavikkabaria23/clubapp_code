﻿using Nop.Core.Configuration;

namespace ShopFast.Plugin.Payments.ProtectPay
{
    public class ProtectPayPaymentSettings : ISettings
    {
        /// <summary>
        /// Gets or sets a value indicating whether to only authorize OR authorize and capture order amount
        /// from customer's bank account/credit card.
        /// </summary>
        public TransactMode TransactMode { get; set; }

        /// <summary>
        /// Gets or sets a unique biller account identifier. It is used to identify the correct collection
        /// of tokens on ProtectPay.
        /// </summary>
        public string BillerAccountId { get; set; }

        /// <summary>
        /// Gets or sets a unique authentication token provided by ProPay. It is used to authenticate every
        /// incoming requests on ProtectPay.
        /// </summary>
        public string AuthenticationToken { get; set; }

        /// <summary>
        /// Gets or sets a unique merchant account identifier. It is required as originating account identifier
        /// while performing split payment transaction.
        /// </summary>
        public string MerchantAccountId { get; set; }

        /// <summary>
        /// Gets or sets a unique merchant profile identifier. It is required when biller ID has access to
        /// multiple merchant accounts.
        /// </summary>
        public string MerchantProfileId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to "additional fee" is specified as percentage,
        /// true - percentage, false - fixed value.
        /// </summary>
        public bool AdditionalFeePercentage { get; set; }

        /// <summary>
        /// Gets or sets an additional fee incur to every transaction.
        /// </summary>
        public decimal AdditionalFee { get; set; }

        /// <summary>
        /// Gets or sets the payment methods (Credit Card and/or eCheck), which should available to the
        /// customer for order payment.
        /// </summary>
        public string PaymentMethods { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to split order total amount (payment) into
        /// secondary account, true - yes, false - no.
        /// </summary>
        public bool SplitPayment { get; set; }

        /// <summary>
        /// Gets or sets a secondary account identifier. It is required as receiving account identifier
        /// while performing split payment transaction.
        /// </summary>
        public string SecondaryAccountId { get; set; }

        /// <summary>
        /// Gets or sets a percentage of order total, which will be split into secondary account.
        /// </summary>
        public decimal SplitPercentage { get; set; }
    }
}