﻿using System.Web.Routing;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public class ProPayMerchantPlugin : BasePlugin, IMiscPlugin
    {
        #region Fields

        private readonly ISettingService _settingService;

        #endregion

        #region Constructors

        public ProPayMerchantPlugin(ISettingService settingService)
        {
            this._settingService = settingService;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets a route for provider configuration.
        /// </summary>
        /// <param name="actionName">Action name.</param>
        /// <param name="controllerName">Controller name.</param>
        /// <param name="routeValues">Route values.</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "MiscProPayMerchant";
            routeValues = new RouteValueDictionary { { "Namespaces", "ShopFast.Plugin.Misc.ProPayMerchant.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Installs plugin.
        /// </summary>
        public override void Install()
        {
            //settings
            var settings = new ProPayMerchantSettings
            {
                CertString = "c7700c21e494547b3ddd6c9a7156c5",
                AuthenticationToken = "5fb2f7b6-0f2f-4410-bd30-60a8c93418e2",
                BillerAccountId = "4263543208491909"
            };
            _settingService.SaveSetting(settings);

            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.CertString", "Certification String");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.CertString.Hint", "Specify a certification string, which will be used to authenticate that the incoming data at ProPay is from the correct source and the account in which money will be deposited.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId", "Biller Account ID");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId.Hint", "Specify a biller account identifier, which will be used to identify the correct collection of tokens.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken", "Authentication Token");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken.Hint", "Specify an authentication token, which will be used to access the APIs of ProPay.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.ProPayMerchant.TechnicalError", "We're sorry, an internal error has occurred while processing the request. Please try again later.");

            base.Install();
        }

        /// <summary>
        /// Uninstalls plugin.
        /// </summary>
        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<ProPayMerchantSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.CertString");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.CertString.Hint");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId.Hint");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken.Hint");
            this.DeletePluginLocaleResource("Plugins.Misc.ProPayMerchant.TechnicalError");

            base.Uninstall();
        }

        #endregion
    }
}
