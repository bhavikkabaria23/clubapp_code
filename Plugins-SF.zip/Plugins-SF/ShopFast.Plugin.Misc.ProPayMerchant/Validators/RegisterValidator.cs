﻿using System;
using FluentValidation;
using FluentValidation.Results;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Validators
{
    public partial class RegisterValidator : BaseNopValidator<RegisterModel>
    {
        public RegisterValidator(ILocalizationService localizationService, IStateProvinceService stateProvinceService, CustomerSettings customerSettings)
        {
            RuleFor(x => x.FirstName).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.FirstName.Required"));
            RuleFor(x => x.LastName).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.LastName.Required"));
            RuleFor(x => x.SocialSecurityNumber).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.SocialSecurityNumber.Required"));
            RuleFor(x => x.SocialSecurityNumber).Matches(@"^(\d{3}-?\d{2}-?\d{4}|XXX-XX-XXXX)$").WithMessage(localizationService.GetResource("Merchant.Fields.SocialSecurityNumber.Wrong"));
            Custom(x =>
            {
                var dateOfBirth = x.ParseDateOfBirth();
                //entered?
                if (!dateOfBirth.HasValue)
                {
                    return new ValidationFailure("DateOfBirthDay", localizationService.GetResource("Account.Fields.DateOfBirth.Required"));
                }
                //minimum age
                if (customerSettings.DateOfBirthMinimumAge.HasValue &&
                    CommonHelper.GetDifferenceInYears(dateOfBirth.Value, DateTime.Today) < customerSettings.DateOfBirthMinimumAge.Value)
                {
                    return new ValidationFailure("DateOfBirthDay", string.Format(localizationService.GetResource("Account.Fields.DateOfBirth.MinimumAge"), customerSettings.DateOfBirthMinimumAge.Value));
                }
                return null;
            });
            RuleFor(x => x.Email).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
            RuleFor(x => x.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));


            RuleFor(x => x.BusinessName).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.BusinessName.Required"));
            Custom(x =>
            {
                if (x.BusinessCategory == 0)
                {
                    return new ValidationFailure("BusinessCategory", localizationService.GetResource("Merchant.Fields.BusinessCategory.Required"));
                }
                return null;
            });
            RuleFor(x => x.StreetAddress).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
            RuleFor(x => x.City).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.City.Required"));
            Custom(x =>
            {
                if (x.StateProvinceId == 0)
                {
                    return new ValidationFailure("StateProvinceId", localizationService.GetResource("Account.Fields.StateProvince.Required"));
                }
                return null;
            });
            RuleFor(x => x.ZipPostalCode).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));
            RuleFor(x => x.Phone).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));


            Custom(x =>
            {
                if (string.IsNullOrEmpty(x.BankAccountType) || string.IsNullOrEmpty(x.AccountType))
                {
                    return new ValidationFailure("BankAccountType", localizationService.GetResource("Merchant.Fields.AccountType.Required"));
                }
                return null;
            });
            RuleFor(x => x.BankName).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.BankName.Required"));
            RuleFor(x => x.RoutingNumber).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.RoutingNumber.Required"));
            RuleFor(x => x.RoutingNumber).Matches("^[0-9]{9}$").WithMessage(localizationService.GetResource("Merchant.Fields.RoutingNumber.Wrong"));
            RuleFor(x => x.AccountNumber).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.AccountNumber.Required"));
            RuleFor(x => x.AccountNumber).Matches("^[0-9]{4,17}$").WithMessage(localizationService.GetResource("Merchant.Fields.AccountNumber.Wrong"));
            RuleFor(x => x.NameOnAccount).NotEmpty().WithMessage(localizationService.GetResource("Merchant.Fields.NameOnAccount.Required"));
        }
    }
}