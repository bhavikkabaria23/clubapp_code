﻿using Nop.Core;
using System;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Domain
{
    /// <summary>
    /// Represents a merchant.
    /// </summary>
    public partial class Merchant : BaseEntity
    {
        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the birth date.
        /// </summary>
        public DateTime? BirthDate { get; set; }

        /// <summary>
        /// Gets or sets the business name.
        /// </summary>
        public string BusinessName { get; set; }

        /// <summary>
        /// Gets or sets the industry type identifier.
        /// </summary>
        public int IndustryTypeId { get; set; }

        /// <summary>
        /// Gets or sets the website url.
        /// </summary>
        public string Website { get; set; }

        /// <summary>
        /// Gets or sets the phone number
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the address
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the state/province identifier
        /// </summary>
        public string StateProvince { get; set; }
        
        /// <summary>
        /// Gets or sets the zip/postal code
        /// </summary>
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets the country identifier
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the custom fields in XML format
        /// </summary>
        public string CustomFieldsXml { get; set; }
    }
}
