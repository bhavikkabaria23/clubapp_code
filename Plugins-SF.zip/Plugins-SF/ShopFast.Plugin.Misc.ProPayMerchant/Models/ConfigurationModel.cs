﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.CertString")]
        public string CertString { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId")]
        public string BillerAccountId { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken")]
        public string AuthenticationToken { get; set; }
    }
}