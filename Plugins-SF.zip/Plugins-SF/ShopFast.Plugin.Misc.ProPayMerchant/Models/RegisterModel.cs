﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using FluentValidation.Attributes;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.ProPayMerchant.Validators;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    [Validator(typeof(RegisterValidator))]
    public partial class RegisterModel : BaseNopModel
    {
        [NopResourceDisplayName("Account.Fields.FirstName")]
        [AllowHtml]
        public string FirstName { get; set; }

        [NopResourceDisplayName("Account.Fields.LastName")]
        [AllowHtml]
        public string LastName { get; set; }

        [NopResourceDisplayName("Merchant.Fields.SocialSecurityNumber")]
        [AllowHtml]
        public string SocialSecurityNumber { get; set; }

        [NopResourceDisplayName("Account.Fields.DateOfBirth")]
        public int? DateOfBirthDay { get; set; }
        [NopResourceDisplayName("Account.Fields.DateOfBirth")]
        public int? DateOfBirthMonth { get; set; }
        [NopResourceDisplayName("Account.Fields.DateOfBirth")]
        public int? DateOfBirthYear { get; set; }
        public bool DateOfBirthRequired { get; set; }
        public DateTime? ParseDateOfBirth()
        {
            if (!DateOfBirthYear.HasValue || !DateOfBirthMonth.HasValue || !DateOfBirthDay.HasValue)
                return null;

            DateTime? dateOfBirth = null;
            try
            {
                dateOfBirth = new DateTime(DateOfBirthYear.Value, DateOfBirthMonth.Value, DateOfBirthDay.Value);
            }
            catch { }
            return dateOfBirth;
        }

        [NopResourceDisplayName("Account.Fields.Email")]
        [AllowHtml]
        public string Email { get; set; }
        
        [NopResourceDisplayName("Merchant.Fields.BusinessName")]
        [AllowHtml]
        public string BusinessName { get; set; }

        [NopResourceDisplayName("Merchant.Fields.BusinessCategory")]
        public int BusinessCategory { get; set; }
        public IList<SelectListItem> AvailableBusinessCategories { get; set; }

        [NopResourceDisplayName("Account.Fields.StreetAddress")]
        [AllowHtml]
        public string StreetAddress { get; set; }

        [NopResourceDisplayName("Account.Fields.City")]
        [AllowHtml]
        public string City { get; set; }

        [NopResourceDisplayName("Account.Fields.StateProvince")]
        public int StateProvinceId { get; set; }
        public IList<SelectListItem> AvailableStates { get; set; }

        [NopResourceDisplayName("Account.Fields.ZipPostalCode")]
        [AllowHtml]
        public string ZipPostalCode { get; set; }
        
        [NopResourceDisplayName("Account.Fields.Phone")]
        [AllowHtml]
        public string Phone { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Merchant.Fields.AccountType")]
        public string BankAccountType { get; set; }
        public IList<SelectListItem> BankAccountTypes { get; set; }

        [AllowHtml]
        public string AccountType { get; set; }
        public IList<SelectListItem> AccountTypes { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Merchant.Fields.BankName")]
        public string BankName { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Merchant.Fields.RoutingNumber")]
        public string RoutingNumber { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Merchant.Fields.AccountNumber")]
        public string AccountNumber { get; set; }

        [AllowHtml]
        [NopResourceDisplayName("Merchant.Fields.NameOnAccount")]
        public string NameOnAccount { get; set; }
    }
}