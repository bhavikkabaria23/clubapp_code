﻿namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    public class RegisterResultModel
    {
        public string MerchantAccountId { get; set; }

        public string MerchantProfileId { get; set; }
    }
}
