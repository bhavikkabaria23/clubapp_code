﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //signup page
            routes.MapRoute("Plugin.Misc.ProPayMerchant.Register",
                "merchant-signup/",
                new { controller = "MiscProPayMerchant", action = "Register" },
                new[] { "ShopFast.Plugin.Misc.ProPayMerchant.Controllers" }
            );
        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
