﻿using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public class ProPayMerchantSettings : ISettings
    {
        /// <summary>
        /// Gets or sets a unique certification string. It is used to authenticate that the incoming data at
        /// ProPay is from the correct source.
        /// </summary>
        public string CertString { get; set; }

        /// <summary>
        /// Gets or sets a unique biller account identifier. It is used to identify the correct collection
        /// of tokens on ProtectPay.
        /// </summary>
        public string BillerAccountId { get; set; }

        /// <summary>
        /// Gets or sets a unique authentication token provided by ProPay. It is used to authenticate every
        /// incoming requests on ProtectPay.
        /// </summary>
        public string AuthenticationToken { get; set; }
    }
}
