﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.Mvc;
using System.Xml;
using Nop.Core;
using Nop.Services.Configuration;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Security;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Controllers
{
    public class MiscProPayMerchantController : BasePluginController
    {
        #region Fields


        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ILocalizationService _localizationService;
        private readonly ILogger _logger;

        #endregion

        #region Constructors

        public MiscProPayMerchantController(IWorkContext workContext, IStoreContext storeContext,
            IStoreService storeService, ISettingService settingService, ICountryService countryService,
            IStateProvinceService stateProvinceService, ILocalizationService localizationService,
            ILogger logger)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._localizationService = localizationService;
            this._logger = logger;
        }

        #endregion

        #region Utilities

        /// <summary>
        /// Executes a request of ProtectPay's SOAP API.
        /// </summary>
        /// <param name="methodName">Method name.</param>
        /// <param name="requestXml">Request xml.</param>
        /// <returns>Response xml.</returns>
        private string ExecuteRequest(string methodName, string requestXml)
        {
            string responseXml = string.Empty;

            //create a web request using a service URL
            var webRequest = WebRequest.Create("https://protectpaytest.propay.com/API/SPS.svc");
            //set the SOAPAction header to the web request to call appropriate service method
            webRequest.Headers.Add("SOAPAction", string.Format("http://propay.com/SPS/contracts/SPSService/{0}", methodName));
            //set the Method property of the web request to POST data
            webRequest.Method = "POST";


            //create SOAP envelope
            var xmlBuilder = new StringBuilder();
            xmlBuilder.Append(string.Format("<soapenv:Envelope xmlns:soapenv=\"{0}\" xmlns:con=\"{1}\" xmlns:typ=\"{2}\"{3}{4}>",
                "http://schemas.xmlsoap.org/soap/envelope/", "http://propay.com/SPS/contracts", "http://propay.com/SPS/types",
                (requestXml.Contains("prop:") ? string.Format(" xmlns:prop{0}=\"{1}\"", (methodName == "ProcessSplitPayTransaction" ? "1" : string.Empty),
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.SPS.External") : string.Empty),
                (methodName == "ProcessSplitPayTransaction" ? string.Format(" xmlns:prop=\"{0}\"",
                    "http://schemas.datacontract.org/2004/07/Propay.Contracts.FraudDetection") : string.Empty)));
            xmlBuilder.Append("<soapenv:Header/>");
            xmlBuilder.Append("<soapenv:Body>");
            xmlBuilder.Append(requestXml);
            xmlBuilder.Append("</soapenv:Body>");
            xmlBuilder.Append("</soapenv:Envelope>");

            //convert a request xml to byte array
            byte[] byteArray = Encoding.UTF8.GetBytes(xmlBuilder.ToString());
            //set the ContentType property of the web request
            webRequest.ContentType = "text/xml";
            //set the ContentLength property of the web request
            webRequest.ContentLength = byteArray.Length;

            //get the request stream to write data
            var dataStream = webRequest.GetRequestStream();
            //write the request xml byte array to the request stream
            dataStream.Write(byteArray, 0, byteArray.Length);
            //close the request stream object
            dataStream.Close();


            //get the response
            var webResponse = webRequest.GetResponse();
            //get the response stream containing response returned by the ProtectPay
            dataStream = webResponse.GetResponseStream();
            //open the response stream using a StreamReader for easy access
            var streamReader = new StreamReader(dataStream);
            //get the response xml string
            responseXml = streamReader.ReadToEnd();

            //clean up the stream objects
            streamReader.Close();
            dataStream.Close();
            webResponse.Close();

            //returns response
            return responseXml;
        }

        /// <summary>
        /// Executes a request of ProtectPay's SOAP API.
        /// </summary>
        /// <param name="methodName">Method name.</param>
        /// <param name="requestXml">Request xml.</param>
        /// <returns>Response xml.</returns>
        private string ExecuteRequest1(string requestXml)
        {
            string responseXml = string.Empty;

            //create a web request using a service URL
            var webRequest = WebRequest.Create("https://xmltest.propay.com/API/PropayAPI.aspx");
            //set the Method property of the web request to POST data
            webRequest.Method = "POST";


            //convert a request xml to byte array
            byte[] byteArray = Encoding.UTF8.GetBytes(requestXml);
            //set the ContentType property of the web request
            webRequest.ContentType = "application/xml";
            //set the ContentLength property of the web request
            webRequest.ContentLength = byteArray.Length;

            //get the request stream to write data
            var dataStream = webRequest.GetRequestStream();
            //write the request xml byte array to the request stream
            dataStream.Write(byteArray, 0, byteArray.Length);
            //close the request stream object
            dataStream.Close();


            //get the response
            var webResponse = webRequest.GetResponse();
            //get the response stream containing response returned by the ProtectPay
            dataStream = webResponse.GetResponseStream();
            //open the response stream using a StreamReader for easy access
            var streamReader = new StreamReader(dataStream);
            //get the response xml string
            responseXml = streamReader.ReadToEnd();

            //clean up the stream objects
            streamReader.Close();
            dataStream.Close();
            webResponse.Close();

            //returns response
            return responseXml;
        }

        #endregion

        #region Methods

        #region - Configuration -

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a main store scope
            var proPayMerchantSettings = _settingService.LoadSetting<ProPayMerchantSettings>();

            var model = new ConfigurationModel();
            model.CertString = proPayMerchantSettings.CertString;
            model.BillerAccountId = proPayMerchantSettings.BillerAccountId;
            model.AuthenticationToken = proPayMerchantSettings.AuthenticationToken;

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/MiscProPayMerchant/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a main store scope
            var proPayMerchantSettings = _settingService.LoadSetting<ProPayMerchantSettings>();

            //save settings
            proPayMerchantSettings.CertString = model.CertString;
            proPayMerchantSettings.BillerAccountId = model.BillerAccountId;
            proPayMerchantSettings.AuthenticationToken = model.AuthenticationToken;

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Configuration.Updated"));

            return Configure();
        }

        #endregion

        #region - Register -

        public ActionResult Signup()
        {
            var model = new RegisterModel
            {
                AvailableBusinessCategories = new List<SelectListItem>(),
                AvailableStates = new List<SelectListItem>(),
                BankAccountTypes = new List<SelectListItem>(),
                AccountTypes = new List<SelectListItem>()
            };

            //business categories
            model.AvailableBusinessCategories.Add(new SelectListItem { Text = _localizationService.GetResource("Merchant.Fields.BusinessCategory.Select"), Value = "0" });
            model.AvailableBusinessCategories.Add(new SelectListItem { Text = "General Merchandise", Value = "5399" });

            //states
            var country = _countryService.GetCountryByThreeLetterIsoCode("USA");
            var states = _stateProvinceService.GetStateProvincesByCountryId(country != null ? country.Id : 0, _workContext.WorkingLanguage.Id).ToList();
            if (states.Count > 0)
            {
                model.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectState"), Value = "0" });
                foreach (var s in states)
                {
                    model.AvailableStates.Add(new SelectListItem { Text = s.GetLocalized(x => x.Name), Value = s.Id.ToString(), Selected = (s.Id == model.StateProvinceId) });
                }
            }

            //bank account types
            model.BankAccountTypes.Add(new SelectListItem { Value = "Business", Text = "Business", Selected = true });
            model.BankAccountTypes.Add(new SelectListItem { Value = "Personal", Text = "Personal" });

            //account types
            model.AccountTypes.Add(new SelectListItem { Value = "Checking", Text = "Checking", Selected = true });
            model.AccountTypes.Add(new SelectListItem { Value = "Savings", Text = "Savings" });

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/MiscProPayMerchant/Signup.cshtml", model);
        }

        [HttpPost]
        [PublicAntiForgery]
        [ValidateInput(false)]
        public ActionResult Signup(RegisterModel model)
        {
            var xmlBuilder = new StringBuilder();
            xmlBuilder.Append("<?xml version=\"1.0\"?>");
            xmlBuilder.Append("<!DOCTYPE Request.dtd>");
            xmlBuilder.Append("<XMLRequest>");
            xmlBuilder.Append("<certStr>c7700c21e494547b3ddd6c9a7156c5</certStr>");
            xmlBuilder.Append("<class>partner</class>");
            xmlBuilder.Append("<XMLTrans>");
            xmlBuilder.Append("<transType>01</transType>");
            xmlBuilder.Append(string.Format("<sourceEmail>{0}</sourceEmail>", model.Email));
            xmlBuilder.Append(string.Format("<firstName>{0}</firstName>", model.FirstName));
            xmlBuilder.Append(string.Format("<lastName>{0}</lastName>", model.LastName));
            xmlBuilder.Append(string.Format("<addr>{0}</addr>", model.StreetAddress));
            xmlBuilder.Append(string.Format("<city>{0}</city>", model.City));
            xmlBuilder.Append(string.Format("<state>{0}</state>", _stateProvinceService.GetStateProvinceById(model.StateProvinceId).Abbreviation));
            xmlBuilder.Append(string.Format("<zip>{0}</zip>", model.ZipPostalCode));
            xmlBuilder.Append(string.Format("<dayPhone>{0}</dayPhone>", model.Phone));
            xmlBuilder.Append(string.Format("<evenPhone>{0}</evenPhone>", model.Phone));
            xmlBuilder.Append(string.Format("<dob>{0:MM-dd-yyyy}</dob>", model.ParseDateOfBirth().Value));
            xmlBuilder.Append(string.Format("<externalId>{0}</externalId>", Guid.NewGuid().ToString().Split('-')[0]));
            xmlBuilder.Append(string.Format("<ssn>{0}</ssn>", model.SocialSecurityNumber));
            xmlBuilder.Append("<tier>Premium</tier>");
            xmlBuilder.Append(string.Format("<DoingBusinessAs>{0}</DoingBusinessAs>", model.BusinessName));
            xmlBuilder.Append(string.Format("<BankName>{0}</BankName>", model.BankName));
            xmlBuilder.Append(string.Format("<Description>{0}</Description>", model.BankAccountType));
            xmlBuilder.Append(string.Format("<accountName>{0}</accountName>", model.NameOnAccount));
            xmlBuilder.Append(string.Format("<AccountNumber>{0}</AccountNumber>", model.AccountNumber));
            xmlBuilder.Append(string.Format("<RoutingNumber>{0}</RoutingNumber>", model.RoutingNumber));
            xmlBuilder.Append(string.Format("<accountType>{0}</accountType>", model.AccountType));
            xmlBuilder.Append(string.Format("<AccountOwnershipType>{0}</AccountOwnershipType>", model.BankAccountType));
            xmlBuilder.Append(string.Format("<MCCCode>{0}</MCCCode>", model.BusinessCategory));
            xmlBuilder.Append("</XMLTrans>");
            xmlBuilder.Append("</XMLRequest>");

            var responseXml = ExecuteRequest1(xmlBuilder.ToString());
            var xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(responseXml);

            string merchantAccountId = string.Empty;
            string merchantProfileId = string.Empty;
            if (xmlDocument.SelectSingleNode("XMLResponse/XMLTrans/status").InnerText == "00")
            {
                merchantAccountId = xmlDocument.SelectSingleNode("XMLResponse/XMLTrans/accntNum").InnerText;
            }

            if (!string.IsNullOrEmpty(merchantAccountId))
            {
                //prepares void payment request xml
                var requestXml = new StringBuilder();
                requestXml.Append("<con:CreateMerchantProfile>");

                //sets the identification elements
                requestXml.Append("<con:identification>");
                requestXml.Append(string.Format("<typ:AuthenticationToken>{0}</typ:AuthenticationToken>", "5fb2f7b6-0f2f-4410-bd30-60a8c93418e2"));
                requestXml.Append(string.Format("<typ:BillerAccountId>{0}</typ:BillerAccountId>", "4263543208491909"));
                requestXml.Append("</con:identification>");

                requestXml.Append("<con:merchantProfile>");
                requestXml.Append("<prop:PaymentProcessor>LegacyProPay</prop:PaymentProcessor>");
                requestXml.Append("<prop:ProcessorData>");

                requestXml.Append("<prop:ProcessorDatum>");
                requestXml.Append("<prop:ProcessorField>certStr</prop:ProcessorField>");
                requestXml.Append("<prop:Value>c7700c21e494547b3ddd6c9a7156c5</prop:Value>");
                requestXml.Append("</prop:ProcessorDatum>");

                requestXml.Append("<prop:ProcessorDatum>");
                requestXml.Append("<prop:ProcessorField>termId</prop:ProcessorField>");
                requestXml.Append("<prop:Value>7156c5</prop:Value>");
                requestXml.Append("</prop:ProcessorDatum>");

                requestXml.Append("<prop:ProcessorDatum>");
                requestXml.Append("<prop:ProcessorField>accountNum</prop:ProcessorField>");
                requestXml.Append(string.Format("<prop:Value>{0}</prop:Value>", merchantAccountId));
                requestXml.Append("</prop:ProcessorDatum>");

                requestXml.Append("</prop:ProcessorData>");
                requestXml.Append(string.Format("<prop:ProfileName>{0}</prop:ProfileName>", model.BusinessName));
                requestXml.Append("</con:merchantProfile>");

                requestXml.Append("</con:CreateMerchantProfile>");


                //executes the create merchant profile request
                var responseXml1 = ExecuteRequest("CreateMerchantProfile", requestXml.ToString());
                var xmlDocument1 = new XmlDocument();
                xmlDocument1.LoadXml(responseXml1);

                var xmlnsManager = new XmlNamespaceManager(xmlDocument1.NameTable);
                xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                xmlnsManager.AddNamespace("a", "http://schemas.datacontract.org/2004/07/Propay.Contracts.SPS.External");
                xmlnsManager.AddNamespace("b", "http://propay.com/SPS/types");

                //check for, status of request
                string resultXmlPath = "/s:Envelope/s:Body/c:CreateMerchantProfileResponse/c:CreateMerchantProfileResult/";
                switch (xmlDocument1.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/b:ResultValue"), xmlnsManager).InnerText)
                {
                    case "SUCCESS":
                        {
                            merchantProfileId = xmlDocument1.SelectSingleNode(string.Concat(resultXmlPath, "a:ProfileId"), xmlnsManager).InnerText;

                            break;
                        }
                    case "FAILURE":
                        {
                            _logger.Warning(string.Format("Failure occurred while executing the '{0}'method. FailureMessage: {1}", "CreateMerchantProfile",
                                xmlDocument1.SelectSingleNode(string.Concat(resultXmlPath, "a:RequestResult/b:ResultMessage"), xmlnsManager).InnerText));

                            break;
                        }
                    default:
                        break;
                }
            }

            _logger.Information(string.Format("Merchant Account Id: {0} | Merchant Profile Id: {1}", merchantAccountId, merchantProfileId));
            var result = new RegisterResultModel { MerchantAccountId = merchantAccountId, MerchantProfileId = merchantProfileId };

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/MiscProPayMerchant/SignupResult.cshtml", result);
        }

        #endregion

        #endregion
    }
}
