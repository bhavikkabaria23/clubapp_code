﻿using Nop.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Misc.BulkImport
{
    public class BulkImportSettings : ISettings
    {
        public string Provider { get; set; }
    }
}
