﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Messages;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Data;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Messages;
using Nop.Web.Framework.Menu;
using Shopfast.Plugin.Misc.BulkImport.Data;
using SiteMapNode = Nop.Web.Framework.Menu.SiteMapNode;

namespace Shopfast.Plugin.Misc.BulkImport
{
    public class BulkImport : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly ISettingService _settingService;
        private readonly BulkImportSettings _settings;
        private readonly BulkImportContext _bulkImportContext;

        public BulkImport(ISettingService settingService, 
            BulkImportSettings settings, 
            BulkImportContext bulkImportContext)
        {
            _settingService = settingService;
            _settings = settings;
            _bulkImportContext = bulkImportContext;
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
           SetDefaultSettings();
            
            _bulkImportContext.Install();

            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            _bulkImportContext.Uninstall();
            
            base.Uninstall();
        }

        //nop3.7 upgrade begin
        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var urlHelper = new UrlHelper(HttpContext.Current.Request.RequestContext);

            var pluginsNode = rootNode.ChildNodes.First(n => n.Title == "Plugins");
            pluginsNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true, 
                Title = "Bulk Import",
                Url = urlHelper.RouteUrl("Shopfast.Plugin.Misc.BulkImport.Import"),
            });
        }
        //nop3.7 upgrade end

        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();

            var defaultSettings = new BulkImportSettings
            {
                Provider = "Microsoft.Jet.OLEDB.4.0"
            };
            settingService.SaveSetting(defaultSettings);

            string script = File.ReadAllText(HttpContext.Current
                .Server.MapPath("~/Plugins/Shopfast.Misc.BulkImport/SqlScripts/InstallScript.sql"));
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(script);

            InstallEmailTemplates();
        }

        private static void InstallEmailTemplates()
        {
            IMessageTemplateService messageTemplateService = EngineContext.Current.Resolve<IMessageTemplateService>();
            IStoreContext storeContext = EngineContext.Current.Resolve<IStoreContext>();
            IRepository<EmailAccount> emailAccountRepository = EngineContext.Current.Resolve<IRepository<EmailAccount>>();
            IRepository<MessageTemplate> messageTemplateRepository = EngineContext.Current.Resolve<IRepository<MessageTemplate>>();

            var eaGeneral = emailAccountRepository.Table.FirstOrDefault();
            if (eaGeneral == null)
                throw new Exception("Default email account cannot be loaded");
            var messageTemplates = new List<MessageTemplate>
            {
                //Import
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.BulkImport.OrderImported",
                    Subject = File.ReadAllText(HttpContext.Current
                        .Server.MapPath("~/Plugins/ShopFast.Misc.BulkImport/EmailTemplates/OrderImportedSubject.txt")),
                    Body = File.ReadAllText(HttpContext.Current
                        .Server.MapPath("~/Plugins/ShopFast.Misc.BulkImport/EmailTemplates/OrderImportedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                }
            };
            foreach (var messageTemplate in messageTemplates)
            {
                if (messageTemplateService.GetMessageTemplateByName(messageTemplate.Name, storeContext.CurrentStore.Id) == null)
                {
                    messageTemplateService.InsertMessageTemplate(messageTemplate);
                }
            }
        }

        /// <summary>
        /// Get a route for provide configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        void IMiscPlugin.GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "BulkImport";
            routeValues = new RouteValueDictionary { { "Namespaces", "Shopfast.Plugin.Misc.BulkImport.Controllers" }, { "area", null } };
        }

        public bool Authenticate()
        {
            return true;
        }
    }
}
