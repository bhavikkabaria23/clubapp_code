﻿using System.Data.Entity.ModelConfiguration;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Data
{
    public partial class TmpCategoryMap : EntityTypeConfiguration<TmpCategory>
    {
        public TmpCategoryMap()
        {
            //Map the primary key
            HasKey(m => m.Id);
            ToTable("TmpCategoriesTable");
        }
        
    }
}
