﻿using System.Data.Entity.ModelConfiguration;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Data
{
    public partial class TmpOrderMap : EntityTypeConfiguration<TmpOrder>
    {
        public TmpOrderMap()
        {
            //Map the primary key
            HasKey(m => m.Id);
            ToTable("TmpOrdersTable");
        }
        
    }
}
