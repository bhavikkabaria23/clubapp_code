﻿using System.Data.Entity.ModelConfiguration;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Data
{
    public partial class TmpCustomerMap : EntityTypeConfiguration<TmpCustomer>
    {
        public TmpCustomerMap()
        {
            //Map the primary key
            HasKey(m => m.Id);
            ToTable("TmpCustomersTable");
        }
        
    }
}
