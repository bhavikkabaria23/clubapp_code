﻿IF EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'TmpCustomersIdsTable' ) DROP TABLE TmpCustomersIdsTable;

CREATE TABLE TmpCustomersIdsTable (
[Id] [int] NOT NULL
CONSTRAINT [PK_TmpCustomersIdsTable] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) );

MERGE [dbo].[Customer] trgt
USING [dbo].[TmpCustomersTable] AS src
ON trgt.[Email] = src.[Email]
WHEN NOT MATCHED
    THEN INSERT(
	[CustomerGuid],
    [Username],
	[Email],
	[Password],
	[PasswordFormatId],
	[PasswordSalt],
	[AdminComment],
	[IsTaxExempt],
	[AffiliateId],
	[VendorId],
	[Active],
	[Deleted],
	[IsSystemAccount],
	[HasShoppingCartItems],
	[CreatedOnUtc],
	[LastActivityDateUtc]
	)
     VALUES(
    src.[CustomerGuid],
    src.[Username],
	src.[Email],
	src.[PasswordStr],
	src.[PasswordFormatId],
	src.[PasswordSalt],
	src.[AdminComment],
	src.[IsTaxExempt],
	src.[AffiliateId],
	src.[VendorId],
	src.[Active],
	src.[Deleted],
	src.[IsSystemAccount],
	0,
	GETDATE(),
	GETDATE()
	)
WHEN MATCHED THEN UPDATE SET
	[CustomerGuid] = src.[CustomerGuid],
    [Username] = src.[Username],
	[Email] = src.[Email],
	[Password] = src.[PasswordStr],
	[PasswordFormatId] = src.[PasswordFormatId],
	[PasswordSalt] = src.[PasswordSalt],
	[AdminComment] = src.[AdminComment],
	[IsTaxExempt] = src.[IsTaxExempt],
	[AffiliateId] = src.[AffiliateId],
	[VendorId] = src.[VendorId],
	[Active] = src.[Active],
	[Deleted] = src.[Deleted],
	[IsSystemAccount] = src.[IsSystemAccount]
OUTPUT inserted.ID INTO TmpCustomersIdsTable;

--merge generic att

MERGE [dbo].[GenericAttribute] trgt
USING (SELECT Id, [Key], Value
		FROM Customer c
			inner join(
				SELECT Email, [Key], [Value]
					FROM (
						SELECT Email, FirstName, LastName, Gender, Company, StreetAddress, StreetAddress2, ZipPostalCode, City, CONVERT(nvarchar(1000),CountryId) as CountryId, CONVERT(nvarchar(1000),StateProvinceId) as StateProvinceId, Phone, Fax, VatNumber, CONVERT(nvarchar(1000),VatNumberStatusId) as VatNumberStatusId, CONVERT(nvarchar(1000),TimeZoneId) as TimeZoneId, CONVERT(nvarchar(1000),AvatarPictureId) as AvatarPictureId, CONVERT(nvarchar(1000),ForumPostCount) as ForumPostCount, [Signature]
						FROM [TmpCustomersTable]
					)  as tcga
				UNPIVOT
					(
						[Value]
						FOR [Key] IN (FirstName, LastName, Gender, Company, StreetAddress, StreetAddress2, ZipPostalCode, City, CountryId, StateProvinceId, Phone, Fax, VatNumber, VatNumberStatusId, TimeZoneId, AvatarPictureId, ForumPostCount, [Signature])
					) AS P
			) tcga on c.Email = tcga.Email 
		WHERE tcga.Value is not null
		 ) AS src
ON trgt.EntityId = src.Id and trgt.KeyGroup = 'Customer' and trgt.[Key] = src.[Key]
WHEN NOT MATCHED
THEN INSERT([EntityId]
           ,[KeyGroup]
           ,[Key]
           ,[Value]
           ,[StoreId])
     VALUES(
    src.[Id],
    'Customer',
	src.[Key],
	src.Value,
	0 -- todo: parameter
	)
WHEN MATCHED THEN UPDATE SET
	[Value] = src.[Value];  
  
-- merge customer role mapping ([IsGuest], [IsRegistered], [IsAdministrator], [IsForumModerator])
MERGE [dbo].[Customer_CustomerRole_Mapping] trgt
USING (SELECT Id,tcr.RoleID
		FROM Customer c
			inner join(
				SELECT   Email, [RoleID]
				FROM 
				(SELECT Email, cr1.Id as Role1ID, cr2.Id as Role2ID, cr3.Id as Role3ID, cr4.Id as Role4ID,  cr1.Id as RoleTest1ID,cr2.Id as RoleTest2ID
					FROM [TmpCustomersTable] tt
					left join [CustomerRole] cr1 on tt.IsAdministrator=1 and cr1.SystemName='Administrators'
					left join [CustomerRole] cr2 on tt.IsForumModerator=1 and cr2.SystemName='ForumModerators'
					left join [CustomerRole] cr3 on tt.IsRegistered=1 and cr3.SystemName='Registered'
					left join [CustomerRole] cr4 on tt.IsGuest=1 and cr4.SystemName='Guests') as tcr
				UNPIVOT
				(
						[RoleID]
						FOR [ColumnName] IN ([Role1ID], [Role2ID], [Role3ID], [Role4ID])
				) AS P
			) tcr on c.Email = tcr.Email
		 ) AS src
ON trgt.Customer_Id = src.Id
and trgt.CustomerRole_Id = RoleID
WHEN NOT MATCHED
THEN INSERT(
	[Customer_Id],
    [CustomerRole_Id]
	)
     VALUES(
    src.[Id],
    src.[RoleID]
	);

-- DROP TABLE [TmpCustomersTable];

--DELETE FROM [TmpCustomersTable];

select c.* from TmpCustomersIdsTable tcidst
	INNER JOIN [Customer] c on tcidst.Id=c.Id