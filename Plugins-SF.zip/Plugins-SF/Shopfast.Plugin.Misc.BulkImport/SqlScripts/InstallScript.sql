﻿IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[ITP_Source]') AND type in (N'U'))BEGIN
CREATE TABLE [dbo].[ITP_Source](
	[SourceId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_ITP_Source] PRIMARY KEY CLUSTERED 
(
	[SourceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END

IF NOT EXISTS(SELECT * FROM sys.columns 
        WHERE [name] = N'ExtId' AND [object_id] = OBJECT_ID(N'Order'))
BEGIN
   ALTER TABLE [dbo].[Order] ADD [ExtId] nvarchar(max) null;
END
IF NOT EXISTS(SELECT * FROM sys.columns 
        WHERE [name] = N'SourceId' AND [object_id] = OBJECT_ID(N'Order'))
BEGIN
   ALTER TABLE [dbo].[Order] ADD [SourceId] int null;
END
IF NOT EXISTS(SELECT * FROM sys.columns 
        WHERE [name] = N'ExtId' AND [object_id] = OBJECT_ID(N'Address'))
BEGIN
   ALTER TABLE [dbo].[Address] ADD [ExtId] nvarchar(max) null;
END
IF NOT EXISTS(SELECT * FROM sys.columns 
        WHERE [name] = N'SourceId' AND [object_id] = OBJECT_ID(N'Address'))
BEGIN
   ALTER TABLE [dbo].[Address] ADD [SourceId] int null;
END

INSERT INTO [dbo].[ITP_Source]
           ([Name])
     VALUES
           ('ExtOrderBillingAddressId')
--GO
INSERT INTO [dbo].[ITP_Source]
           ([Name])
     VALUES
           ('ExtOrderShippingAddressId')