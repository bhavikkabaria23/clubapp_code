﻿IF EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'TmpCustomersTable' ) DROP TABLE TmpCustomersTable;
CREATE TABLE TmpCustomersTable(
	[Id] [int] IDENTITY(1,1) NOT NULL,

	[CustomerGuid][uniqueidentifier] NOT NULL,
    [Username] [nvarchar](1000) NULL,
	[Email] [nvarchar](1000) NULL,
	[PasswordStr] [nvarchar](max) NULL,
	[PasswordFormatId] [int] NOT NULL,
	[PasswordSalt] [nvarchar](max) NULL,
	[AdminComment] [nvarchar](max) NULL,
	[IsTaxExempt] [bit] NOT NULL,
	[AffiliateId] [int] NOT NULL,
	[VendorId] [int] NOT NULL,
	[Active] [bit] NOT NULL,
	IsGuest [bit] NOT NULL,
	IsRegistered [bit] NOT NULL,
	IsAdministrator [bit] NOT NULL,
	IsForumModerator [bit] NOT NULL,
	[Deleted] [bit] NOT NULL,
	[IsSystemAccount] [bit] NOT NULL,
--for generic
	[FirstName] [nvarchar](1000) NULL,
	[LastName] [nvarchar](1000) NULL,
	[Gender] [nvarchar](1000) NULL,
	
	[Company] [nvarchar](1000) NULL,
	[StreetAddress] [nvarchar](1000) NULL,
	[StreetAddress2] [nvarchar](1000) NULL,
	[ZipPostalCode] [nvarchar](1000) NULL,
	[City] [nvarchar](1000) NULL,
	[CountryId] [int] NULL,
	[StateProvinceId] [int] NULL,
	[Phone] [nvarchar](1000) NULL,
	[Fax] [nvarchar](1000) NULL,
	[VatNumber] [nvarchar](1000) NULL,
	[VatNumberStatusId] [int]  NULL,
	[TimeZoneId] [int] NULL,
	[AvatarPictureId] [int] NULL,
	[ForumPostCount] [int] NULL,
	[Signature] [nvarchar](1000) NULL,

	 CONSTRAINT [PK_TmpCustomersTable] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) );