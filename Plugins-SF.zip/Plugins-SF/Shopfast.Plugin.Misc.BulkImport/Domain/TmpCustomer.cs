﻿
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Directory;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Misc.BulkImport.Domain
{

    public class TmpCustomer : BaseEntity
    {
        public TmpCustomer()
        {
            //Defaul values
            Deleted = 0;
            AdminComment = null;
            IsSystemAccount = false;
        }

        public Guid CustomerGuid { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string PasswordStr { get; set; }
        public int PasswordFormatId { get; set; }
        public string PasswordSalt { get; set; }
        public bool IsTaxExempt { get; set; }
        public int AffiliateId { get; set; }
        public int VendorId { get; set; }
        public bool Active { get; set; }
        public bool IsGuest { get; set; }
        public bool IsRegistered { get; set; }
        public bool IsAdministrator { get; set; }
        public bool IsForumModerator { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Company { get; set; }
        public string StreetAddress { get; set; }
        public string StreetAddress2 { get; set; }
        public string ZipPostalCode { get; set; }
        public string City { get; set; }
        public int? CountryId { get; set; }
        public int? StateProvinceId { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string VatNumber { get; set; }
        public int? VatNumberStatusId { get; set; }
        public int? TimeZoneId { get; set; }
        public int? AvatarPictureId { get; set; }
        public int? ForumPostCount { get; set; }
        public string Signature { get; set; }

        public int Deleted { get; set; }
        public string AdminComment { get; set; }
        public bool IsSystemAccount { get; set; }
    }
}
