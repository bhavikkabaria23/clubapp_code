﻿
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Misc.BulkImport.Domain
{

    public class TmpOrder : BaseEntity
    {
        public int? OrderId { get; set; }

        public Guid OrderGuid { get; set; }
        public int StoreId { get; set; }
        public int? CustomerId { get; set; }
        public int OrderStatusId { get; set; }
        public int ShippingStatusId { get; set; }
        public int PaymentStatusId { get; set; }
        public string PaymentMethodSystemName { get; set; }
        public string CustomerCurrencyCode { get; set; }
        public decimal CurrencyRate { get; set; }
        public string VatNumber { get; set; }

        public decimal OrderSubtotalInclTax { get; set; }
        public decimal OrderSubtotalExclTax { get; set; }
        public decimal OrderSubTotalDiscountInclTax { get; set; }
        public decimal OrderSubTotalDiscountExclTax { get; set; }
        public decimal OrderShippingInclTax { get; set; }
        public decimal OrderShippingExclTax { get; set; }
        public decimal PaymentMethodAdditionalFeeInclTax { get; set; }
        public decimal PaymentMethodAdditionalFeeExclTax { get; set; }
        public string TaxRates { get; set; }
        public decimal OrderTax { get; set; }
        public decimal OrderDiscount { get; set; }
        public decimal OrderTotal { get; set; }
        public decimal RefundedAmount { get; set; }

        public int AffiliateId { get; set; }
        public string ShippingMethod { get; set; }
        public string ShippingRateComputationMethodSystemName { get; set; }
        public string CustomValuesXml { get; set; }

        public string BillingFirstName { get; set; }
        public string BillingLastName { get; set; }
        public string BillingEmail { get; set; }
        public string BillingCompany { get; set; }
        public string BillingCountry { get; set; }
        public string BillingStateProvince { get; set; }
        public string BillingCity { get; set; }
        public string BillingAddress1 { get; set; }
        public string BillingAddress2 { get; set; }
        public string BillingZipPostalCode { get; set; }
        public string BillingPhoneNumber { get; set; }
        public string BillingFaxNumber { get; set; }

        public string ShippingFirstName { get; set; }
        public string ShippingLastName { get; set; }
        public string ShippingEmail { get; set; }
        public string ShippingCompany { get; set; }
        public string ShippingCountry { get; set; }
        public string ShippingStateProvince { get; set; }
        public string ShippingCity { get; set; }
        public string ShippingAddress1 { get; set; }
        public string ShippingAddress2 { get; set; }
        public string ShippingZipPostalCode { get; set; }
        public string ShippingPhoneNumber { get; set; }
        public string ShippingFaxNumber { get; set; }

        public string CustomerEmail { get; set; }
        public string ExtId { get; set; }
        public string SourceId { get; set; }
        
    }
}
