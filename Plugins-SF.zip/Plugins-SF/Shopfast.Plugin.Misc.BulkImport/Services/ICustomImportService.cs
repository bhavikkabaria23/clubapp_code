﻿using System.Data;
using System.IO;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public interface ICustomImportService
    {
        DataTable GetCustomersTable(string args = "");

        DataTable GetOrdersTable(string args = "");

        DataTable GetCategoriesTable(Stream input =null, string args = "");
    }
}
