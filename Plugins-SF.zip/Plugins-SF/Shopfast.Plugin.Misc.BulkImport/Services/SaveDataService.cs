﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Logging;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Shopfast.Plugin.Misc.BulkImport.Data;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public class SaveDataService : ISaveDataService
    {
        private readonly IDbContext _dbContext;
        private readonly ILogger _logger;
        private readonly IRepository<TmpCustomer> _tmpCustomersTableRepository;
        private readonly IRepository<TmpOrder> _tmpOrdersRepository;
        private readonly IRepository<TmpCategory> _tmpCategoriesTableRepository;

        public SaveDataService(IDbContext dbContext, 
            ILogger logger, 
            IRepository<TmpCustomer> tmpCustomersTableRepository, 
            IRepository<TmpOrder> tmpOrdersRepository, IRepository<TmpCategory> tmpCategoriesTableRepository)
        {
            _dbContext = dbContext;
            _logger = logger;
            _tmpCustomersTableRepository = tmpCustomersTableRepository;
            _tmpOrdersRepository = tmpOrdersRepository;
            _tmpCategoriesTableRepository = tmpCategoriesTableRepository;
        }

        public List<Customer> SaveCustomers(List<TmpCustomer> tmpCustomers, string sqlScriptProcessPath)
        {
            ClearTmpTable("TmpCustomersTable");
            _tmpCustomersTableRepository.Insert(tmpCustomers);

            string processCommnad = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath(sqlScriptProcessPath));
            var result = _dbContext.ExecuteStoredProcedureList<Customer>(processCommnad).ToList();
            return result;
        }

        public List<Order> SaveOrders(List<TmpOrder> tmpOrders, string sqlScriptProcessPath)
        {
            ClearTmpTable("TmpOrdersTable");
            _tmpOrdersRepository.Insert(tmpOrders);

            string processCommnad = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath(sqlScriptProcessPath));
            var result = _dbContext.ExecuteStoredProcedureList<Order>(processCommnad).ToList();
            return result;
        }

        //no output this version
        public void SaveCategories(List<TmpCategory> tmpCategories, string sqlScriptProcessPath)
        {
            ClearTmpTable("TmpCategoriesTable");
            _tmpCategoriesTableRepository.Insert(tmpCategories);

            string processCommnad = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath(sqlScriptProcessPath));
            _dbContext.ExecuteSqlCommand(processCommnad);
            
        }

        protected void ClearTmpTable(string tableName)
        {
            if (tableName.Contains("Tmp"))
            {
                IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
                dbContext.ExecuteSqlCommand(string.Format("TRUNCATE TABLE {0};", tableName));
            }
        }

        /// <summary>
        /// Saves data to merge table and executes merge script
        /// </summary>
        /// <param name="dataTable">Mapped merge table</param>
        /// <param name="destinationTableName">Merge table's name</param>
        /// <param name="sqlScriptProcessPath">Merge script's path</param>
        /// <returns>Inserted ids</returns>
        public List<T> SaveDataTable<T>(DataTable dataTable, string destinationTableName, string sqlScriptProcessPath)
            where T : BaseEntity, new()
        {
            List<T> result = new List<T>();

            string processCommnad = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath(sqlScriptProcessPath));

            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            var connectionString = (dbContext as DbContext).Database.Connection.ConnectionString;
            
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(connectionString))
            {
                bulkcopy.BulkCopyTimeout = 1200;
                bulkcopy.DestinationTableName = destinationTableName;
                bulkcopy.WriteToServer(dataTable);
                bulkcopy.Close();
            }
            result = _dbContext.ExecuteStoredProcedureList<T>(processCommnad).ToList();

            /*_logger.Warning("BulkImport: Got Connection String");
            _logger.Warning("BulkImport: " + connectionString);
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                _logger.Warning("BulkImport: Got Connection");
                using (SqlCommand command = new SqlCommand("", conn))
                {
                    _logger.Warning("BulkImport: Got Command");
                    conn.Open();
                    _logger.Warning("BulkImport: Oppened Connection");
                    using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conn))
                    {
                        bulkcopy.BulkCopyTimeout = 1200;
                        bulkcopy.DestinationTableName = destinationTableName;
                        _logger.Warning("BulkImport: Got Preparations for Writing");
                        bulkcopy.WriteToServer(dataTable);
                        _logger.Warning("BulkImport: Wrote to Server");
                        bulkcopy.Close();
                    }
                    command.CommandTimeout = 600;
                    command.CommandText = processCommnad;
                    result = _dbContext.ExecuteStoredProcedureList<T>(processCommnad).ToList();
                    _logger.Warning("BulkImport: Saved");
                    //var sqlReader = command.ExecuteReader();
                    //ids = (from IDataRecord r in sqlReader select (int)r["Id"]).ToList();
                    conn.Close();
                }
            }*/

            return result;
        }
    }
}
