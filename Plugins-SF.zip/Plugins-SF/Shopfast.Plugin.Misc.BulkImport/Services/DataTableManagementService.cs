﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Directory;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public class DataTableManagementService : IDataTableManagementService
    {
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;

        public DataTableManagementService(ICountryService countryService,
            IStateProvinceService stateService,
            IAddressService addressService,
            ICustomerService customerService)
        {
            _countryService = countryService;
            _stateService = stateService;
            _addressService = addressService;
            _customerService = customerService;
        }

        #region Orders

        public List<TmpOrder> GetOrderRecords(DataTable dataTable)
        {
            return (from DataRow row in dataTable.Rows
                    select new TmpOrder()
                    {
                        OrderId = GetValueInt(row["OrderId"]),
                        OrderGuid = GetValueGuid(row["OrderGuid"]),
                        StoreId = GetValueInt(row["StoreId"]).GetValueOrDefault(),
                        CustomerId = GetValueInt(row["CustomerId"]),
                        OrderStatusId = GetValueInt(row["OrderStatusId"]).GetValueOrDefault(),
                        ShippingStatusId = GetValueInt(row["ShippingStatusId"]).GetValueOrDefault(),
                        PaymentStatusId = GetValueInt(row["PaymentStatusId"]).GetValueOrDefault(),
                        PaymentMethodSystemName = GetValueString(row["PaymentMethodSystemName"]),
                        CustomerCurrencyCode = GetValueString(row["CustomerCurrencyCode"]),
                        CurrencyRate = GetValueDecimal(row["CurrencyRate"]).GetValueOrDefault(),
                        VatNumber = GetValueString(row["VatNumber"]),

                        OrderSubtotalInclTax = GetValueDecimal(row["OrderSubtotalInclTax"]).GetValueOrDefault(),
                        OrderSubtotalExclTax = GetValueDecimal(row["OrderSubtotalExclTax"]).GetValueOrDefault(),
                        OrderSubTotalDiscountInclTax = GetValueDecimal(row["OrderSubTotalDiscountInclTax"]).GetValueOrDefault(),
                        OrderSubTotalDiscountExclTax = GetValueDecimal(row["OrderSubTotalDiscountExclTax"]).GetValueOrDefault(),
                        OrderShippingInclTax = GetValueDecimal(row["OrderShippingInclTax"]).GetValueOrDefault(),
                        OrderShippingExclTax = GetValueDecimal(row["OrderShippingExclTax"]).GetValueOrDefault(),
                        PaymentMethodAdditionalFeeInclTax = GetValueDecimal(row["PaymentMethodAdditionalFeeInclTax"]).GetValueOrDefault(),
                        PaymentMethodAdditionalFeeExclTax = GetValueDecimal(row["PaymentMethodAdditionalFeeExclTax"]).GetValueOrDefault(),
                        TaxRates = GetValueString(row["TaxRates"]),
                        OrderTax = GetValueDecimal(row["OrderTax"]).GetValueOrDefault(),
                        OrderDiscount = GetValueDecimal(row["OrderDiscount"]).GetValueOrDefault(),
                        OrderTotal = GetValueDecimal(row["OrderTotal"]).GetValueOrDefault(),
                        RefundedAmount = GetValueDecimal(row["RefundedAmount"]).GetValueOrDefault(),
                        AffiliateId = GetValueInt(row["AffiliateId"]).GetValueOrDefault(),
                        ShippingMethod = GetValueString(row["ShippingMethod"]),
                        ShippingRateComputationMethodSystemName = GetValueString(row["ShippingRateComputationMethodSystemName"]),
                        CustomValuesXml = GetValueString(row["CustomValuesXml"]),

                        BillingFirstName = GetValueString(row["BillingFirstName"]),
                        BillingLastName = GetValueString(row["BillingLastName"]),
                        BillingEmail = GetValueString(row["BillingEmail"]),
                        BillingCompany = GetValueString(row["BillingCompany"]),
                        BillingCountry = GetValueString(row["BillingCountry"]),
                        BillingStateProvince = GetValueString(row["BillingStateProvince"]),
                        BillingCity = GetValueString(row["BillingCity"]),
                        BillingAddress1 = GetValueString(row["BillingAddress1"]),
                        BillingAddress2 = GetValueString(row["BillingAddress2"]),
                        BillingZipPostalCode = GetValueString(row["BillingZipPostalCode"]),
                        BillingPhoneNumber = GetValueString(row["BillingPhoneNumber"]),
                        BillingFaxNumber = GetValueString(row["BillingFaxNumber"]),

                        ShippingFirstName = GetValueString(row["ShippingFirstName"]),
                        ShippingLastName = GetValueString(row["ShippingLastName"]),
                        ShippingEmail = GetValueString(row["ShippingEmail"]),
                        ShippingCompany = GetValueString(row["ShippingCompany"]),
                        ShippingCountry = GetValueString(row["ShippingCountry"]),
                        ShippingStateProvince = GetValueString(row["ShippingStateProvince"]),
                        ShippingCity = GetValueString(row["ShippingCity"]),
                        ShippingAddress1 = GetValueString(row["ShippingAddress1"]),
                        ShippingAddress2 = GetValueString(row["ShippingAddress2"]),
                        ShippingZipPostalCode = GetValueString(row["ShippingZipPostalCode"]),
                        ShippingPhoneNumber = GetValueString(row["ShippingPhoneNumber"]),
                        ShippingFaxNumber = GetValueString(row["ShippingFaxNumber"]),

                        CustomerEmail = GetValueString(row["CustomerEmail"]),
                        ExtId = GetValueString(row["ExtId"]),
                        SourceId = GetValueString(row["SourceId"])
                    }).ToList();
        }

        public DataTable MapToOrder(DataTable sourceTable)
        {
            string script = File.ReadAllText(HttpContext.Current
                .Server.MapPath("~/Plugins/Shopfast.Misc.BulkImport/SqlScripts/CreateTempOrders.sql"));
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(script);

            var targetTable = GetDataTableScheme("[TmpOrdersTable]");
            //defaults
            SetDefaultValues(targetTable);
            List<string> excludedColumns = new List<string>();
            excludedColumns.Add("CreatedOnUtc");
            for (int i = 0; i < sourceTable.Rows.Count; i++)
            {
                var row = sourceTable.Rows[i];
                var newRow = targetTable.NewRow();
                FillMatchingRows(sourceTable, excludedColumns, targetTable, newRow, row);
                //BillingAddress
                targetTable.Rows.Add(newRow);
            }

            return targetTable;
        }

        #endregion

        #region Customers


        public List<TmpCustomer> GetCustomerRecords(DataTable dataTable)
        {
            var result = new List<TmpCustomer>();

            //string script = File.ReadAllText(HttpContext.Current
            //    .Server.MapPath("~/Plugins/Shopfast.Misc.BulkImport/SqlScripts/CreateTempCustomers.sql"));
            //IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            //dbContext.ExecuteSqlCommand(script);

            foreach (DataRow row in dataTable.Rows)
            {
                var newRecord = new TmpCustomer()
                {
                    Id = (int)row["Id"],
                    CustomerGuid = GetValueGuid(row["CustomerGuid"]),
                    Username = GetValueString(row["Username"]),
                    Email = GetValueString(row["Email"]),
                    PasswordStr = GetValueString(row["PasswordStr"]),
                    PasswordFormatId = GetValueInt(row["PasswordFormatId"]).GetValueOrDefault(),
                    PasswordSalt = GetValueString(row["PasswordSalt"]),
                    IsTaxExempt = GetValueBool(row["IsTaxExempt"]).GetValueOrDefault(),
                    AffiliateId = GetValueInt(row["AffiliateId"]).GetValueOrDefault(),
                    VendorId = GetValueInt(row["VendorId"]).GetValueOrDefault(),
                    Active = GetValueBool(row["Active"]).GetValueOrDefault(),
                    IsGuest = GetValueBool(row["IsGuest"]).GetValueOrDefault(),
                    IsRegistered = GetValueBool(row["IsRegistered"]).GetValueOrDefault(),
                    IsAdministrator = GetValueBool(row["IsAdministrator"]).GetValueOrDefault(),
                    IsForumModerator = GetValueBool(row["IsForumModerator"]).GetValueOrDefault(),

                    FirstName = GetValueString(row["FirstName"]),
                    LastName = GetValueString(row["LastName"]),
                    Gender = GetValueString(row["Gender"]),
                    Company = GetValueString(row["Company"]),
                    StreetAddress = GetValueString(row["StreetAddress"]),
                    StreetAddress2 = GetValueString(row["StreetAddress2"]),
                    ZipPostalCode = GetValueString(row["ZipPostalCode"]),
                    City = GetValueString(row["City"]),
                    CountryId = GetValueInt(row["CountryId"]).GetValueOrDefault(),
                    StateProvinceId = GetValueInt(row["StateProvinceId"]).GetValueOrDefault(),
                    Phone = GetValueString(row["Phone"]),
                    Fax = GetValueString(row["Fax"]),
                    VatNumber = GetValueString(row["VatNumber"]),
                    VatNumberStatusId = GetValueInt(row["VatNumberStatusId"]),
                    TimeZoneId = GetValueInt(row["TimeZoneId"]),
                    AvatarPictureId = GetValueInt(row["AvatarPictureId"]),
                    ForumPostCount = GetValueInt(row["ForumPostCount"]),
                    Signature = (GetValueString(row["Signature"]))
                };

                result.Add(newRecord);
            }

            return result;
        }

        public DataTable MapToCustomer(DataTable sourceTable)
        {
            string script = File.ReadAllText(HttpContext.Current
                .Server.MapPath("~/Plugins/Shopfast.Misc.BulkImport/SqlScripts/CreateTempCustomers.sql"));
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(script);

            var targetTable = GetDataTableScheme("[TmpCustomersTable]");
            //defaults
            SetDefaultValues(targetTable);
            List<string> excludedColumns = new List<string>();
            excludedColumns.Add("CreatedOnUtc");
            for (int i = 0; i < sourceTable.Rows.Count; i++)
            {
                var row = sourceTable.Rows[i];
                var newRow = targetTable.NewRow();
                FillMatchingRows(sourceTable, excludedColumns, targetTable, newRow, row);
                //BillingAddress
                targetTable.Rows.Add(newRow);
            }
            return targetTable;

        }

        #endregion

        #region Utilities

        protected string GetValueString(object dataField)
        {
            return dataField == DBNull.Value
                ? null
                : dataField.ToString();
        }

        protected Guid GetValueGuid(object dataField)
        {
            return Guid.Parse(dataField.ToString());
        }

        protected int? GetValueInt(object dataField)
        {
            return dataField == DBNull.Value
                ? (int?)null
                : Int32.Parse(dataField.ToString());
        }

        protected decimal? GetValueDecimal(object dataField)
        {
            return dataField == DBNull.Value
                ? (decimal?)null
                : Decimal.Parse(dataField.ToString());
        }

        protected bool? GetValueBool(object dataField)
        {
            return dataField == DBNull.Value
                ? (bool?)null
                : bool.Parse(dataField.ToString());
        }

        protected bool? GetValueBoolFromBit(object dataField)
        {
            return dataField == DBNull.Value
                ? (bool?)null
                : (dataField.ToString()) == "1";
        }

        private static void FillMatchingRows(DataTable sourceTable, List<string> excludedColumns, DataTable targetTable, DataRow newRow,
            DataRow row)
        {
            foreach (DataColumn column in sourceTable.Columns)
            {
                if (!excludedColumns.Contains(column.ColumnName))
                {
                    if (targetTable.Columns.Contains(column.ColumnName))
                    {
                        newRow[column.ColumnName] = row[column.ColumnName];
                    }
                }
            }
        }

        private void SetDefaultValues(DataTable targetTable)
        {
            foreach (DataColumn col in targetTable.Columns)
            {
                if (col.ColumnName != "Id" && col.DataType != typeof(DateTime) && col.DataType != typeof(String)
                    && col.DataType != typeof(Guid))
                    col.DefaultValue = 0;
                if (col.DataType == typeof(String)) col.DefaultValue = "";
                if (col.DataType == typeof(DateTime)) col.DefaultValue = DateTime.UtcNow;//DBNull.Value; db null
                if (col.DataType == typeof(Guid)) col.DefaultValue = new Guid();//db null
            }
        }

        private DataTable GetDataTableScheme(string tableName)
        {
            var newTable = new DataTable();

            var connectionString = new DataSettingsManager().LoadSettings().DataConnectionString;
            using (SqlConnection nopConnection = new SqlConnection(connectionString))
            {
                nopConnection.Open();
                var cmd = new SqlCommand("SELECT TOP 0 * FROM " + tableName, nopConnection);
                newTable.Load(cmd.ExecuteReader());
                nopConnection.Close();
            }
            return newTable;
        }

        #endregion

        #region categories
        public List<TmpCategory> GetCategoryRecords(DataTable dataTable)
        {
            var result = new List<TmpCategory>();

            //string script = File.ReadAllText(HttpContext.Current
            //    .Server.MapPath("~/Plugins/Shopfast.Misc.BulkImport/SqlScripts/CreateTempCustomers.sql"));
            //IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            //dbContext.ExecuteSqlCommand(script);

            foreach (DataRow row in dataTable.Rows)
            {
                var newRecord = new TmpCategory()
                {
                    ExtId = GetValueInt(row["Id"]).GetValueOrDefault(),
                    Name = GetValueString(row["Name"]),
                    Description = GetValueString(row["Description"]),
                    CategoryTemplateId = GetValueInt(row["CategoryTemplateId"]).GetValueOrDefault(),
                    MetaKeywords = GetValueString(row["MetaKeywords"]),
                    MetaDescription = GetValueString(row["MetaDescription"]),
                    MetaTitle = GetValueString(row["MetaTitle"]),
                    ParentCategoryId = GetValueInt(row["CategoryTemplateId"]).GetValueOrDefault(),
                    PageSize = GetValueInt(row["CategoryTemplateId"]).GetValueOrDefault(),
                    AllowCustomersToSelectPageSize = GetValueBoolFromBit(row["AllowCustomersToSelectPageSize"]).GetValueOrDefault(),
                    PageSizeOptions = GetValueString(row["PageSizeOptions"]),
                    PriceRanges =GetValueString(row["PriceRanges"]),
                    ShowOnHomePage = GetValueBoolFromBit(row["ShowOnHomePage"]).GetValueOrDefault(),
                    IncludeInTopMenu = GetValueBoolFromBit(row["IncludeInTopMenu"]).GetValueOrDefault(),
                    HasDiscountsApplied = GetValueBoolFromBit(row["HasDiscountsApplied"]).GetValueOrDefault(),
                    SubjectToAcl = GetValueBoolFromBit(row["HasDiscountsApplied"]).GetValueOrDefault(),
                    LimitedToStores = GetValueBoolFromBit(row["HasDiscountsApplied"]).GetValueOrDefault(),
                    Published = GetValueBoolFromBit(row["HasDiscountsApplied"]).GetValueOrDefault(),
                    Deleted = GetValueBoolFromBit(row["HasDiscountsApplied"]).GetValueOrDefault(),
                    DisplayOrder = GetValueInt(row["HasDiscountsApplied"]).GetValueOrDefault()
       
                };

                result.Add(newRecord);
            }

            return result;
        }

        #endregion

    }
}
