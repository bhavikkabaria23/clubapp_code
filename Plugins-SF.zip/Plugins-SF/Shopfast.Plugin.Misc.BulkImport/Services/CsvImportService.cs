﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Nop.Services.Configuration;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public class CsvImportService : ICustomImportService
    {
        private readonly ISettingService _settingService;

        public CsvImportService(ISettingService settingService)
        {
            _settingService = settingService;
        }

        private DataTable ProcessCSV(string fileName)
        {
            
            StreamReader sr = new StreamReader(fileName);
            var dt = CsvStreamToDataTable(sr);
            sr.Dispose();

            //return a the new DataTable

            return dt;
        }

        private DataTable ProcessCSV(StreamReader sr)
        {

            var dt = CsvStreamToDataTable(sr);


            //return a the new DataTable

            return dt;
        }

        private DataTable CsvStreamToDataTable(StreamReader sr)
        {
            
            // work out where we should split on comma, but not in a sentence
            Regex r = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");

            DataTable dt=new DataTable();
            //Read the first line and split the string at , with our regular expression in to an array
            sr.DiscardBufferedData();
            sr.BaseStream.Seek(0, System.IO.SeekOrigin.Begin); 
            string line = sr.ReadLine();
            string[] strArray = r.Split(line);

            //For each item in the new split array, dynamically builds our Data columns. Save us having to worry about it.
            //Array.ForEach(strArray, s => dt.Columns.Add(new DataColumn(s)));
            foreach (var s in strArray)
            {
                var newColumn = new DataColumn(s);
                dt.Columns.Add(newColumn);
            }

            //Read each line in the CVS file until it’s empty
            while ((line = sr.ReadLine()) != null)
            {
                DataRow row = dt.NewRow();

                //add our current value to our data row
                var values = r.Split(line);
                object[] rowData = new object[values.Count()];
                for (int i = 0; i < values.Count(); i++)
                {
                    object newValue = values[i];
                    if (string.IsNullOrEmpty(values[i]))
                    {
                        newValue = DBNull.Value;
                    }
                    rowData[i] = newValue;
                }

                row.ItemArray = rowData;
                //row.ItemArray = values;
                dt.Rows.Add(row);
            }
            return dt;
        }

        public DataTable GetCustomersTable(string path)
        {
            return ProcessCSV(path);
        }

        public DataTable GetOrdersTable(string path)
        {
            return ProcessCSV(path);
        }

        public DataTable GetCategoriesTable(Stream input = null, string path = "")
        {
            return ProcessCSV(new StreamReader(input));
        }
    }
}
