﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public interface ISaveDataService
    {

        List<Customer> SaveCustomers(List<TmpCustomer> tmpCustomers, string sqlScriptProcessPath);

        List<Order> SaveOrders(List<TmpOrder> tmpOrders, string sqlScriptProcessPath);
        
        /// <summary>
        /// Saves data to merge table and executes merge script
        /// </summary>
        /// <param name="dataTable">Mapped merge table</param>
        /// <param name="destinationTableName">Merge table's name</param>
        /// <param name="sqlScriptProcessPath">Merge script's path</param>
        /// <returns>Inserted ids</returns>
        List<T> SaveDataTable<T>(DataTable dataTable, string destinationTableName, string sqlScriptProcessPath)
            where T : BaseEntity, new();
         
        void SaveCategories(List<TmpCategory> tmpCategories, string sqlScriptProcessPath);
    }
}
