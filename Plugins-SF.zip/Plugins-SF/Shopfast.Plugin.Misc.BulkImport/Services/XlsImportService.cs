﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public class XlsImportService : ICustomImportService
    {
        public DataTable GetCustomersTable(string args = "")
        {
            throw new NotImplementedException();
        }

        public DataTable GetOrdersTable(string filePath)
        {
            string sSheetName = null;
            string sConnection = null;
            DataTable dtTablesList = default(DataTable);
            OleDbCommand oleExcelCommand = default(OleDbCommand);
            OleDbDataReader oleExcelReader = default(OleDbDataReader);
            OleDbConnection oleExcelConnection = default(OleDbConnection);

            sConnection =
                String.Format(
                    "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=No;IMEX=1\"",
                    filePath);

            oleExcelConnection = new OleDbConnection(sConnection);
            oleExcelConnection.Open();

            dtTablesList = oleExcelConnection.GetSchema("Tables");

            if (dtTablesList.Rows.Count > 0)
            {
                sSheetName = dtTablesList.Rows[0]["TABLE_NAME"].ToString();
            }

            dtTablesList.Clear();
            dtTablesList.Dispose();


            oleExcelCommand = oleExcelConnection.CreateCommand();
            oleExcelCommand.CommandText = "Select * From [" + sSheetName + "]";
            oleExcelCommand.CommandType = CommandType.Text;
            oleExcelReader = oleExcelCommand.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(oleExcelReader);
            oleExcelReader.Close();
            oleExcelConnection.Close();
            //name columns
            int index = 0;
            foreach (DataColumn col in dataTable.Columns)
            {
                col.ColumnName = dataTable.Rows[0][index].ToString();
                index++;
            }
            //remove first (names) row
            var dr = dataTable.Rows[0];
            dr.Delete();
            dataTable.AcceptChanges();

            return dataTable;
        }

        public DataTable GetCategoriesTable(Stream input = null, string args = "")
        {
            throw new NotImplementedException();
        }
    }
}

