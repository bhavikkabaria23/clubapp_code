﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Core.Data;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Directory;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Shopfast.Plugin.Misc.BulkImport.Domain;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public interface IDataTableManagementService
    {
        List<TmpOrder> GetOrderRecords(DataTable dataTable);

        DataTable MapToOrder(DataTable sourceTable);

        List<TmpCustomer> GetCustomerRecords(DataTable dataTable);

        DataTable MapToCustomer(DataTable sourceTable);

        List<TmpCategory> GetCategoryRecords(DataTable dataTable);
    }
}
