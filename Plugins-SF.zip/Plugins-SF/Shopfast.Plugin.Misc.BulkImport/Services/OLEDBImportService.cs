﻿using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using Nop.Services.Configuration;

namespace Shopfast.Plugin.Misc.BulkImport.Services
{
    public class OLEDBImportService : ICustomImportService
    {
        private readonly ISettingService _settingService;

        public OLEDBImportService(ISettingService settingService)
        {
            _settingService = settingService;
        }

        public DataTable GetCustomersTable(string path)
        {
            var pluginSettings = _settingService.LoadSetting<BulkImportSettings>();

            string header = "Yes";

            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);

            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                string.Format("Provider={0};Data Source={1};Extended Properties=\"Text;HDR={2}\"",
                    pluginSettings.Provider, pathOnly, header)))
            //using (OleDbConnection connection = new OleDbConnection(
            //    @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
            //    ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        public DataTable GetOrdersTable(string path)
        {
            string header = "Yes";

            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);

            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        public DataTable GetCategoriesTable(Stream input = null, string args = "")
        {
            throw new System.NotImplementedException();
        }
    }
}
