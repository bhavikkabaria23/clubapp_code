﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using AutoMapper;
using Nop.Core.Data;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;

namespace Shopfast.Plugin.Misc.BulkImport
{
    public static class MappingExtensions
    {
        #region Order

        #endregion

    }


}
