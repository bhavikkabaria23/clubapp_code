﻿
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Misc.BulkImport.Models
{

    public class BulkImportModel: BaseNopModel
    {
        public string CustomerFilePath { get; set; }

        public string OrderFilePath { get; set; }

        public string CategoryFilePath { get; set; }

    }
}
