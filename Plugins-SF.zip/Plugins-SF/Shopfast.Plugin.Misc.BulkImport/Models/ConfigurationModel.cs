﻿
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Misc.BulkImport.Models
{

    public class ConfigurationModel : BaseNopModel
    {

        public string Provider { get; set; }

    }
}