﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.Misc.BulkImport
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.Settings",
                "BulkImport/Settings",
               new { controller = "BulkImport", action = "Configure" },
               new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.DefaultSettings",
                "BulkImport/DefaultSettings",
               new { controller = "BulkImport", action = "DefaultSettings" },
               new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.ImportOrders",
                "BulkImport/ImportOrders",
               new { controller = "BulkImport", action = "ImportOrders" },
               new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.ImportCustomers",
                "BulkImport/ImportCustomers",
               new { controller = "BulkImport", action = "ImportCustomers" },
               new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.Import",
                "BulkImport/Import",
               new { controller = "BulkImport", action = "Import" },
               new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" }).DataTokens.Add("area", "admin");


            //RouteBase r = routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.Settings",
            //    "Admin/BulkImport/Settings/",
            //    new { controller = "BulkImportAdmin", action = "Configure", area = "admin" },
            //    new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" });
            //routes.Remove(r);
            //routes.Insert(0, r);

            //r = routes.MapRoute("Shopfast.Plugin.Misc.BulkImport.Import",
            //    "Admin/BulkImport/ImportPage/",
            //    new { controller = "BulkImportAdmin", action = "ImportPage", area = "admin" },
            //    new[] { "Shopfast.Plugin.Misc.BulkImport.Controlles" });
            //routes.Remove(r);
            //routes.Insert(0, r);

        }

        public int Priority
        {
            get { return 0; }
        }
    }
}
