﻿using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Misc.BulkImport.Data;
using Shopfast.Plugin.Misc.BulkImport.Domain;
using Shopfast.Plugin.Misc.BulkImport.Services;

namespace Shopfast.Plugin.Misc.BulkImport
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public const string TMP_CUSTOMER_CONTEXT_NAME = "nop_tmp_customers_table_context";
        public const string TMP_BULKIMPORT_CONTEXT_NAME = "nop_bulkimport_context";

        //nop3.7 upgrade begin
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            //register named context
            builder.Register<IDbContext>(c => new BulkImportContext(c.Resolve<DataSettings>().DataConnectionString))
                .Named<IDbContext>(TMP_BULKIMPORT_CONTEXT_NAME)
                .InstancePerLifetimeScope();
            builder.Register<BulkImportContext>(c => new BulkImportContext(c.Resolve<DataSettings>().DataConnectionString))
                .InstancePerLifetimeScope();

            //override required repository with our custom context
            builder.RegisterType<EfRepository<TmpCustomer>>()
                .As<IRepository<TmpCustomer>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(TMP_BULKIMPORT_CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<TmpOrder>>()
                .As<IRepository<TmpOrder>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(TMP_BULKIMPORT_CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<TmpCategory>>()
                .As<IRepository<TmpCategory>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(TMP_BULKIMPORT_CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<CsvImportService>().As<ICustomImportService>().InstancePerHttpRequest();
            builder.RegisterType<SaveDataService>().As<ISaveDataService>().InstancePerHttpRequest();
            builder.RegisterType<DataTableManagementService>().As<IDataTableManagementService>().InstancePerHttpRequest();
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 1; }
        }

    }
}
