﻿using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using Nop.Admin.Controllers;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Forums;
using Nop.Core.Domain.Orders;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.EuropaCheckVatService;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Seo;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Messages;
using Nop.Core.Events;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Customers;
using Nop.Services.Events;
using Nop.Services.Messages;
using Nop.Web.Framework.Security.Captcha;
using Shopfast.Plugin.Misc.BulkImport.Data;
using Shopfast.Plugin.Misc.BulkImport.Domain;
using Shopfast.Plugin.Misc.BulkImport.Models;
using Shopfast.Plugin.Misc.BulkImport.Services;
using ShopFast.Plugin.Misc.Core.Events;

namespace Shopfast.Plugin.Misc.BulkImport.Controllers
{
    [AdminAuthorize]
    public class BulkImportController : BasePluginController
    {
        #region Fields

        public delegate void OrderImportedEventHandler(object sender, EventArgs e);


        private readonly IWorkContext _workContext;
        private readonly CustomerSettings _customerSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly ForumSettings _forumSettings;
        private readonly OrderSettings _orderSettings;
        private readonly IOrderService _orderService;
        private readonly IStoreContext _storeContext;
        private readonly ILanguageService _languageService;
        private readonly ILogger _logger;
        private readonly ILocalizedEntityService _localizedEntityService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly ISettingService _settingService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ILocalizationService _localizationService;
        private readonly CaptchaSettings _captchaSettings;
        private readonly ICustomImportService _customImportService;
        private readonly ISaveDataService _saveDataService;
        private readonly IDataTableManagementService _dataTableManagementService;
        private readonly IEventPublisher _eventPublisher;
        private readonly IMessageTemplateService _messageTemplateService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IMessageTokenProvider _messageTokenProvider;
        private readonly ITokenizer _tokenizer;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly ICustomerService _customerService;
        private readonly BulkImportSettings _pluginSettings;
        private readonly IRepository<TmpCustomer> _tmpCustomerRepository; 

        #endregion

        #region Ctor

        public BulkImportController(IWorkContext workContext,
            CustomerSettings customerSettings,
            ForumSettings forumSettings,
            RewardPointsSettings rewardPointsSettings,
            OrderSettings orderSettings,
            IOrderService orderService,
            IStoreContext storeContext,
            ILanguageService languageService,
            ILocalizedEntityService localizedEntityService,
            IUrlRecordService urlRecordService,
            ISettingService settingService,
            ILogger logger,
            CaptchaSettings captchaSettings,
            IGenericAttributeService genericAttributeService,
            ILocalizationService localizationService,
            ICustomImportService customImportService,
            ISaveDataService saveDataService,
            IDataTableManagementService dataTableManagementService, 
            IEventPublisher eventPublisher, 
            IMessageTemplateService messageTemplateService, 
            IEmailAccountService emailAccountService, 
            EmailAccountSettings emailAccountSettings, 
            LocalizationSettings localizationSettings, 
            IMessageTokenProvider messageTokenProvider, 
            ITokenizer tokenizer, 
            IQueuedEmailService queuedEmailService, 
            ICustomerService customerService, 
            BulkImportSettings pluginSettings, 
            IRepository<TmpCustomer> tmpCustomerRepository)
        {
            _workContext = workContext;
            _customerSettings = customerSettings;
            _rewardPointsSettings = rewardPointsSettings;
            _forumSettings = forumSettings;
            _orderService = orderService;
            _orderSettings = orderSettings;
            _storeContext = storeContext;
            _languageService = languageService;
            _localizedEntityService = localizedEntityService;
            _urlRecordService = urlRecordService;
            _settingService = settingService;
            _logger = logger;
            _genericAttributeService = genericAttributeService;
            _localizationService = localizationService;
            _customImportService = customImportService;
            _saveDataService = saveDataService;
            _dataTableManagementService = dataTableManagementService;
            _eventPublisher = eventPublisher;
            _messageTemplateService = messageTemplateService;
            _emailAccountService = emailAccountService;
            _emailAccountSettings = emailAccountSettings;
            _localizationSettings = localizationSettings;
            _messageTokenProvider = messageTokenProvider;
            _tokenizer = tokenizer;
            _queuedEmailService = queuedEmailService;
            _customerService = customerService;
            _pluginSettings = pluginSettings;
            _tmpCustomerRepository = tmpCustomerRepository;
            _captchaSettings = captchaSettings;
        }

        #endregion

        #region Config
        [AdminAuthorize]
        [HttpGet]
        public ActionResult Configure()
        {
            var pluginSettings = _settingService.LoadSetting<BulkImportSettings>();
            var confModel = new ConfigurationModel
            {
                Provider = pluginSettings.Provider
            };

            return View("~/Plugins/ShopFast.Misc.BulkImport/Views/Configure/Configure.cshtml", confModel);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
            {
                return Configure();
            }

            var pluginSettings = _settingService.LoadSetting<BulkImportSettings>();
            pluginSettings.Provider = model.Provider;
            _settingService.SaveSetting(pluginSettings);
            _settingService.ClearCache();

            return Configure();
        }

        [AdminAuthorize]
        public ActionResult DefaultSettings()
        {
            BulkImport.SetDefaultSettings();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Misc.BulkImport");
        }

        #endregion

        #region Utilites



        #endregion

        #region Methods

        [ActionName("Import")]
        public ActionResult ImportPage()
        {
            return View("~/Plugins/ShopFast.Misc.BulkImport/Views/BulkImport/ImportPage.cshtml", new BulkImportModel());
        }

        [HttpPost, ActionName("Import")]
        [FormValueRequired("importorders")]
        public ActionResult ImportOrders(BulkImportModel model, FormCollection form)
        {
            string ordersFilePath = string.Empty;
            var ordersFile = Request.Files["ordersimportexcelfile"];
            if (ordersFile != null && ordersFile.ContentLength > 0)
            {
                var extension = Path.GetExtension(ordersFile.FileName);
                ordersFilePath =
                    Server.MapPath(string.Format("~/Plugins/ShopFast.Misc.BulkImport/TempFiles/{0}-orders" + extension,
                        Guid.NewGuid()));

                var fileStream = System.IO.File.Create(ordersFilePath);

                try
                {
                    ordersFile.InputStream.Seek(0, SeekOrigin.Begin);
                    ordersFile.InputStream.CopyTo(fileStream);
                    fileStream.Close();

                    var dataTableOrder = _customImportService.GetOrdersTable(ordersFilePath);
                    var tmpOrders = _dataTableManagementService.GetOrderRecords(dataTableOrder);

                    string processComand = @"~/Plugins/ShopFast.Misc.BulkImport/SqlScripts/MergeOrdersScript.sql";
                    var orders = _saveDataService.SaveOrders(tmpOrders, processComand);
                    
                    foreach (var order in orders)
                    {
                        _eventPublisher.Publish(new EntityInserted<Order>(order));
                        _eventPublisher.Publish(new ITPEntityImported<Order>(order));
                    }

                    //SuccessNotification(orders.Count().ToString());
                    SuccessNotification(_localizationService.GetResource("Plugin.BulkImport.ImportOrders.Success"));
                }
                catch (Exception exc)
                {
                    ErrorNotification(string.Format("{0}: {1}", 
                        _localizationService.GetResource("Plugin.BulkImport.ImportOrders.Error"), exc.Message));
                }
                finally
                {
                    System.IO.File.Delete(ordersFilePath);
                }
            }
            else
            {
                ErrorNotification(_localizationService.GetResource("Plugin.BulkImport.ImportOrders.FileNotSet"));
            }
            return ImportPage();
        }

        [HttpPost, ActionName("Import")]
        [FormValueRequired("importcustomers")]
        public ActionResult ImportCustomers(BulkImportModel model, FormCollection form)
        {
            string customersFilePath = string.Empty;
            var customersFile = Request.Files["customersimportexcelfile"];
            if (customersFile != null && customersFile.ContentLength > 0)
            {
                var extension = Path.GetExtension(customersFile.FileName);
                customersFilePath = Server.MapPath(string.Format("~/Plugins/ShopFast.Misc.BulkImport/TempFiles/{0}-customers" + extension,
                    Guid.NewGuid()));

                var fileStream = System.IO.File.Create(customersFilePath);

                try
                {
                    customersFile.InputStream.Seek(0, SeekOrigin.Begin);
                    customersFile.InputStream.CopyTo(fileStream);
                    fileStream.Close();

                    var dataTableCustomer = _customImportService.GetCustomersTable(customersFilePath);
                    var tmpCustomers = _dataTableManagementService.GetCustomerRecords(dataTableCustomer);

                    string processComand = @"~/Plugins/ShopFast.Misc.BulkImport/SqlScripts/MergeCustomersScript.sql";
                    var customers = _saveDataService.SaveCustomers(tmpCustomers, processComand);

                    foreach (var customer in customers)
                    {
                        _eventPublisher.Publish(new EntityInserted<Customer>(customer));
                    }

                    //SuccessNotification(customers.Count().ToString());
                    SuccessNotification(_localizationService.GetResource("Plugin.BulkImport.ImportCustomers.Success"));
                }
                catch (Exception exc)
                {
                    ErrorNotification(string.Format("{0}: {1}", 
                        _localizationService.GetResource("Plugin.BulkImport.ImportCustomers.Error"), exc.Message));
                }
                finally
                {
                    System.IO.File.Delete(customersFilePath);
                }
            }
            else
            {
                ErrorNotification(_localizationService.GetResource("Plugin.BulkImport.ImportCustomers.FileNotSet"));
            }

            return ImportPage();
        }

        [HttpPost, ActionName("Import")]
        [FormValueRequired("importcategories")]
        public ActionResult ImportCategories(BulkImportModel model, FormCollection form)
        {
            string categoriesFilePath = string.Empty;
            var categoriesFile = Request.Files["categoriesimportexcelfile"];
            if (categoriesFile != null && categoriesFile.ContentLength > 0)
            {
                var extension = Path.GetExtension(categoriesFile.FileName);
                categoriesFilePath = Server.MapPath(string.Format("~/Plugins/ShopFast.Misc.BulkImport/TempFiles/{0}-categories" + extension,
                    Guid.NewGuid()));

                var fileStream = System.IO.File.Create(categoriesFilePath);

                try
                {
                    categoriesFile.InputStream.Seek(0, SeekOrigin.Begin);
                    categoriesFile.InputStream.CopyTo(fileStream);
                    fileStream.Close();

                    var dataTableCategories = _customImportService.GetCategoriesTable(categoriesFile.InputStream);
                    
                    
                    var tmpCategories = _dataTableManagementService.GetCategoryRecords(dataTableCategories);
                    string x = "done";
                    string processComand = @"~/Plugins/ShopFast.Misc.BulkImport/SqlScripts/MergeCategoriesScript.sql";
                    _saveDataService.SaveCategories(tmpCategories, processComand);

                    //foreach (var customer in customers)
                    //{
                    //    _eventPublisher.Publish(new EntityInserted<Customer>(customer));
                    //}

                    
                    SuccessNotification(_localizationService.GetResource("Plugin.BulkImport.ImportCustomers.Success"));
                }
                catch (Exception exc)
                {
                    ErrorNotification(string.Format("{0}: {1}",
                        _localizationService.GetResource("Plugin.BulkImport.ImportCustomers.Error"), exc.Message));
                }
                finally
                {
                    System.IO.File.Delete(categoriesFilePath);
                }
            }
            else
            {
                ErrorNotification(_localizationService.GetResource("Plugin.BulkImport.ImportCustomers.FileNotSet"));
            }

            return ImportPage();
        }
        #endregion
    }
}
