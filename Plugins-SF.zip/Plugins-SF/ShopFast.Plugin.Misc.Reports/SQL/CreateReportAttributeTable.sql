﻿if NOT EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_ReportAttribute' )
begin
	CREATE TABLE ShopFast_ReportAttribute(
		[Id] [int] IDENTITY(1,1) NOT NULL,

		[ReportId] [int] NOT NULL,
		[AttributeTypeId] [int] NOT NULL,
		[Name] [nvarchar](max) NOT NULL,
		[DefaultValue] [nvarchar](max) NULL

		CONSTRAINT [PK_ShopFast_ReportAttribute] PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) );
end