﻿IF EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_ReportAttribute' ) DROP TABLE ShopFast_ReportAttribute;

IF EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_Report' ) DROP TABLE ShopFast_Report;