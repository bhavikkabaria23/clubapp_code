﻿using System.Data.Entity.ModelConfiguration;
using Shopfast.Plugin.Misc.Reports.Domain;

namespace Shopfast.Plugin.Misc.Reports.Data
{
    public partial class ReportAttributeMap : EntityTypeConfiguration<ReportAttribute>
    {
        public ReportAttributeMap()
        {
            //Map the primary key
            HasKey(m => m.Id);
            ToTable("ShopFast_ReportAttribute");
            Property(ra => ra.Name).IsRequired().HasMaxLength(100);

            HasRequired(ra => ra.Report)
                .WithMany(r => r.ReportAttributes)
                .HasForeignKey(ra => ra.ReportId)
                .WillCascadeOnDelete(true);
        }
        
    }
}
