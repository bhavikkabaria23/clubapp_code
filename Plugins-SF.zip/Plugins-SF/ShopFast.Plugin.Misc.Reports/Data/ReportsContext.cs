﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Web;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Misc.Reports.Domain;

namespace Shopfast.Plugin.Misc.Reports.Data
{

    public class ReportsContext : DbContext, IDbContext
    {
        public ReportsContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {
            
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ReportMap());
            modelBuilder.Configurations.Add(new ReportAttributeMap());

            //disable EdmMetadata generation
            //modelBuilder.Conventions.Remove<IncludeMetadataConvention>();
         base.OnModelCreating(modelBuilder);
        }

        public string CreateDatabaseScript()
        {
            return ((IObjectContextAdapter)this).ObjectContext.CreateDatabaseScript();
        }

        public new IDbSet<TEntity> Set<TEntity>() where TEntity : BaseEntity
        {
            return base.Set<TEntity>();
        }

        /// <summary>
        /// Install
        /// </summary>
        public void Install()
        {
            //Database.ExecuteSqlCommand(CreateDatabaseScript());

            try
            {
                string dbScript = "";

                dbScript = File.ReadAllText(HttpContext.Current.Server
                    .MapPath("~/Plugins/ShopFast.Misc.Reports/SQL/CreateReportTable.sql"));
                Database.ExecuteSqlCommand(dbScript);
                dbScript = File.ReadAllText(HttpContext.Current.Server
                    .MapPath("~/Plugins/ShopFast.Misc.Reports/SQL/CreateReportAttributeTable.sql"));
                Database.ExecuteSqlCommand(dbScript);

                SaveChanges();
            }
            catch (Exception exc)
            {
                throw;
            }
            
        }

        /// <summary>
        /// Uninstall
        /// </summary>
        public void Uninstall()
        {
            //this.DropPluginTable("ShopFast_ReportAttribute");
            //this.DropPluginTable("ShopFast_Report");

            string dbScript = "";

            dbScript = File.ReadAllText(HttpContext.Current.Server
                .MapPath("~/Plugins/ShopFast.Misc.Reports/SQL/DropTables.sql"));
            Database.ExecuteSqlCommand(dbScript);

            SaveChanges();
        }

        public IList<TEntity> ExecuteStoredProcedureList<TEntity>(string commandText, params object[] parameters) 
            where TEntity : BaseEntity, new()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Creates a raw SQL query that will return elements of the given generic type.  The type can be any type that has properties that match the names of the columns returned from the query, or can be a simple primitive type. The type does not have to be an entity type. The results of this query are never tracked by the context even if the type of object returned is an entity type.
        /// </summary>
        /// <typeparam name="TElement">The type of object returned by the query.</typeparam>
        /// <param name="sql">The SQL query string.</param>
        /// <param name="parameters">The parameters to apply to the SQL query string.</param>
        /// <returns>Result</returns>
        public IEnumerable<TElement> SqlQuery<TElement>(string sql, params object[] parameters)
        {
            //throw new NotImplementedException();
            return Database.SqlQuery<TElement>(sql, parameters);
        }

        /// <summary>
        /// Executes the given DDL/DML command against the database.
        /// </summary>
        /// <param name="sql">The command string</param>
        /// <param name="timeout">Timeout value, in seconds. A null value indicates that the default value of the underlying provider will be used</param>
        /// <param name="parameters">The parameters to apply to the command string.</param>
        /// <returns>The result returned by the database after executing the command.</returns>
        public int ExecuteSqlCommand(string sql, bool doNotEnsureTransaction = false, int? timeout = null, params object[] parameters)
        {
            throw new NotImplementedException();
        }

        //nop3.7 upgrade begin
        public void Detach(object entity)
        {
            
        }

        public bool ProxyCreationEnabled { get; set; }

        public bool AutoDetectChangesEnabled { get; set; }
        //nop3.7 upgrade end
    }
}
