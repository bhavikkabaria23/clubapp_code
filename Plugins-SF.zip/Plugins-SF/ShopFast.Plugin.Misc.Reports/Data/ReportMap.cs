﻿using System.Data.Entity.ModelConfiguration;
using Shopfast.Plugin.Misc.Reports.Domain;

namespace Shopfast.Plugin.Misc.Reports.Data
{
    public partial class ReportMap : EntityTypeConfiguration<Report>
    {
        public ReportMap()
        {
            //Map the primary key
            HasKey(m => m.Id);
            ToTable("ShopFast_Report");

            //HasMany(r => r.ReportAttributes)
            //    .WithRequired(ra => ra.Report)
            //    .HasForeignKey(ra => ra.ReportId);
        }
        
    }
}
