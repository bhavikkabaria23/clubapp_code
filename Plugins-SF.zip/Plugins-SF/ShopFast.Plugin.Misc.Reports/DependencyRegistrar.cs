﻿using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Misc.Reports.Data;
using Shopfast.Plugin.Misc.Reports.Domain;
using Shopfast.Plugin.Misc.Reports.Services;

namespace Shopfast.Plugin.Misc.Reports
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public const string REPORTS_CONTEXT_NAME = "shopfast_reports_context";

        //nop3.7 upgrade begin
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            //register named context
            builder.Register<IDbContext>(c => new ReportsContext(c.Resolve<DataSettings>().DataConnectionString))
                .Named<IDbContext>(REPORTS_CONTEXT_NAME)
                .InstancePerLifetimeScope();
            builder.Register<ReportsContext>(c => new ReportsContext(c.Resolve<DataSettings>().DataConnectionString))
                .InstancePerLifetimeScope();

            //override required repository with our custom context
            builder.RegisterType<EfRepository<Report>>()
                .As<IRepository<Report>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(REPORTS_CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<ReportAttribute>>()
                .As<IRepository<ReportAttribute>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(REPORTS_CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<ReportService>().As<IReportService>().InstancePerHttpRequest();
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 1; }
        }

    }
}
