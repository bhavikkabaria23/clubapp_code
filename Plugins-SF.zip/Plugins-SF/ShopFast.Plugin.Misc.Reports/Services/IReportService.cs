﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;
using Shopfast.Plugin.Misc.Reports.Domain;

namespace Shopfast.Plugin.Misc.Reports.Services
{
    public interface IReportService
    {
        #region Reports

        IQueryable<Report> SearchReports(string name = null, DateTime? createdUtcMin = null, DateTime? createdUtcMax = null);

        Report GetReportById(int id);

        Report GetReportByName(string name);

        void InsertReport(Report report);

        void UpdateReport(Report report);

        void DeleteReport(Report report);

        #endregion

        #region Report Attributes

        ICollection<ReportAttribute> GetReportAttributes(int reportId);

        ReportAttribute GetReportAttributeById(int id);

        IList<string> InsertReportAttribute(ReportAttribute reportAttribute);

        void UpdateReportAttribute(ReportAttribute reportAttribute);

        void DeleteReportAttribute(ReportAttribute reportAttribute);

        #endregion

        DataTable GetReportResultDataTable(int reportId, FormCollection form);

        DataTable GetReportResultDataTable(Report report, FormCollection form);

        DataTable GetReportResultDataTable(Report report, FormCollection form, string sqlCode);
    }
}
