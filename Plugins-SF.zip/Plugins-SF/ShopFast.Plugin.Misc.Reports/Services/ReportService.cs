﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using Nop.Core.Data;
using Nop.Core.Domain.Logging;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Services.Logging;
using Shopfast.Plugin.Misc.Reports.Domain;
using ShopFast.Plugin.Misc.Reports;
using ShopFast.Plugin.Misc.Reports.Models;

namespace Shopfast.Plugin.Misc.Reports.Services
{
    public class ReportService : IReportService
    {
        #region Fields

        private readonly IRepository<Report> _reportRepository;
        private readonly IRepository<ReportAttribute> _reportAttributeRepository;
        private readonly ReportsPluginSettings _reportsPluginSettings;
        
        #endregion

        #region Ctor

        public ReportService(IRepository<Report> reportRepository,
            IRepository<ReportAttribute> reportAttributeRepository,
            ReportsPluginSettings reportsPluginSettings)
        {
            _reportRepository = reportRepository;
            _reportAttributeRepository = reportAttributeRepository;
            _reportsPluginSettings = reportsPluginSettings;
        }

        #endregion

        #region Utilites


        #endregion

        #region Methods

        #region Reports

        public IQueryable<Report> SearchReports(string name = null, DateTime? createdUtcMin = null, DateTime? createdUtcMax = null)
        {
            return _reportRepository.Table.Where(r =>
                ((string.IsNullOrEmpty(name)) || r.Name.Contains(name)) &&
                ((createdUtcMin == null) || r.CreatedUtc >= createdUtcMin) &&
                ((createdUtcMax == null) || r.CreatedUtc <= createdUtcMax)
                );
        }

        public Report GetReportById(int id)
        {
            return _reportRepository.GetById(id);
        }

        public Report GetReportByName(string name)
        {
            return _reportRepository.Table.FirstOrDefault(r =>
                r.Name == name);
        }

        public void InsertReport(Report report)
        {
            report.CreatedUtc = DateTime.Now;
            _reportRepository.Insert(report);
        }

        public void UpdateReport(Report report)
        {
            _reportRepository.Update(report);
        }

        public void DeleteReport(Report report)
        {
            _reportRepository.Delete(report);
        }

        #endregion

        #region Report Attributes

        public ICollection<ReportAttribute> GetReportAttributes(int reportId)
        {
            //return new List<ReportAttribute>();

            //var report = GetReportById(reportId);
            //if (report == null)
            //    return null;
            //return report.ReportAttributes;

            var reportAttrs = _reportAttributeRepository.Table.Where(ra => ra.ReportId == reportId).ToList();

            return reportAttrs;
        }

        public ReportAttribute GetReportAttributeById(int id)
        {
            return _reportAttributeRepository.GetById(id);
        }

        public IList<string> InsertReportAttribute(ReportAttribute reportAttribute)
        {
            var result = new List<string>();
            if (reportAttribute.ReportId == 0)
            {
                result.Add("Report Id not set");
            }

            if (result.Any())
                return result;

            _reportAttributeRepository.Insert(reportAttribute);

            return result;
        }

        public void UpdateReportAttribute(ReportAttribute reportAttribute)
        {
            _reportAttributeRepository.Update(reportAttribute);
        }

        public void DeleteReportAttribute(ReportAttribute reportAttribute)
        {
            _reportAttributeRepository.Delete(reportAttribute);
        }

        #endregion
        
        protected object ParseReportAttributeValue(ReportAttribute reportAttribute, string reportAttributeValue)
        {
            object result = null;

            reportAttributeValue = reportAttributeValue.Replace("%2F", "/");
            reportAttributeValue = reportAttributeValue.Replace("%40", "@");

            switch (reportAttribute.AttributeType)
            {
                case SqlDbType.Bit:
                    result = Boolean.Parse(reportAttributeValue);
                    break;
                case SqlDbType.Int:
                    result = Int32.Parse(reportAttributeValue);
                    break;
                case SqlDbType.Decimal:
                    result = Decimal.Parse(reportAttributeValue);
                    break;
                case SqlDbType.NVarChar:
                    reportAttributeValue = reportAttributeValue;
                    break;
                case SqlDbType.DateTime:
                    result = DateTime.ParseExact(reportAttributeValue, "M/d/yyyy", CultureInfo.InvariantCulture);
                    //result = DateTime.Parse(reportAttributeValue);
                    break;
            }
            return result;
        }

        protected SqlCommand GetSqlCommand(string sqlCode, ICollection<ReportAttribute> reportAttributes, FormCollection form, 
            SqlConnection sqlConnection)
        {
            SqlCommand sqlCommand;

            /*foreach (var reportAttribute in report.ReportAttributes)
            {
                var reportAttributeFormName = string.Format("{0}{1}",
                        _reportsPluginSettings.ReportAttributePrefix, reportAttribute.Name);
                string reportAttributeValue;
                try
                {
                    reportAttributeValue = form[reportAttributeFormName];
                    //reportAttributeValue = System.Net.WebUtility.HtmlDecode(form[reportAttributeFormName]);
                }
                catch (Exception)
                {
                    reportAttributeValue = reportAttribute.DefaultValue;
                }

                sqlString = sqlString.Replace(string.Format("@{0}", reportAttribute.Name), reportAttributeValue);
            }
             
            sqlCommand = new SqlCommand(sqlString, sqlConnection);*/

            sqlCommand = new SqlCommand(sqlCode, sqlConnection);
            foreach (var reportAttribute in reportAttributes)
            {
                var reportAttributeFormName = string.Format("{0}{1}",
                    _reportsPluginSettings.ReportAttributePrefix, reportAttribute.Name);
                object reportAttributeValue;
                try
                {
                    reportAttributeValue = form[reportAttributeFormName];
                }
                catch (Exception)
                {
                    reportAttributeValue = reportAttribute.DefaultValue;
                }

                try
                {
                    reportAttributeValue = ParseReportAttributeValue(reportAttribute, reportAttributeValue.ToString());
                }
                catch (Exception)
                {
                    reportAttributeValue = ParseReportAttributeValue(reportAttribute, reportAttribute.DefaultValue);
                }

                var sqlParameter = new SqlParameter(string.Format("@{0}", reportAttribute.Name.ToLower()), 
                    reportAttribute.AttributeType);
                sqlParameter.Value = reportAttributeValue;

                sqlCommand.Parameters.Add(sqlParameter);
            }

            return sqlCommand;
        }

        public DataTable GetReportResultDataTable(int reportId, FormCollection form)
        {
            var report = GetReportById(reportId);
            if (report == null)
                return null;

            return GetReportResultDataTable(report, form);
        }

        public DataTable GetReportResultDataTable(Report report, FormCollection form)
        {
            var sqlCode = report.SqlCode;

            return GetReportResultDataTable(report, form, sqlCode);
        }
        
        public DataTable GetReportResultDataTable(Report report, FormCollection form, string sqlCode)
        {
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            var dataTable = new DataTable();
            var connectionString = new DataSettingsManager().LoadSettings().DataConnectionString;
            //var connectionString = MultisiteHelper.AdminConnectionString;

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                var sqlCommand = GetSqlCommand(sqlCode, report.ReportAttributes, form, sqlConnection); //new SqlCommand(SetSqlStringParams(report, form), sqlConnection);

                using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                {
                    dataTable.Load(sqlDataReader);
                    sqlDataReader.Close();
                }
                sqlConnection.Close();
            }

            return dataTable;
        }

        #endregion
    }
}
