﻿
using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Orders;

namespace Shopfast.Plugin.Misc.Reports.Domain
{

    public class Report : BaseEntity
    {
        private ICollection<ReportAttribute> _reportAttributes;

        public Report()
        {

        }
        
        public string Name { get; set; }
        public string SqlCode { get; set; }
        public string SqlCodeDetail { get; set; }
        public string HtmlCode { get; set; }

        public DateTime CreatedUtc { get; set; }
        
        /// <summary>
        /// Gets or sets the customer roles
        /// </summary>
        public virtual ICollection<ReportAttribute> ReportAttributes
        {
            get { return _reportAttributes ?? (_reportAttributes = new List<ReportAttribute>()); }
            set { _reportAttributes = value; }
        }
    }
}
