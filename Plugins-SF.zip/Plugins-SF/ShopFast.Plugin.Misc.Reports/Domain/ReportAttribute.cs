﻿
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Orders;

namespace Shopfast.Plugin.Misc.Reports.Domain
{

    public class ReportAttribute : BaseEntity
    {
        public ReportAttribute()
        {

        }

        public int ReportId { get; set; }

        public int AttributeTypeId { get; set; }

        public string Name { get; set; }

        public string DefaultValue { get; set; }

        public virtual Report Report { get; set; }
        
        /// <summary>
        /// Gets the attribute control type
        /// </summary>
        [NotMapped]
        public virtual SqlDbType AttributeType
        {
            get
            {
                return (SqlDbType)this.AttributeTypeId;
            }
            set
            {
                this.AttributeTypeId = (int)value;
            }
        }

    }
}
