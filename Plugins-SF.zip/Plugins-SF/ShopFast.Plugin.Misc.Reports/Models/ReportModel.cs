﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Reports.Models
{
    public class ReportModel: BaseNopModel
    {
        public ReportModel()
        {
            ResultValues = new Dictionary<string, string>();
        }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Id")]
        public int ReportId { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Name")]
        public string Name { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.CreatedUtc")]
        public DateTime CreatedUtc { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.SqlCode")]
        public string SqlCode { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.SqlCodeDetail")]
        public string SqlCodeDetail { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.HtmlCode")]
        [AllowHtml]
        public string HtmlCode { get; set; }
    
        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.DateTimeFormatingString")]
        public string DateTimeFormatingString { get; set; }

        public string ReportAttributePrefix { get; set; }

        public IList<ReportAttributeModel> ReportAttributeModels { get; set; }

        public Dictionary<string, string> ResultValues { get; private set; }

        public JsonResult JsonResult { get; set; }


        public bool ReportExist
        {
            get { return ReportId > 0; }
        }

        /// <summary>
        /// Gets or sets result value for generated report
        /// </summary>
        public string this[string key]
        {
            get { return ResultValues[key]; }
            set { ResultValues.Add(key, value); }
        }
    }
}
