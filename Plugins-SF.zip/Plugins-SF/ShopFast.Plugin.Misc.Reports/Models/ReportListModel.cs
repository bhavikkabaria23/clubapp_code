﻿using System;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Reports.Models
{
    public class ReportListModel: BaseNopModel
    {
        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Id")]
        public string ReportId { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Name")]
        public string Name { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.CreatedUtc")]
        public DateTime CreatedUtc { get; set; }
    }
}
