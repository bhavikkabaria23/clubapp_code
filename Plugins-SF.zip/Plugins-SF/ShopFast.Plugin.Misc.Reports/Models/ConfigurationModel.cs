﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Reports.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        //[NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.DateTimeFormatingString")]
        //public string DateTimeFormatingString { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.DbName")]
        public string DbName { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.DbNameHolder")]
        public string DbNameHolder { get; set; }

        public string DefaultDateTimeFromValue { get; set; }

        public string DefaultDateTimeToValue { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.UpdateExistingReports")]
        public bool UpdateExistingReports { get; set; }
    }
}
