﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Reports.Models
{
    public class ReportSearchModel : BaseNopModel
    {
        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Name")]
        public string Name { get; set; }
    }
}
