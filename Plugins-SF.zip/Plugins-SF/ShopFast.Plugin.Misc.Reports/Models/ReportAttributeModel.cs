﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Misc.Reports.Domain;

namespace ShopFast.Plugin.Misc.Reports.Models
{
    public class ReportAttributeModel: BaseNopEntityModel
    {
        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Id")]
        public int ReportId { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.Reports.Name")]
        public string Name { get; set; }

        public int AttributeTypeId { get; set; }
        public string AttributeType { get; set; }

        public string Value { get; set; }

        public string DefaultValue { get; set; }
        
        public bool ReportExist
        {
            get { return ReportId > 0; }
        }
    }
}
