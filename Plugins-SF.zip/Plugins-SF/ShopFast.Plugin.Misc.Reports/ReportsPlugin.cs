﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;
using Shopfast.Plugin.Misc.Reports.Data;
using Shopfast.Plugin.Misc.Reports.Domain;
using Shopfast.Plugin.Misc.Reports.Services;
using ShopFast.Plugin.Misc.Core.Services;
using SiteMapNode = Nop.Web.Framework.Menu.SiteMapNode;

namespace ShopFast.Plugin.Misc.Reports
{
    public class ReportsPlugin: BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        #region Fields

        private readonly ReportsContext _reportsContext;
        private readonly ISettingService _settingService;

        #endregion

        #region Ctor

        public ReportsPlugin(ReportsContext reportsContext, 
            ISettingService settingService)
        {
            _reportsContext = reportsContext;
            _settingService = settingService;
        }

        #endregion

        #region Methods

        public override void Install()
        {
            _reportsContext.Install();

            SetDefaultSettings();
            LoadDefaultReports();
            
            base.Install();
        }

        public override void Uninstall()
        {
            _reportsContext.Uninstall();

            _settingService.DeleteSetting<ReportsPluginSettings>();

            foreach (var localizationPair in GetLocaleResources())
            {
                this.DeletePluginLocaleResource(localizationPair.Key);
            }
            
            base.Uninstall();
        }

        //nop3.7 upgrade begin
        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var urlHelper = new UrlHelper(HttpContext.Current.Request.RequestContext);

            var pluginsNode = rootNode.ChildNodes.First(n => n.Title == "Plugins");
            pluginsNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true,
                Title = "Reports",
                Url = urlHelper.RouteUrl("Shopfast.Plugin.Misc.Reports.List"),
            });

        }
        //nop3.7 upgrade end

        public static void LoadDefaultReports()
        {
            const string sqlPathTemplate = "~/Plugins/ShopFast.Misc.Reports/Reports/{0}.sql";
            const string viewPathTemplate = "~/Plugins/ShopFast.Misc.Reports/Reports/{0}.cshtml";

            var reportSettings = EngineContext.Current.Resolve<ReportsPluginSettings>();
            var reportService = EngineContext.Current.Resolve<IReportService>();

            var reports = new List<Report>
            {
                //Total Sales Summary
                new Report()
                {
                    Name = "Total Sales Summary",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Sales By Server
                new Report()
                {
                    Name = "Sales By Server",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Server Gratuity
                new Report()
                {
                    Name = "Server Pay",
                    SqlCodeDetail = File.ReadAllText(HttpContext.Current.Server
                        .MapPath(string.Format(sqlPathTemplate, "Server Pay - Detail"))),
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Dine-In Server Perfomance
                new Report()
                {
                    Name = "Dine-In Server Perfomance",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Sales By Order Type
                new Report()
                {
                    Name = "Sales By Order Type",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Daily Sales Analysis
                new Report()
                {
                    Name = "Daily Sales Analysis",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Weekly Sales Analysis
                new Report()
                {
                    Name = "Weekly Sales Analysis",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Voids
                new Report()
                {
                    Name = "Voids",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Sales By Hour (Summary)
                new Report()
                {
                    Name = "Sales By Hour (Summary)",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Tax
                new Report()
                {
                    Name = "Tax",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Sales By Hour (Detail)
                new Report()
                {
                    Name = "Sales By Hour (Detail)",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Sales By Menu Item
                new Report()
                {
                    Name = "Sales By Menu Item",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
                //Gift Certificate List
                new Report()
                {
                    Name = "Gift Certificate List",
                    ReportAttributes = new List<ReportAttribute>
                    {
                        new ReportAttribute()
                        {
                            Name = "From",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeFromValue
                        },
                        new ReportAttribute()
                        {
                            Name = "To",
                            AttributeTypeId = (int) SqlDbType.DateTime,
                            DefaultValue = reportSettings.DefaultDateTimeToValue
                        }
                    }
                },
            };

            foreach (var newReport in reports)
            {
                newReport.SqlCode = File.ReadAllText(HttpContext.Current.Server
                    .MapPath(string.Format(sqlPathTemplate, newReport.Name)));
                newReport.HtmlCode = File.ReadAllText(HttpContext.Current.Server
                    .MapPath(string.Format(viewPathTemplate, newReport.Name)));

                var report = reportService.GetReportByName(newReport.Name);
                if (report != null)
                {
                    if (!reportSettings.UpdateExistingReports)
                    {
                        reportService.DeleteReport(report);
                        reportService.InsertReport(newReport);
                        continue;
                    }
                    
                    report.HtmlCode = newReport.HtmlCode;
                    report.SqlCode = newReport.SqlCode;
                    report.SqlCodeDetail = newReport.SqlCodeDetail;
                    reportService.UpdateReport(report);
                }
                else
                {
                    reportService.InsertReport(newReport);
                }

                
            }
        }

        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();

            var defaultSettings = new ReportsPluginSettings()
            {
                DbName = "YOWZA_ciaograzie",
                DbNameHolder = "DB_Name",
                EntityIdHolder = "@EnitityValue",
                DefaultDateTimeFromValue = "01/01/1999",
                DefaultDateTimeToValue = "01/01/2019",
                UpdateExistingReports = true,
                ReportAttributePrefix = "reportattr_"
            };
            settingService.SaveSetting(defaultSettings);

            var reportContext = EngineContext.Current.Resolve<ReportsContext>();
            reportContext.Install();

            foreach (var localeResource in GetLocaleResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localeResource.Key, localeResource.Value);
            }
        }

        private static ICollection<KeyValuePair<string, string>> GetLocaleResources()
        {
            var result = new List<KeyValuePair<string, string>>();

            //result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.", ""));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.List", "Reports"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Report", "Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.ReportAttribute", "Report Attribute"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.ReportAttributes", "Report Attributes"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.AddNew", "Add new Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Id", "Id"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Name", "Name"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.CreatedUtc", "Created On"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.SqlCode", "SQL"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.SqlCodeDetail", "SQL Detail"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.HtmlCode", "HTML5/JavaScript"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.DateTimeFormatingString", "Date Format"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Create", "Create Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Edit", "Edit Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.View", "View Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Save", "Save Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.BackToList", "back to report list"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.SaveSuccess", "Report saved"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.SaveError", "Report not save"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.ReportAttributeType", 
                "Attribute Type"));

            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Generate", "Generate Report"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Result", "Result"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Params", "Report Params"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Print", "Print"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Pdf", "Pdf"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.Excel", "Excel"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.ApplyReportAttributes",
                "Apply Report Attributes"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.DbName", "DataBase Name"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.DbNameHolder", "DataBase Name Holder"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.UpdateExistingReports", 
                "Update existing reports"));
            result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.UpdateExistingReports.Hint",
                "If \"No\" then it will delete old with the same name and insert new"));
            //result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.", ""));
            //result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.", ""));
            //result.Add(new KeyValuePair<string, string>("ShopFast.Plugin.Misc.Reports.", ""));

            //Hints

            return result;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "Reports";
            routeValues = new RouteValueDictionary
            {
                { "Namespaces", "ShopFast.Plugin.Misc.Reports.Controllers" }, 
                { "area", null } 
            };
        }

        #endregion

        public bool Authenticate()
        {
            return true;
        }
    }
}
