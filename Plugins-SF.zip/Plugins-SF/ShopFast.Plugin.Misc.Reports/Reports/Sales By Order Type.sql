﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--results
SELECT CASE WHEN o.ShippingMethod='' THEN  'In Store Orders' ELSE o.ShippingMethod END as [Type],
		SUM(o.OrderSubtotalExclTax) as [SalesAmount],
		SUM(o.OrderTotal) as [SalesTotal],
		SUM(o.OrderTax) as [TaxAmount],
		SUM(o.OrderTotal) / @OrderTotal as [Percentage],
		Count(1) as [Count],
		AVG(o.OrderTotal) as [AvgOrder]
	FROM [dbo].[Order] o
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
	GROUP BY o.ShippingMethod