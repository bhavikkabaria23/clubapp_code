﻿Use [DB_Name];

IF (@from IS NULL OR @from='') BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL OR @to='') BEGIN
	SET @to = GETUTCDATE()
END 

DECLARE @FilterTable TABLE (ID INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o WHERE o.Deleted=0 AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to AND OrderStatusId=30

DECLARE @priceExclTax decimal(18,4)
SET @priceExclTax = (Select SUM(oi.PriceExclTax) FROM [dbo].[OrderItem] oi INNER JOIN @FilterTable o ON oi.OrderId = o.Id)

SELECT p.Id AS [ItemId], p.Name AS [ItemName],
		SUM(oi.PriceExclTax) AS [SalesAmount],
		(SUM(oi.PriceExclTax) / @priceExclTax) as [Percentage],
		COUNT(1) AS [Count]
	FROM @FilterTable o
	INNER JOIN [dbo].[OrderItem] oi 
		ON oi.OrderId = o.Id
	INNER JOIN [dbo].[Product] p 
		ON oi.ProductId = p.Id
	GROUP BY p.Id, p.Name
	ORDER BY p.Name;