﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND o.OrderStatusId=30
		
--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

-- results
SELECT DATEPART(wk, o.CreatedOnUtc) AS [WeekNumber],
        DATEADD(dd, -(DATEPART(dw, Min(o.CreatedOnUtc))-1), Min(o.CreatedOnUtc)) [WeekStart],
        DATEADD(dd, 7-(DATEPART(dw, Min(o.CreatedOnUtc))), Min(o.CreatedOnUtc)) [WeekEnd],
        year(o.CreatedOnUtc) AS [Year],
        SUM(o.OrderSubtotalExclTax) AS [NetTotal],
        SUM(o.OrderTax) AS [TaxTotal],
        SUM(o.OrderTotal) AS [TtlTotal],
        SUM(o.OrderTotal) / @OrderTotal as [Percentage],
        AVG(o.OrderTotal) as [AvgOrder],
        Min(o.OrderTotal) as [MinOrder],
        Max(o.OrderTotal) as [MaxOrder],
        COUNT(1) AS [Count]
    FROM  [dbo].[Order] o
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
    GROUP BY DATEPART(wk, o.CreatedOnUtc), year(o.CreatedOnUtc)
    ORDER BY year(o.CreatedOnUtc), DATEPART(wk, o.CreatedOnUtc) ASC;
