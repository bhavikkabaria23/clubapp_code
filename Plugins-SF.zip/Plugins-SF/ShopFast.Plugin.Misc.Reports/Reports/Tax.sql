﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30
		
--results
SELECT p.[TaxCategoryId], CASE WHEN tc.Name is null THEN 'Non Taxable Sales' ELSE tc.Name END as Tax, SUM(oi.PriceExclTax) as PriceExclTax, SUM(oi.PriceInclTax) as PriceInclTax, 
	SUM(CASE WHEN  p.[IsTaxExempt]=1 THEN  oi.PriceInclTax ELSE 0 END) as TaxExemptSales, SUM(CASE WHEN tc.Name is not null THEN oi.PriceInclTax ELSE 0 END) as TaxableSales
FROM [dbo].[OrderItem] oi
	INNER JOIN [dbo].[Product] p on p.id = oi.ProductId
	INNER JOIN [dbo].[Order] o ON o.id=oi.OrderId
	INNER JOIN @FilterTable ft ON o.Id = ft.Id	
	LEFT JOIN TaxCategory tc on tc.Id = p.TaxCategoryId
GROUP BY p.[TaxCategoryId], tc.Name