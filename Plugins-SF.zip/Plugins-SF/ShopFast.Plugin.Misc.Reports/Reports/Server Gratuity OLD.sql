﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT (CASE WHEN ct.CustomerId IS NOT NULL THEN ct.CustomerId ELSE '-' END) as [CustomerId], 
		ct.CustomerEmail as [CustomerEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [CustomerFullName],
		(CASE WHEN SUM(o.OrderTotal) IS NOT NULL THEN SUM(o.OrderTotal) ELSE 0 END) as [Total],
		(CASE WHEN SUM(rot.TipAmount) IS NOT NULL THEN SUM(rot.TipAmount) ELSE 0 END) as [PosRecordedTips], 
		(CASE WHEN (SUM(rot.TipAmount) / SUM(o.OrderTotal)) IS NOT NULL THEN (SUM(rot.TipAmount) / SUM(o.OrderTotal)) ELSE 0 END) as [PosRecordedTipsPercentage],
		(CASE WHEN SUM(rop.TipAmount) IS NOT NULL THEN SUM(rop.TipAmount) ELSE 0 END) as [ReportedTips], 
		(CASE WHEN (SUM(rop.TipAmount) / SUM(o.OrderTotal)) IS NOT NULL THEN (SUM(rop.TipAmount) / SUM(o.OrderTotal)) ELSE 0 END) as [ReportedTipsPercentage]
	FROM [Order] o 
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId
		LEFT JOIN [RestaurantOrderTip] rot ON rot.OrderId = o.Id
		LEFT JOIN [RestaurantOrderPayment] rop ON rop.OrderId = o.Id
	GROUP BY ct.CustomerId, ct.CustomerEmail, ct.FirstName, ct.LastName;