﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

DECLARE @EnitityId INT;
SET @EnitityId = (CASE WHEN @EnitityValue > 0 THEN @EnitityValue ELSE NULL END);

--filtertable
DECLARE @FilterTable TABLE (Id INT, SubTotal DECIMAL(18, 4), CashTips DECIMAL(18, 4), CardTips DECIMAL(18, 4), GrandTotal DECIMAL(18, 4))
IF @EnitityId IS NOT NULL 
BEGIN
	INSERT  INTO @FilterTable
		SELECT o.ID, o.OrderTotal,--OrderSubtotalInclTax, 
				(SELECT SUM(rot.TipAmount) FROM [dbo].[RestaurantOrderTip] rot 
					WHERE rot.OrderId = o.Id), 
				(SELECT SUM(rop.TipAmount) FROM [dbo].[RestaurantOrderPayment] rop 
					WHERE rop.OrderId = o.Id),
				0
		FROM [dbo].[Order] o
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
		WHERE o.Deleted=0 
			AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
			AND OrderStatusId=30
			AND c.Id = @EnitityId;
END
ELSE
BEGIN
	INSERT  INTO @FilterTable
		SELECT o.ID, OrderSubtotalInclTax, 
				(SELECT SUM(rot.TipAmount) FROM [dbo].[RestaurantOrderTip] rot 
					WHERE rot.OrderId = o.Id), 
				(SELECT SUM(rop.TipAmount) FROM [dbo].[RestaurantOrderPayment] rop 
					WHERE rop.OrderId = o.Id),
				0
		FROM [dbo].[Order] o
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
		WHERE o.Deleted=0 
			AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
			AND OrderStatusId=30
			AND c.Id IS NULL;
END

UPDATE @FilterTable SET CashTips = 0 WHERE CashTips IS NULL
UPDATE @FilterTable SET CardTips = 0 WHERE CardTips IS NULL 
UPDATE @FilterTable SET GrandTotal = SubTotal + CashTips + CardTips;

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT (CASE WHEN ct.CustomerId IS NOT NULL THEN ct.CustomerId ELSE '-' END) as [CustomerId], 
		ct.CustomerEmail as [CustomerEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [CustomerFullName],
		CONCAT((CASE WHEN ct.CustomerId IS NOT NULL THEN CONCAT(ct.CustomerId, ': ') ELSE '- ' END), CONCAT(ct.FirstName, ' ', ct.LastName)) as [Customer],
		o.Id as [OrderId],
		ft.SubTotal as [SubTotal],
		ft.GrandTotal as [Total],
		ft.CashTips as [PosRecordedTips], 
		(CASE WHEN ft.GrandTotal > 0 AND ft.CashTips IS NOT NULL THEN (ft.CashTips / ft.GrandTotal) ELSE 0 END) as [PosRecordedTipsPercentage],
		ft.CardTips [ReportedTips],
		(CASE WHEN ft.GrandTotal > 0 AND SUM(ft.CardTips) IS NOT NULL THEN (ft.CardTips / ft.GrandTotal) ELSE 0 END) as [ReportedTipsPercentage]
	FROM [Order] o 
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId
	GROUP BY ct.CustomerId, ct.CustomerEmail, ct.FirstName, ct.LastName, o.Id, ft.SubTotal, ft.GrandTotal, ft.CashTips, ft.CardTips
	ORDER BY ct.CustomerId, o.Id;
