﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT, SubTotal DECIMAL(18, 4), CashTips DECIMAL(18, 4), CardTips DECIMAL(18, 4), GrandTotal DECIMAL(18, 4))
INSERT  INTO @FilterTable
SELECT ID, o.OrderTotal,--OrderSubtotalInclTax, 
		(SELECT SUM(rot.TipAmount) FROM [dbo].[RestaurantOrderTip] rot 
			WHERE rot.OrderId = o.Id), 
		(SELECT SUM(rop.TipAmount) FROM [dbo].[RestaurantOrderPayment] rop 
			WHERE rop.OrderId = o.Id),
		0
	FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

UPDATE @FilterTable SET CashTips = 0 WHERE CashTips IS NULL
UPDATE @FilterTable SET CardTips = 0 WHERE CardTips IS NULL 
UPDATE @FilterTable SET GrandTotal = SubTotal + CashTips + CardTips;

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

-- calculate attendance payment
DECLARE @WaiterRatesTable TABLE ([WaiterRatesId] INT, [WaiterId] INT, [FirstDayOfWeek] INT, [HourlyRate] decimal(18,4), [HourCount] INT, [OvertimeRate] decimal(18,4), 
	[BonusRate] decimal(18,4), [HourlyHours] decimal(18,4), [OvertimeHours] decimal(18,4), [AttendancePay] decimal(18,4))
INSERT  INTO @WaiterRatesTable
	([WaiterRatesId], [WaiterId],[FirstDayOfWeek], [HourlyRate], [HourCount], [OvertimeRate], [BonusRate], [HourlyHours], [OvertimeHours], [AttendancePay])
	SELECT * FROM(SELECT  MIN(wwr.[Id]) AS [WaiterRatesId], ct.[CustomerId] as [WaiterId], 
		7 AS [FirstDayOfWeek],
		0 AS [HourlyRate], 0 AS [HourCount],
		0 AS [OvertimeRate], 0 AS [BonusRate], 0 AS [HourlyHours], 0 AS [OvertimeHours], 0 AS [AttendancePay]
	FROM @CustomerTable ct
	LEFT JOIN [dbo].[ShopFast_TimeAndAttendance_WaiterWorkingRates] wwr 
		ON ct.[CustomerId] = wwr.WaiterId
	GROUP BY ct.[CustomerId]
) as waiterRates 

UPDATE @WaiterRatesTable 
	SET [FirstDayOfWeek] = wwr.[FirstDayOfWeek], [HourlyRate] = wwr.[HourlyRate], [HourCount] = wwr.HourCount, 
	[OvertimeRate] = wwr.OvertimeRate, [BonusRate] = wwr.[BonusRate]
	FROM @WaiterRatesTable wrt
	INNER JOIN [dbo].[ShopFast_TimeAndAttendance_WaiterWorkingRates] wwr ON wwr.[Id] = wrt.[WaiterRatesId]
	WHERE wrt.[WaiterRatesId] IS NOT NULL;

SET DATEFIRST 1;

DECLARE @WaiterWorkingWeekTableTemp TABLE ([WaiterId] INT, [WeekStart] datetime, [TotalSeconds] decimal(18,4), 
	[HourlyHours] decimal(18,4), [OvertimeHours] decimal(18,4), [AttendancePay] decimal(18,4))
INSERT  INTO @WaiterWorkingWeekTableTemp
	([WaiterId], [WeekStart], [TotalSeconds], [HourlyHours], [OvertimeHours], [AttendancePay])
	SELECT
		wwtr.[WaiterId],
		CONVERT(date, DATEADD(day, -(datepart(weekday, [StartTimeUtc]) + 7 - datepart(weekday, wrt.[FirstDayOfWeek] - 1)), [StartTimeUtc])) AS [WeekStart],
		--DATEADD(week, DATEDIFF(week, 0, [StartTimeUtc]), 0) AS [WeekStart],
		--SUM(DATEDIFF(second, [StartTimeUtc], [EndTimeUtc])) AS [TotalHours],
		SUM(DATEDIFF(second, StartTimeUtc, EndTimeUtc) - DATEDIFF(day, StartTimeUtc, EndTimeUtc) * 60 * 60 * 24) AS [TotalSeconds],
		0, 0, 0
	FROM [dbo].[ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord] wwtr
	INNER JOIN @WaiterRatesTable wrt ON wwtr.[WaiterId] = wrt.[WaiterId]
	WHERE [EndTimeUtc] IS NOT NULL
		AND datepart(weekday, [StartTimeUtc]) < datepart(weekday, wrt.[FirstDayOfWeek] - 1) 
		AND [StartTimeUtc] >= @from AND [StartTimeUtc] <= @to 
	GROUP BY wwtr.WaiterId, CONVERT(date, DATEADD(day, -(datepart(weekday, [StartTimeUtc]) + 7 - datepart(weekday, wrt.[FirstDayOfWeek] - 1)), [StartTimeUtc]))

INSERT  INTO @WaiterWorkingWeekTableTemp
	([WaiterId], [WeekStart], [TotalSeconds], [HourlyHours], [OvertimeHours], [AttendancePay])
	SELECT
		wwtr.[WaiterId],
		CONVERT(date, DATEADD(day, -(datepart(weekday, [StartTimeUtc]) - datepart(weekday, wrt.[FirstDayOfWeek] - 1)), [StartTimeUtc])) AS [WeekStart],
		--DATEADD(week, DATEDIFF(week, 0, [StartTimeUtc]), 0) AS [WeekStart],
		--SUM(DATEDIFF(second, [StartTimeUtc], [EndTimeUtc])) AS [TotalHours],
		SUM(DATEDIFF(second, StartTimeUtc, EndTimeUtc) - DATEDIFF(day, StartTimeUtc, EndTimeUtc) * 60 * 60 * 24) AS [TotalSeconds],
		0, 0, 0
	FROM [dbo].[ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord] wwtr
	INNER JOIN @WaiterRatesTable wrt ON wwtr.[WaiterId] = wrt.[WaiterId]
	WHERE [EndTimeUtc] IS NOT NULL
		AND datepart(weekday, [StartTimeUtc]) >= datepart(weekday, wrt.[FirstDayOfWeek] - 1) 
		AND [StartTimeUtc] >= @from AND [StartTimeUtc] <= @to 
	GROUP BY wwtr.WaiterId, CONVERT(date, DATEADD(day, -(datepart(weekday, [StartTimeUtc]) - datepart(weekday, wrt.[FirstDayOfWeek] - 1)), [StartTimeUtc]))

DECLARE @WaiterWorkingWeekTable TABLE ([WaiterId] INT, [WeekStart] datetime, [TotalSeconds] decimal(18,4), 
	[HourlyHours] decimal(18,4), [OvertimeHours] decimal(18,4), [AttendancePay] decimal(18,4))
INSERT  INTO @WaiterWorkingWeekTable
	([WaiterId], [WeekStart], [TotalSeconds], [HourlyHours], [OvertimeHours], [AttendancePay])
	SELECT
		[WaiterId], [WeekStart], SUM([TotalSeconds]), SUM([HourlyHours]), SUM([OvertimeHours]), SUM([AttendancePay])
	FROM @WaiterWorkingWeekTableTemp wwwtt
	GROUP BY [WaiterId], [WeekStart]

UPDATE @WaiterWorkingWeekTable 
	SET [HourlyHours] = wwwt.[TotalSeconds] / 3600
	FROM @WaiterWorkingWeekTable wwwt
	INNER JOIN @WaiterRatesTable wrt ON wwwt.WaiterId = wrt.WaiterId
	WHERE [TotalSeconds] <= wrt.HourCount* 3600;

UPDATE @WaiterWorkingWeekTable 
	SET [HourlyHours] = wrt.HourCount, [OvertimeHours] = [TotalSeconds] / 3600 - wrt.HourCount
	FROM @WaiterWorkingWeekTable wwwt
	INNER JOIN @WaiterRatesTable wrt ON wwwt.WaiterId = wrt.WaiterId
	WHERE [TotalSeconds] > wrt.HourCount * 3600;
	
UPDATE @WaiterWorkingWeekTable
	SET [AttendancePay] = wwwt.[HourlyHours] * wrt.[HourlyRate] + wwwt.[OvertimeHours] * wrt.[OvertimeRate]
	FROM @WaiterWorkingWeekTable wwwt
	INNER JOIN @WaiterRatesTable wrt ON wwwt.WaiterId = wrt.WaiterId;

UPDATE @WaiterRatesTable
	SET 
		[AttendancePay] = BonusRate + (SELECT SUM(wwwt.AttendancePay) FROM @WaiterWorkingWeekTable wwwt WHERE wrt.WaiterId = wwwt.WaiterId),
		[HourlyHours] = (SELECT SUM(wwwt.HourlyHours) FROM @WaiterWorkingWeekTable wwwt WHERE wrt.WaiterId = wwwt.WaiterId),
		[OvertimeHours] = (SELECT SUM(wwwt.OvertimeHours) FROM @WaiterWorkingWeekTable wwwt WHERE wrt.WaiterId = wwwt.WaiterId)
	FROM @WaiterRatesTable wrt;

UPDATE @WaiterRatesTable SET [HourlyHours] = 0 WHERE [HourlyHours] IS NULL
UPDATE @WaiterRatesTable SET [OvertimeHours] = 0 WHERE [OvertimeHours] IS NULL
UPDATE @WaiterRatesTable SET [AttendancePay] = 0 WHERE [AttendancePay] IS NULL

--results
SELECT (CASE WHEN ct.CustomerId IS NOT NULL THEN ct.CustomerId ELSE '-' END) as [CustomerId], 
		ct.CustomerEmail as [CustomerEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [CustomerFullName],
		--CONCAT((CASE WHEN ct.CustomerId IS NOT NULL THEN CONCAT(ct.CustomerId, ': ') ELSE '- ' END), CONCAT(ct.FirstName, ' ', ct.LastName)) as [Customer],
		SUM(ft.SubTotal) as [SubTotal],
		SUM(ft.GrandTotal) as [Total],
		SUM(ft.CashTips) as [PosRecordedTips], 
		(CASE WHEN SUM(ft.GrandTotal) > 0 AND SUM(ft.CashTips) IS NOT NULL THEN (SUM(ft.CashTips) / SUM(ft.GrandTotal)) ELSE 0 END) as [PosRecordedTipsPercentage],
		SUM(ft.CardTips) [ReportedTips],
		(CASE WHEN SUM(ft.GrandTotal) > 0 AND SUM(ft.CardTips) IS NOT NULL THEN (SUM(ft.CardTips) / SUM(ft.GrandTotal)) ELSE 0 END) as [ReportedTipsPercentage],
		--SUM(wwwt.AttendancePay) as [AttendancePay]
		convert(varchar, right ('00' + ltrim(str(FLOOR(MIN(wrt.[HourlyHours])))), 2)) + ':' + convert(varchar, right ('00' + ltrim(str(FLOOR((MIN(wrt.[HourlyHours]) - FLOOR(MIN(wrt.[HourlyHours]))) * 60))), 2)) as [StandardHours],
		--convert(varchar, FLOOR(MIN(wrt.[HourlyHours]))) + ':' + convert(varchar, FLOOR((MIN(wrt.[HourlyHours]) - FLOOR(MIN(wrt.[HourlyHours]))) * 60)) as [StandardHours],
		convert(varchar, right ('00' + ltrim(str(FLOOR(MIN(wrt.[OvertimeHours])))), 2)) + ':' + convert(varchar, right ('00' + ltrim(str(FLOOR((MIN(wrt.[OvertimeHours]) - FLOOR(MIN(wrt.[OvertimeHours]))) * 60))), 2)) as [OvertimeHours],
		--convert(varchar, FLOOR(MIN(wrt.[OvertimeHours]))) + ':' + convert(varchar, FLOOR((MIN(wrt.[OvertimeHours]) - FLOOR(MIN(wrt.[OvertimeHours]))) * 60)) as [OvertimeHours],
		convert(varchar, right ('00' + ltrim(str(FLOOR(MIN(wrt.[HourlyHours]) + MIN(wrt.[OvertimeHours])))), 2)) + ':' + convert(varchar, right ('00' + ltrim(str(FLOOR((MIN(wrt.[HourlyHours]) + MIN(wrt.[OvertimeHours]) - FLOOR(MIN(wrt.[HourlyHours]) + MIN(wrt.[OvertimeHours]))) * 60))), 2)) as [TotalHours],
		--MIN(ISNULL(wrt.[HourlyHours], 0)) + MIN(ISNULL(wrt.[OvertimeHours], 0)) as [TotalHours],
		MIN(ISNULL(wrt.[AttendancePay], 0)) as [AttendancePay]
	FROM [Order] o 
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId
		LEFT JOIN @WaiterRatesTable wrt ON wrt.WaiterId = ct.CustomerId
		LEFT JOIN @WaiterWorkingWeekTable wwwt ON wwwt.WaiterId = ct.CustomerId
	GROUP BY ct.CustomerId, ct.CustomerEmail, ct.FirstName, ct.LastName
	ORDER BY ct.CustomerId;