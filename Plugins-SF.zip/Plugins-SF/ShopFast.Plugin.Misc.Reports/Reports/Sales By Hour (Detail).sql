﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--results
SELECT Min(o.CreatedOnUtc) as [MinDate],
		(CASE WHEN p.Name IS NOT NULL THEN p.Name ELSE '-' END) AS [Item],
		DATEPART(hh, o.CreatedOnUtc) as [Hour],
		SUM(o.OrderSubtotalExclTax) as [SalesAmount],
		SUM(o.OrderTax) as [TaxAmount],
		SUM(o.OrderTotal) as [TotalAmount],
		SUM(o.OrderTotal) / @OrderTotal as [Percentage],
		COUNT(1) as [Count],
		AVG(o.OrderTotal) as [AvgOrder]
	FROM [dbo].[Order] o
	INNER JOIN @FilterTable ft 
		ON o.Id = ft.Id	
	LEFT JOIN [dbo].[OrderItem] oi 
		ON oi.OrderId = o.Id
	LEFT JOIN [dbo].[Product] p 
		ON oi.ProductId = p.Id
	GROUP BY DATEPART(hh, o.CreatedOnUtc), p.Name
	ORDER BY DATEPART(hh, o.CreatedOnUtc), p.Name;