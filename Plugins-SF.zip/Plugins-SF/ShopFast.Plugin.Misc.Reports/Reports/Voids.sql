﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND o.OrderStatusId=30
		AND o.PaymentStatusId = 50 -- voided
		
--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT o.Id as [OrderId], 
		o.CreatedOnUtc as [CreatedOnUtc], 
		o.PaymentMethodSystemName as [PaymentMethod],
		p.Name as [ProductName],
		N'VOIDED' as [PaymentStatus],
		ro.WaiterId as [WaiterId],
		ct.CustomerEmail as [WaiterEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [WaiterFullName],
		o.OrderTotal as [Amount]
	FROM [dbo].[Order] o
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [dbo].[OrderItem] oi ON oi.OrderId= o.Id
		LEFT JOIN [dbo].[Product] p ON p.Id= oi.ProductId
		LEFT JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId= o.Id
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId