﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o WHERE o.Deleted=0
	AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
	AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

SELECT CONVERT(date, o.CreatedOnUtc) AS [Date],
        SUM(o.OrderSubtotalExclTax) AS [NetTotal],
        SUM(o.OrderTax) AS [TaxTotal],
        SUM(o.OrderTotal) AS [TtlTotal],
        SUM(o.OrderTotal) / @OrderTotal as [Percentage],
        COUNT(1) AS [Count],
        AVG(o.OrderTotal) as [AvgOrder],
        Min(o.OrderTotal) as [MinOrder],
        Max(o.OrderTotal) as [MaxOrder]
    FROM [dbo].[Order] o
		INNER JOIN @FilterTable ft ON o.Id = ft.Id
    GROUP BY CONVERT(date, o.CreatedOnUtc)
    ORDER BY CONVERT(date, o.CreatedOnUtc) ASC;
