﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--voided
DECLARE @VoidedTable TABLE (Id INT, OrderSubtotalExclTax DECIMAL(18,4))
INSERT  INTO @VoidedTable
SELECT ID, OrderSubtotalExclTax FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30
		AND o.PaymentStatusId = 50 --voided
		
--results
SELECT [Group], DisplayOrder, Name, SUM([Amount]) as [Amount], SUM([Count]) as [Count], SUM([RefundedAmount]) as [RefundedAmount], SUM([OrderDiscount]) as [OrderDiscount], SUM([OrderTax]) as [OrderTax]
		, (CASE WHEN SUM([VoidAmount]) IS NOT NULL THEN SUM([VoidAmount]) ELSE 0 END) as [VoidAmount] 
	FROM (
	SELECT '01 Payment Method System Name' as [Group],0 as DisplayOrder, case when [PaymentMethodSystemName] is null then '-' when [PaymentMethodSystemName]='' then '-' else [PaymentMethodSystemName] end as Name, SUM([OrderTotal]) as [Amount], COUNT(1) as [Count], SUM([RefundedAmount]) as [RefundedAmount], SUM([OrderDiscount]) as [OrderDiscount], SUM([OrderTax]) as [OrderTax], SUM(vt.OrderSubtotalExclTax) as [VoidAmount]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id	
			LEFT JOIN @VoidedTable vt ON o.Id = vt.Id	
		GROUP BY [PaymentMethodSystemName]
	UNION
	SELECT '02 Card Type' as [Group],1 as DisplayOrder, case when [CardType] = 'xGAVh3zER4PXXGeB2dMzlQ==' then 'Visa' when [CardType] = 'm22BxK36lV2IKN8Is/9Eyw==' then 'MasterCard'  when [CardType] = 'kCr6xKI3PYOaRHBgl/B4cA==' then 'American Express' when [CardType] is null then '-' when [CardType]='' then '-' else [CardType] end as Name, SUM([OrderTotal]) as [Amount], COUNT(1) as [Count], SUM([RefundedAmount]) as [RefundedAmount], SUM([OrderDiscount]) as [OrderDiscount], SUM([OrderTax]) as [OrderTax], SUM(vt.OrderSubtotalExclTax) as [VoidAmount]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id		
			LEFT JOIN @VoidedTable vt ON o.Id = vt.Id	
		GROUP BY [CardType]
    ) as temp
    GROUP BY [Group],[Name],DisplayOrder
    ORDER BY DisplayOrder