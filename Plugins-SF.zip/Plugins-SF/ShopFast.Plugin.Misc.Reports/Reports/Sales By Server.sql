﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o WHERE o.Deleted=0 AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT c.[Id] as [CustomerId],
		CASE 
			WHEN ct.FirstName IS NOT NULL AND ct.LastName IS NOT NULL THEN CONCAT(ct.FirstName,' ',ct.LastName) 
			WHEN ct.FirstName IS NOT NULL AND c.[Email] IS NOT NULL THEN ct.FirstName
			WHEN ct.LastName IS NOT NULL AND c.[Email] IS NOT NULL THEN ct.LastName
		END as [Customer],
        Sum(o.OrderTotal) as [Total],
        Sum(o.OrderTax) as [TaxTotal],
        Sum(o.OrderTotal) / @OrderTotal as [Percentage],
        Count(1) as [Count],
        AVG(o.OrderTotal) as [AvgOrderTotal]
FROM [dbo].[Order] o 
	INNER JOIN @FilterTable ft ON o.Id = ft.Id	
	LEFT JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = ft.Id	
	LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	LEFT JOIN @CustomerTable ct ON ct.CustomerId = c.Id	
GROUP BY c.[Id], c.[Email], ct.FirstName, ct.LastName;