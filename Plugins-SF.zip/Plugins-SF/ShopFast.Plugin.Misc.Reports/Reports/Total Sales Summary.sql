﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--voided
DECLARE @VoidedTable TABLE (Id INT, OrderTotal DECIMAL(18,4))
INSERT  INTO @VoidedTable
SELECT ID, OrderTotal FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30
		AND o.PaymentStatusId = 50 --voided
		
--results
SELECT [Group], DisplayOrderGroup, DisplayOrder, Name, (CASE WHEN SUM([Amount]) IS NOT NULL THEN SUM([Amount]) ELSE 0 END) as [Amount], SUM([Count]) as [Count]
		, (SELECT SUM(tempo.OrderTotal) FROM [dbo].[Order] tempo INNER JOIN @FilterTable ft ON tempo.Id = ft.Id) as [TotalAmount]
	FROM (
	SELECT 'Total Cash & Check' as [Group], 
			0 as DisplayOrderGroup, 
			0 as DisplayOrder, 
			N'Total Cash Sales' as Name, 
			SUM(o.OrderTotal) as [Amount], 
			COUNT(0) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
		WHERE o.PaymentMethodSystemName != N'Payments.CheckMoneyOrder'
			AND o.CardType = ''
	UNION
	SELECT 'Total Cash & Check' as [Group], 
			0 as DisplayOrderGroup, 
			1 as DisplayOrder, 
			N'Total Check Sales' as Name, 
			SUM(o.OrderTotal) as [Amount], 
			COUNT(0) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
		WHERE o.PaymentMethodSystemName = 'Payments.CheckMoneyOrder'
	UNION
	SELECT 'Card Type' as [Group], 
			1 as DisplayOrderGroup, 
			1 as DisplayOrder, 
			N'Visa' as Name, 
			SUM(OrderTotal) as [Amount], 
			COUNT(1) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
			WHERE o.[CardType] = 'xGAVh3zER4PXXGeB2dMzlQ=='
	UNION
	SELECT 'Card Type' as [Group], 
			1 as DisplayOrderGroup, 
			2 as DisplayOrder, 
			N'MasterCard' as Name, 
			SUM([OrderSubtotalExclTax]) as [Amount], 
			COUNT(1) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
			WHERE o.[CardType] = 'm22BxK36lV2IKN8Is/9Eyw=='
	UNION
	SELECT 'Card Type' as [Group], 
			1 as DisplayOrderGroup, 
			3 as DisplayOrder, 
			N'Discover' as Name, 
			SUM(OrderTotal) as [Amount], 
			COUNT(1) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
			WHERE o.[CardType] = 'Discover'
	UNION
	SELECT 'Card Type' as [Group], 
			1 as DisplayOrderGroup, 
			4 as DisplayOrder, 
			N'American Express' as Name, 
			SUM(OrderTotal) as [Amount], 
			COUNT(1) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
			WHERE o.[CardType] = 'kCr6xKI3PYOaRHBgl/B4cA=='
	UNION
	SELECT 'Card Type' as [Group], 
			1 as DisplayOrderGroup, 
			5 as DisplayOrder, 
			N'Gift Cards' as Name, 
			SUM(OrderTotal) as [Amount], 
			COUNT(1) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
			WHERE o.[CardType] = 'Gift CArds'
	UNION
	SELECT 'Taxes' as [Group], 
			2 as DisplayOrderGroup, 
			0 as DisplayOrder, 
			(CASE WHEN tc.Name IS NOT NULL THEN tc.Name ELSE '-' END) as Name, 
			(SUM(oi.PriceInclTax) - SUM(oi.PriceExclTax)) as [Amount], 
			COUNT(o.Id) as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id	
			INNER JOIN [dbo].[OrderItem] oi ON oi.OrderId = o.Id
			INNER JOIN [dbo].[Product] p on p.id = oi.ProductId
			LEFT JOIN TaxCategory tc on tc.Id = p.TaxCategoryId
		GROUP BY p.[TaxCategoryId], tc.Name
	UNION
	SELECT 'Totals' as [Group], 
			3 as DisplayOrderGroup, 
			1 as DisplayOrder, 
			N'Refunded Amount' as Name, 
			SUM([RefundedAmount]) as [Amount], 
			0 as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
	UNION
	SELECT 'Totals' as [Group], 
			3 as DisplayOrderGroup, 
			2 as DisplayOrder, 
			N'Total Voids' as Name, 
			SUM(o.OrderTotal) as [Amount], 
			0 as [Count]
		FROM [dbo].[Order] o	
			INNER JOIN @VoidedTable vt ON o.Id = vt.Id
	UNION
	SELECT 'Totals' as [Group], 
			3 as DisplayOrderGroup, 
			3 as DisplayOrder, 
			N'Order Discount' as Name, 
			SUM([OrderDiscount]) as [Amount], 
			0 as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
	UNION
	SELECT 'Totals' as [Group], 
			3 as DisplayOrderGroup, 
			4 as DisplayOrder, 
			N'Order Tax' as Name, 
			SUM([OrderTax]) as [Amount], 
			0 as [Count]
		FROM [dbo].[Order] o
			INNER JOIN @FilterTable ft ON o.Id = ft.Id
    ) as temp
    GROUP BY [Group], [Name], DisplayOrderGroup, DisplayOrder
    ORDER BY DisplayOrderGroup, DisplayOrder