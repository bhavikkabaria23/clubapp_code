﻿Use [DB_Name];

IF (@from IS NULL) BEGIN
	SET @from = DATEADD(YEAR, -1, GETUTCDATE());
END 
IF (@to IS NULL) BEGIN
	SET @to = GETUTCDATE()
END 

SELECT	GiftCards.[AttributesXml].query('/Attributes/GiftCardInfo/RecipientName/text()') as RecipientName
		,GiftCards.[AttributesXml].query('/Attributes/GiftCardInfo/RecipientEmail/text()') as RecipientEmail
		,GiftCards.[AttributesXml].query('/Attributes/GiftCardInfo/SenderName/text()') as SenderName
		,GiftCards.[AttributesXml].query('/Attributes/GiftCardInfo/SenderEmail/text()') as SenderEmail
		,GiftCards.[AttributesXml].query('/Attributes/GiftCardInfo/Message/text()') as [Message]
		,o.CreatedOnUtc
		,c.Email + '"'+c.Username + '"' as AuthBy
	FROM (
		SELECT [OrderId]
				,CAST([AttributesXml] AS XML) as [AttributesXml]
			FROM [dbo].[OrderItem] tmpoi
			INNER JOIN [dbo].[Order] tmpo ON tmpo.Id= tmpoi.OrderId
			WHERE AttributesXml is not null AND AttributesXml<>'' AND CAST([AttributesXml] AS XML).exist('/Attributes/GiftCardInfo')=1
				AND tmpo.[Deleted]=0
				AND tmpo.CreatedOnUtc >= @from AND tmpo.CreatedOnUtc <= @to
				AND OrderStatusId=30
		) as GiftCards 
	INNER JOIN [dbo].[Order] o ON o.Id= GiftCards.OrderId
	LEFT JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId= GiftCards.OrderId
	LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	WHERE o.[Deleted]=0 
		AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to
		AND OrderStatusId=30;