﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace ShopFast.Plugin.Misc.Reports
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Shopfast.Plugin.Misc.Reports.DefaultSettings",
                 "Plugin/Report/SetDefaultSettings",
                 new { controller = "Reports", action = "DefaultSettings" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.DefaultReports",
                 "Plugin/Report/DefaultReports",
                 new { controller = "Reports", action = "DefaultReports" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            #region Reports

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.List",
                 "Plugin/Report/List",
                 new { controller = "Reports", action = "List" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.ReportList",
                 "Plugin/Report/ReportList",
                 new { controller = "Reports", action = "ReportList" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Create",
                 "Plugin/Report/Create",
                 new { controller = "Reports", action = "Create" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.View",
                 "Plugin/Report/View/{id}",
                 new { controller = "Reports", action = "View", id = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Export",
                 "Plugin/Report/Export",
                 new { controller = "Reports", action = "Export", id = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Edit",
                 "Plugin/Report/Edit/{id}",
                 new { controller = "Reports", action = "Edit", id = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");
            
            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Delete",
                 "Plugin/Report/Delete/{id}",
                 new { controller = "Reports", action = "Delete", id = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Generate",
                 "Plugin/Report/Generate",
                 new { controller = "Reports", action = "Generate" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.AjaxGenerateReport",
                 "Plugin/Report/Ajax/AjaxGetReportData",
                 new { controller = "Reports", action = "AjaxGetReportData" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.AjaxGenerateReportDetail",
                 "Plugin/Report/Ajax/AjaxGetReportDataDetail",
                 new { controller = "Reports", action = "AjaxGetReportDataDetail" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            #endregion

            #region Report Attributes

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.ReportAttributeList",
                 "Plugin/Report/ReportAttributeList",
                 new { controller = "Reports", action = "ReportAttributeList" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.CreateReportAttribute",
                 "Plugin/Report/CreateReportAttribute",
                 new { controller = "Reports", action = "CreateReportAttribute" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.UpdateReportAttribute",
                 "Plugin/Report/UpdateReportAttribute",
                 new { controller = "Reports", action = "UpdateReportAttribute" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.DeleteReportAttribute",
                 "Plugin/Report/DeleteReportAttribute",
                 new { controller = "Reports", action = "DeleteReportAttribute" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            #endregion

            #region Print/PDf/Excel

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.GetPdf",
                 "Plugin/Report/GetPdf",
                 new { controller = "Reports", action = "GetPdf" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            #endregion

            //TestPage
            routes.MapRoute("Shopfast.Plugin.Misc.Reports.Test",
                "Plugin/Report/Test",
                new { controller = "Reports", action = "TestPage" },
                new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.AjaxGetTestReportData",
                 "Plugin/Report/Ajax/AjaxGetTestReportData",
                 new { controller = "Reports", action = "AjaxGetTestReportData" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("Shopfast.Plugin.Misc.Reports.AjaxGetTestReportDataDetail",
                 "Plugin/Report/Ajax/AjaxGetTestReportDataDetail",
                 new { controller = "Reports", action = "AjaxGetTestReportDataDetail" },
                 new[] { "ShopFast.Plugin.Misc.Reports.Controllers" }).DataTokens.Add("area", "admin");
        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
