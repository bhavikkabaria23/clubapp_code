﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Security;
using Shopfast.Plugin.Misc.Reports.Data;
using Shopfast.Plugin.Misc.Reports.Domain;
using Shopfast.Plugin.Misc.Reports.Services;
using ShopFast.Plugin.Misc.Reports.Models;
using MappingExtensions = Nop.Admin.Extensions.MappingExtensions;
using ShopFast.Plugin.Misc.Reports;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Controllers
{
    [AdminAuthorize]
    public class ReportsController : BasePluginController
    {
        #region Fields

        private readonly ILogger _logger;
        private readonly IReportService _reportService;
        private readonly ReportsPluginSettings _reportsPluginSettings;
        private readonly ISettingService _settingService;
        private readonly IPdfService _pdfService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ILocalizationService _localizationService;
        private readonly IDateTimeHelper _dateTimeHelper;

        #endregion

        #region Ctor

        public ReportsController(ILogger logger,
            IReportService reportService,
            ReportsPluginSettings reportsPluginSettings,
            ISettingService settingService, 
            IPdfService pdfService, 
            IWorkContext workContext, 
            IStoreContext storeContext, 
            ILocalizationService localizationService, IDateTimeHelper dateTimeHelper)
        {
            _logger = logger;
            _reportService = reportService;
            _reportsPluginSettings = reportsPluginSettings;
            _settingService = settingService;
            _pdfService = pdfService;
            _workContext = workContext;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _dateTimeHelper = dateTimeHelper;
        }

        #endregion

        #region Utilites

        [NonAction]
        protected string GetViewFullPath(string viewName)
        {
            return "~/Plugins/ShopFast.Misc.Reports/Views/Reports/" + viewName + ".cshtml";
        }
        
        [NonAction]
        protected ReportModel PrepareReportModel(Report report = null, ReportModel model = null, FormCollection form = null)
        {
            if (model == null)
                model = new ReportModel()
                {

                };

            //Default values
            //model.DateTimeFormatingString = _reportsPluginSettings.DateTimeFormatingString;
            model.ReportAttributePrefix = _reportsPluginSettings.ReportAttributePrefix;

            if (report != null)
            {
                model.ReportId = report.Id;
                model.Name = report.Name;
                model.SqlCode = report.SqlCode;
                model.HtmlCode = report.HtmlCode;
                model.CreatedUtc = _dateTimeHelper.ConvertToUserTime(report.CreatedUtc, DateTimeKind.Utc);//report.CreatedUtc.ToString(_reportsPluginSettings.DateTimeFormatingString);
                model.ReportAttributeModels = _reportService.GetReportAttributes(report.Id).Select(ra =>
                    new ReportAttributeModel()
                    {
                        Id = ra.Id,
                        Name = ra.Name,
                        ReportId = ra.ReportId,
                        //Value = ra.DefaultValue,
                        DefaultValue = ra.DefaultValue,
                        AttributeType = ra.AttributeType.ToString(),
                        AttributeTypeId = ra.AttributeTypeId
                    }
                    ).ToList();


                if (form != null)
                {
                    foreach (var reportAttr in model.ReportAttributeModels)
                    {
                        var reportAttrValue = form[string.Format("{0}{1}",
                            _reportsPluginSettings.ReportAttributePrefix, reportAttr.Name)];

                        if (!string.IsNullOrEmpty(reportAttrValue))
                        {
                            model.ReportAttributeModels.First(ram => ram.Name == reportAttr.Name).Value = reportAttrValue;
                        }
                    }
                }    
            }

            return model;
        }

        [NonAction]
        protected List<ReportListModel> CreateReportList(List<Report> reports)
        {
            return reports.Select(report => new ReportListModel()
            {
                ReportId = report.Id.ToString(),
                Name = report.Name,
                CreatedUtc = _dateTimeHelper.ConvertToUserTime(report.CreatedUtc, DateTimeKind.Utc)//report.CreatedUtc.ToString(_reportsPluginSettings.DateTimeFormatingString)
            }).ToList();
        }

        [NonAction]
        protected FormCollection ParseStringToFormCollection(string str)
        {
            //"reportId=1&reportattr_orderIdMin=3000"
            var result = new FormCollection();

            if (!string.IsNullOrEmpty(str))
            {
                var pairs = str.Split('&');
                foreach (var pair in pairs)
                {
                    var array = pair.Split('=');
                    var key = array.First();
                    var value = pair.Substring(key.Length + 1);

                    result.Add(key, value);
                }
            }

            return result;
        }

        #endregion Utitlites

        #region Methods

        #region Configuration

        [NonAction]
        protected ConfigurationModel PrepareConfigurationModel()
        {
            var model = new ConfigurationModel()
            {
                //DateTimeFormatingString = _reportsPluginSettings.DateTimeFormatingString,
                DbName = _reportsPluginSettings.DbName,
                DbNameHolder = _reportsPluginSettings.DbNameHolder,
                UpdateExistingReports = _reportsPluginSettings.UpdateExistingReports
            };

            return model;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = PrepareConfigurationModel();

            return View(GetViewFullPath("Configure"), model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
            {
                model = PrepareConfigurationModel();
                return View(GetViewFullPath("Configure"), model); 
            }

            //_reportsPluginSettings.DateTimeFormatingString = model.DateTimeFormatingString;
            _reportsPluginSettings.DbName = model.DbName;
            _reportsPluginSettings.DbNameHolder = model.DbNameHolder;
            _reportsPluginSettings.UpdateExistingReports = model.UpdateExistingReports;

            _settingService.SaveSetting(_reportsPluginSettings);
            _settingService.ClearCache();

            model = PrepareConfigurationModel();
            return View(GetViewFullPath("Configure"), model);
        }

        [AdminAuthorize]
        public ActionResult DefaultSettings()
        {
            ReportsPlugin.SetDefaultSettings();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Plugin.Misc.Reports");
        }

        [AdminAuthorize]
        public ActionResult DefaultReports()
        {
            ReportsPlugin.LoadDefaultReports();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Plugin.Misc.Reports");
        }

        #endregion

        #region Reports

        [HttpPost]
        public ActionResult ReportList(DataSourceRequest command, ReportSearchModel model)
        {
            List<Report> reports = _reportService.SearchReports(
                name: model.Name
                ).ToList();

            var reportList = CreateReportList(reports);
            var gridModel = new DataSourceResult
            {
                Data = new PagedList<ReportListModel>(reportList, command.Page - 1, command.PageSize),
                Total = reportList.Count
            };

            return Json(gridModel);
        }

        public ActionResult List()
        {
            var model = new ReportSearchModel();

            ViewBag.Title = _localizationService.GetResource("ShopFast.Plugin.Misc.Reports.List");
            return View(GetViewFullPath("List"), model);
        }

        public ActionResult Create()
        {
            var model = PrepareReportModel();

            ViewBag.Title = _localizationService.GetResource("ShopFast.Plugin.Misc.Reports.Create");
            return View(GetViewFullPath("Edit"), model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public ActionResult Create(ReportModel model, bool continueEditing)
        {
            if (!ModelState.IsValid)
                return View(GetViewFullPath("Edit"), PrepareReportModel(model: model));

            var report = new Report()
            {
                Name = model.Name,
                SqlCode = model.SqlCode,
                HtmlCode = model.HtmlCode,
                CreatedUtc = DateTime.UtcNow
            };

            _reportService.InsertReport(report);

            return continueEditing
                ? RedirectToRoute("Shopfast.Plugin.Misc.Reports.Edit", new { report.Id })
                : RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");
        }

        public ActionResult Edit(int? id)
        {
            var report = _reportService.GetReportById(id.GetValueOrDefault());
            if (report == null)
                return RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");

            var model = PrepareReportModel(report);

            ViewBag.Title = _localizationService.GetResource("ShopFast.Plugin.Misc.Reports.Edit");
            return View(GetViewFullPath("Edit"), model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public ActionResult Edit(ReportModel model, bool continueEditing)
        {
            var report = _reportService.GetReportById(model.ReportId);
            if (report == null)
                return HttpNotFound();

            if (!ModelState.IsValid)
                return View(GetViewFullPath("Edit"), PrepareReportModel(report: report, model: model));

            report.Name = model.Name;
            report.SqlCode = model.SqlCode;
            report.HtmlCode = model.HtmlCode;

            _reportService.UpdateReport(report);

            return continueEditing
                ? RedirectToRoute("Shopfast.Plugin.Misc.Reports.Edit", report.Id)
                : RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");
        }

        public ActionResult Delete(int? id)
        {
            var report = _reportService.GetReportById(id.GetValueOrDefault());
            if (report != null)
            {
                _reportService.DeleteReport(report);
            }
            else
            {
                
            }

            return RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");
        }

        public ActionResult View(int? id)
        {
            var report = _reportService.GetReportById(id.GetValueOrDefault());
            if (report == null)
                return RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");

            var model = PrepareReportModel(report);

            ViewBag.Title = report.Name;
            return View(GetViewFullPath("View"), model);
        }

        #endregion

        #region Report Attributes

        [HttpPost]
        public ActionResult ReportAttributeList(DataSourceRequest command, int? reportId = null)
        {
            if (!reportId.HasValue)
                return new NullJsonResult();

            var reportAttributes = _reportService.GetReportAttributes(reportId.GetValueOrDefault()).ToList();
            var reportAttributeModelList = new List<ReportAttributeModel>();
            foreach (var reportAttribute in reportAttributes)
            {
                reportAttributeModelList.Add(new ReportAttributeModel()
                {
                    Id = reportAttribute.Id,
                    ReportId = reportAttribute.ReportId,
                    Name = reportAttribute.Name,
                    AttributeType = reportAttribute.AttributeType.ToString(),
                    AttributeTypeId = reportAttribute.AttributeTypeId,
                    DefaultValue = reportAttribute.DefaultValue
                });
            }

            var gridModel = new DataSourceResult
            {
                Data = new PagedList<ReportAttributeModel>(reportAttributeModelList, command.Page - 1, command.PageSize),
                Total = reportAttributeModelList.Count
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult CreateReportAttribute([Bind(Exclude = "ConfigurationRouteValues")] ReportAttributeModel model,
            int? reportId = null)
        {
            if (!reportId.HasValue)
                return new NullJsonResult();

            var reportAttribute = new ReportAttribute()
            {
                ReportId = reportId.GetValueOrDefault(),
                Name = model.Name,
                DefaultValue = model.DefaultValue,
                AttributeTypeId = model.AttributeTypeId
            };

            var warnings = _reportService.InsertReportAttribute(reportAttribute);

            return Json(warnings);
        }

        [HttpPost]
        public ActionResult UpdateReportAttribute([Bind(Exclude = "ConfigurationRouteValues")] ReportAttributeModel model)
        {
            var reportAttribute = _reportService.GetReportAttributeById(model.Id);
            if (reportAttribute == null)
                return new NullJsonResult();

            reportAttribute.Name = model.Name;
            reportAttribute.DefaultValue = model.DefaultValue;
            reportAttribute.AttributeTypeId = model.AttributeTypeId;

            _reportService.UpdateReportAttribute(reportAttribute);

            return new NullJsonResult();
        }

        [HttpPost]
        public ActionResult DeleteReportAttribute([Bind(Exclude = "ConfigurationRouteValues")] ReportAttributeModel model)
        {
            var reportAttribute = _reportService.GetReportAttributeById(model.Id);
            if (reportAttribute == null)
                return new NullJsonResult();

            _reportService.DeleteReportAttribute(reportAttribute);

            return new NullJsonResult();
        }

        #endregion

        #region Print/Pdf/Excel

        [HttpPost]
        public String AjaxGetReportData(string formDataString)
        {
            var form = ParseStringToFormCollection(formDataString);
            var reportId = Int32.Parse(form["reportId"]);
            var report = _reportService.GetReportById(reportId);
            if (report == null)
                return null;

            //var dataTable = _reportService.GetReportResultDataTable(reportId, form);
            report.SqlCode = report.SqlCode.Replace(string.Format("[{0}]", _reportsPluginSettings.DbNameHolder), 
                string.Format("[{0}]", _reportsPluginSettings.DbName));
            var dataTable = _reportService.GetReportResultDataTable(report, form);

            return JsonConvert.SerializeObject(dataTable);
        }

        [HttpPost]
        public String AjaxGetReportDataDetail(string formDataString, int entityId = 0)
        {
            var form = ParseStringToFormCollection(formDataString);
            var reportId = Int32.Parse(form["reportId"]);
            var report = _reportService.GetReportById(reportId);
            if (report == null)
                return null;

            var sqlCode = report.SqlCodeDetail.Replace(string.Format("[{0}]", _reportsPluginSettings.DbNameHolder),
                string.Format("[{0}]", _reportsPluginSettings.DbName));
            sqlCode = sqlCode.Replace(_reportsPluginSettings.EntityIdHolder,
                entityId.ToString());

            var dataTable = _reportService.GetReportResultDataTable(report, form, sqlCode);

            return JsonConvert.SerializeObject(dataTable);
        }

        [HttpPost, ActionName("View")]
        [FormValueRequired("print")]
        public ActionResult Print(ReportModel model, FormCollection form)
        {
            var report = _reportService.GetReportById(model.ReportId);
            if (report == null)
                return RedirectToRoute("Shopfast.Plugin.Misc.Reports.List");

            model = PrepareReportModel(report, form: form);

            ViewBag.Title = report.Name;
            return View(GetViewFullPath("View"), model);
        }

        [HttpPost]
        public ActionResult Export(string contentType, string base64, string fileName)//(ReportModel model, FormCollection form)
        {
            var fileContents = Convert.FromBase64String(base64);

            return File(fileContents, contentType, fileName);
            /*
            var reportId = Int32.Parse(form["reportId"]);
            var report = _reportService.GetReportById(reportId);
            if (report == null)
                return new HttpNotFoundResult();

            var dt = _reportService.GetReportResultDataTable(reportId, form);
            string attachment = string.Format("attachment; filename={0}.xls", report.Name);
            Response.ClearContent();
            Response.AddHeader("content-disposition", attachment);
            Response.ContentType = "application/vnd.ms-excel";
            string tab = "";
            foreach (DataColumn dc in dt.Columns)
            {
                Response.Write(tab + dc.ColumnName);
                tab = "\t";
            }
            Response.Write("\n");
            int i;
            foreach (DataRow dr in dt.Rows)
            {
                tab = "";
                for (i = 0; i < dt.Columns.Count; i++)
                {
                    Response.Write(tab + dr[i].ToString());
                    tab = "\t";
                }
                Response.Write("\n");
            }
            Response.End();

            model = PrepareReportModel(report, form: form);

            return View(GetViewFullPath("View"), model);*/
        }

        #endregion

        public ActionResult TestPage()
        {
            var model = new ReportModel();

            return View(GetViewFullPath("Test"));
        }

        [HttpPost]
        public String AjaxGetTestReportData()
        {
            var sqlCode = @"

USE [YOWZA_ciaograzie];

--filtertable
DECLARE @FilterTable TABLE (Id INT)
INSERT  INTO @FilterTable
SELECT ID FROM [dbo].[Order] o 
	WHERE o.Deleted=0 
		--AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
		AND OrderStatusId=30

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT (CASE WHEN ct.CustomerId IS NOT NULL THEN ct.CustomerId ELSE '-' END) as [CustomerId], 
		ct.CustomerEmail as [CustomerEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [CustomerFullName],
		--CONCAT((CASE WHEN ct.CustomerId IS NOT NULL THEN CONCAT(ct.CustomerId, ': ') ELSE '- ' END), CONCAT(ct.FirstName, ' ', ct.LastName)) as [Customer],
		SUM(o.OrderSubtotalExclTax) as [SubTotal],
		SUM(o.OrderTotal) as [Total],
		(CASE WHEN SUM(rot.TipAmount) IS NOT NULL THEN SUM(rot.TipAmount) ELSE 0 END) as [PosRecordedTips], 
		(CASE WHEN SUM(o.OrderTotal) > 0 AND SUM(rot.TipAmount) IS NOT NULL THEN (SUM(rot.TipAmount) / SUM(o.OrderTotal)) ELSE 0 END) as [PosRecordedTipsPercentage],
		(CASE WHEN SUM(rop.TipAmount) IS NOT NULL THEN SUM(rop.TipAmount) ELSE 0 END) as [ReportedTips],
		(CASE WHEN SUM(o.OrderTotal) > 0 AND SUM(rop.TipAmount) IS NOT NULL THEN (SUM(rop.TipAmount) / SUM(o.OrderTotal)) ELSE 0 END) as [ReportedTipsPercentage]
	FROM [Order] o 
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId
		LEFT JOIN [RestaurantOrderTip] rot ON rot.OrderId = o.Id
		LEFT JOIN [RestaurantOrderPayment] rop ON rop.OrderId = o.Id
	GROUP BY ct.CustomerId, ct.CustomerEmail, ct.FirstName, ct.LastName
	ORDER BY ct.CustomerId;
            ";

            //sqlCode = _reportService.GetReportById(34).SqlCode;

            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            var dataTable = new DataTable();
            try
            {
                using (
                    SqlConnection sqlConnection =
                        new SqlConnection((dbContext as DbContext).Database.Connection.ConnectionString))
                {
                    sqlConnection.Open();
                    var sqlCommand = new SqlCommand(sqlCode, sqlConnection);

                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        dataTable.Load(sqlDataReader);
                        sqlDataReader.Close();
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception)
            {
                
            }

            return JsonConvert.SerializeObject(dataTable);
        }

        [HttpPost]
        public String AjaxGetTestReportDataDetail(int entityId)
        {
            var sqlCode = @"

USE [YOWZA_ciaograzie];

DECLARE @EnitityId INT;
SET @EnitityId = (CASE WHEN @EnitityValue > 0 THEN @EnitityValue ELSE NULL END);

--filtertable
DECLARE @FilterTable TABLE (Id INT)
IF @EnitityId IS NOT NULL 
BEGIN
	INSERT  INTO @FilterTable
		SELECT o.ID FROM [dbo].[Order] o
			LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
			LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
		WHERE o.Deleted=0 
			--AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
			AND OrderStatusId=30
			AND c.Id = @EnitityId;
END
ELSE
BEGIN
	INSERT  INTO @FilterTable
		SELECT o.ID FROM [dbo].[Order] o
			LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
			LEFT JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
		WHERE o.Deleted=0 
			--AND o.CreatedOnUtc >= @from AND o.CreatedOnUtc <= @to 
			AND OrderStatusId=30
			AND c.Id IS NULL
END

--ordertotal
DECLARE @OrderTotal decimal(18,4)
SET @OrderTotal = (Select SUM(o.OrderTotal) FROM [dbo].[Order] o INNER JOIN @FilterTable ft ON o.Id=ft.ID)

--customers with generic att
DECLARE @CustomerTable TABLE ([CustomerId] INT, [CustomerEmail] NVARCHAR(1000), [FirstName] NVARCHAR(MAX), [LastName] NVARCHAR(MAX))
INSERT  INTO @CustomerTable
	([CustomerId], [CustomerEmail])
	SELECT * FROM(SELECT c.Id as [CustomerId],
       c.Email as [CustomerEmail]
	FROM @FilterTable ft
	INNER JOIN [dbo].[Order] o ON o.Id = ft.Id
	INNER JOIN [dbo].[RestaurantOrder] ro ON ro.OrderId = o.Id
	INNER JOIN [dbo].[Customer] c ON c.Id = ro.WaiterId
	GROUP BY c.Id, c.Email
) as customers
	
UPDATE @CustomerTable SET FirstName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'FirstName')

UPDATE @CustomerTable SET LastName = (SELECT TOP 1 Value FROM [dbo].[GenericAttribute] ga 
		WHERE ga.[EntityId] = CustomerId AND ga.[KeyGroup]='Customer' AND ga.[Key] = 'LastName')

--results
SELECT (CASE WHEN ct.CustomerId IS NOT NULL THEN ct.CustomerId ELSE '-' END) as [CustomerId], 
		ct.CustomerEmail as [CustomerEmail],
		CONCAT(ct.FirstName, ' ', ct.LastName) as [CustomerFullName],
		--CONCAT((CASE WHEN ct.CustomerId IS NOT NULL THEN CONCAT(ct.CustomerId, ': ') ELSE '- ' END), CONCAT(ct.FirstName, ' ', ct.LastName)) as [Customer],
		o.Id as [OrderId],
		o.OrderSubtotalExclTax as [SubTotal],
		o.OrderTotal as [Total],
		(CASE WHEN SUM(rot.TipAmount) IS NOT NULL THEN SUM(rot.TipAmount) ELSE 0 END) as [PosRecordedTips], 
		(CASE WHEN o.OrderTotal > 0 AND SUM(rot.TipAmount) IS NOT NULL THEN (SUM(rot.TipAmount) / o.OrderTotal) ELSE 0 END) as [PosRecordedTipsPercentage],
		(CASE WHEN SUM(rop.TipAmount) IS NOT NULL THEN SUM(rop.TipAmount) ELSE 0 END) as [ReportedTips],
		(CASE WHEN o.OrderTotal > 0 AND SUM(rop.TipAmount) IS NOT NULL THEN (SUM(rop.TipAmount) / o.OrderTotal) ELSE 0 END) as [ReportedTipsPercentage]
	FROM [Order] o 
		INNER JOIN @FilterTable ft ON o.Id = ft.Id	
		LEFT JOIN [RestaurantOrder] ro ON ro.OrderId = o.Id	
		LEFT JOIN @CustomerTable ct ON ct.CustomerId = ro.WaiterId
		LEFT JOIN [RestaurantOrderTip] rot ON rot.OrderId = o.Id
		LEFT JOIN [RestaurantOrderPayment] rop ON rop.OrderId = o.Id
	GROUP BY ct.CustomerId, ct.CustomerEmail, ct.FirstName, ct.LastName, o.Id, o.OrderTotal, o.OrderSubtotalExclTax	
	ORDER BY ct.CustomerId, o.Id;

            ";

            sqlCode = sqlCode.Replace("@EnitityValue", entityId.ToString());

            //sqlCode = _reportService.GetReportById(34).SqlCode;

            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            var dataTable = new DataTable();
            try
            {
                using (
                    SqlConnection sqlConnection =
                        new SqlConnection((dbContext as DbContext).Database.Connection.ConnectionString))
                {
                    sqlConnection.Open();
                    var sqlCommand = new SqlCommand(sqlCode, sqlConnection);

                    using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        dataTable.Load(sqlDataReader);
                        sqlDataReader.Close();
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception)
            {

            }

            return JsonConvert.SerializeObject(dataTable);
        }

        #endregion
    }
}
