﻿using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.Reports
{
    public class ReportsPluginSettings : ISettings
    {
        //public string DateTimeFormatingString { get; set; }

        public string DbName { get; set; }

        public string DbNameHolder { get; set; }

        public string EntityIdHolder { get; set; }

        //Default report upload
        public string DefaultDateTimeFromValue { get; set; }

        public string DefaultDateTimeToValue { get; set; }

        public bool UpdateExistingReports { get; set; }

        //Not editable
        public string ReportAttributePrefix { get; set; }   
    }
}