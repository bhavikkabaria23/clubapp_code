using System.Collections.Generic;
using System.IO;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Plugins;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Common;
using Nop.Web.Framework.Menu;
using System.Web.Mvc;
using System.Linq;
using Nop.Core.Data;

namespace Shopfast.Plugin.Misc.StoreSignUpToggle
{
    /// <summary>
    /// PLugin
    /// </summary>
    public class StoreSignUpTogglePlugin : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly ISettingService _settingService;

        public StoreSignUpTogglePlugin(ISettingService settingService)
        {
            this._settingService = settingService;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "StoreSignUpToggle";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Shopfast.Plugin.Misc.StoreSignUpToggle.Controllers" }, { "area", null } };
        }


        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            //settings
            var settings = new StoreSignUpToggleSettings()
            {
                StoreSignUpForm = ""            
            };
            _settingService.SaveSetting(settings);
            this.AddOrUpdatePluginLocaleResource("Plugins.Misc.StoreSignUpToggle.StoreSignUpForm", "Store Sign Up Form");            

            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<StoreSignUpToggleSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.Misc.StoreSignUpToggle.StoreSignUpForm");            

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            if (MultisiteHelper.IsAdminSite)
            {
                var helper = new UrlHelper(System.Web.HttpContext.Current.Request.RequestContext);
                var menuItem = new SiteMapNode()
                {
                    SystemName = "Store Signup Toggle",
                    Title = "Store Signup Toggle",
                    Url = "/Admin/Plugin/ConfigureMiscPlugin?systemName=Misc.StoreSignUpToggle",
                    Visible = true,
                    IconClass = "fa-genderless"
                };
                var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Configuration");
                if (pluginNode != null)
                {
                    var pluginChildNode = pluginNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Settings");
                    if (pluginChildNode != null)
                    {
                        pluginChildNode.ChildNodes.Insert(1,menuItem);
                    }
                    else
                    {
                        rootNode.ChildNodes.Add(menuItem);
                    }
                }
                else
                    rootNode.ChildNodes.Add(menuItem);
            }
        }
    }
}
