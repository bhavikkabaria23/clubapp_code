﻿using Nop.Core.Configuration;

namespace Shopfast.Plugin.Misc.StoreSignUpToggle
{
    public class StoreSignUpToggleSettings : ISettings
    {
        public string StoreSignUpForm { get; set; }
    }
}
