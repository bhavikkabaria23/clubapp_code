﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Services.Configuration;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.Misc.StoreSignUpToggle.Models;

namespace Shopfast.Plugin.Misc.StoreSignUpToggle
{
    public class StoreSignUpToggleController : BaseController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreService _storeService;        
        private readonly ISettingService _settingService;

        public StoreSignUpToggleController(IWorkContext workContext,
            IStoreContext storeContext, IStoreService storeService, 
            ISettingService settingService)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._storeService = storeService;            
            this._settingService = settingService;
        }
        
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var StoreSignUpToggleSettings = _settingService.LoadSetting<StoreSignUpToggleSettings>(storeScope);
            var model = new ConfigurationModel();
            model.StoreSignUpForm = StoreSignUpToggleSettings.StoreSignUpForm;            
            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.StoreSignUpForm_OverrideForStore = _settingService.SettingExists(StoreSignUpToggleSettings, x => x.StoreSignUpForm, storeScope);                
            }

            return View("~/Plugins/Shopfast.Plugin.Misc.StoreSignUpToggle/Views/StoreSignUpToggle/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var StoreSignUpToggleSettings = _settingService.LoadSetting<StoreSignUpToggleSettings>(storeScope);

            StoreSignUpToggleSettings.StoreSignUpForm = model.StoreSignUpForm;            

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */
            if (model.StoreSignUpForm_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(StoreSignUpToggleSettings, x => x.StoreSignUpForm, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(StoreSignUpToggleSettings, x => x.StoreSignUpForm, storeScope);            
            
            //now clear settings cache
            _settingService.ClearCache();
            
            return Configure();
        }       
    }
}