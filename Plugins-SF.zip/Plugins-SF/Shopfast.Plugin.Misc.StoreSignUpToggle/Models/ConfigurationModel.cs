﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Misc.StoreSignUpToggle.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        /// <summary>
        /// Gets or sets a value of StoreSignUpForm
        /// </summary>
        [NopResourceDisplayName("Plugins.Misc.StoreSignUpToggle.StoreSignUpForm")]
        public string StoreSignUpForm { get; set; }
        public bool StoreSignUpForm_OverrideForStore { get; set; }                

    }
}
