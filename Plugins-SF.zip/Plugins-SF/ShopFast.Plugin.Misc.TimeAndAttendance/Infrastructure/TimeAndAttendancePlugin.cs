﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Cms;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.TimeAndAttendance.Data;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Infrastructure
{
    /// <summary>
    /// Live person provider
    /// </summary>
    public class TimeAndAttendancePlugin : BasePlugin, IMiscPlugin
    {
        private static readonly string ADMIN_CUSTOMER_CREATE_OR_UPDATE_VIEW_PATH =
            "~/Administration/Views/Customer/_CreateOrUpdate.cshtml";

        private readonly ISettingService _settingService;
        private readonly TimeAndAttendanceObjectContext _timeAndAttendanceObjectContext;

        public TimeAndAttendancePlugin(ISettingService settingService, 
            TimeAndAttendanceObjectContext timeAndAttendanceObjectContext)
        {
            this._settingService = settingService;
            _timeAndAttendanceObjectContext = timeAndAttendanceObjectContext;
        }

        #region Utilites

        private static Dictionary<string, string> GetLocalizationResources()
        {
            return new Dictionary<string, string>()
            {
                { "ShopFast.Plugin.Misc.TimeAndAttendance.TimeAndAttendance", "Time & Attendance" },

                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourlyRate", "Hourly Rate ($)" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourlyRate.Hint", "Hourly rate" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourCount", "Weekly Hours" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourCount.Hint",
                    "Hours that will be paid by hourly rate" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.OvertimeRate", "Overtime ($)" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.OvertimeRate.Hint", "Overtime rate" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.BonusRate", "Bonus ($)" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.BonusRate.Hint", "Bonus Rate" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.FirstDayOfWeek", "Start Day" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.FirstDayOfWeek.Hint", "First day of week" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRates.Saved", "Rates Saved" },

                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.Date", "Date" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.StartTime", "Start Time" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.EndTime", "End Time" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.TotalHours", "Total Work Hours" },

                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingSummaryModel.TotalHoursThisWeek",
                    "This week working-hours {0:0.00} H" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingSummaryModel.TotalHours", "Working hours" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingSummaryModel.TotalPayment", "Attendance pay" },

                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeButtons.ClockIn", "Clock In" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeButtons.ClockOut", "Clock Out" },

                { "ShopFast.Plugin.Misc.TimeAndAttendance.ConfigurationModel.DeffaultSettings", "Deffault Settings" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.ConfigurationModel.AddTab", "Add Tab" },
                { "ShopFast.Plugin.Misc.TimeAndAttendance.ConfigurationModel.RemoveTab", "Remove Tabs" },
            };
        }

        public static void AddTabToEditCustomerDetailsView()
        {
            var viewData = File.ReadAllText(HttpContext.Current.Server
                .MapPath(ADMIN_CUSTOMER_CREATE_OR_UPDATE_VIEW_PATH));
            var tabTitleData = File.ReadAllText(HttpContext.Current.Server
                .MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/EditCustomerDetails/TabTitleData.cshtml"));
            var tabContentData = File.ReadAllText(HttpContext.Current.Server
                .MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/EditCustomerDetails/TabContentData.cshtml"));
            
            var tabTitleHolderMatch
                = Regex.Match(viewData, @"@Html.RenderBootstrapTabHeader\(""tab-backinstock\"",\s*@T\(""Admin.Customers.Customers.BackInStockSubscriptions""\)\)\s*");
            var tabContentHolderMatch
                = Regex.Match(viewData, @"@Html.RenderBootstrapTabContent\(""tab-backinstock"", @TabBackInStockSubscriptions\(\)\)\s*");

            if (tabTitleHolderMatch.Success && tabContentHolderMatch.Success)
            {
                viewData = viewData.Insert(tabContentHolderMatch.Index + tabContentHolderMatch.Length, tabContentData);
                viewData = viewData.Insert(tabTitleHolderMatch.Index + tabTitleHolderMatch.Length, tabTitleData);
            }

            File.WriteAllText(HttpContext.Current.Server.MapPath(ADMIN_CUSTOMER_CREATE_OR_UPDATE_VIEW_PATH), viewData);
        }

        public static void RemoveTabFromEditCustomerDetailsView()
        {
            var viewData = File.ReadAllText(HttpContext.Current.Server
                .MapPath(ADMIN_CUSTOMER_CREATE_OR_UPDATE_VIEW_PATH));
            var tabTitleData = File.ReadAllText(HttpContext.Current.Server
                .MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/EditCustomerDetails/TabTitleData.cshtml"));
            var tabContentData = File.ReadAllText(HttpContext.Current.Server
                .MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/EditCustomerDetails/TabContentData.cshtml"));

            viewData = viewData.Replace(tabTitleData, "").Replace(tabContentData, "");

            File.WriteAllText(HttpContext.Current.Server.MapPath(ADMIN_CUSTOMER_CREATE_OR_UPDATE_VIEW_PATH), viewData);
        }

        #endregion

        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();
            var settings = new ProductColorSwitcherSettings
            {

            };
            settingService.SaveSetting(settings);
            
            foreach (var localizationResource in GetLocalizationResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localizationResource.Key, localizationResource.Value);
            }

            TimeAndAttendanceObjectContext timeAndAttendanceObjectContext = EngineContext.Current.Resolve<TimeAndAttendanceObjectContext>();
            timeAndAttendanceObjectContext.Install();           
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "TimeAndAttendance";
            routeValues = new RouteValueDictionary { { "Namespaces", "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }, 
            { "area", null } };
        }
        
        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            SetDefaultSettings();

            base.Install();
        }
        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            foreach (var localizationResource in GetLocalizationResources())
            {
                this.DeletePluginLocaleResource(localizationResource.Key);
            }

            RemoveTabFromEditCustomerDetailsView();

            base.Uninstall();
        }
    }
}