﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Infrastructure
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //  Time And Attendance
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.Test",
                "Plugin/TimeAndAttendance/Test",
                new { controller = "TimeAndAttendance", action = "Test" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Waiter Working Rates
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxGetWaiterWorkingRates",
                "Plugin/TimeAndAttendance/Ajax/AjaxGetWaiterWorkingRates",
                new { controller = "TimeAndAttendance", action = "AjaxGetWaiterWorkingRates" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxSaveWaiterWorkingRates",
                "Plugin/TimeAndAttendance/Ajax/AjaxSaveWaiterWorkingRates",
                new { controller = "TimeAndAttendance", action = "AjaxSaveWaiterWorkingRates" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Waiter Working Time Record
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.KendoListWaiterWorkingTimeRecords",
                "Plugin/TimeAndAttendance/Kendo/KendoListWaiterWorkingTimeRecords",
                new { controller = "TimeAndAttendance", action = "KendoListWaiterWorkingTimeRecords" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.KendoListWaiterWorkingTimeRecordUpdate",
                "Plugin/TimeAndAttendance/Kendo/KendoListWaiterWorkingTimeRecordUpdate",
                new { controller = "TimeAndAttendance", action = "KendoListWaiterWorkingTimeRecordUpdate" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");
            
            //  Waiter Working Summary
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxGetWaiterWorkingSummary",
                "Plugin/TimeAndAttendance/Ajax/AjaxGetWaiterWorkingSummary",
                new { controller = "TimeAndAttendance", action = "AjaxGetWaiterWorkingSummary" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Waiter Working Time Buttons
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxClockIn",
                "Plugin/TimeAndAttendance/Ajax/AjaxClockIn",
                new { controller = "TimeAndAttendance", action = "AjaxClockIn" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxClockOut",
                "Plugin/TimeAndAttendance/Ajax/AjaxClockOut",
                new { controller = "TimeAndAttendance", action = "AjaxClockOut" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AjaxClockInIndicator",
                "Plugin/TimeAndAttendance/Ajax/AjaxClockInIndicator",
                new { controller = "TimeAndAttendance", action = "AjaxClockInIndicator" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Default Settings
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.SetDefaultSettings",
                "Plugin/TimeAndAttendance/SetDefaultSettings",
                new { controller = "TimeAndAttendance", action = "SetDefaultSettings" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Add Tab
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.AddTab",
                "Plugin/TimeAndAttendance/AddTab",
                new { controller = "TimeAndAttendance", action = "AddTab" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

            //  Remove Tab
            routes.MapRoute("ShopFast.Plugin.Misc.TimeAndAttendance.RemoveTab",
                "Plugin/TimeAndAttendance/RemoveTab",
                new { controller = "TimeAndAttendance", action = "RemoveTab" },
                new[] { "ShopFast.Plugin.Misc.TimeAndAttendance.Controllers" }).DataTokens.Add("area", "admin");

        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
