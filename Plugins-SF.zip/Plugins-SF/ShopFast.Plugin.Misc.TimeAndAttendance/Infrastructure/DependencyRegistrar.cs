﻿using System.Web.Mvc;
using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Data;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.TimeAndAttendance.Data;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;
using ShopFast.Plugin.Misc.TimeAndAttendance.Installation;
using ShopFast.Plugin.Misc.TimeAndAttendance.Services;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Infrastructure
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        private const string CONTEXT_NAME = "nop_object_context_shopfast_time_and_attendace";

        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            //this.RegisterPluginDataContext<TimeAndAttendanceObjectContext>(builder, CONTEXT_NAME);
            builder.Register<IDbContext>(c => 
                new TimeAndAttendanceObjectContext(c.Resolve<DataSettings>().DataConnectionString))
                .Named<IDbContext>(CONTEXT_NAME)
                .InstancePerLifetimeScope();
            builder.Register<TimeAndAttendanceObjectContext>(c => 
                new TimeAndAttendanceObjectContext(c.Resolve<DataSettings>().DataConnectionString))
                .InstancePerLifetimeScope();

            builder.RegisterType<TimeAndAttendanceInstallationService>()
                .As<TimeAndAttendanceInstallationService>().InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<WaiterWorkingTimeRecord>>()
                .As<IRepository<WaiterWorkingTimeRecord>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(CONTEXT_NAME))
                .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<WaiterWorkingRates>>()
                .As<IRepository<WaiterWorkingRates>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>(CONTEXT_NAME))
                .InstancePerLifetimeScope();

            builder.RegisterType<TimeAndAttendanceService>().As<TimeAndAttendanceService>().InstancePerRequest();
        }

        public int Order => 1;
    }
}
