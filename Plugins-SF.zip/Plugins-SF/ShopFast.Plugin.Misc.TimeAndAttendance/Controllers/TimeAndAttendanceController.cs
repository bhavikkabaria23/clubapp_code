﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Web.Models.Catalog;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.Core.Domain;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;
using ShopFast.Plugin.Misc.TimeAndAttendance.Models;
using ShopFast.Plugin.Misc.TimeAndAttendance.Services;
using ShopFast.Plugin.Misc.TimeAndAttendance.Infrastructure;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Controllers
{
    public class TimeAndAttendanceController : BasePluginController
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly TimeAndAttendanceService _timeAndAttendanceService;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Constr

        public TimeAndAttendanceController(TimeAndAttendanceService timeAndAttendanceService, 
            IWorkContext workContext, 
            ILocalizationService localizationService)
        {
            _timeAndAttendanceService = timeAndAttendanceService;
            _workContext = workContext;
            _localizationService = localizationService;
        }

        #endregion

        #region Utilites

        protected virtual DateTime ParseKendoDate(string dateString)
        {
            DateTime result;
            dateString = Regex.Replace(dateString, @" GMT(\+|\-).*", "");
            //Fri Apr 22 2016 00:00:00 GMT+0300 (Belarus Standard Time)
            if (!DateTime.TryParseExact(dateString, @"ddd MMM dd yyyy hh:mm:ss",
                CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out result))
            {
                result = DateTime.ParseExact(dateString, "dddd MM'/'dd'/'yyyy", CultureInfo.InvariantCulture);
            }

            return result;
        }

        protected virtual DateTime ParseKendoTime(string timeString)
        {
            //Fri Apr 22 2016 00:00:00 GMT+0300 (Belarus Standard Time)
            //12:00:00 AM
            timeString = Regex.Match(timeString, @"\d{1,2}:\d{1,2}:\d{1,2}( AM| PM)?").Value;
            return DateTime.Parse(timeString);
        }

        protected virtual bool CurrentUserIsAdmin()
        {
            return !CurrentUserIsWaiter();
        }

        protected virtual bool CurrentUserIsWaiter(int waiterId = 0)
        {
            if (waiterId == 0)
            {
                return _workContext.CurrentCustomer.IsInCustomerRole("Waiters");
            }
            else
            {
                return _workContext.CurrentCustomer.IsInCustomerRole("Waiters")
                    && _workContext.CurrentCustomer.Id == waiterId;
            }
        }

        protected virtual bool CurrentUserIsWaiterOrAdmin(int waiterId)
        {
            return (CurrentUserIsWaiter() && _workContext.CurrentCustomer.Id == waiterId)
                   || CurrentUserIsAdmin();
        }

        #endregion

        #region Configure

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = new ConfigurationModel();

            return View("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            
            return View("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/Configure.cshtml", model);
        }

        [AdminAuthorize]
        public ActionResult SetDefaultSettings()
        {
            TimeAndAttendancePlugin.SetDefaultSettings();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Plugin.Misc.TimeAndAttendance");
        }

        [AdminAuthorize]
        public ActionResult AddTab()
        {
            TimeAndAttendancePlugin.AddTabToEditCustomerDetailsView();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Plugin.Misc.TimeAndAttendance");
        }

        [AdminAuthorize]
        public ActionResult RemoveTab()
        {
            TimeAndAttendancePlugin.RemoveTabFromEditCustomerDetailsView();
            return Redirect("/Admin/Plugin/ConfigureMiscPlugin?systemName=Shopfast.Plugin.Misc.TimeAndAttendance");
        }

        #endregion

        #region Methods

        //  http://localhost:15537/Plugin/TimeAndAttendance/Test
        public ActionResult Test()
        {
            var customer = EngineContext.Current.Resolve<ICustomerService>().GetCustomerById(6);

            _timeAndAttendanceService.StartTimeRecord(customer.Id);
            _timeAndAttendanceService.EndTimeRecord(customer.Id);

            return null;
        }

        #endregion

        #region Waiter Working Rates

        [HttpPost]
        public ActionResult AjaxGetWaiterWorkingRates(int waiterId)
        {
            return PartialView("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/_WaiterWorkingRates.cshtml",
                _timeAndAttendanceService.PrepareWaiterWorkingRatesModel(waiterId));
        }

        [HttpPost]
        public ActionResult AjaxSaveWaiterWorkingRates(int waiterId, decimal hourlyRate, int hourCount, decimal overtimeRate,
            decimal bonusRate, int firstDayOfWeek = 7)
        {
            if (CurrentUserIsAdmin())
            {
                var waiterWorkingRates = _timeAndAttendanceService.GetWaiterWorkingRates(waiterId);
                waiterWorkingRates.HourlyRate = hourlyRate;
                waiterWorkingRates.HourCount = hourCount;
                waiterWorkingRates.OvertimeRate = overtimeRate;
                waiterWorkingRates.BonusRate = bonusRate;
                waiterWorkingRates.FirstDayOfWeek = firstDayOfWeek;
                _timeAndAttendanceService.UpdateWaiterWorkingRates(waiterWorkingRates);

                return Json(_localizationService
                    .GetResource("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRates.Saved"));
            }

            return new NullJsonResult();
        }

        #endregion

        #region Waiter Working Summary

        [HttpPost]
        public ActionResult AjaxGetWaiterWorkingSummary(int waiterId, string startDateTimeStr = null, string endDateTimeStr = null)
        {
            DateTime? startDateTime = !string.IsNullOrEmpty(startDateTimeStr)
                ? (DateTime?)ParseKendoDate(startDateTimeStr) : null;
            DateTime? endDateTime = !string.IsNullOrEmpty(endDateTimeStr)
                ? (DateTime?)ParseKendoDate(endDateTimeStr).AddDays(1).AddTicks(-1) : null;

            return PartialView("~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/_WaiterWorkingSummary.cshtml",
                _timeAndAttendanceService.PrepaWaiterWorkingSummaryModel(waiterId, startDateTime, endDateTime));
        }

        #endregion

        #region Clock In/Out & Status

        [HttpPost]
        public ActionResult AjaxClockIn(int waiterId)
        {
            if (CurrentUserIsWaiterOrAdmin(waiterId))
            {
                _timeAndAttendanceService.StartTimeRecord(waiterId);
            }
            return new NullJsonResult();
        }

        [HttpPost]
        public ActionResult AjaxClockOut(int waiterId)
        {
            if (CurrentUserIsWaiterOrAdmin(waiterId))
            {
                _timeAndAttendanceService.EndTimeRecord(waiterId);
            }
            return new NullJsonResult();
        }

        [HttpPost]
        public ActionResult AjaxClockInIndicator(int waiterId)
        {
            var timeRecord = _timeAndAttendanceService.GetOngoingRecord(waiterId);
            if (timeRecord != null)
            {
                return PartialView(
                    "~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/_WaiterWorkingStatus.InProgress.cshtml");
            }
            else
            {
                return PartialView(
                    "~/Plugins/ShopFast.Misc.TimeAndAttendance/Views/TimeAndAttendance/_WaiterWorkingStatus.Free.cshtml");
            }
        }

        #endregion

        #region Waiter Working Time Records

        [HttpPost]
        public ActionResult KendoListWaiterWorkingTimeRecords(DataSourceRequest command, int waiterId = 0, 
            string startDateTimeStr = null, string endDateTimeStr = null)
        {
            DateTime? startDateTime = !string.IsNullOrEmpty(startDateTimeStr) 
                ? ( DateTime?) ParseKendoDate(startDateTimeStr) : null;
            DateTime? endDateTime = !string.IsNullOrEmpty(endDateTimeStr) 
                ? (DateTime?)ParseKendoDate(endDateTimeStr).AddDays(1).AddTicks(-1) : null;

            var waiterWorkingTimeRecords = _timeAndAttendanceService.GetWaiterWorkingTimeRecords(waiterId, startDateTime,
                endDateTime);
            var waiterWorkingTimeRecordModels = waiterWorkingTimeRecords.Select(tr =>
            {
                var waiterWorkingTimerRecordModel = new WaiterWorkingTimeRecordModel()
                {
                    Id = tr.Id,
                    Date = tr.StartTimeUtc.Date.ToString("dddd MM'/'dd'/'yyyy"),
                    StartTime = tr.StartTimeUtc.ToString("hh:mm:ss tt"),
                    EndTime = tr.EndTimeUtc?.ToString("hh:mm:ss tt") ?? string.Empty,
                    TotalHours = string.Empty
                };

                if (tr.Ended)
                {
                    waiterWorkingTimerRecordModel.TotalHours = tr.TotalTime.ToString(@"hh\:mm\:ss");
                }

                return waiterWorkingTimerRecordModel;
            }).ToList();

            var gridModel = new DataSourceResult
            {
                Data = new PagedList<WaiterWorkingTimeRecordModel>(waiterWorkingTimeRecordModels,
                    command.Page - 1, command.PageSize),
                Total = waiterWorkingTimeRecordModels.Count
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult KendoListWaiterWorkingTimeRecordUpdate(WaiterWorkingTimeRecordModel model, int waiterId = 0)
        {
            var warnings = new List<string>();
            try
            {
                if (CurrentUserIsAdmin())
                {
                    var date = ParseKendoDate(model.Date);
                    var startTime = ParseKendoTime(model.StartTime);
                    var endTime = ParseKendoTime(model.EndTime);

                    var startDateTime = new DateTime(date.Year, date.Month, date.Day, startTime.Hour, startTime.Minute,
                        startTime.Second);
                    var endDateTime = new DateTime(date.Year, date.Month, date.Day, endTime.Hour, endTime.Minute,
                        endTime.Second);

                    if (startDateTime > endDateTime)
                    {
                        throw new Exception("Start Time can't be less than End Time");
                    }

                    var waiterWorkingTimeRecord = _timeAndAttendanceService.GetWaiterWorkingTimeRecordById(model.Id);
                    waiterWorkingTimeRecord.StartTimeUtc = startDateTime;
                    waiterWorkingTimeRecord.EndTimeUtc = endDateTime;
                    if (waiterWorkingTimeRecord.TotalTime.TotalSeconds > 0)
                    {
                        _timeAndAttendanceService.UpdateWaiterWorkingTimeRecord(waiterWorkingTimeRecord);
                    }
                    else
                    {
                        _timeAndAttendanceService.DeleteWaiterWorkingTimeRecord(waiterWorkingTimeRecord);
                    }
                }
                else
                {
                    throw new AuthenticationException();
                }
            }
            catch (Exception exc)
            {
                warnings.Add(exc.Message);
            }

            return Json(warnings);
        }


        #endregion
    }
}