﻿using System.Collections.Generic;
using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.TimeAndAttendance
{
    public class ProductColorSwitcherSettings : ISettings
    {

    }
}