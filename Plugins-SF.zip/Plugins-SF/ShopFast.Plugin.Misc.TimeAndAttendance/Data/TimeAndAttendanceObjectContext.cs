﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Data.Mapping.Media;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;
using ShopFast.Plugin.Misc.TimeAndAttendance.Installation;
using System.Collections.Generic;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Data
{
    public class TimeAndAttendanceObjectContext : DbContext, IDbContext
    {
        public TimeAndAttendanceObjectContext(string nameOrConnectionString)
            : base(nameOrConnectionString) { }

        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new WaiterWorkingTimeRecordMap());
            modelBuilder.Configurations.Add(new WaiterWorkingRatesMap());

            //disable EdmMetadata generation
            //modelBuilder.Conventions.Remove<IncludeMetadataConvention>();
            base.OnModelCreating(modelBuilder);
        }

        public string CreateDatabaseScript()
        {
            return ((IObjectContextAdapter)this).ObjectContext.CreateDatabaseScript();
        }

        public new IDbSet<TEntity> Set<TEntity>() where TEntity : BaseEntity
        {
            return base.Set<TEntity>();
        }

        /// <summary>
        /// Install
        /// </summary>
        public void Install()
        {
            var installation = EngineContext.Current.Resolve<TimeAndAttendanceInstallationService>();
            installation.InstallData();

            SaveChanges();
        }

        /// <summary>
        /// Uninstall
        /// </summary>
        public void Uninstall()
        {
            var installation = EngineContext.Current.Resolve<TimeAndAttendanceInstallationService>();
            installation.DeinstallData();

            SaveChanges();
        }

        public IList<TEntity> ExecuteStoredProcedureList<TEntity>(string commandText, params object[] parameters)
            where TEntity : BaseEntity, new()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<TElement> SqlQuery<TElement>(string sql, params object[] parameters)
        {
            return Database.SqlQuery<TElement>(sql, parameters);
        }
        
        public int ExecuteSqlCommand(string sql, bool doNotEnsureTransaction = false, int? timeout = null, params object[] parameters)
        {
            throw new NotImplementedException();
        }
        
        public void Detach(object entity)
        {

        }

        public bool ProxyCreationEnabled { get; set; }

        public bool AutoDetectChangesEnabled { get; set; }
    }
}
