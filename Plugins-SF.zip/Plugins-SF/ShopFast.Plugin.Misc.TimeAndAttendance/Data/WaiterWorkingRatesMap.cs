﻿using System.Data.Entity.ModelConfiguration;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Data
{
    public class WaiterWorkingRatesMap : EntityTypeConfiguration<WaiterWorkingRates>
    {
        public WaiterWorkingRatesMap()
        {
            this.ToTable("ShopFast_TimeAndAttendance_WaiterWorkingRates");
            this.HasKey(m => m.Id);
            this.Property(m => m.WaiterId).IsRequired();
            this.Property(m => m.HourlyRate).IsRequired();
            this.Property(m => m.HourCount).IsRequired();
            this.Property(m => m.OvertimeRate).IsRequired();
            this.Property(m => m.BonusRate).IsRequired();
        }
    }
}
