﻿using System.Data.Entity.ModelConfiguration;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Data
{
    public class WaiterWorkingTimeRecordMap : EntityTypeConfiguration<WaiterWorkingTimeRecord>
    {
        public WaiterWorkingTimeRecordMap()
        {
            this.ToTable("ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord");
            this.HasKey(m => m.Id);
            this.Property(m => m.StartTimeUtc).IsRequired();
            this.Property(m => m.EndTimeUtc).IsOptional();
        }
    }
}
