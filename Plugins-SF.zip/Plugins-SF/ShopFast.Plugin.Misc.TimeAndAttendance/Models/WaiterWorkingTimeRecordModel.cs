﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Models
{
    public class WaiterWorkingTimeRecordModel : BaseNopModel
    {
        public int Id { get; set; }
        
        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.Date")]
        public string Date { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.StartTime")]
        public string StartTime { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.EndTime")]
        public string EndTime { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingTimeRecordModel.TotalHours")]
        public string TotalHours { get; set; }
    }
}