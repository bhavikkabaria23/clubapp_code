﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Models
{
    public class WaiterWorkingRatesModel : BaseNopModel
    {
        public int WaiterId { get; set; }

        public bool Editable { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourlyRate")]
        public decimal HourlyRate { get; set; }
        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.HourCount")]
        public int HourCount { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.OvertimeRate")]
        public decimal OvertimeRate { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.FirstDayOfWeek")]
        public int FirstDayOfWeek { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingRatesModel.BonusRate")]
        public decimal BonusRate { get; set; }
    }
}