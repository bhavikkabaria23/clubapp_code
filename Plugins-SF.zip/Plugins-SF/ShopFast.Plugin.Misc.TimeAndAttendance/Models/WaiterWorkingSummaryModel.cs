﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Models
{
    public class WaiterWorkingSummaryModel : BaseNopModel
    {
        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingSummaryModel.TotalHours")]
        public float TotalHoursWorked { get; set; }

        [NopResourceDisplayName("ShopFast.Plugin.Misc.TimeAndAttendance.WaiterWorkingSummaryModel.TotalPayment")]
        public float TotalPayment { get; set; }
    }
}