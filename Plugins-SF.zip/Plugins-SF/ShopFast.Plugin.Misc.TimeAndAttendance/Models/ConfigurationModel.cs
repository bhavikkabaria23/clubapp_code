﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Models
{
    public class ConfigurationModel : BaseNopModel
    {


    }
}