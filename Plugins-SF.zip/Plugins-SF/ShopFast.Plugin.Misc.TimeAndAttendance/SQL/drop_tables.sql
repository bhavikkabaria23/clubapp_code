﻿if EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord' )
begin
	DROP TABLE ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord
end;

if EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_TimeAndAttendance_WaiterWorkingRates' )
begin
	DROP TABLE ShopFast_TimeAndAttendance_WaiterWorkingRates
end;