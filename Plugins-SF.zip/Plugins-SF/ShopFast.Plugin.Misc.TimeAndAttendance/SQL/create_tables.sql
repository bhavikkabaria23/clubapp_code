﻿if NOT EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord' )
begin
	CREATE TABLE ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord(
		[Id] [int] IDENTITY(1,1) NOT NULL,

		[WaiterId] [int] NOT NULL,
		[StartTimeUtc] [datetime2] NOT NULL,		
		[EndTimeUtc] [datetime2] NULL,

		CONSTRAINT [PK_ShopFast_TimeAndAttendance_WaiterWorkingTimeRecord] PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) );
end;


if NOT EXISTS ( SELECT [name] FROM sys.tables WHERE [name] = 'ShopFast_TimeAndAttendance_WaiterWorkingRates' )
begin
	CREATE TABLE ShopFast_TimeAndAttendance_WaiterWorkingRates(
		[Id] [int] IDENTITY(1,1) NOT NULL,
		
		[WaiterId] [int] NOT NULL,
		[HourlyRate] [decimal] (18,4) NOT NULL,
		[HourCount] [int] NOT NULL,
		[OvertimeRate] [decimal] (18,4) NOT NULL,
		[BonusRate] [decimal] (18,4) NOT NULL,
		[FirstDayOfWeek] [int] NOT NULL,

		CONSTRAINT [PK_ShopFast_TimeAndAttendance_WaiterWorkingRates] PRIMARY KEY CLUSTERED
	(
		[Id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) );
end;

IF COL_LENGTH('[dbo].[ShopFast_TimeAndAttendance_WaiterWorkingRates]', 'FirstDayOfWeek') IS NULL
BEGIN
	ALTER TABLE [dbo].[ShopFast_TimeAndAttendance_WaiterWorkingRates]
	ADD [FirstDayOfWeek] [int] NOT NULL DEFAULT 7
END