﻿using System.Web;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Stores;
using Nop.Services.Installation;
using Nop.Data;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Installation
{
    public class TimeAndAttendanceInstallationService : SqlFileInstallationService
    {
        private readonly IWebHelper _webHelper;

        public TimeAndAttendanceInstallationService(IRepository<Language> languageRepository, 
            IRepository<Customer> customerRepository, 
            IRepository<Store> storeRepository, 
            IDbContext dbContext, 
            IWebHelper webHelper)
            : base(languageRepository, customerRepository, storeRepository, dbContext, webHelper)
        {
            _webHelper = webHelper;
        }

        public virtual void InstallData()
        {
            ExecuteSqlFile(
                HttpContext.Current.Server.MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/SQL/create_tables.sql"));
        }

        public virtual void DeinstallData()
        {
            //ExecuteSqlFile(_webHelper
            //    .MapPath("~/Plugins/ShopFast.Misc.TimeAndAttendance/SQL/drop_tables.sql"));
        }

    }
}
