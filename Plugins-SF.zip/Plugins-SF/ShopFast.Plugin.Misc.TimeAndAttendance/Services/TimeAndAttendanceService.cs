﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Nop.Core;
using Nop.Core.Data;
using Nop.Services.Localization;
using Nop.Web.Framework;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.TimeAndAttendance.Domain;
using ShopFast.Plugin.Misc.TimeAndAttendance.Models;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Services
{
    public class TimeAndAttendanceService
    {
        private readonly IWorkContext _workContext;
        private readonly ILocalizationService _localizationService;
        private readonly IRepository<WaiterWorkingTimeRecord> _waiterWorkingTimeRecordRepository;
        private readonly IRepository<WaiterWorkingRates> _waiterWorkingRatesRepository;

        public TimeAndAttendanceService(IWorkContext workContext,
            IRepository<WaiterWorkingTimeRecord> waiterWorkingTimeRecordRepository,
            IRepository<WaiterWorkingRates> waiterWorkingRatesRepository,
            ILocalizationService localizationService)
        {
            _waiterWorkingTimeRecordRepository = waiterWorkingTimeRecordRepository;
            _waiterWorkingRatesRepository = waiterWorkingRatesRepository;
            _localizationService = localizationService;
            _workContext = workContext;
        }

        #region Utilites
        #endregion

        #region Prepare Models

        public WaiterWorkingRatesModel PrepareWaiterWorkingRatesModel(int waiterId)
        {
            var waiterWorkingRates = GetWaiterWorkingRates(waiterId);
            var model = new WaiterWorkingRatesModel()
            {
                WaiterId = waiterId,
                Editable = _workContext.CurrentCustomer.CustomerRoles.All(cr => cr.SystemName != "Waiters"),
                HourlyRate = waiterWorkingRates.HourlyRate,
                HourCount = waiterWorkingRates.HourCount,
                OvertimeRate = waiterWorkingRates.OvertimeRate,
                BonusRate = waiterWorkingRates.BonusRate,
                FirstDayOfWeek = waiterWorkingRates.FirstDayOfWeek
            };
            return model;
        }

        protected Dictionary<DateTime, double> GetkHoursPerWeekList(List<WaiterWorkingTimeRecord> timeRecords, 
            WaiterWorkingRates rates)
        {
            var result = new Dictionary<DateTime, double>();
            var firstDayOfWeek = rates.FirstDayOfWeek != 7 ? rates.FirstDayOfWeek : 0;

            timeRecords.ForEach(tr =>
            {
                int delta = ((DayOfWeek) firstDayOfWeek) - tr.StartTimeUtc.DayOfWeek;
                if (delta > 0)
                    delta -= 7;
                DateTime weekStart = tr.StartTimeUtc.AddDays(delta).Date;

                if (result.ContainsKey(weekStart))
                {
                    result[weekStart] += tr.TotalTime.TotalHours;
                }
                else
                {
                    result.Add(weekStart, tr.TotalTime.TotalHours);
                }
            });

            return result;
        }

        public WaiterWorkingSummaryModel PrepaWaiterWorkingSummaryModel(int waiterId, DateTime? startDateTime = null,
            DateTime? endDateTime = null)
        {
            var waiterWorkingTimeRecords = GetWaiterWorkingTimeRecords(waiterId, startDateTime, endDateTime);
            var rates = GetWaiterWorkingRates(waiterId);
            var totalHours = waiterWorkingTimeRecords.Sum(tr => tr.TotalTime.TotalHours);

            //var totalPayment = (totalHours <= rates.HourCount ? totalHours : rates.HourCount) * ((double) rates.HourlyRate)
            //    + (totalHours > rates.HourCount ? totalHours - rates.HourCount : 0) * ((double)rates.OvertimeRate)
            //    + ((double) rates.BonusRate);

            var totalPayment = GetkHoursPerWeekList(waiterWorkingTimeRecords, rates).Sum(thpw =>
                (thpw.Value <= rates.HourCount ? thpw.Value : rates.HourCount) * ((double)rates.HourlyRate)
                + (thpw.Value > rates.HourCount ? thpw.Value - rates.HourCount : 0) * ((double)rates.OvertimeRate)
            ) + ((double) rates.BonusRate);

            var model = new WaiterWorkingSummaryModel()
            {
                TotalHoursWorked = (float) totalHours,
                TotalPayment = (float) totalPayment
            };
            return model;
        }

        #endregion

        #region Methods

        protected void DeleteExtraWorkingRates(int waiterId)
        {
            var workingRates = _waiterWorkingRatesRepository.Table.Where(wr => wr.WaiterId == waiterId).ToList();
            if (workingRates.Count() > 1)
            {
                for (int i = 1; i < workingRates.Count(); i++)
                {
                    _waiterWorkingRatesRepository.Delete(workingRates[i]);
                }
            }
        }

        public WaiterWorkingRates GetWaiterWorkingRates(int waiterId)
        {
            var waiterWorkingRate = _waiterWorkingRatesRepository.Table.FirstOrDefault(wr => wr.WaiterId == waiterId);
            if (waiterWorkingRate != null)
                return waiterWorkingRate;

            waiterWorkingRate = new WaiterWorkingRates() { WaiterId = waiterId };
            _waiterWorkingRatesRepository.Insert(waiterWorkingRate);
            return waiterWorkingRate;

            //DeleteExtraWorkingRates(waiterId);
            //return _waiterWorkingRatesRepository.Table.FirstOrDefault(wr => wr.WaiterId == waiterId);
        }

        public void UpdateWaiterWorkingRates(WaiterWorkingRates waiterWorkingRates)
        {
            _waiterWorkingRatesRepository.Update(waiterWorkingRates);
        }

        #endregion

        #region Time Records

        public virtual WaiterWorkingTimeRecord GetOngoingRecord(int waiterId)
        {
            return _waiterWorkingTimeRecordRepository.Table.FirstOrDefault(tm =>
                !tm.EndTimeUtc.HasValue && tm.WaiterId == waiterId);
        }

        public List<WaiterWorkingTimeRecord> GetWaiterWorkingTimeRecords(int waiterId, DateTime? startDateTime = null,
            DateTime? endDateTime = null, bool onlyThisWeek = false, bool sortByDate = true)
        {
            List<WaiterWorkingTimeRecord> result;
            if (onlyThisWeek)
            {
                var dateTimeNow = DateTime.Now;
                startDateTime = dateTimeNow.AddDays(-(int)dateTimeNow.DayOfWeek).Date;
                endDateTime = dateTimeNow.AddDays(7 - (int)dateTimeNow.DayOfWeek).Date.AddTicks(-1);
            }

            result = _waiterWorkingTimeRecordRepository.Table.Where(tr =>
                tr.WaiterId == waiterId
                && (!startDateTime.HasValue || startDateTime <= tr.StartTimeUtc)
                && (!endDateTime.HasValue || endDateTime >= tr.StartTimeUtc)
                ).ToList();

            if (sortByDate)
            {
                result.Sort((tr1, tr2) => tr1.StartTimeUtc.CompareTo(tr2.StartTimeUtc));
            }

            return result;
        }

        public WaiterWorkingTimeRecord StartTimeRecord(int waiterId)
        {
            var timeRecord = GetOngoingRecord(waiterId);
            if (timeRecord == null)
            {
                timeRecord = new WaiterWorkingTimeRecord()
                {
                    WaiterId = waiterId,
                    StartTimeUtc = DateTime.Now
                };
                _waiterWorkingTimeRecordRepository.Insert(timeRecord);
                return timeRecord;
            }
            return null;
        }

        public WaiterWorkingTimeRecord EndTimeRecord(int waiterId)
        {
            var timeRecord = GetOngoingRecord(waiterId);
            if (timeRecord != null)
            {
                var endDateTime = DateTime.Now;
                //adding extra records for every day worked
                while (timeRecord.StartTimeUtc.Date != endDateTime.Date)
                {
                    timeRecord.EndTimeUtc = timeRecord.StartTimeUtc.Date.AddDays(1).AddTicks(-1);
                    _waiterWorkingTimeRecordRepository.Update(timeRecord);

                    var startDateTime = timeRecord.StartTimeUtc.Date.AddDays(1);

                    timeRecord = new WaiterWorkingTimeRecord()
                    {
                        WaiterId = waiterId,
                        StartTimeUtc = startDateTime
                    };
                    _waiterWorkingTimeRecordRepository.Insert(timeRecord);
                }
                timeRecord.EndTimeUtc = endDateTime;
                _waiterWorkingTimeRecordRepository.Update(timeRecord);
            }

            return timeRecord;
        }

        public WaiterWorkingTimeRecord GetWaiterWorkingTimeRecordById(int id)
        {
            return _waiterWorkingTimeRecordRepository.GetById(id);
        }

        public void UpdateWaiterWorkingTimeRecord(WaiterWorkingTimeRecord timeRecord)
        {
            _waiterWorkingTimeRecordRepository.Update(timeRecord);
        }

        public void DeleteWaiterWorkingTimeRecord(WaiterWorkingTimeRecord timeRecord)
        {
            _waiterWorkingTimeRecordRepository.Delete(timeRecord);
        }

        #endregion
    }
}