﻿using System;
using System.Globalization;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Tasks;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Domain
{
    public class WaiterWorkingRates : BaseEntity
    {
        public int WaiterId { get; set; }
        
        public decimal HourlyRate { get; set; }

        public int HourCount { get; set; }

        public decimal OvertimeRate { get; set; }

        public decimal BonusRate { get; set; }

        public int FirstDayOfWeek { get; set; }
    }
}
