﻿using System;
using System.Globalization;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Tasks;

namespace ShopFast.Plugin.Misc.TimeAndAttendance.Domain
{
    public class WaiterWorkingTimeRecord : BaseEntity
    {
        public int WaiterId { get; set; }
        
        public DateTime StartTimeUtc { get; set; }

        public DateTime? EndTimeUtc { get; set; }

        public virtual bool Ended => EndTimeUtc.HasValue;

        public virtual TimeSpan TotalTime => (this.EndTimeUtc ?? DateTime.Now) - this.StartTimeUtc;
    }
}
