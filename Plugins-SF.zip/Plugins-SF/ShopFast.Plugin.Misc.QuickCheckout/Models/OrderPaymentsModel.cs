﻿using Nop.Admin.Models.Orders;
using Nop.Core.Domain.Common;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Nop.Admin.Models.ShoppingCart;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using Nop.Web.Framework;
using Nop.Web.Models.Common;
using ShoppingCartModel = Nop.Web.Models.ShoppingCart.ShoppingCartModel;

namespace ShopFast.Plugin.Misc.QuickCheckout.Models
{
    public class OrderPaymentsModel : BaseNopModel
    {
        public OrderPaymentsModel()
        {
          
        }

        public int OrderId { get; set; }
        public List<OrderModel> Payments { get; set; } 
    }
}
