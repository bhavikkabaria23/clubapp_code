﻿using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    public class QuickCheckoutSettings : ISettings
    {
       
    }
}