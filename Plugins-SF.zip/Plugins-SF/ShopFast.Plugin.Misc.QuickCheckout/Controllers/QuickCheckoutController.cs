﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Nop.Admin;
//using Nop.Admin.Extensions;
using Nop.Admin.Models.Customers;
using Nop.Admin.Models.Orders;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Logging;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Services.Vendors;
using Nop.Web.Extensions;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc;
using Nop.Web.Infrastructure.Cache;
using Nop.Web.Models.Checkout;
using Nop.Web.Models.Common;
using Nop.Web.Models.Media;
using Nop.Web.Models.Order;
using Nop.Web.Models.ShoppingCart;
using ShopFast.Plugin.Misc.Core.Domain;
using ShopFast.Plugin.Misc.Core.Models;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.QuickCheckout.Models;
using ShopFast.Plugin.Misc.QuickCheckout.Services;
using MappingExtensions = Nop.Admin.Extensions.MappingExtensions;

namespace ShopFast.Plugin.Misc.QuickCheckout.Controllers
{
    public class QuickCheckoutController : BasePluginController
    {
        #region Fields

        private const int CHECKOUT_CART_ID = -0xBADBABE;
        private const string DATETIME_FORMATING_STR = "{0:yyyy/MM/dd h:mm tt}";

        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ILocalizationService _localizationService;
        private readonly IITPOrderProcessingService _orderProcessingService;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IShippingService _shippingService;
        private readonly IPaymentService _paymentService;
        private readonly IPluginFinder _pluginFinder;
        private readonly ILogger _logger;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IAddressAttributeFormatter _addressAttributeFormatter;

        private readonly OrderSettings _orderSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly PaymentSettings _paymentSettings;
        private readonly AddressSettings _addressSettings;
        private readonly PrepareCheckoutModels _prepareCheckoutModels;
        private readonly PrepareShoppingCartModels _prepareShoppingCartModels;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;
        private readonly IInvoiceCartService _invoiceCartService;
        private readonly IITPOrderService _orderService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IDiscountService _discountService;
        private readonly IGiftCardService _giftCardService;
        private readonly IITPInvoiceTotalCalculationService _invoiceTotalCalculationService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ITaxService _taxService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly ShoppingCartSettings _shoppingCartSettings;
        private readonly MediaSettings _mediaSettings;
        private readonly ICheckoutAttributeService _checkoutAttributeService;
        private readonly ICheckoutAttributeParser _checkoutAttributeParser;
        private readonly IPermissionService _permissionService;
        private readonly IDownloadService _downloadService;
        private readonly TipsCheckoutAttributeParser _tipsCheckoutAttributeParser;
        private readonly IITPPartialPaymentService _partialPaymentService;
        private readonly IWebHelper _webHelper;
        private readonly IStoreService _storeService;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly TaxSettings _taxSettings;
        private readonly CurrencySettings _currencySettings;
        private readonly IEncryptionService _encryptionService;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly IVendorService _vendorService;

        private readonly QuickCheckoutPluginService _quickCheckoutPluginService;

        #endregion

        #region Ctor

        public QuickCheckoutController(IWorkContext workContext,
            IStoreContext storeContext,
            ILocalizationService localizationService,
            IITPOrderProcessingService orderProcessingService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IShippingService shippingService,
            IPaymentService paymentService,
            IPluginFinder pluginFinder,
            ILogger logger,
            IAddressAttributeParser addressAttributeParser,
            IAddressAttributeService addressAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            OrderSettings orderSettings,
            RewardPointsSettings rewardPointsSettings,
            PaymentSettings paymentSettings,
            AddressSettings addressSettings,
            PrepareCheckoutModels prepareCheckoutModels,
            PrepareShoppingCartModels prepareShoppingCartModels,
            InvoiceItemAttributeParser invoiceItemAttributeParser,
            IInvoiceCartService invoiceCartService,
            IITPOrderService orderService,
            IShoppingCartService shoppingCartService,
            IDiscountService discountService,
            IGiftCardService giftCardService,
            IITPInvoiceTotalCalculationService invoiceTotalCalculationService,
            ITaxService taxService,
            IPriceCalculationService priceCalculationService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            ShoppingCartSettings shoppingCartSettings,
            MediaSettings mediaSettings,
            ICheckoutAttributeService checkoutAttributeService,
            ICheckoutAttributeParser checkoutAttributeParser,
            IPermissionService permissionService,
            IDownloadService downloadService,
            TipsCheckoutAttributeParser tipsCheckoutAttributeParser,
            IITPPartialPaymentService partialPaymentService, IWebHelper webHelper, IStoreService storeService, IDateTimeHelper dateTimeHelper, TaxSettings taxSettings, CurrencySettings currencySettings, IEncryptionService encryptionService, IProductAttributeParser productAttributeParser, IVendorService vendorService, IOrderTotalCalculationService orderTotalCalculationService, QuickCheckoutPluginService quickCheckoutPluginService)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._localizationService = localizationService;
            this._orderProcessingService = orderProcessingService;
            this._customerService = customerService;
            this._genericAttributeService = genericAttributeService;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._shippingService = shippingService;
            this._paymentService = paymentService;
            this._pluginFinder = pluginFinder;
            this._logger = logger;
            this._addressAttributeParser = addressAttributeParser;
            this._addressAttributeService = addressAttributeService;
            this._addressAttributeFormatter = addressAttributeFormatter;

            this._orderSettings = orderSettings;
            this._rewardPointsSettings = rewardPointsSettings;
            this._paymentSettings = paymentSettings;
            this._addressSettings = addressSettings;
            _prepareCheckoutModels = prepareCheckoutModels;
            _prepareShoppingCartModels = prepareShoppingCartModels;
            _invoiceItemAttributeParser = invoiceItemAttributeParser;
            _invoiceCartService = invoiceCartService;
            _orderService = orderService;
            _shoppingCartService = shoppingCartService;
            _discountService = discountService;
            _giftCardService = giftCardService;
            _invoiceTotalCalculationService = invoiceTotalCalculationService;
            _taxService = taxService;
            _priceCalculationService = priceCalculationService;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _shoppingCartSettings = shoppingCartSettings;
            _mediaSettings = mediaSettings;
            _checkoutAttributeService = checkoutAttributeService;
            _checkoutAttributeParser = checkoutAttributeParser;
            _permissionService = permissionService;
            _downloadService = downloadService;
            _tipsCheckoutAttributeParser = tipsCheckoutAttributeParser;
            _partialPaymentService = partialPaymentService;
            _webHelper = webHelper;
            _storeService = storeService;
            _dateTimeHelper = dateTimeHelper;
            _taxSettings = taxSettings;
            _currencySettings = currencySettings;
            _encryptionService = encryptionService;
            _productAttributeParser = productAttributeParser;
            _vendorService = vendorService;
            _orderTotalCalculationService = orderTotalCalculationService;
            _quickCheckoutPluginService = quickCheckoutPluginService;
        }

        #endregion

        #region Utilites

        [NonAction]
        protected string GetViewname(string viewname)
        {
            return "~/Plugins/ShopFast.Misc.QuickCheckout/Views/QuickCheckout/" + viewname + ".cshtml";
        }

        [NonAction]//Done
        protected string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View,
                                             ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        [NonAction]
        protected Address SaveAddress(QuickCheckoutModel model, FormCollection form)
        {
            var customer = _customerService.GetCustomerById(model.CustomerId.GetValueOrDefault()) ??
                           _workContext.CurrentCustomer;

            var billingAddressModel = new AddressModel();
            TryUpdateModel(billingAddressModel, "BillingAddress");

            var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
            var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
            foreach (var error in customAttributeWarnings)
            {
                ModelState.AddModelError("", error);
            }

            //validate model
            TryValidateModel(billingAddressModel);
            /*if (!ModelState.IsValid)
            {
                return null;
            }*/

            var billingAddress = customer.Addresses.ToList().FindAddress(
                billingAddressModel.FirstName, billingAddressModel.LastName, billingAddressModel.PhoneNumber,
                billingAddressModel.Email, billingAddressModel.FaxNumber, billingAddressModel.Company,
                billingAddressModel.Address1, billingAddressModel.Address2, billingAddressModel.City,
                billingAddressModel.StateProvinceId, billingAddressModel.ZipPostalCode,
                billingAddressModel.CountryId, customAttributes);

            if (billingAddress == null)
            {
                //address is not found. let's create a new one
                billingAddress = billingAddressModel.ToEntity();
                billingAddress.CustomAttributes = customAttributes;
                billingAddress.CreatedOnUtc = DateTime.UtcNow;
                //some validation
                if (billingAddress.CountryId == 0)
                    billingAddress.CountryId = null;
                if (billingAddress.StateProvinceId == 0)
                    billingAddress.StateProvinceId = null;
                if (billingAddress.CountryId.HasValue && billingAddress.CountryId.Value > 0)
                {
                    billingAddress.Country = _countryService.GetCountryById(billingAddress.CountryId.Value);
                }
                customer.Addresses.Add(billingAddress);
            }
            customer.BillingAddress = billingAddress;

            if (model.RequiresShipping)
            {
                customer.ShippingAddress = billingAddress;

                if (model.UseDifferentAddressForShipping)
                {
                    var shippingAddressModel = new AddressModel();
                    TryUpdateModel(shippingAddressModel, "ShippingAddress");
                    TryValidateModel(shippingAddressModel);

                    var shippingAddress = customer.Addresses.ToList().FindAddress(
                        shippingAddressModel.FirstName, shippingAddressModel.LastName, shippingAddressModel.PhoneNumber,
                        shippingAddressModel.Email, shippingAddressModel.FaxNumber, shippingAddressModel.Company,
                        shippingAddressModel.Address1, shippingAddressModel.Address2, shippingAddressModel.City,
                        shippingAddressModel.StateProvinceId, shippingAddressModel.ZipPostalCode,
                        shippingAddressModel.CountryId, customAttributes);

                    if (shippingAddress == null)
                    {
                        //address is not found. let's create a new one
                        shippingAddress = shippingAddressModel.ToEntity();
                        shippingAddress.CustomAttributes = customAttributes;
                        shippingAddress.CreatedOnUtc = DateTime.UtcNow;
                        //some validation
                        if (shippingAddress.CountryId == 0)
                            shippingAddress.CountryId = null;
                        if (shippingAddress.StateProvinceId == 0)
                            shippingAddress.StateProvinceId = null;
                        if (shippingAddress.CountryId.HasValue && shippingAddress.CountryId.Value > 0)
                        {
                            shippingAddress.Country = _countryService.GetCountryById(shippingAddress.CountryId.Value);
                        }
                        customer.Addresses.Add(shippingAddress);
                    }

                    customer.ShippingAddress = shippingAddress;
                }
            }

            _customerService.UpdateCustomer(customer);

            return billingAddress;
        }

        [NonAction]
        protected ActionResult GetActionResult(QuickCheckoutModel model, string ids = "")
        {
            var orderIds = _quickCheckoutPluginService.GetOrderIds(ids);
            var cart = _quickCheckoutPluginService.GetShoppingCart(orderIds);

            var customer = _customerService.GetCustomerById(model.CustomerId.GetValueOrDefault()) ??
                          _workContext.CurrentCustomer;

            var paymentMethod = model.PaymentMethodSystemName;

            if (!String.IsNullOrEmpty(paymentMethod) && customer != null)
            {
                _genericAttributeService.SaveAttribute(customer,
                    SystemCustomerAttributeNames.SelectedPaymentMethod, paymentMethod, _storeContext.CurrentStore.Id);
            }

            model = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart,
                        orderIds,
                        model.Warnings,
                        model.WarningsPayment,
                        model.WarningsShipping,
                        showPartialPaymentSelector: true,
                        customerId: model.CustomerId,
                        area: model.Area
                        );

            model.PaymentMethodSystemName = paymentMethod;

            return View(GetViewname("QuickCheckout"), model);
        }

        [NonAction]
        protected QuickCheckoutModel.DiscountBoxModel GetAppliedDiscount(Customer customer)
        {
            var model = new QuickCheckoutModel.DiscountBoxModel
            {
                Display = true
            };

            try
            {
                var discount = _discountService.GetDiscountByCouponCode(_genericAttributeService
                               .GetAttributesForEntity(customer.Id, "Customer").First(p => p.Key == "DiscountCouponCode").Value);

                if (discount != null)
                {
                    model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied");
                    model.IsApplied = true;
                    model.CurrentCode = discount.CouponCode;
                }
            }
            catch (Exception)
            {
                // customer haven't any records in genericAttributes table
            }

            return model;
        }

        #endregion

        #region AJAX Methods

        [HttpPost]
        public ActionResult AjaxOrderSummary(string shippingoption, string paymentmethod, string ids = "", int? customerId = null)
        {
            var orderIds = _quickCheckoutPluginService.GetOrderIds(ids);
            var cart = _quickCheckoutPluginService.GetShoppingCart(orderIds, authorizeOnly: false);

            Customer customer = _workContext.CurrentCustomer;
            if (customerId.HasValue)
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault());

            #region Set Shipping Method

            if (cart.RequiresShipping() || !String.IsNullOrEmpty(shippingoption))
            {
                if (String.IsNullOrEmpty(shippingoption))
                    throw new Exception("Selected shipping method can't be parsed");

                var splittedOption = shippingoption.Split(new[] { "___" }, StringSplitOptions.RemoveEmptyEntries);
                if (splittedOption.Length != 2)
                    throw new Exception("Selected shipping method can't be parsed");
                string selectedName = splittedOption[0];
                string shippingRateComputationMethodSystemName = splittedOption[1];

                var shippingOptions =
                    customer.GetAttribute<List<ShippingOption>>(
                        SystemCustomerAttributeNames.OfferedShippingOptions, _storeContext.CurrentStore.Id);
                if (shippingOptions == null || shippingOptions.Count == 0)
                {
                    shippingOptions = _shippingService
                        .GetShippingOptions(cart, customer.ShippingAddress,
                            shippingRateComputationMethodSystemName, _storeContext.CurrentStore.Id)
                        .ShippingOptions
                        .ToList();
                }
                else
                {
                    shippingOptions =
                        shippingOptions.Where(
                            so =>
                                so.ShippingRateComputationMethodSystemName.Equals(
                                    shippingRateComputationMethodSystemName, StringComparison.InvariantCultureIgnoreCase))
                            .ToList();
                }

                var shippingOption = shippingOptions
                    .Find(
                        so =>
                            !String.IsNullOrEmpty(so.Name) &&
                            so.Name.Equals(selectedName, StringComparison.InvariantCultureIgnoreCase));
                if (shippingOption == null)
                    throw new Exception("Selected shipping method can't be loaded");

                _genericAttributeService.SaveAttribute(customer,
                    SystemCustomerAttributeNames.SelectedShippingOption, shippingOption, _storeContext.CurrentStore.Id);
            }

            #endregion

            #region Set Payment Method

            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            if (paymentMethodInst == null ||
                !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
                !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
                throw new Exception("Selected payment method can't be parsed");

            _genericAttributeService.SaveAttribute(customer,
                SystemCustomerAttributeNames.SelectedPaymentMethod, paymentmethod, _storeContext.CurrentStore.Id);

            #endregion

            CustomOrderTotalsModel model = null;
            if (orderIds.Count == 0)
            {
                model = _invoiceTotalCalculationService.PrepareOrderTotalsModel(cart);
            }
            if (orderIds.Count == 1)
            {
                model = _invoiceTotalCalculationService.PrepareOrderTotalsModel(cart, orderId: orderIds.First());
            }
            if (orderIds.Count > 1)
            {
                var orders = _quickCheckoutPluginService.GetOrders(orderIds);
                model = new CustomOrderTotalsModel
                {
                    SubTotal = _priceFormatter.FormatPrice(orders.Sum(o => o.OrderSubtotalExclTax), true, false),
                    DisplayTax = orders.Sum(o => o.OrderTax) > decimal.Zero,
                    Tax = _priceFormatter.FormatPrice(orders.Sum(o => o.OrderTax), true, false),
                    OrderTotal = _priceFormatter.FormatPrice(orders.Sum(o => o.OrderTotal), true, false)
                };
            }

            return PartialView(GetViewname("OrderSummary"), model);
        }

        [HttpPost]
        public ActionResult AjaxPaymentInfo(string paymentmethod)
        {
            var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentInfoModel(paymentMethod);

            return PartialView(GetViewname("PaymentInfo"), paymentInfoModel);
            //return Json(RenderPartialViewToString(GetViewname("PaymentInfo"), paymentInfoModel));
        }

        [HttpPost]
        public ActionResult AjaxPaymentMethod(QuickCheckoutModel model, FormCollection form)
        {
            var cart = _quickCheckoutPluginService.GetShoppingCart(_quickCheckoutPluginService.GetOrderIds(model.OrderIds));

            _quickCheckoutPluginService.ITPPreparePaymentMethodModel(cart, model);

            return Json(model.PaymentMethods);
        }

        [HttpPost]
        public ActionResult AjaxShippingMethod(QuickCheckoutModel model, FormCollection form)
        {
            if (model.ShippingAddress.CountryId == 0 || model.ShippingAddress.CountryId == null)
                return null;

            Customer customer = _workContext.CurrentCustomer;
            if (model.CustomerId.HasValue)
                customer = _customerService.GetCustomerById(model.CustomerId.GetValueOrDefault());

            var cart = _quickCheckoutPluginService.GetShoppingCart(_quickCheckoutPluginService.GetOrderIds(model.OrderIds));

            int shippingAddressId;
            int.TryParse(form["ShippingAddress.Id"], out shippingAddressId);

            var address = customer.Addresses.FirstOrDefault(a => a.Id == shippingAddressId) ??
                          new Address();

            address.CountryId = model.ShippingAddress.CountryId;
            address.StateProvinceId = model.ShippingAddress.StateProvinceId > 0
                ? model.ShippingAddress.StateProvinceId
                : null;

            customer.ShippingAddress = address;

            _quickCheckoutPluginService.ITPPrepareShippingMethodModel(cart, customer.ShippingAddress, model);
            return Json(model.ShippingMethods);
        }

        [HttpPost]
        public ActionResult AjaxSetPaymentSection(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);

            if (order == null)
            {
                return new NullJsonResult();
            }

            var cart = _quickCheckoutPluginService.ReOrder(orderId);
            if (!cart.Any() || order.PaymentStatus == PaymentStatus.Paid || order.OrderTotal == 0)
            {
                return Json(RenderPartialViewToString(GetViewname("CheckoutLinks"), new OrderModel { Id = 0 }));
            }

            return Json(RenderPartialViewToString(GetViewname("CheckoutLinks"), new OrderModel { Id = orderId }));
        }

        #region Discounts

        [HttpPost] //Done
        public ActionResult AjaxGetAppliedDiscount(int? customerId = null)
        {
            Customer customer = _workContext.CurrentCustomer;
            if (customerId.HasValue)
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault()) ?? customer;

            var model = new QuickCheckoutModel.DiscountBoxModel
            {
                Display = true
            };
            model = GetAppliedDiscount(customer);
            return Json(new
            {
                partial = RenderPartialViewToString(GetViewname("_DiscountBox"),
                    model)
            });
        }

        [HttpPost] //Done
        public ActionResult AjaxApplyDiscountCoupon(string discountcouponcode, FormCollection form, int? customerId = null)
        {
            var model = new QuickCheckoutModel.DiscountBoxModel();
            try
            {
                Customer customer = _workContext.CurrentCustomer;
                if (customerId.HasValue)
                    customer = _customerService.GetCustomerById(customerId.GetValueOrDefault()) ?? customer;

                if (!String.IsNullOrWhiteSpace(discountcouponcode))
                {
                    var discount = _discountService.GetDiscountByCouponCode(discountcouponcode);
                    bool isDiscountValid = discount != null &&
                                           discount.RequiresCouponCode
                        //nop3.7 upgrade begin
                        //&& _discountService.IsDiscountValid(discount, customer, discountcouponcode)
                        //nop3.7 upgrade end
                                           ;
                    if (isDiscountValid)
                    {
                        _genericAttributeService.SaveAttribute(customer,
                            Nop.Core.Domain.Customers.SystemCustomerAttributeNames.DiscountCouponCode,
                            discountcouponcode);
                        model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied");
                        model.IsApplied = true;
                        model.CurrentCode = discount.CouponCode;
                    }
                    else
                    {
                        model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount");
                        model.IsApplied = false;
                    }
                }
                else
                {
                    model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount");
                    model.IsApplied = false;
                }
            }
            catch (Exception exc)
            {
                model.Message = exc.Message;
                model.CurrentCode = null;
            }

            model.Display = true;
            return Json(new
            {
                value = model.CurrentCode,
                partial = RenderPartialViewToString(GetViewname("_DiscountBox"), model)
            });
        }

        [HttpPost] //Done
        public ActionResult AjaxRemoveDiscountCoupon(int? customerId = null)
        {
            Customer customer = _workContext.CurrentCustomer;
            if (customerId.HasValue)
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault()) ?? customer;
            if (customer != null)
            {
                _genericAttributeService.SaveAttribute<string>(customer,
                    Nop.Core.Domain.Customers.SystemCustomerAttributeNames.DiscountCouponCode, null);
            }

            return Json(new
            {
                partial = RenderPartialViewToString(GetViewname("_DiscountBox"),
                    new QuickCheckoutModel.DiscountBoxModel
                    {
                        Display = true
                    })
            });
        }

        #endregion

        #region GiftCards

        [HttpPost]
        public ActionResult AjaxApplyGiftCard(string giftcardcouponcode, int? customerId = null)
        {
            Customer customer = _workContext.CurrentCustomer;
            if (customerId.HasValue)
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault()) ?? customer;

            var model = new QuickCheckoutModel.GiftCardBoxModel();
            if (!String.IsNullOrWhiteSpace(giftcardcouponcode))
            {
                var giftCard = _giftCardService.GetAllGiftCards(giftCardCouponCode: giftcardcouponcode).FirstOrDefault();
                bool isGiftCardValid = giftCard != null && giftCard.IsGiftCardValid();
                if (isGiftCardValid)
                {
                    customer.ApplyGiftCardCouponCode(giftcardcouponcode);
                    _customerService.UpdateCustomer(customer);
                    model.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.Applied");
                }
                else
                    model.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.WrongGiftCard");
            }
            else
                model.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.WrongGiftCard");

            model.Display = true;
            return Json(new
            {
                value = giftcardcouponcode,
                partial = RenderPartialViewToString(GetViewname("_GiftCardBox"), model)
            });
        }

        [HttpPost] //Done
        public ActionResult AjaxRemoveGiftCard(string giftcardId, int? customerId = null)
        {
            Customer customer = _workContext.CurrentCustomer;
            if (customerId.HasValue)
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault()) ?? customer;

            //get gift card identifier
            int giftCardId = Convert.ToInt32(giftcardId);
            var gc = _giftCardService.GetGiftCardById(giftCardId);
            if (gc != null)
            {
                customer.RemoveGiftCardCouponCode(gc.GiftCardCouponCode);
                _customerService.UpdateCustomer(customer);
            }

            return new NullJsonResult();
        }

        #endregion

        #endregion

        #region Methods

        [AdminAuthorize]
        public ActionResult Configure()
        {
            return View(GetViewname("Configure"));
        }

        [HttpPost, ActionName("Configure")]
        [AdminAuthorize]
        [ChildActionOnly]
        [FormValueRequired("default-settings")]
        public ActionResult DefaultSettings()
        {
            QuickCheckoutPlugin.SetDefaultSettings();
            return Configure();
        }

        public ActionResult QuickCheckout(int? orderId = null)
        {
            var cart = _quickCheckoutPluginService.GetShoppingCart(orderId);

            if (cart.Count == 0)
                return RedirectToRoute("ShoppingCart");

            var model = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart, orderId: orderId, showPartialPaymentSelector: true);

            return View(GetViewname("QuickCheckout"), model);
        }

        [ActionName("QuickCheckout"), HttpPost]
        public ActionResult Confirm(QuickCheckoutModel model, FormCollection form)
        {
            try
            {
                if (SaveAddress(model, form) == null)
                {
                    throw new Exception("Address is empty");
                }

                var cart = _quickCheckoutPluginService.GetShoppingCart(model.OrderId);

                if (cart.Count == 0)
                    throw new Exception("Your cart is empty");

                if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                {
                    //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.AnonymousNotAllowed"));
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.AnonymousNotAllowed"));
                }

                //prevent 2 orders being placed within an X seconds time frame
                /*if (!_prepareCheckoutModels.IsMinimumOrderPlacementIntervalValid(_workContext.CurrentCustomer))
                {
                    model.Warnings.Add(_localizationService.GetResource("Checkout.MinOrderPlacementInterval"));
                    throw new Exception(_localizationService.GetResource("Checkout.MinOrderPlacementInterval"));
                }*/

                var paymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                    SystemCustomerAttributeNames.SelectedPaymentMethod, _genericAttributeService,
                    _storeContext.CurrentStore.Id)
                    ?? model.PaymentMethodSystemName;
                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentMethodSystemName)
                                    ?? _paymentService.LoadPaymentMethodBySystemName(model.PaymentMethodSystemName);
                if (paymentMethod == null)
                {
                    //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethodNotSelected"));
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethodNotSelected"));
                }

                var paymentControllerType = paymentMethod.GetControllerType();
                var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as BasePaymentController;
                if (paymentController == null)
                    throw new Exception("Payment controller cannot be loaded");

                var warnings = paymentController.ValidatePaymentForm(form);
                foreach (var warning in warnings)
                    ModelState.AddModelError("PaymentInfo", warning);

                model.WarningsPayment = warnings;

                if (warnings.Count > 0)
                {
                    //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.IncorrectPaymentInfo"));
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.IncorrectPaymentInfo"));
                }

                if (model.PaymentOperationType == PaymentOperationType.Partial &&
                        model.PartialPaymentAmount == decimal.Zero)
                {
                    throw new Exception("Partial payment amount should be higher than 0.00");
                }

                //place order
                var processPaymentRequest = paymentController.GetPaymentInfo(form);

                if (processPaymentRequest == null)
                {
                    //Check whether payment workflow is required
                    if (_prepareCheckoutModels.IsPaymentWorkflowRequired(cart))
                    {
                        //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.NotEnteredPaymentInfo"));
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.NotEnteredPaymentInfo"));
                    }
                    processPaymentRequest = new ProcessPaymentRequest();
                }
                
                processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
                processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
                processPaymentRequest.PaymentMethodSystemName = paymentMethodSystemName;//_workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.SelectedPaymentMethod, _genericAttributeService, _storeContext.CurrentStore.Id);
                if (model.PaymentOperationType == PaymentOperationType.Partial)
                    processPaymentRequest.OrderTotal = model.PartialPaymentAmount;

                Order paymentOrder = null;
                var placeOrderResult = _orderProcessingService.PlaceOrder(processPaymentRequest, model.PaymentOperationType,
                     out paymentOrder);
                if (placeOrderResult.Success)
                {
                    var order = paymentOrder ?? placeOrderResult.PlacedOrder;
                    var customer = _customerService.GetCustomerById(model.CustomerId.GetValueOrDefault());
                    order.CheckoutAttributesXml = _quickCheckoutPluginService.ParseAndSaveCheckoutAttributesExt(cart, form, customer ?? _workContext.CurrentCustomer);//order.CheckoutAttributesXml = ParseAndSaveCheckoutAttributesExt(cart, form, cart.GetCustomer());
                    _orderService.UpdateOrder(order);

                    if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                    {
                        //redirect
                        //return RedirectToAction("OpcCompleteRedirectionPayment", "Checkout");
                        return CompleteRedirectionPayment(order);
                    }

                    var postProcessPaymentRequest = new PostProcessPaymentRequest
                    {
                        Order = order
                    };
                    _paymentService.PostProcessPayment(postProcessPaymentRequest);
                    //success
                    return CheckoutCompleted(postProcessPaymentRequest.Order.Id, false);
                    //return RedirectToAction("Completed", "Checkout", new { orderId = postProcessPaymentRequest.Order.Id });
                }

                //error
                foreach (var error in placeOrderResult.Errors)
                    model.Warnings.Add(error);

                if (placeOrderResult.PlacedOrder != null)
                    return GetActionResult(model, placeOrderResult.PlacedOrder.Id.ToString());

                return GetActionResult(model, null);
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                model.Warnings.Add(exc.Message);

                return GetActionResult(model, null);
            }
        }

        [HttpPost]
        public ActionResult OrderQuickCheckout(QuickCheckoutModel model, FormCollection form)
        {
            if (!string.IsNullOrEmpty(model.OrderIds))
            {
                try
                {
                    if (SaveAddress(model, form) == null)
                    {
                        throw new Exception("Address is empty");
                    }

                    var orderIds = _quickCheckoutPluginService.GetOrderIds(model.OrderIds);
                    var orders = _quickCheckoutPluginService.GetOrders(orderIds);
                    if (!orders.Any())
                        return HttpNotFound();
                    Customer customer = _customerService.GetCustomerById(model.CustomerId.GetValueOrDefault());
                    if (customer == null)
                        throw new Exception("Customer not found");

                    var cart = _quickCheckoutPluginService.GetShoppingCart(orderIds, authorizeOnly: false);
                    var remainingBalance = _partialPaymentService.GetRemainingBalance(orders);

                    if ((customer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                    {
                        //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.AnonymousNotAllowed"));
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.AnonymousNotAllowed"));
                    }
                    
                    var paymentMethodSystemName = model.PaymentMethodSystemName;
                    var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentMethodSystemName);
                    if (paymentMethod == null)
                    {
                        //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethodNotSelected"));
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethodNotSelected"));
                    }
                    
                    var paymentControllerType = paymentMethod.GetControllerType();
                    var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as BasePaymentController;
                    if (paymentController == null)
                        throw new Exception("Payment controller cannot be loaded");

                    //_logger.InsertLog(LogLevel.Debug, "QC: 4.1");
                    var warnings = paymentController.ValidatePaymentForm(form);
                    foreach (var warning in warnings)
                        ModelState.AddModelError("PaymentInfo", warning);

                    model.WarningsPayment = warnings;

                    //_logger.InsertLog(LogLevel.Debug, "QC: 5");
                    if (warnings.Count > 0)
                    {
                        //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.IncorrectPaymentInfo"));
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.IncorrectPaymentInfo"));
                    }

                    if (model.PaymentOperationType == PaymentOperationType.Partial &&
                        model.PartialPaymentAmount == decimal.Zero)
                    {
                        throw new Exception("Partial payment amount should be higher than 0.00");
                    }

                    //place order
                    var processPaymentRequest = paymentController.GetPaymentInfo(form);

                    if (processPaymentRequest == null)
                    {
                        //Check whether payment workflow is required
                        if (_prepareCheckoutModels.IsPaymentWorkflowRequired(cart))
                        {
                            //model.Warnings.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.NotEnteredPaymentInfo"));
                            throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.NotEnteredPaymentInfo"));
                        }
                        processPaymentRequest = new ProcessPaymentRequest();
                    }

                    var paymentAmount = model.PaymentOperationType == PaymentOperationType.Partial
                        ? model.PartialPaymentAmount
                        : remainingBalance;

                    processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
                    processPaymentRequest.CustomerId = customer.Id;
                    processPaymentRequest.PaymentMethodSystemName = paymentMethodSystemName;
                    //processPaymentRequest.InitialOrderId = order.Id;
                    processPaymentRequest.OrderTotal = paymentAmount;

                    ProcessPaymentResult paymentProcessResult = null;
                    Order paymentOrder;
                    paymentProcessResult = _partialPaymentService.ProcessPaymentForMultipleOrders(processPaymentRequest, orders,
                        out paymentOrder);

                    if (paymentProcessResult.Success && orders.Any())
                    {
                        foreach (var order in orders)
                        {
                            order.CheckoutAttributesXml = _quickCheckoutPluginService.ParseAndSaveCheckoutAttributesExt(
                                _quickCheckoutPluginService.GetShoppingCart(order.Id), form, customer);
                            //order.PaymentMethodSystemName = paymentMethodSystemName;
                            _orderService.UpdateOrder(order);
                        }

                        if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                        {
                            if (model.PaymentOperationType == PaymentOperationType.Full)
                                return CompleteRedirectionPayment(orders, model); 
                            if (model.PaymentOperationType == PaymentOperationType.Partial)
                                return CompleteRedirectionPayment(new List<Order>() { paymentOrder }, model);
                            //return CompleteRedirectionPayment(orders, model);
                        }

                        if (model.PaymentOperationType == PaymentOperationType.Full)
                        {
                            orders.ForEach(order =>
                            {
                                var postProcessPaymentRequest = new PostProcessPaymentRequest
                                {
                                    Order = order
                                };
                                _paymentService.PostProcessPayment(postProcessPaymentRequest);
                            });
                        } 
                        else if (model.PaymentOperationType == PaymentOperationType.Partial)
                        {
                            var postProcessPaymentRequest = new PostProcessPaymentRequest
                            {
                                Order = paymentOrder
                            };
                            _paymentService.PostProcessPayment(postProcessPaymentRequest);
                        }

                        /*foreach (var order in orders)
                        {
                            var postProcessPaymentRequest = new PostProcessPaymentRequest
                            {
                                Order = order
                            };
                            _paymentService.PostProcessPayment(postProcessPaymentRequest);
                        }*/

                        switch (model.Area)
                        {
                            case "Admin":
                                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Payments");
                                break;
                            case "Customer":
                            default:
                                return CheckoutCompleted(paymentOrder != null ? paymentOrder.Id : orders.First().Id, false);
                                //return RedirectToAction("Completed", "Checkout", new { orderId = orders.First().Id });
                                break;
                        }
                    }
                    else
                    {
                        foreach (var error in paymentProcessResult.Errors)
                            model.Warnings.Add(error);
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Payment.ProcessFailed"));
                    }
                }
                catch (Exception exc)
                {
                    model.Warnings.Add(exc.Message);
                    _logger.InsertLog(LogLevel.Error, exc.Message, exc.InnerException?.Message);
                    return GetActionResult(model, model.OrderIds);
                }
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult AdminOrderQuickCheckout(QuickCheckoutModel model, FormCollection form)
        {
            return OrderQuickCheckout(model, form);
        }

        public ActionResult OrderQuickCheckout(string ids = "")
        {
            var orderIds = _quickCheckoutPluginService.GetOrderIds(ids);
            var orders = _quickCheckoutPluginService.GetOrders(orderIds);
            if (!orderIds.Any() || _quickCheckoutPluginService.GetOrders(orderIds).Any(order => order.PaymentStatus == PaymentStatus.Paid))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            if (orders.Any(order => order.Customer != orders.First().Customer))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var cart = _quickCheckoutPluginService.GetShoppingCart(_quickCheckoutPluginService.GetOrderIds(ids), authorizeOnly: true);
            if (cart == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            if (!cart.Any() || _partialPaymentService.GetRemainingBalance(orders) == decimal.Zero)
            {
                // cart is empty, need to redirect back
                return RedirectToAction("UnpaidOrders", "OrderPaymentWidget");
            }

            var model = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart, orderIds: _quickCheckoutPluginService.GetOrderIds(ids), showPartialPaymentSelector: true);

            return View(GetViewname("QuickCheckout"), model);
        }

        public ActionResult AnonymousOrderSearch()
        {
            var model = new OrderSearchModel();
            return View(GetViewname("AnonymousInvoiceSearcher"), model);
        }

        [HttpPost]
        public ActionResult AnonymousOrderSearch(OrderSearchModel model)
        {

            var order = _orderService.GetOrderById(model.OrderId.GetValueOrDefault());
            if (order == null || model.Amount == null || order.OrderTotal != model.Amount)
            {
                model.Warnings = new List<string>()
                {
                    _localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.OrderNotFound")
                };
                return View(GetViewname("AnonymousInvoiceSearcher"), model);
            }

            if (order.PaymentStatus == PaymentStatus.Paid || order.OrderTotal == decimal.Zero)
            {
                model.Warnings = new List<string>()
                {
                    _localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.Order.NotRequiresCheckout")
                };
                return View(GetViewname("AnonymousInvoiceSearcher"), model);
            }

            var cart = _quickCheckoutPluginService.GetShoppingCart(order.Id, authorizeOnly: false);
            if (cart == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            if (!cart.Any() || _partialPaymentService.GetRemainingBalance(order) == decimal.Zero)
            {
                // cart is empty, need to redirect back
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var qcmodel = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart, orderId: order.Id,
                showPartialPaymentSelector: true);
            return View(GetViewname("QuickCheckout"), qcmodel);
        }

        public ActionResult CryptedMakeAPayment(string cryptedId)
        {
            try
            {
                var order = _orderService.GetOrderById(_orderService.GetOrderDecryptedId(cryptedId));
                //var order = _orderService.GetOrderByGuid(Guid.Parse(cryptedId));
                if (order == null)
                    throw new Exception();

                //Render view
                var model = new OrderSearchModel();
                if (order.PaymentStatus == PaymentStatus.Paid || order.OrderTotal == decimal.Zero)
                {
                    model.Warnings = new List<string>()
                    {
                        _localizationService.GetResource("ShopFast.Plugins.Misc.QuickCheckout.Order.NotRequiresCheckout")
                    };
                    return View(GetViewname("AnonymousInvoiceSearcher"), model);
                }

                var cart = _quickCheckoutPluginService.GetShoppingCart(order.Id, authorizeOnly: false);
                if (cart == null)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

                var qcmodel = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart, orderId: order.Id,
                    showPartialPaymentSelector: true);

                return View(GetViewname("QuickCheckout"), qcmodel);
            }
            catch (Exception exc)
            {
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
        }

        [AdminAuthorize]
        public ActionResult AdminOrderQuickCheckout(string ids = "")
        {
            var orderIds = _quickCheckoutPluginService.GetOrderIds(ids);
            var orders = _quickCheckoutPluginService.GetOrders(orderIds);
            var cart = _quickCheckoutPluginService.GetShoppingCart(orderIds, authorizeOnly: false);

            if (!cart.Any() || _partialPaymentService.GetRemainingBalance(orders) == decimal.Zero)
            {
                // cart is empty, need to redirect back
                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Payments");
            }

            if (!orderIds.Any() || _quickCheckoutPluginService.GetOrders(orderIds)
                .Any(order => order.PaymentStatus == PaymentStatus.Paid))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            if (orders.Any(order => order.Customer != orders.First().Customer))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var model = _quickCheckoutPluginService.PrepareQuickCheckoutModel(cart, orderIds,
                showPartialPaymentSelector: true, area: "Admin");

            return View(GetViewname("AdminQuickCheckout"), model);
        }

        public ActionResult CompleteRedirectionPayment(Order order)
        {
            try
            {
                if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                    return new HttpUnauthorizedResult();

                if (order == null)
                    return RedirectToRoute("HomePage");

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(order.PaymentMethodSystemName);
                if (paymentMethod == null)
                    return RedirectToRoute("HomePage");
                if (paymentMethod.PaymentMethodType != PaymentMethodType.Redirection)
                    return RedirectToRoute("HomePage");

                //Redirection will not work on one page checkout page because it's AJAX request.
                //That's why we process it here
                var postProcessPaymentRequest = new PostProcessPaymentRequest
                {
                    Order = order
                };

                _paymentService.PostProcessPayment(postProcessPaymentRequest);

                if (_webHelper.IsRequestBeingRedirected || _webHelper.IsPostBeingDone)
                {
                    //redirection or POST has been done in PostProcessPayment
                    return Content("Redirected");
                }

                //if no redirection has been done (to a third-party payment page)
                //theoretically it's not possible
                return RedirectToRoute("CheckoutCompleted", new { orderId = order.Id });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Content(exc.Message);
            }
        }

        public ActionResult CheckoutCompleted(int? orderId, bool authorixationRequires = true)
        {
            //validation
            if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                return new HttpUnauthorizedResult();

            Order order = null;
            if (orderId.HasValue)
            {
                //load order by identifier (if provided)
                order = _orderService.GetOrderById(orderId.Value);
            }
            if (order == null)
            {
                order = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                customerId: _workContext.CurrentCustomer.Id, pageSize: 1)
                    .FirstOrDefault();
            }
            if (order == null || order.Deleted || (authorixationRequires && _workContext.CurrentCustomer.Id != order.CustomerId))
            {
                return RedirectToRoute("HomePage");
            }

            //disable "order completed" page?
            if (_orderSettings.DisableOrderCompletedPage)
            {
                return RedirectToRoute("OrderDetails", new { orderId = order.Id });
            }

            //model
            var model = new CheckoutCompletedModel
            {
                OrderId = order.Id
            };

            return View(GetViewname("Completed"), model);
        }

        public ActionResult CompleteRedirectionPayment(List<Order> orders, QuickCheckoutModel model)
        {
            try
            {
                if ((_workContext.CurrentCustomer.IsGuest() && !_orderSettings.AnonymousCheckoutAllowed))
                    return new HttpUnauthorizedResult();

                if (!orders.Any())
                    return RedirectToRoute("HomePage");

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(orders.First().PaymentMethodSystemName);
                if (paymentMethod == null)
                    return RedirectToRoute("HomePage");
                if (paymentMethod.PaymentMethodType != PaymentMethodType.Redirection)
                    return RedirectToRoute("HomePage");

                foreach (var order in orders)
                {
                    var postProcessPaymentRequest = new PostProcessPaymentRequest
                    {
                        Order = order
                    };
                    _paymentService.PostProcessPayment(postProcessPaymentRequest);
                }

                if (_webHelper.IsRequestBeingRedirected || _webHelper.IsPostBeingDone)
                {
                    return Content("Redirected");
                }

                switch (model.Area)
                {
                    case "Admin":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Payments");
                        break;
                    case "Customer":
                    default:
                        return RedirectToAction("Completed", "Checkout", new { orderId = orders.First().Id });
                        break;
                }
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Content(exc.Message);
            }
        }

        [ChildActionOnly]
        public ActionResult PublicInfo(string widgetZone, object additionalData = null)
        {
            if (additionalData == null || Int32.Parse(additionalData.ToString()) <= 0)
            {
                return null;
            }

            var orderId = Int32.Parse(additionalData.ToString());
            var order = _orderService.GetOrderById(orderId);

            if (order != null && order.OrderTotal > 0 && order.OrderItems.Any())
            {
                var payments = _partialPaymentService.GetOrderPayments(order)
                    .Select(p => new OrderModel
                        {
                            CreatedOn = p.CreatedOnUtc,
                            OrderTotal = _priceFormatter.FormatPrice(p.OrderTotal, true, false),
                            PaymentStatus = p.PaymentStatus.ToString(),
                            PaymentMethod = p.PaymentMethodSystemName,
                            CustomerEmail = p.Customer != null ? p.Customer.Email : ""
                        })
                    .ToList();

                return View(GetViewname("PaymentSection"),
                    new OrderPaymentsModel
                    {
                        OrderId = order.Id,
                        Payments = payments
                    }
                );
            }
            return null;
        }

        #endregion
    }
}
