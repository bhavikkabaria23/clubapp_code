﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Services.Configuration;
using Nop.Services.Media;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.Customer.GoogleMap.Models;
using System.Collections.Generic;
using Nop.Services.Customers;
using System.Linq;
using Nop.Core.Domain.Customers;
using System;
using Nop.Services.Directory;
using Nop.Services.Common;
using Shopfast.Plugin.Customer.GoogleMap.Cache;
using Nop.Core.Caching;
using Shopfast.Plugin.Customer.GoogleMap.Services;
using System.Net;
using System.Xml.Linq;

namespace Shopfast.Plugin.Customer.GoogleMap.Controllers
{
    public class GoogleMapController : BaseController
    {
        //private readonly IWorkContext _workContext;
        //private readonly IStoreContext _storeContext;
        //private readonly IStoreService _storeService;
        //private readonly IPictureService _pictureService;
        //private readonly ISettingService _settingService;

        private readonly ICountryService _countryService;
        private readonly IGoogleMapService _googleMapService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICacheManager _cacheManager;

        public GoogleMapController(
            //IWorkContext workContext,
            //IStoreContext storeContext, IStoreService storeService, 
            //IPictureService pictureService, ISettingService settingService
            IGoogleMapService googleMapService, ICountryService countryService, IStateProvinceService stateProvinceService, ICacheManager cacheManager)
        {
            //this._workContext = workContext;
            //this._storeContext = storeContext;
            //this._storeService = storeService;
            //this._pictureService = pictureService;
            //this._settingService = settingService;
            this._googleMapService = googleMapService;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._cacheManager = cacheManager;
        }
        
        [ChildActionOnly]        
        public ActionResult ShowGoogleMap()
        {
            //var customers = _customerService.GetAllCustomersForMap();
            string cacheKey = string.Format(ModelCacheEventConsumer.GOOGLEMAP_LOCATIONS_MODEL_KEY);
            List<Location> lstLocations = _cacheManager.Get(cacheKey, () =>
            {
                return GetLocations();
            });            
            ViewBag.loc = lstLocations;
            return View("~/Plugins/Shopfast.Plugin.Customer.GoogleMap/Views/GoogleMap/GoogleMap.cshtml");
        }

        private List<Location> GetLocations()
        {
            var customers = _googleMapService.GetAllCustomers();

            List<Location> lstLocations = new List<Location>();

            foreach (var item in customers)
            {
                Location locobj = new Location();                

                string customerName = item.GetFullName();
                string address1 = string.Empty;
                string city = string.Empty;
                string state = string.Empty;
                int stateId = 0;
                string country = string.Empty;
                int countryId = 0;
                string zipcode = string.Empty;
                string customerInfo = string.Empty;

                address1 = item.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress);
                city = item.GetAttribute<string>(SystemCustomerAttributeNames.City);
                stateId = Convert.ToInt32(item.GetAttribute<string>(SystemCustomerAttributeNames.StateProvinceId));
                if (stateId > 0)
                {
                    state = _stateProvinceService.GetStateProvinceById(stateId).Name;
                }
                countryId = Convert.ToInt32(item.GetAttribute<string>(SystemCustomerAttributeNames.CountryId));
                if (countryId > 0)
                {
                    country = _countryService.GetCountryById(countryId).Name;
                }
                zipcode = item.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode);
              
                if (!string.IsNullOrEmpty(address1))
                {
                    customerInfo += address1;
                }
                if (!string.IsNullOrEmpty(city))
                {
                    customerInfo = customerInfo + "," + city;
                }
                if (!string.IsNullOrEmpty(state))
                {
                    customerInfo = customerInfo + "," + state;
                }
                if (!string.IsNullOrEmpty(country))
                {
                    customerInfo = customerInfo + "," + country;
                }
                if (!string.IsNullOrEmpty(zipcode))
                {
                    customerInfo = customerInfo + "," + zipcode;
                }                
                locobj = GetLatLonFromAddress(customerInfo);
                locobj.customerInfo = customerName + " : " + customerInfo;
                if (!string.IsNullOrEmpty(locobj.lat) && !string.IsNullOrEmpty(locobj.lng))
                {
                    lstLocations.Add(locobj);
                }
            }
            return lstLocations;
        }

        private static Location GetLatLonFromAddress(string fulladdress)
        {            
            Location location = new Location();
            try
            {                
                var requestUri = string.Format("http://maps.googleapis.com/maps/api/geocode/xml?address={0}&sensor=false", Uri.EscapeDataString(fulladdress));
                var request = WebRequest.Create(requestUri);
                var response = request.GetResponse();
                var xdoc = XDocument.Load(response.GetResponseStream());

                var result = xdoc.Element("GeocodeResponse").Element("result");
                if (result != null)
                {
                    var locationElement = result.Element("geometry").Element("location");
                    location.lat = locationElement.Element("lat").Value;
                    location.lng = locationElement.Element("lng").Value;                  
                }
                return location;
            }
            catch (Exception ex)
            {
                return location;
            }
        }
    }
}