﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Customer.GoogleMap.Services
{
    public partial interface IGoogleMapService
    {
        IList<Nop.Core.Domain.Customers.Customer> GetAllCustomers();
    }
}
