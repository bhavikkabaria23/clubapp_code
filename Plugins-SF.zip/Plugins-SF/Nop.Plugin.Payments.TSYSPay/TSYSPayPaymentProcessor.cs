using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Plugin.Payments.TSYSPay.Controller;
using Nop.Services.Configuration;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Tax;
using System.Security.Cryptography;
using Nop.Core.Domain.Catalog;
using Nop.Services.Customers;
using System.Text.RegularExpressions;
using System.Xml;

namespace Nop.Plugin.Payments.TSYSPay
{
    public class TSYSPayPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly TSYSPayPaymentSettings _TSYSPayPaymentSettings;
        private readonly ISettingService _settingService;
        private readonly ICurrencyService _currencyService;
        private readonly CurrencySettings _currencySettings;
        private readonly IWebHelper _webHelper;
        private readonly ICheckoutAttributeParser _checkoutAttributeParser;
        private readonly ITaxService _taxService;
        private readonly HttpContextBase _httpContext;
        private readonly ICustomerService _customerService;

        #endregion


        #region Ctor

        public TSYSPayPaymentProcessor(TSYSPayPaymentSettings TSYSPayPaymentSettings,
            ISettingService settingService, ICurrencyService currencyService,
            CurrencySettings currencySettings, IWebHelper webHelper,
            ICheckoutAttributeParser checkoutAttributeParser, ITaxService taxService,
            HttpContextBase httpContext, ICustomerService customerService)
        {
            this._TSYSPayPaymentSettings = TSYSPayPaymentSettings;
            this._settingService = settingService;
            this._currencyService = currencyService;
            this._currencySettings = currencySettings;
            this._webHelper = webHelper;
            this._checkoutAttributeParser = checkoutAttributeParser;
            this._taxService = taxService;
            this._httpContext = httpContext;
            this._customerService = customerService;
        }

        #endregion


        #region Utilities

        /// <summary>
        /// Gets Paypal URL
        /// </summary>
        /// <returns></returns>
        private string GetPaypalUrl()
        {
            return "https://cert.dataxchange.biz/ws/transact.asmx";
        }
        /// <summary>
        /// Gets PDT details
        /// </summary>
        /// <param name="tx">TX</param>
        /// <param name="values">Values</param>
        /// <param name="response">Response</param>
        /// <returns>Result</returns>
        public bool GetPDTDetails(string tx, out Dictionary<string, string> values, out string response)
        {
            var req = (HttpWebRequest)WebRequest.Create(GetPaypalUrl());
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";

            string formContent = string.Format("cmd=_notify-synch&at={0}&tx={1}", _TSYSPayPaymentSettings.DeviceID, tx);
            req.ContentLength = formContent.Length;

            using (var sw = new StreamWriter(req.GetRequestStream(), Encoding.ASCII))
                sw.Write(formContent);

            response = null;
            using (var sr = new StreamReader(req.GetResponse().GetResponseStream()))
                response = HttpUtility.UrlDecode(sr.ReadToEnd());

            values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            bool firstLine = true, success = false;
            foreach (string l in response.Split('\n'))
            {
                string line = l.Trim();
                if (firstLine)
                {
                    success = line.Equals("SUCCESS", StringComparison.OrdinalIgnoreCase);
                    firstLine = false;
                }
                else
                {
                    int equalPox = line.IndexOf('=');
                    if (equalPox >= 0)
                        values.Add(line.Substring(0, equalPox), line.Substring(equalPox + 1));
                }
            }

            return success;
        }

        /// <summary>
        /// Verifies IPN
        /// </summary>
        /// <param name="formString">Form string</param>
        /// <param name="values">Values</param>
        /// <returns>Result</returns>
        public bool VerifyIPN(string formString, out Dictionary<string, string> values)
        {
            var req = (HttpWebRequest)WebRequest.Create(GetPaypalUrl());
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";

            string formContent = string.Format("{0}&cmd=_notify-validate", formString);
            req.ContentLength = formContent.Length;

            using (var sw = new StreamWriter(req.GetRequestStream(), Encoding.ASCII))
            {
                sw.Write(formContent);
            }

            string response = null;
            using (var sr = new StreamReader(req.GetResponse().GetResponseStream()))
            {
                response = HttpUtility.UrlDecode(sr.ReadToEnd());
            }
            bool success = response.Trim().Equals("VERIFIED", StringComparison.OrdinalIgnoreCase);

            values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string l in formString.Split('&'))
            {
                string line = l.Trim();
                int equalPox = line.IndexOf('=');
                if (equalPox >= 0)
                    values.Add(line.Substring(0, equalPox), line.Substring(equalPox + 1));
            }

            return success;
        }
        #endregion

        #region Methods

        public string GetSHA1(string SHA1Data)
        {
            SHA1 sha = new SHA1CryptoServiceProvider();
            string HashedPassword = SHA1Data;
            byte[] hashbytes = Encoding.GetEncoding("ISO-8859-9").GetBytes(HashedPassword);
            byte[] inputbytes = sha.ComputeHash(hashbytes);
            return GetHexaDecimal(inputbytes);
        }
        public string GetHexaDecimal(byte[] bytes)
        {
            StringBuilder s = new StringBuilder();
            int length = bytes.Length;
            for (int n = 0; n <= length - 1; n++)
            {
                s.Append(String.Format("{0,2:x}", bytes[n]).Replace(" ", "0"));
            } return s.ToString();
        }

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        /// 

        protected String GetPaypalCreditCardTypeBySwipe(string creditCardType)
        {

            if (creditCardType.ToLower() == "visa")
                return "%B4003000123456781^VISA/TEST CARD^151250254321987123456789012345?";


            if (creditCardType.ToLower() == "mastercard")
                return "%B5454545454545454^MASTERCARD/TEST CARD^15121015432112345678?";

            if (creditCardType.ToLower() == "americanexpress")
                return "%B371449635398431^AMEX/TEST CARD^1512941116203?";

            if (creditCardType.ToLower() == "discover")
                return "%B6011000995504101^DISCOVER/ TESTCARD^15121011000627210201?";
            return "";
            //throw new NopException("Unknown credit card type");
        }

        protected string GetRequestData(WebRequest request1, string Postdata1)
        {

            byte[] byteArray1 = Encoding.UTF8.GetBytes(Postdata1);
            // Set the ContentType property of the WebRequest.
            request1.ContentType = "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest.
            request1.ContentLength = byteArray1.Length;
            // Get the request stream.
            Stream dataStream1 = request1.GetRequestStream();
            // Write the data to the request stream.


            dataStream1.Write(byteArray1, 0, byteArray1.Length);
            // Close the Stream object.
            dataStream1.Close();
            // Get the response.
            WebResponse response1 = request1.GetResponse();
            // Display the status.
            Console.WriteLine(((HttpWebResponse)response1).StatusDescription);
            // Get the stream containing content returned by the server.
            dataStream1 = response1.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader1 = new StreamReader(dataStream1);
            // Read the content.
            string responseFromServer1 = reader1.ReadToEnd();
            // Display the content.
            Console.WriteLine(responseFromServer1);
            // Clean up the streams.
            reader1.Close();
            dataStream1.Close();
            response1.Close();
            response1.Dispose();
            request1.Abort();
            return responseFromServer1;

        }

        protected string GetRequestData1(WebRequest request11, string Postdata1)
        {

            byte[] byteArray11 = Encoding.UTF8.GetBytes(Postdata1);
            // Set the ContentType property of the WebRequest.
            request11.Method = "POST";
            request11.ContentType = "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest.
            request11.ContentLength = byteArray11.Length;
            // Get the request stream.
            Stream dataStream11 = request11.GetRequestStream();
            // Write the data to the request stream.


            dataStream11.Write(byteArray11, 0, byteArray11.Length);
            // Close the Stream object.
            dataStream11.Close();
            // Get the response.
            WebResponse response1 = request11.GetResponse();
            // Display the status.
            Console.WriteLine(((HttpWebResponse)response1).StatusDescription);
            // Get the stream containing content returned by the server.
            dataStream11 = response1.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader1 = new StreamReader(dataStream11);
            // Read the content.
            string responseFromServer1 = reader1.ReadToEnd();
            // Display the content.
            Console.WriteLine(responseFromServer1);
            // Clean up the streams.
            reader1.Close();
            dataStream11.Close();
            response1.Close();
            response1.Dispose();
            request11.Abort();
            return responseFromServer1;

        }

        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {

            var result = new ProcessPaymentResult();
            Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel PaymentInfoTSYSPayPay = new Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel();
            PaymentInfoTSYSPayPay = (Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel)_httpContext.Session["PaymentInfoTSYSPay"];

            var Cust = _customerService.GetCustomerById(processPaymentRequest.CustomerId);

            if (PaymentInfoTSYSPayPay.CustomValue == "1")
            {

                #region Request to url credit card

                WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

                request.Method = "POST";
                // Create POST data and convert it to a byte array.

                string strCustomerName1 = processPaymentRequest.CreditCardName.Split(',')[0].ToString();
                string strCardNumber1 = processPaymentRequest.CreditCardNumber.Split(',')[0].ToString();

                string Year1 = PaymentInfoTSYSPayPay.ExpireYear.Split(',')[0].ToString().Substring(2, 2);
                string strexpmonth = PaymentInfoTSYSPayPay.ExpireMonth.Split(',')[0].ToString();
                if (strexpmonth.Length == 1)
                {
                    strexpmonth = "0" + strexpmonth;
                }
                //string strExpireDate = "1212";
                //   string strCVV21 = processPaymentRequest.CreditCardCvv2.Split(',')[0].ToString();

                //  string strAmount1 = "2.00";
                string strAmount1 = processPaymentRequest.OrderTotal.ToString();

                string DeviceID = _TSYSPayPaymentSettings.DeviceID;
                string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;

                string postData = "";
                if (_TSYSPayPaymentSettings.Authorized == "1")
                {
                    postData = "<Auth><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><cardDataSource>MANUAL</cardDataSource><transactionAmount>" + strAmount1 + "</transactionAmount><cardNumber>" + strCardNumber1 + "</cardNumber><expirationDate>" + (strexpmonth + Year1) + "</expirationDate></Auth>";
                }
                else
                {

                    postData = "<Sale><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><cardDataSource>MANUAL</cardDataSource><transactionAmount>" + strAmount1 + "</transactionAmount><cardNumber>" + strCardNumber1 + "</cardNumber><expirationDate>" + (strexpmonth + Year1) + "</expirationDate><orderNumber>001</orderNumber></Sale>";
                }

                string responseFromServer1 = GetRequestData(request, postData);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(responseFromServer1);


                string orderid = "", status = "", historyid = "";

                status = doc.GetElementsByTagName("responseMessage")[0].InnerXml.ToString();
                if (status.ToLower().Contains("success"))
                {
                    historyid = doc.GetElementsByTagName("transactionID")[0].InnerXml.ToString();
                    orderid = doc.GetElementsByTagName("hostReferenceNumber")[0].InnerXml.ToString();
                    if (responseFromServer1.ToLower().Contains("saleresponse"))
                    {
                        result.NewPaymentStatus = PaymentStatus.Paid;
                        result.CaptureTransactionResult = status;
                        result.SubscriptionTransactionId = orderid;
                        result.CaptureTransactionId = historyid;
                    }
                    else if (responseFromServer1.ToLower().Contains("authresponse"))
                    {
                        result.NewPaymentStatus = PaymentStatus.Authorized;
                        result.AuthorizationTransactionResult = status;
                        result.SubscriptionTransactionId = orderid;
                        result.AuthorizationTransactionId = historyid;
                    }
                    else
                    {
                        result.AddError(status);
                    }
                }
                else
                {
                    result.AddError(status);
                }
                #endregion Request to Url


            }

            if (PaymentInfoTSYSPayPay.CustomValue == "3")
            {


                #region Request to url debit card

                WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

                request.Method = "POST";
                // Create POST data and convert it to a byte array.
                string strCustomerName1 = processPaymentRequest.CreditCardName.Split(',')[1].ToString(); ;
                //string strInvoiceNumber = processPaymentRequest.OrderGuid.ToString();


                string strAmount1 = processPaymentRequest.OrderTotal.ToString();
                string strPin = processPaymentRequest.CreditCardNumber.Split(',')[1].ToString();
                string strKSN = processPaymentRequest.CreditCardCvv2.ToString();

                string DeviceID = _TSYSPayPaymentSettings.DeviceID;
                string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;



                string postData = "<DebitSale><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><transactionAmount>" + strAmount1 + "</transactionAmount><track2Data>" + strPin + "=" + strKSN + "</track2Data><pin>" + strPin + "</pin><pinKsn>" + strKSN + "</pinKsn></DebitSale>";

                string responseFromServer1 = GetRequestData(request, postData);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(responseFromServer1);

                string orderid = "", status = "", historyid = "";
                string error = "";
                status = doc.GetElementsByTagName("responseMessage")[0].InnerXml.ToString();
                if (status.ToLower().Contains("success"))
                {
                    historyid = doc.GetElementsByTagName("transactionID")[0].InnerXml.ToString();
                    orderid = doc.GetElementsByTagName("hostReferenceNumber")[0].InnerXml.ToString();
                    if (responseFromServer1.ToLower().Contains("saleresponse"))
                    {
                        result.NewPaymentStatus = PaymentStatus.Paid;
                        result.CaptureTransactionResult = status;
                        result.SubscriptionTransactionId = orderid;
                        result.CaptureTransactionId = historyid;

                    }
                    else if (responseFromServer1.ToLower().Contains("authresponse"))
                    {
                        result.NewPaymentStatus = PaymentStatus.Authorized;
                        result.AuthorizationTransactionResult = status;
                        result.SubscriptionTransactionId = orderid;
                        result.AuthorizationTransactionId = historyid;
                    }
                    else
                    {
                        result.AddError(status);
                    }
                }
                else
                {
                    result.AddError(status);
                }
                #endregion Request to Url


            }
            return result;

        }
        public static string Strip(string text)
        {
            text = Regex.Replace(text, @"<(.|\n)*?>,", string.Empty);
            return text.Replace("&nbsp;", " ");
        }
        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {

        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {

            return decimal.Zero;
        }
        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }
        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            #region
            WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

            request.Method = "POST";
            // Create POST data and convert it to a byte array.
            string DeviceID = _TSYSPayPaymentSettings.DeviceID;
            string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;

            string postData = "<Capture><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><transactionAmount>" + Math.Round(capturePaymentRequest.Order.OrderTotal, 2).ToString() + "</transactionAmount><transactionID>" + capturePaymentRequest.Order.AuthorizationTransactionId + "</transactionID></Capture>";

            string responseFromServer1 = GetRequestData(request, postData);

            var result = new CapturePaymentResult();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseFromServer1);
            string status = "", historyid = "";
            status = doc.GetElementsByTagName("responseMessage")[0].InnerXml.ToString();
            if (status.ToLower().Contains("success"))
            {
                historyid = doc.GetElementsByTagName("transactionID")[0].InnerXml.ToString();
                if (responseFromServer1.ToLower().Contains("captureresponse"))
                {
                    result.NewPaymentStatus = PaymentStatus.Paid;
                    result.CaptureTransactionResult = status.Replace("\r", "");
                    result.CaptureTransactionId = historyid.Replace("\r", "");
                }
                else
                {
                    result.AddError(status);
                }
            }
            else
            {
                result.AddError(status);
            }
            #endregion
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {

            #region
            WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

            request.Method = "POST";
            // Create POST data and convert it to a byte array.
            string DeviceID = _TSYSPayPaymentSettings.DeviceID;
            string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;

            string transactionId = refundPaymentRequest.Order.CaptureTransactionId;

            string postData = "<Return><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><transactionAmount>" + Math.Round(refundPaymentRequest.Order.OrderTotal, 2).ToString() + "</transactionAmount><transactionID>" + transactionId + "</transactionID></Return>";

            string responseFromServer1 = GetRequestData(request, postData);

            var result = new RefundPaymentResult();
            string error = "";
            //bool success = PaypalHelper.CheckSuccess(response, out error);
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseFromServer1);
            string status = "";
            status = doc.GetElementsByTagName("responseMessage")[0].InnerXml.ToString();
            if (status.ToLower().Contains("success"))
            {
                result.NewPaymentStatus = PaymentStatus.Refunded;
            }
            else
            {
                result.AddError(status);
            }
            #endregion
            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {

            #region

            WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

            request.Method = "POST";
            // Create POST data and convert it to a byte array.
            string DeviceID = _TSYSPayPaymentSettings.DeviceID;
            string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;


            string transactionId = voidPaymentRequest.Order.AuthorizationTransactionId;
            if (String.IsNullOrEmpty(transactionId))
                transactionId = voidPaymentRequest.Order.CaptureTransactionId;

            string postData = "<Void><deviceID>" + DeviceID + "</deviceID><transactionKey>" + TransactionKey + "</transactionKey><transactionAmount>" + Math.Round(voidPaymentRequest.Order.OrderTotal, 2).ToString() + "</transactionAmount><transactionID>" + transactionId + "</transactionID></Void>";

            string responseFromServer1 = GetRequestData(request, postData);

            var result = new VoidPaymentResult();
            string error = "";
            //bool success = PaypalHelper.CheckSuccess(response, out error);
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseFromServer1);
            string status = "";
            status = doc.GetElementsByTagName("responseMessage")[0].InnerXml.ToString();
            if (status.ToLower().Contains("success"))
            {
                result.NewPaymentStatus = PaymentStatus.Voided;
            }
            else
            {
                result.AddError(status);
            }
            #endregion
            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        /// 

        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel PaymentInfoTSYSPayPay = new Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel();
            PaymentInfoTSYSPayPay = (Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel)_httpContext.Session["PaymentInfoTSYSPay"];
            var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);


            #region Request to url credit card

            WebRequest request = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");
            WebRequest request11 = WebRequest.Create("https://stagegw.transnox.com/servlets/TransNox_API_Server");

            request.Method = "POST";
            // Create POST data and convert it to a byte array.

            string strCustomerName1 = processPaymentRequest.CreditCardName.Split(',')[0].ToString();
            string strCardNumber1 = processPaymentRequest.CreditCardNumber.Split(',')[0].ToString();

            string Year1 = PaymentInfoTSYSPayPay.ExpireYear.Split(',')[0].ToString();
            string strexpmonth = PaymentInfoTSYSPayPay.ExpireMonth.Split(',')[0].ToString();
            if (strexpmonth.Length == 1)
            {
                strexpmonth = "0" + strexpmonth;
            }
            //string strExpireDate = "1212";
            //   string strCVV21 = processPaymentRequest.CreditCardCvv2.Split(',')[0].ToString();

            //  string strAmount1 = "2.00";
            string strAmount1 = processPaymentRequest.OrderTotal.ToString();

            string DeviceID = _TSYSPayPaymentSettings.DeviceID;
            string TransactionKey = _TSYSPayPaymentSettings.TransactionKey;

            string postData = "";
            string expinfo = Year1 + strexpmonth;

            string statep = "";
            if (customer.BillingAddress.StateProvince.Abbreviation != null)
            {
                statep = customer.BillingAddress.StateProvince.Abbreviation.ToString();
            }

            string CardType = "V";
            if (strCardNumber1.Substring(0, 1).ToString() == "4")
            {
                CardType = "V";
            }
            else if (strCardNumber1.Substring(0, 1).ToString() == "5")
            {
                CardType = "M";
            }
            else if (strCardNumber1.Substring(0, 1).ToString() == "3")
            {
                CardType = "A";
            }
            else if (strCardNumber1.Substring(0, 1).ToString() == "6")
            {
                CardType = "D";
            }

            postData = "<InfoNox_Interface><TransNox_API_Interface><EnrollCustomerRQ><Device_Info><Merchant_ID>" + _TSYSPayPaymentSettings.MerchantId + "</Merchant_ID><Device_ID>" + _TSYSPayPaymentSettings.DeviceID + "</Device_ID>";
            postData = postData + "<Operator>TA101169</Operator><Password>" + _TSYSPayPaymentSettings.Password + "</Password></Device_Info><Transaction_Info><Service_Code>ENROLL</Service_Code><SubServiceCode>AUTH</SubServiceCode>";
            postData = postData + "</Transaction_Info><Customer_Info><Name><FirstName>" + customer.BillingAddress.FirstName + "</FirstName><LastName>" + customer.BillingAddress.LastName + "</LastName><MI></MI><Suffix>TestSuffix</Suffix><MaternalName>AAA</MaternalName>";
            postData = postData + "<PaternalName></PaternalName><Company_Info><Name>" + customer.BillingAddress.Company + "</Name><TID></TID><BusinessType>IT</BusinessType></Company_Info></Name>";
            postData = postData + "<Action>ENROLL</Action><Address><StreetAddress>" + customer.BillingAddress.Address1 + "</StreetAddress><Address2>" + customer.BillingAddress.Address2 + "</Address2><City>" + customer.BillingAddress.City + "</City><State>" + statep + "</State>";
            postData = postData + "<NumericStateCode>" + statep + "</NumericStateCode><ZipCode>" + customer.BillingAddress.ZipPostalCode + "</ZipCode><Country>" + customer.BillingAddress.Country.ThreeLetterIsoCode + "</Country><Phone>" + customer.BillingAddress.PhoneNumber + "</Phone><MobilePhone></MobilePhone>";
            postData = postData + "<WorkPhone>" + customer.BillingAddress.PhoneNumber + "</WorkPhone><Fax>" + customer.BillingAddress.FaxNumber + "</Fax><Email>" + customer.BillingAddress.Email + "</Email></Address><CustomerCode></CustomerCode><ExternalCustomerNumber>" + customer.Id + "</ExternalCustomerNumber>";
            postData = postData + "<Program_Type><Program_Name>CUSTOMER_DATABASE</Program_Name><Program_Level>MERCHANT</Program_Level></Program_Type><Customer_Notes>Good</Customer_Notes>";
            postData = postData + "<Card_Info><Type>" + CardType + "</Type><Number>" + strCardNumber1 + "</Number><ExpirationDate>" + expinfo + "</ExpirationDate><Status>ACTIVE</Status><Entry_Mode>MANUAL</Entry_Mode>";
            postData = postData + "<Cardholder>PRESENT</Cardholder><Payment_Sequence>1</Payment_Sequence></Card_Info></Customer_Info></EnrollCustomerRQ></TransNox_API_Interface></InfoNox_Interface>";


            string cycleperiod = processPaymentRequest.RecurringCyclePeriod.ToString();
            string period = "";
            if (processPaymentRequest.RecurringCycleLength <= 0)
            {
                result.AddError("Not supported cycle period"); return result;
            }
            switch (processPaymentRequest.RecurringCyclePeriod)
            {

                case RecurringProductCyclePeriod.Days:
                    if (processPaymentRequest.RecurringCycleLength > 1)
                    {
                        result.AddError("Not supported cycle period"); return result;
                    }
                    else
                    {
                        period = "<DAILY>Y</DAILY>";
                    }

                    break;
                case RecurringProductCyclePeriod.Weeks:
                    if (processPaymentRequest.RecurringCycleLength > 1)
                    {
                        result.AddError("Not supported cycle period"); return result;
                    }

                    period = "<WEEKLY></WEEKLY>";

                    break;
                case RecurringProductCyclePeriod.Months:

                    if (processPaymentRequest.RecurringCycleLength == 1)
                    {
                        period = "<MONTHLY></MONTHLY>";
                    }
                    else if (processPaymentRequest.RecurringCycleLength == 6)
                    {
                        period = "<HALF_YEARLY>Y</HALF_YEARLY>";
                    }
                    else if (processPaymentRequest.RecurringCycleLength == 3)
                    {
                        period = "<QUARTERLY>Y</QUARTERLY>";
                    }
                    else if (processPaymentRequest.RecurringCycleLength >= 12)
                    {
                        period = "<YEARLY>Y</YEARLY>";
                    }
                    else
                    {
                        period = "<MONTHLY>";

                        string monthname = DateTime.UtcNow.Month.ToString();
                        int Currentmonth = DateTime.UtcNow.Month;
                        string[] months = new string[] { "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", };
                        int cnt = 12 / processPaymentRequest.RecurringCycleLength;
                        for (int i = 0; i < cnt; i++)
                        {
                            if (i == 0)
                            {
                                months[Currentmonth - 1] = "Y";
                            }
                            if ((Currentmonth - 1) + (processPaymentRequest.RecurringCycleLength * i) <= 12)
                            {
                                if (i != 0)
                                {
                                    months[(Currentmonth - 1) + (processPaymentRequest.RecurringCycleLength * i)] = "Y";
                                }
                            }
                            else
                            {
                                months[((Currentmonth - 1) + (processPaymentRequest.RecurringCycleLength * i)) - 12] = "Y";
                            }
                        }

                        period = period + "<JANUARY>" + months[0].ToString().ToUpper() + "</JANUARY>";
                        period = period + "<FEBRUARY>" + months[1].ToString().ToUpper() + "</FEBRUARY>";
                        period = period + "<MARCH>" + months[2].ToString().ToUpper() + "</MARCH>";
                        period = period + "<APRIL>" + months[3].ToString().ToUpper() + "</APRIL>";
                        period = period + "<MAY>" + months[4].ToString().ToUpper() + "</MAY>";
                        period = period + "<JUNE>" + months[5].ToString().ToUpper() + "</JUNE>";
                        period = period + "<JULY>" + months[6].ToString().ToUpper() + "</JULY>";
                        period = period + "<AUGUST>" + months[7].ToString().ToUpper() + "</AUGUST>";
                        period = period + "<SEPTEMBER>" + months[8].ToString().ToUpper() + "</SEPTEMBER>";
                        period = period + "<OCTOBER>" + months[9].ToString().ToUpper() + "</OCTOBER>";
                        period = period + "<NOVEMBER>" + months[10].ToString().ToUpper() + "</NOVEMBER>";
                        period = period + "<DECEMBER>" + months[11].ToString().ToUpper() + "</DECEMBER>";

                        period = period + "</MONTHLY>";
                    }




                    break;
                case RecurringProductCyclePeriod.Years:
                    period = "<YEARLY>Y</YEARLY>";
                    break;
                default:
                    result.AddError("Not supported cycle period"); return result;
            }

            string StartDate = DateTime.UtcNow.ToString("MM/dd/yyyy");
            StartDate = StartDate + " " + "00:00:00";

            string postData1 = "<InfoNox_Interface><TransNox_API_Interface><ScheduleTransactionRQ><Device_Info><Merchant_ID>" + _TSYSPayPaymentSettings.MerchantId + "</Merchant_ID><Device_ID>" + _TSYSPayPaymentSettings.DeviceID + "</Device_ID>";
            postData1 = postData1 + "<Operator>TA101169</Operator><Password>" + _TSYSPayPaymentSettings.Password + "</Password></Device_Info><Customer_Info><ExternalCustomerNumber>" + customer.Id + "</ExternalCustomerNumber>";
            postData1 = postData1 + "<Program_Type><Program_Name>CUSTOMER_DATABASE</Program_Name><Program_Level>MERCHANT</Program_Level></Program_Type></Customer_Info><Schedule_Info>";
            postData1 = postData1 + "<Schedule_Pattern><Schedule_Frequency>" + period + "</Schedule_Frequency></Schedule_Pattern><Schedule_Amount>" + processPaymentRequest.OrderTotal.ToString() + "</Schedule_Amount><Schedule_Status>ACTIVE</Schedule_Status>";
            postData1 = postData1 + "<Schedule_Occurrences><Start_Date>" + StartDate + "</Start_Date> <UpTo> <Payment_Count>" + processPaymentRequest.RecurringTotalCycles + "</Payment_Count> </UpTo> </Schedule_Occurrences>";
            postData1 = postData1 + "<Action>ADD_SCHEDULE</Action> </Schedule_Info><Payment_Mode><Payment_Info><Card_Info> <Type>" + CardType + "</Type> <Number>" + strCardNumber1 + "</Number><ExpirationDate>" + expinfo + "</ExpirationDate>";
            postData1 = postData1 + "<Status>ACTIVE</Status><Entry_Mode>MANUAL</Entry_Mode><Cardholder>PRESENT</Cardholder> <Payment_Sequence>1</Payment_Sequence></Card_Info>";
            postData1 = postData1 + "</Payment_Info></Payment_Mode></ScheduleTransactionRQ></TransNox_API_Interface></InfoNox_Interface>";

            string responseFromServer1 = GetRequestData(request, postData);
            string responseFromServer11 = GetRequestData1(request11, postData1);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseFromServer11);
            string orderid = "", status = "", historyid = "";

            status = doc.GetElementsByTagName("Message")[0].InnerXml.ToString();
            if (status.ToLower().Contains("approved"))
            {
                orderid = doc.GetElementsByTagName("Schedule_ID")[0].InnerXml.ToString();
                //   orderid = doc.GetElementsByTagName("hostReferenceNumber")[0].InnerXml.ToString();

                result.NewPaymentStatus = PaymentStatus.Paid;
                result.CaptureTransactionResult = status;
                result.SubscriptionTransactionId = orderid;
                result.CaptureTransactionId = orderid;
            }
            else
            {
                result.AddError(status);
            }

            #endregion
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            var result = new CancelRecurringPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //PayPal Standard is the redirection payment method
            //It also validates whether order is also paid (after redirection) so customers will not be able to pay twice

            //payment status should be Pending
            if (order.PaymentStatus != PaymentStatus.Pending)
                return false;

            //let's ensure that at least 1 minute passed after order is placed
            if ((DateTime.UtcNow - order.CreatedOnUtc).TotalMinutes < 1)
                return false;

            return true;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "PaymentTSYSPay";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.Payments.TSYSPay.Controller" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "PaymentTSYSPay";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.Payments.TSYSPay.Controller" }, { "area", null } };
        }

        public Type GetControllerType()
        {
            return typeof(PaymentTSYSPayController);
        }

        public override void Install()
        {

            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CardType", "Select CardType");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UserName", "User Name ");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UserName.Hint", "Specify user name");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Password", "Password");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Password.Hint", "Specify password");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Authorize", "Authorize");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Authorize.Hint", "Select authorize");

            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.MerchantId", "MerchantId ");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.MerchantId.Hint", "Specify merchant id");

            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.deviceID", "DeviceId ");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.deviceID.Hint", "Specify device id");


            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TransactionKey", "TransactionKey ");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TransactionKey.Hint", "Specify transaction key");


            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UseSendBox", "Use SendBox");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UseSendBox.Hint", "Select Use SendBox");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.DisImagebox", "Display Image Box");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.DisImagebox.Hint", "Specify for Display Image Box");

            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TranType", "TranType");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CardNumber", "Card Number");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.ExpirationDate", "Expiry Date");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.NameOnCard", "NameOnCard");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CvNum", "CvNum");
            this.AddOrUpdatePluginLocaleResource("Payment.CustomValues", "Payment type");


            base.Install();
        }

        public override void Uninstall()
        {
            //locales
            this.DeletePluginLocaleResource("Payment.CustomValues");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Check.Fields.AccountNumber");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Check.Fields.NameOnCard");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CardType");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.RedirectionTip");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UserName");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.UserName.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Password");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Password.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Authorized");


            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.MerchantId");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.MerchantId.Hint");

            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.deviceID");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.deviceID.Hint");

            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TransactionKey");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TransactionKey.Hint");


            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.TranType");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CardNumber");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.ExpirationDate");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.MaxData");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.NameOnCard");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.ZipCode");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Street");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.CvNum");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.ExData");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.PnRef");
            this.DeletePluginLocaleResource("Payment.CustomValues");

            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Require.UserName");
            this.DeletePluginLocaleResource("Plugins.Payments.TSYSPay.Fields.Require.Password");
            base.Uninstall();
        }

        #endregion

        #region Properies

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Automatic;
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>  
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Redirection;
            }
        }
        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }
        #endregion
    }

}
