﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.Payments.PrismPay
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.Payments.TSYSPay.Configure",
                 "Plugins/PaymentTSYSPay/Configure",
                 new { controller = "PaymentTSYSPay", action = "Configure" },
                 new[] { "Nop.Plugin.Payments.TSYSPay.Controller" }
            );

            routes.MapRoute("Plugin.Payments.TSYSPay.PaymentInfo",
                 "Plugins/PaymentTSYSPay/PaymentInfo",
                 new { controller = "PaymentTSYSPay", action = "PaymentInfo" },
                 new[] { "Nop.Plugin.Payments.TSYSPay.Controller" }
            );

            //PDT
            routes.MapRoute("Plugin.Payments.TSYSPay.PDTHandler",
                 "Plugins/PaymentTSYSPay/PDTHandler",
                 new { controller = "PaymentTSYSPay", action = "PDTHandler" },
                 new[] { "Nop.Plugin.Payments.TSYSPay.Controller" }
            );
            //IPN
            routes.MapRoute("Plugin.Payments.TSYSPay.IPNHandler",
                 "Plugins/PaymentPrismPay/IPNHandler",
                 new { controller = "PaymentTSYSPay", action = "IPNHandler" },
                 new[] { "Nop.Plugin.Payments.TSYSPay.Controller" }
            );
            //Cancel
            routes.MapRoute("Plugin.Payments.TSYSPay.CancelOrder",
                 "Plugins/PaymentPrismPay/CancelOrder",
                 new { controller = "PaymentTSYSPay", action = "CancelOrder" },
                 new[] { "Nop.Plugin.Payments.TSYSPay.Controller" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
