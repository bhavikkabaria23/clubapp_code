﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System.Collections.Generic;
using System.Web.Mvc;
namespace Nop.Plugin.Payments.TSYSPay.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public ConfigurationModel()
        {
            Authorizeds = new List<SelectListItem>();
            

        }
        //[NopResourceDisplayName("Plugins.Payments.PrismPay.Fields.MerchantId")]
        //public string MerchantCardNumber { get; set; }

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.DisImagebox")]
        public bool DisImagebox { get; set; }

        public bool CreditCard { get; set; }

        public bool Debit { get; set; }

      
        

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.MerchantId")]
        [AllowHtml]
        public string MerchantId { get; set; }
      
        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.UserName")]
        [AllowHtml]
        public string UserName { get; set; }


        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.Password")]
        [AllowHtml]
        public string Password { get; set; }

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.deviceID")]
        [AllowHtml]
        public string DeviceID { get; set; }

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.transactionKey")]
        [AllowHtml]
        public string TransactionKey { get; set; }

       [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.CardType")]
        [AllowHtml]
        public string CreditCardTypes { get; set; }

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.Authorize")]
        public string Authorized { get; set; }
        public IList<SelectListItem> Authorizeds { get; set; }

        [NopResourceDisplayName("Plugins.Payments.GlobalPay.Fields.UseSendBox")]

        public bool UseSendBox { get; set; }
    }
}
