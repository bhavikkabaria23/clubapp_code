﻿
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;


namespace Nop.Plugin.Payments.TSYSPay.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
        public PaymentInfoModel()
        {
              CustomValues = new List<SelectListItem>();
            CreditCardTypes = new List<SelectListItem>();
            ExpireMonths = new List<SelectListItem>();
            ExpireYears = new List<SelectListItem>();
            //CustomValues = new Dictionary<string, object>();
         
        }
        [NopResourceDisplayName("Payment.SelectCreditCard")]
        [AllowHtml]
        public string CreditCardType { get; set; }
        [NopResourceDisplayName("Payment.SelectCreditCard")]
        public IList<SelectListItem> CreditCardTypes { get; set; }
         [NopResourceDisplayName("Payment.CustomValues")]
        public IList<SelectListItem> CustomValues { get; set; }

        public string CustomValue { get; set; }

        public string PaymentType { get; set; }
        [NopResourceDisplayName("Payment.PaymentType")]
        public IList<SelectListItem> PaymentTypes { get; set; }

        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.NameOnCard")]
        [AllowHtml]
        public string NameOnCard { get; set; }


        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.ExpirationDate")]
        [AllowHtml]
        public string ExpireMonth { get; set; }
        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.ExpirationDate")]
        [AllowHtml]
        public string ExpireYear { get; set; }
        public IList<SelectListItem> ExpireMonths { get; set; }
        public IList<SelectListItem> ExpireYears { get; set; }



        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.CardNumber")]
        [AllowHtml]
        public string CardNumber { get; set; }


        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Fields.CvNum")]
        [AllowHtml]
        public string CvNum { get; set; }



        [NopResourceDisplayName("Plugins.Payments.TSYSPay.Check.Fields.NameOnCard")]
        [AllowHtml]
        public string CkNameOnCard { get; set; }

        

    }
}