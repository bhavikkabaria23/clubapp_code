﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Plugin.Payments.TSYSPay.Models;
using Nop.Services.Configuration;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Web.Framework.Controllers;
using Nop.Services.Localization;
using System.Net;
using System.IO;
using Nop.Plugin.Payments.TSYSPay;
using Nop.Plugin.Payments.TSYSPay.Validators;
namespace Nop.Plugin.Payments.TSYSPay.Controller
{
    public class PaymentTSYSPayController : BasePaymentController
    {
        private readonly ISettingService _settingService;
        private readonly IPaymentService _paymentService;
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly ILogger _logger;
        private readonly IWebHelper _webHelper;
        private readonly TSYSPayPaymentSettings _TSYSPayPaymentSettings;
        private readonly PaymentSettings _paymentSettings;
        private readonly ILocalizationService _localizationService;


        public PaymentTSYSPayController(ISettingService settingService, ILocalizationService localizationService,
            IPaymentService paymentService, IOrderService orderService,
            IOrderProcessingService orderProcessingService,
            ILogger logger, IWebHelper webHelper,
            TSYSPayPaymentSettings TSYSPayPaymentSettings,
            PaymentSettings paymentSettings)
        {
            this._settingService = settingService;
            this._paymentService = paymentService;
            this._orderService = orderService;
            this._orderProcessingService = orderProcessingService;
            this._logger = logger;
            this._webHelper = webHelper;
            this._TSYSPayPaymentSettings = TSYSPayPaymentSettings;
            this._paymentSettings = paymentSettings;
            this._localizationService = localizationService;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = new ConfigurationModel();

            var CartList1 = new SelectList(new[] {  
                                            
                                              new {Text="Master card",Value="Master card"},
                                              new {Text="Visa",Value="Visa"},
                                              new {Text="Discover",Value="Discover"},
                                              new {Text="Amex",Value="Amex"},
            
            }, "Value", "Text", null);


            ViewData["CartList"] = CartList1;

            var AuthType = new SelectList(new[] {  
                                            
            
                                               new {Text="Authorize",Value="1"},
                                              new {Text="Authorize & Capture",Value="0"},
            }, "Value", "Text", null);


            model.Authorizeds.Add(new SelectListItem { Text = "Authorize", Value = "1" });
            model.Authorizeds.Add(new SelectListItem { Text = "Authorize & Capture", Value = "0" });
            model.CreditCardTypes = _TSYSPayPaymentSettings.CreditCardTypes;
            model.DisImagebox = _TSYSPayPaymentSettings.DisImagebox;
            model.DeviceID = _TSYSPayPaymentSettings.DeviceID;
            model.TransactionKey = _TSYSPayPaymentSettings.TransactionKey;

            model.UserName = _TSYSPayPaymentSettings.UserName;
            model.Password = _TSYSPayPaymentSettings.Password;
            model.MerchantId = _TSYSPayPaymentSettings.MerchantId;
          
            model.CreditCard = _TSYSPayPaymentSettings.CreditCard;
            model.Debit = _TSYSPayPaymentSettings.Debit;
            model.Authorized = _TSYSPayPaymentSettings.Authorized;
            ViewData["CreditCardTypes"] = _TSYSPayPaymentSettings.CreditCardTypes;
            return View("~/Plugins/Payments.TSYSPay/Views/TSYSPay/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();
            string ListType = "";


            ListType = "Master card,Visa,Discover,Amex";



            //save settings


            model.Authorizeds.Add(new SelectListItem { Text = "Authorize", Value = "1" });
            model.Authorizeds.Add(new SelectListItem { Text = "Authorize & Capture", Value = "0" });



            model.CreditCardTypes = ListType;
            _TSYSPayPaymentSettings.CreditCardTypes = ListType;
            _TSYSPayPaymentSettings.DisImagebox = model.DisImagebox;
            _TSYSPayPaymentSettings.DeviceID = model.DeviceID;
            _TSYSPayPaymentSettings.TransactionKey = model.TransactionKey;
            _TSYSPayPaymentSettings.CreditCard = model.CreditCard;
            _TSYSPayPaymentSettings.Debit = model.Debit;

            _TSYSPayPaymentSettings.UserName = model.UserName;
            _TSYSPayPaymentSettings.Password = model.Password;
            _TSYSPayPaymentSettings.MerchantId = model.MerchantId;
            
            _TSYSPayPaymentSettings.Authorized = model.Authorized;
            
            _settingService.SaveSetting(_TSYSPayPaymentSettings);
            var CartList1 = new SelectList(new[] {  
                                            
                                              new {Text="Master card",Value="Master card"},
                                              new {Text="Visa",Value="Visa"},
                                              new {Text="Discover",Value="Discover"},
                                              new {Text="Amex",Value="Amex"},
            
            }, "Value", "Text", null);




            ViewData["CartList"] = CartList1;
            ViewData["CreditCardTypes"] = ListType;
            return View("~/Plugins/Payments.TSYSPay/Views/TSYSPay/Configure.cshtml", model);
        }

        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();


            string SelectedCartList = "Master card,Visa,Discover,Amex";
            bool ImageDrop = _TSYSPayPaymentSettings.DisImagebox;
            ViewData["ImageType"] = true;
            ViewData["SelectedCartList"] = SelectedCartList;
            int chk = 0;
            if (_TSYSPayPaymentSettings.CreditCard == true)
            {
                chk = 1;
                model.CustomValues.Add(new SelectListItem()
                {
                    Text = "Credit Card",
                    Value = "1",
                });
            }
           
            if (_TSYSPayPaymentSettings.Debit == true)
            {
                if (chk == 1 || chk == 2)
                {
                }
                else
                {
                    chk = 3;
                }
                model.CustomValues.Add(new SelectListItem()
                {
                    Text = "Debit Card",
                    Value = "3",
                });
            }


            //CC types
            if (SelectedCartList.Contains("Visa"))
            {
                model.CreditCardTypes.Add(new SelectListItem()
                {
                    Text = "Visa",
                    Value = "Visa",
                });

            }
            if (SelectedCartList.Contains("Master card"))
            {
                model.CreditCardTypes.Add(new SelectListItem()
                {
                    Text = "Master card",
                    Value = "MasterCard",
                });
            }
            if (SelectedCartList.Contains("Discover"))
            {
                model.CreditCardTypes.Add(new SelectListItem()
                {
                    Text = "Discover",
                    Value = "Discover",
                });
            }
            if (SelectedCartList.Contains("Amex"))
            {
                model.CreditCardTypes.Add(new SelectListItem()
                {
                    Text = "Amex",
                    Value = "Amex",
                });
            }

            //years
            for (int i = 0; i < 15; i++)
            {
                string year = Convert.ToString(DateTime.Now.Year + i);
                model.ExpireYears.Add(new SelectListItem()
                {
                    Text = year,
                    Value = year,
                });
            }

            //months
            for (int i = 1; i <= 12; i++)
            {
                string text = (i < 10) ? "0" + i.ToString() : i.ToString();
                model.ExpireMonths.Add(new SelectListItem()
                {
                    Text = text,
                    Value = i.ToString(),
                });
            }
            //model.ExpireMonths.Add(new SelectListItem() { Text = "January (01)", Value = "1" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "February (02)", Value = "2" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "March (03)", Value = "3" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "April (04)", Value = "4" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "May (05)", Value = "5" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "June (06)", Value = "6" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "July (07)", Value = "7" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "August (08)", Value = "8" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "September (09)", Value = "9" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "October (10)", Value = "10" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "November (11)", Value = "11" });
            //model.ExpireMonths.Add(new SelectListItem() { Text = "December (12)", Value = "12" });

            //set postback values
            var form = this.Request.Form;

            model.NameOnCard = form["NameOnCard"];
            model.CardNumber = form["CardNumber"];
            model.CvNum = form["CvNum"];
            model.CreditCardType = form["CreditCardType"];
            ViewBag.chk = chk.ToString();
            return View("~/Plugins/Payments.TSYSPay/Views/TSYSPay/PaymentInfo.cshtml", model);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();

            //validate
            var validator = new PaymentInfoValidator(_localizationService);
            ViewData["ImageType"] = _TSYSPayPaymentSettings.DisImagebox;
            if (_TSYSPayPaymentSettings.DisImagebox)
            {
                var model = new PaymentInfoModel()
                {

                    NameOnCard = form["NameOnCard"],
                    CardNumber = form["CardNumber"],
                    CvNum = form["CvNum"],
                    CreditCardType = form["hdnselectCard"].ToString(),
                  
                    CustomValue = form["CustomValues"]

                };
                if (model.CardNumber.Contains(","))
                {
                    model.CardNumber = model.CardNumber.Replace(',', ' ');
                    model.CardNumber.Trim();
                }
                if (model.CvNum.Contains(","))
                {
                    model.CvNum = model.CvNum.Replace(',', ' ');
                    model.CvNum.Trim();
                }
                if (model.NameOnCard.Contains(","))
                {
                    model.NameOnCard = model.NameOnCard.Replace(',', ' ');
                    model.NameOnCard.Trim();
                }
                var validationResult = validator.Validate(model);
                if (!validationResult.IsValid)
                    foreach (var error in validationResult.Errors)
                        warnings.Add(error.ErrorMessage);
                return warnings;
            }
            else
            {

                var model = new PaymentInfoModel()
                {
                    NameOnCard = form["NameOnCard"],
                    CardNumber = form["CardNumber"],
                    CvNum = form["CvNum"],
                   // CreditCardType = form["CreditCardType"],
                    CreditCardType = form["hdnselectCard"].ToString(),
                    CustomValue = form["CustomValues"]

                };
                if (model.CardNumber.Contains(","))
                {
                    model.CardNumber = model.CardNumber.Replace(',', ' ');
                    model.CardNumber = model.CardNumber.Trim();
                }
                if (model.CvNum.Contains(","))
                {
                    model.CvNum = model.CvNum.Replace(',', ' ');
                    model.CvNum = model.CvNum.Trim();
                }
                if (model.NameOnCard.Contains(","))
                {
                    model.NameOnCard = model.NameOnCard.Replace(',', ' ');
                    model.NameOnCard = model.NameOnCard.Trim();
                }
                var validationResult = validator.Validate(model);
                if (!validationResult.IsValid)
                    foreach (var error in validationResult.Errors)
                        warnings.Add(error.ErrorMessage);
                return warnings;
            }

        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
          paymentInfo.CreditCardType = form["hdnselectCard"].ToString();
            //if (_TSYSPayPaymentSettings.DisImagebox)
            //{
            //    paymentInfo.CreditCardType = form["hdnselectCard"].ToString();
            //}
            //else
            //{
            //    paymentInfo.CreditCardType = form["CreditCardType"].ToString();
            //}
            paymentInfo.CreditCardName = form["NameOnCard"];
            paymentInfo.CreditCardNumber = form["CardNumber"];
            paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            paymentInfo.CreditCardCvv2 = form["CvNum"];


           


            Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel PaymentInfoTSYSPay = new Nop.Plugin.Payments.TSYSPay.Models.PaymentInfoModel();

            PaymentInfoTSYSPay.ExpireMonth = form["ExpireMonth"];
            PaymentInfoTSYSPay.ExpireYear = form["ExpireYear"];
            PaymentInfoTSYSPay.CustomValue = form["CustomValues"];
            PaymentInfoTSYSPay.CkNameOnCard = form["CkNameOnCard"];
            System.Web.HttpContext.Current.Session["PaymentInfoTSYSPay"] = PaymentInfoTSYSPay;

            return paymentInfo;
        }

        [ValidateInput(false)]
        public ActionResult PDTHandler(FormCollection form)
        {
            string tx = _webHelper.QueryString<string>("tx");
            Dictionary<string, string> values;
            string response;

            var processor = _paymentService.LoadPaymentMethodBySystemName("Payments.TSYSPay") as TSYSPayPaymentProcessor;
            if (processor == null ||
                !processor.IsPaymentMethodActive(_paymentSettings) || !processor.PluginDescriptor.Installed)
                throw new NopException("TSYSPay Standard module cannot be loaded");

            if (processor.GetPDTDetails(tx, out values, out response))
            {
                string orderNumber = string.Empty;
                values.TryGetValue("custom", out orderNumber);
                Guid orderNumberGuid = Guid.Empty;
                try
                {
                    orderNumberGuid = new Guid(orderNumber);
                }
                catch { }
                Order order = _orderService.GetOrderByGuid(orderNumberGuid);
                if (order != null)
                {
                    decimal total = decimal.Zero;
                    try
                    {
                        total = decimal.Parse(values["mc_gross"], new CultureInfo("en-US"));
                    }
                    catch (Exception exc)
                    {
                        _logger.Error("TSYSPay PDT. Error getting mc_gross", exc);
                    }

                    string payer_status = string.Empty;
                    values.TryGetValue("payer_status", out payer_status);
                    string payment_status = string.Empty;
                    values.TryGetValue("payment_status", out payment_status);
                    string pending_reason = string.Empty;
                    values.TryGetValue("pending_reason", out pending_reason);
                    string mc_currency = string.Empty;
                    values.TryGetValue("mc_currency", out mc_currency);
                    string txn_id = string.Empty;
                    values.TryGetValue("txn_id", out txn_id);
                    string payment_type = string.Empty;
                    values.TryGetValue("payment_type", out payment_type);
                    string payer_id = string.Empty;
                    values.TryGetValue("payer_id", out payer_id);
                    string receiver_id = string.Empty;
                    values.TryGetValue("receiver_id", out receiver_id);
                    string invoice = string.Empty;
                    values.TryGetValue("invoice", out invoice);
                    string payment_fee = string.Empty;
                    values.TryGetValue("payment_fee", out payment_fee);

                    var sb = new StringBuilder();
                    sb.AppendLine("Garanti PDT:");
                    sb.AppendLine("total: " + total);
                    sb.AppendLine("Payer status: " + payer_status);
                    sb.AppendLine("Payment status: " + payment_status);
                    sb.AppendLine("Pending reason: " + pending_reason);
                    sb.AppendLine("mc_currency: " + mc_currency);
                    sb.AppendLine("txn_id: " + txn_id);
                    sb.AppendLine("payment_type: " + payment_type);
                    sb.AppendLine("payer_id: " + payer_id);
                    sb.AppendLine("receiver_id: " + receiver_id);
                    sb.AppendLine("invoice: " + invoice);
                    sb.AppendLine("payment_fee: " + payment_fee);


                    //order note
                    order.OrderNotes.Add(new OrderNote()
                    {
                        Note = sb.ToString(),
                        DisplayToCustomer = false,
                        CreatedOnUtc = DateTime.UtcNow
                    });
                    _orderService.UpdateOrder(order);

                    //validate order total

                    //if (_garantiStandardPaymentSettings.PdtValidateOrderTotal && !Math.Round(total, 2).Equals(Math.Round(order.OrderTotal, 2)))
                    //{
                    //    string errorStr = string.Format("PayPal PDT. Returned order total {0} doesn't equal order total {1}", total, order.OrderTotal);
                    //    _logger.Error(errorStr);

                    //    return RedirectToAction("Index", "Home", new { area = "" });
                    //}

                    //mark order as paid
                    if (_orderProcessingService.CanMarkOrderAsPaid(order))
                    {
                        order.AuthorizationTransactionId = txn_id;
                        _orderService.UpdateOrder(order);

                        _orderProcessingService.MarkOrderAsPaid(order);
                    }
                }

                return RedirectToRoute("CheckoutCompleted");
            }
            else
            {
                string orderNumber = string.Empty;
                values.TryGetValue("custom", out orderNumber);
                Guid orderNumberGuid = Guid.Empty;
                try
                {
                    orderNumberGuid = new Guid(orderNumber);
                }
                catch { }
                Order order = _orderService.GetOrderByGuid(orderNumberGuid);
                if (order != null)
                {
                    //order note
                    order.OrderNotes.Add(new OrderNote()
                    {
                        Note = "TSYSPay PDT failed. " + response,
                        DisplayToCustomer = false,
                        CreatedOnUtc = DateTime.UtcNow
                    });
                    _orderService.UpdateOrder(order);
                }
                return RedirectToAction("Index", "Home", new { area = "" });
            }
        }

        [ValidateInput(false)]
        public ActionResult IPNHandler()
        {


            //nothing should be rendered to visitor
            return Content("");
        }

        public ActionResult CancelOrder(FormCollection form)
        {
            return RedirectToAction("Index", "Home", new { area = "" });
        }

        // public ILocalizationService _localizationService { get; set; }
    }
}