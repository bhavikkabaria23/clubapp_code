﻿using Nop.Core.Configuration;
using System.Web.Mvc;
using System.Collections.Generic;
namespace Nop.Plugin.Payments.TSYSPay
{
    public class TSYSPayPaymentSettings : ISettings
    {

      public string CreditCardTypes { get; set; }
      public bool DisImagebox { get; set; }
      public string DeviceID { get; set; }
      public string UserName { get; set; }
      public string Password { get; set; }
      public string MerchantId { get; set; }
      public string TransactionKey { get; set; }
        public bool CreditCard { get; set; }
        public bool Debit { get; set; }
        public string Authorized { get; set; }
      
    }
}
