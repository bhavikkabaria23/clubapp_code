﻿using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Widgets.Login.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [AllowHtml]
        public string WidgetZone { get; set; }

    }
}