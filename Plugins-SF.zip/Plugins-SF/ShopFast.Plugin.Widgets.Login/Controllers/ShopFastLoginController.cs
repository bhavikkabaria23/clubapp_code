﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Services.Authentication;
using Nop.Services.Authentication.External;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Security;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Models.Customer;
using ShopFast.Plugin.Widgets.Login.Models;

namespace ShopFast.Plugin.Widgets.Login.Controllers
{
    public class ShopFastLoginController : BasePluginController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly IOrderService _orderService;
        private readonly ILogger _logger;
        private readonly ICategoryService _categoryService;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly ILocalizationService _localizationService;
        private readonly CustomerSettings _customerSettings;
        private readonly CaptchaSettings _captchaSettings;
        private readonly IShopFastCustomerRegistrationService _shopFastCustomerRegistrationService;
        private readonly ICustomerService _customerService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IAuthenticationService _authenticationService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly IGenericAttributeService _genericAttributeService;

        public ShopFastLoginController(IWorkContext workContext,
            IStoreContext storeContext,
            IStoreService storeService,
            ISettingService settingService,
            IOrderService orderService,
            ILogger logger,
            ICategoryService categoryService,
            IProductAttributeParser productAttributeParser,
            ILocalizationService localizationService,
            CustomerSettings customerSettings,
            CaptchaSettings captchaSettings,
            IShopFastCustomerRegistrationService shopFastCustomerRegistrationService,
            ICustomerService customerService,
            IShoppingCartService shoppingCartService,
            IAuthenticationService authenticationService,
            ICustomerActivityService customerActivityService,
            IGenericAttributeService genericAttributeService)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._orderService = orderService;
            this._logger = logger;
            this._categoryService = categoryService;
            this._productAttributeParser = productAttributeParser;
            this._localizationService = localizationService;
            _customerSettings = customerSettings;
            _captchaSettings = captchaSettings;
            _shopFastCustomerRegistrationService = shopFastCustomerRegistrationService;
            _customerService = customerService;
            _shoppingCartService = shoppingCartService;
            _authenticationService = authenticationService;
            _customerActivityService = customerActivityService;
            _genericAttributeService = genericAttributeService;
        }

        #region Settings COnfiguration

        private ConfigurationModel PrepareConfigurationModel()
        {
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var settings = _settingService.LoadSetting<ShopFastLoginSettings>(storeScope);
            var model = new ConfigurationModel
            {
                WidgetZone = settings.WidgetZone
            };
            return model;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            var model = PrepareConfigurationModel();

            return View("~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            var settings = _settingService.LoadSetting<ShopFastLoginSettings>(_storeContext.CurrentStore.Id);
            settings.WidgetZone = model.WidgetZone;

            _settingService.SaveSetting(settings, x => x.WidgetZone, _storeContext.CurrentStore.Id, false);

            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }

        [AdminAuthorize]
        public ActionResult DefaultSettings()
        {
            ShopFastLoginPlugin.SetDefaultSettings();

            return Redirect("/Admin/Widget/ConfigureWidget?systemName=Widgets.Login");
        }

        #endregion

        #region Login Form Methods

        public string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext,
                                                                         viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View,
                                             ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        [HttpPost]
        public ActionResult AjaxLogin(string username, string email, string password, bool rememberMe)
        {
            var model = new LoginModel
            {
                Username = username,
                Email = email,
                Password = password,
                UsernamesEnabled = _customerSettings.UsernamesEnabled,
                RememberMe = rememberMe
            };
            if (ModelState.IsValid)
            {
                if (_customerSettings.UsernamesEnabled && model.Username != null)
                {
                    model.Username = model.Username.Trim();
                }
                var loginResult = _shopFastCustomerRegistrationService.ShopFastValidateCustomer(_customerSettings.UsernamesEnabled ? model.Username : model.Email, model.Password);
                switch (loginResult)
                {
                    case CustomerLoginResults.Successful:
                        {
                            var customer = _customerSettings.UsernamesEnabled
                                ? _customerService.GetCustomerByUsername(model.Username)
                                : _customerService.GetCustomerByEmail(model.Email);

                            //migrate shopping cart
                            _shoppingCartService.MigrateShoppingCart(_workContext.CurrentCustomer,
                                customer, true);

                            //sign in new customer
                            _authenticationService.SignIn(customer, model.RememberMe);

                            //activity log
                            _customerActivityService.InsertActivity("PublicStore.Login",
                                _localizationService.GetResource("ActivityLog.PublicStore.Login"), customer);

                            if (!customer.IsAdmin())
                            {
                                //return RedirectToRoute("CustomerInfo");
                                return Json(new
                                {
                                    redirect = true,
                                    url = Url.RouteUrl("CustomerInfo")
                                });
                            }
                            else
                            {
                                //return Redirect("/admin");
                                return Json(new
                                {
                                    redirect = true,
                                    url = "/admin"
                                });
                            }
                            //return Redirect(returnUrl);
                        }
                    case CustomerLoginResults.CustomerNotExist:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.CustomerNotExist"));
                        break;
                    case CustomerLoginResults.Deleted:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.Deleted"));
                        break;
                    case CustomerLoginResults.NotActive:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotActive"));
                        break;
                    case CustomerLoginResults.NotRegistered:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotRegistered"));
                        break;
                    case CustomerLoginResults.WrongPassword:
                    default:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials"));
                        break;
                }
            }

            //If we got this far, something failed, redisplay form
            model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage;

            return Json(new
            {
                redirect = false,
                form = RenderRazorViewToString(
                    "~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Login.cshtml", model)
            });
            //return PartialView("~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Login.cshtml", model);
        }

        public ActionResult PublicInfo(string widgetZone, object additionalData = null)
        {
            var customer = _authenticationService.GetAuthenticatedCustomer();
            if (customer != null)
            {
                return View("~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Redirect.cshtml", customer);
            }
            else
            {
                var model = new LoginModel
                {
                    UsernamesEnabled = _customerSettings.UsernamesEnabled,
                    DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage
                };
                return View("~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Login.cshtml", model);
            }
        }

        [NopHttpsRequirement(SslRequirement.Yes)]
        public ActionResult Login(bool? checkoutAsGuest)
        {
            var model = new LoginModel();
            model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            model.CheckoutAsGuest = checkoutAsGuest.GetValueOrDefault();
            model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage;
            return View("~/Plugins/ShopFast.Widget.Login/Views/ShopFastLogin/Login.cshtml", model);
        }

        public ActionResult Logout()
        {
            //external authentication
            ExternalAuthorizerHelper.RemoveParameters();

            if (_workContext.OriginalCustomerIfImpersonated != null)
            {
                //logout impersonated customer
                _genericAttributeService.SaveAttribute<int?>(_workContext.OriginalCustomerIfImpersonated,
                    SystemCustomerAttributeNames.ImpersonatedCustomerId, null);
                //redirect back to customer details page (admin area)
                return this.RedirectToAction("Edit", "Customer", new { id = _workContext.CurrentCustomer.Id, area = "Admin" });

            }
            _customerActivityService.InsertActivity("PublicStore.Logout", _localizationService.GetResource("ActivityLog.PublicStore.Logout"));

            _authenticationService.SignOut();
            return RedirectToRoute("HomePage");
        }

        #endregion
    }
}