﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;
namespace ShopFast.Plugin.Widgets.Login
{
    /// <summary>
    /// Live person provider
    /// </summary>
    public class ShopFastLoginPlugin : BasePlugin, IWidgetPlugin
    {
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        public ShopFastLoginPlugin(ISettingService settingService,
            IStoreContext storeContext)
        {
            this._settingService = settingService;
            _storeContext = storeContext;
        }
        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();
            IProductTemplateService productTemplateService = EngineContext.Current.Resolve<IProductTemplateService>();
            var settings = new ShopFastLoginSettings { WidgetZone = "billpay_login" };
            settingService.SaveSetting(settings);
        }
        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            var pluginSettings = _settingService.LoadSetting<ShopFastLoginSettings>(
                _storeContext.CurrentStore.Id);
            var result = new List<string>();
            if (!string.IsNullOrEmpty(pluginSettings.WidgetZone))
            {
                result.Add(pluginSettings.WidgetZone);
            }
            return result;
        }
        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "ShopFastLogin";
            routeValues = new RouteValueDictionary { { "Namespaces", 
                                                         "ShopFast.Plugin.Widgets.Login.Controllers" }, 
                                                         { "area", null } };
        }
        /// <summary>
        /// Gets a route for displaying widget
        /// </summary>
        /// <param name="widgetZone">Widget zone where it's displayed</param>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PublicInfo";
            controllerName = "ShopFastLogin";
            routeValues = new RouteValueDictionary
            {
                {"Namespaces", "ShopFast.Plugin.Widgets.Login.Controllers"},
                {"area", null},
                {"widgetZone", widgetZone}
            };
        }
        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            SetDefaultSettings();
            base.Install();
        }
        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {

            base.Uninstall();
        }
    }
}