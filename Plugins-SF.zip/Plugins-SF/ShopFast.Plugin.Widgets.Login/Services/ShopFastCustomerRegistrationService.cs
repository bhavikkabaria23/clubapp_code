using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Stores;

namespace ShopFast.Plugin.Widgets.Login.Services
{
    /// <summary>
    /// Customer registration service
    /// </summary>
    public partial class ShopFastCustomerRegistrationService : CustomerRegistrationService, 
        IShopFastCustomerRegistrationService
    {
        #region Fields

        private readonly ICustomerService _customerService;
        private readonly IEncryptionService _encryptionService;
        private readonly INewsLetterSubscriptionService _newsLetterSubscriptionService;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreService _storeService;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly IRewardPointService _rewardPointService;
        private readonly CustomerSettings _customerSettings;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="customerService">Customer service</param>
        /// <param name="encryptionService">Encryption service</param>
        /// <param name="newsLetterSubscriptionService">Newsletter subscription service</param>
        /// <param name="localizationService">Localization service</param>
        /// <param name="storeService">Store service</param>
        /// <param name="rewardPointService">Reward points service</param>
        /// <param name="rewardPointsSettings">Reward points settings</param>
        /// <param name="customerSettings">Customer settings</param>
        public ShopFastCustomerRegistrationService(ICustomerService customerService, 
            IEncryptionService encryptionService, 
            INewsLetterSubscriptionService newsLetterSubscriptionService,
            ILocalizationService localizationService,
            IStoreService storeService,
            IRewardPointService rewardPointService,
            RewardPointsSettings rewardPointsSettings,
            CustomerSettings customerSettings) : base(customerService,
            encryptionService,
            newsLetterSubscriptionService,
            localizationService,
            storeService,
            rewardPointService,
            rewardPointsSettings,
            customerSettings)
        {
            this._customerService = customerService;
            this._encryptionService = encryptionService;
            this._newsLetterSubscriptionService = newsLetterSubscriptionService;
            this._localizationService = localizationService;
            this._storeService = storeService;
            this._rewardPointsSettings = rewardPointsSettings;
            this._customerSettings = customerSettings;
            _rewardPointService = rewardPointService;
        }

        #endregion

        #region Utilites

        private bool PasswordCorrect(Customer customer, string password)
        {
            string pwd = "";
            var _encryptionService = EngineContext.Current.Resolve<IEncryptionService>();
            //var _encryptionService = new EncryptionService(null);
            var _customerSettings = EngineContext.Current.Resolve<CustomerSettings>();
            switch (customer.PasswordFormat)
            {
                case PasswordFormat.Encrypted:
                    pwd = _encryptionService.EncryptText(password);
                    break;
                case PasswordFormat.Hashed:
                    pwd = _encryptionService.CreatePasswordHash(password, customer.PasswordSalt, _customerSettings.HashedPasswordFormat);
                    //pwd = _encryptionService.CreatePasswordHash(password, customer.PasswordSalt);
                    break;
                default:
                    pwd = password;
                    break;
            }

            return pwd == customer.Password;
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Validate customer
        /// </summary>
        /// <param name="usernameOrEmail">Username or email</param>
        /// <param name="password">Password</param>
        /// <returns>Result</returns>
        public virtual CustomerLoginResults ShopFastValidateCustomer(string usernameOrEmail, string password)
        {
            Customer customer;
            customer = _customerService.GetAllCustomers().ToList().Find(p => 
                (_customerSettings.UsernamesEnabled && usernameOrEmail.Equals(p.Username, 
                    StringComparison.OrdinalIgnoreCase))
                || (!_customerSettings.UsernamesEnabled && usernameOrEmail.Equals(p.Email, 
                    StringComparison.OrdinalIgnoreCase)));
            if (customer != null && PasswordCorrect(customer, password))
            {
                return CustomerLoginResults.Successful;
            }
            
            return  CustomerLoginResults.WrongPassword;
        }

        #endregion
    }
}