﻿
using System.Collections.Generic;
using Nop.Core.Configuration;

namespace ShopFast.Plugin.Widgets.Login
{
    public class ShopFastLoginSettings : ISettings
    {
        public string WidgetZone { get; set; }
    }
}