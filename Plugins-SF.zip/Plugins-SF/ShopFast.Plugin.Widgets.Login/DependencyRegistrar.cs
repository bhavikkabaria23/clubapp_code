﻿using Autofac;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Services.Customers;
using ShopFast.Plugin.Widgets.Login.Services;

namespace ShopFast.Plugin.Widgets.Login
{
    public class DependencyRegistrar : IDependencyRegistrar
    {

        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<ShopFastCustomerRegistrationService>()
                .As<IShopFastCustomerRegistrationService>().InstancePerLifetimeScope();
        }

        public int Order
        {
            get { return 1; }
        }

    }
}
