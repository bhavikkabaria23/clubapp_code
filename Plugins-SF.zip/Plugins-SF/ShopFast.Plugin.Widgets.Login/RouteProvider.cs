﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;
namespace ShopFast.Plugin.Widgets.Login
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //IPN
            routes.MapRoute("ShopFast.Plugin.Widgets.Login.Login", "Plugin/ShopFastLogin/Login",
               new { controller = "ShopFastLogin", action = "Login" },
               new[] { "ShopFast.Plugin.Widgets.Login.Controllers" });
            routes.MapRoute("ShopFast.Plugin.Widgets.Login.DefaultSettings",
               "Admin/Plugin/ShopFastLogin/Settings/DefaultSettings",
               new { controller = "ShopFastLogin", action = "DefaultSettings" },
               new[] { "ShopFast.Plugin.Widgets.Login.Controllers" }).DataTokens.Add("area", "admin");
            routes.MapRoute("ShopFast.Plugin.Widgets.Login.AjaxLogin", "Plugin/ShopFastLogin/AjaxLogin",
                new { controller = "ShopFastLogin", action = "AjaxLogin" },
                new[] { "ShopFast.Plugin.Widgets.Login.Controllers" });
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
