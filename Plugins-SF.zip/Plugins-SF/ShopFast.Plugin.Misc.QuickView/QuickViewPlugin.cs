using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.QuickView
{
    /// <summary>
    /// PLugin
    /// </summary>
    public class QuickViewPlugin : BasePlugin, IWidgetPlugin
    {




        public QuickViewPlugin()
        {

        }

        public bool Authenticate()
        {
            return true;
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string>() { "body_end_html_tag_before" };
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "QuickViewSettings";
            controllerName = "QuickViewAdmin";
            routeValues = new RouteValueDictionary() { { "Namespaces", "ShopFast.Plugin.Misc.QuickView.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for displaying widget
        /// </summary>
        /// <param name="widgetZone">Widget zone where it's displayed</param>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "AddButton";
            controllerName = "QuickView";
            routeValues = new RouteValueDictionary()
            {
                {"Namespaces", "ShopFast.Plugin.Misc.QuickView.Controllers"},
                {"area", null},
                {"widgetZone", widgetZone}
            };
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            SetDefaultSettings();

            base.Install();
        }

        public static void SetDefaultSettings()
        {
            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();
            var settings = new QuickViewSettings
            {
                EnableWidget = true,
                ShowAlsoPurchased = true,
                EnableEnlargePicture = true,
                ShowRelatedProducts = true,
                ApplyForProductsWithProductAtts = true,
                ButtonContainerName = ".buttons,.overlay-content",
                ButtonAddToCart = ".product-box-add-to-cart-button"
            };
            settingService.SaveSetting(settings);

            foreach (var localeResource in GetLocaleResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localeResource.Key, localeResource.Value);
            }
        }

        private static Dictionary<string, string> GetLocaleResources()
        {
            return new Dictionary<string, string>()
            {
                { "ShopFast.Plugins.Admin.QuickView.configuare", "Configuare Quick View" },
                { "ShopFast.Plugins.Admin.QuickView.save", "Save Quick View" },
                { "ITPartner.Plugins.QuickView.Fields.ShowAlsoPurchased", "Show Also Purchased Products" },
                { "ITPartner.Plugins.QuickView.Fields.ShowRelatedProducts", "Show Related Products" },
                { "ITPartner.Plugins.QuickView.Fields.EnableWidget", "Enable QuickView Widget" },
                { "ITPartner.Plugins.QuickView.Fields.EnableEnlargePicture", "Enable Enlarging Product Pictures" },
                { "ITPartner.Plugins.QuickView.Fields.ButtonContainerName", "Button Container Class (eg: .buttons)" },
                { "ITPartner.Plugins.QuickView.Fields.ButtonAddToCart", "Button AddToCart Class (eg: .buttons)" },
                { "ITPartner.Plugins.QuickView.Fields.ApplyForProductsWithProductAtts",
                    "Enable Quick View Dialog only for products with product atts" },
                { "ShopFast.Plugins.Admin.QuickView.Help", "Help" },
                { "ShopFast.Plugins.Admin.QuickView.Settings", "Settings" },
                { "ShopFast.Plugins.Admin.QuickView", "Quick View" }
            };
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            foreach (var localeResource in GetLocaleResources())
            {
                this.DeletePluginLocaleResource(localeResource.Key);
            }

            base.Uninstall();
        }
    }
}
