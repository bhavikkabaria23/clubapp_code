﻿
using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.QuickView
{
    public class QuickViewSettings : ISettings
    {
        public bool ShowAlsoPurchased { get; set; }
        public bool ShowRelatedProducts { get; set; }
        public bool EnableWidget { get; set; }
        public bool EnableEnlargePicture { get; set; }
        public bool ApplyForProductsWithProductAtts { get; set; }
        public string ButtonContainerName { get; set; }
        public string ButtonAddToCart { get; set; }
    }
}