﻿using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Catalog;

namespace ShopFast.Plugin.Misc.QuickView.Models
{
    public class QuickViewModel : BaseNopEntityModel
    {
        public QuickViewModel()
        {
            ProductDetailsModel = new ProductDetailsModel();
            QuickViewSettingsModel = new QuickViewSettingsModel();
        }

        public ProductDetailsModel ProductDetailsModel { get; set; }
        public QuickViewSettingsModel QuickViewSettingsModel { get; set; }
    }
}