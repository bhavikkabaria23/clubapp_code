﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.QuickView.Models
{
    public class QuickViewSettingsModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.ShowAlsoPurchased")]
        public bool ShowAlsoPurchased { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.ShowRelatedProducts")]
        public bool ShowRelatedProducts { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.EnableWidget")]
        public bool EnableWidget { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.EnableEnlargePicture")]
        public bool EnableEnlargePicture { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.ButtonContainerName")]
        public string ButtonContainerName { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.ApplyForProductsWithProductAtts")]
        public bool ApplyForProductsWithProductAtts { get; set; }

        public System.Collections.Generic.List<Nop.Core.Domain.Catalog.Product> ProductsWithProductAtts { get; set; }
        [NopResourceDisplayName("ITPartner.Plugins.QuickView.Fields.ButtonAddToCart")]
        public string ButtonAddToCart { get; set; }
    }
}