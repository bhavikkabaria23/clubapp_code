﻿
using Nop.Web.Framework.Themes;

namespace ShopFast.Plugin.Misc.QuickView.ViewEngines
{
    class CustomViewEngine : ThemeableRazorViewEngine 
    {
        
        public  CustomViewEngine()
        {



            ViewLocationFormats = new[]
                                             {
                                                 "~/Plugins/ShopFast.Misc.QuickView/Views/{0}.cshtml"
                                             };

            PartialViewLocationFormats = new[]
                                             {

                                                 "~/Plugins/ShopFast.Misc.QuickView/Views/{0}.cshtml"
                                             };

            
        }
    }
}
