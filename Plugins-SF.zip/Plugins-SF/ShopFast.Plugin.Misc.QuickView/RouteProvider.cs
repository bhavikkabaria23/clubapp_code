﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;
using ShopFast.Plugin.Misc.QuickView.ViewEngines;

namespace ShopFast.Plugin.Misc.QuickView
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            System.Web.Mvc.ViewEngines.Engines.Insert(0, new CustomViewEngine());

           
            routes.MapRoute("ShopFast.Plugin.Misc.QuickView.ProductDetails", "product_details/{id}",
                new { controller = "QuickView", action = "ProductDetails", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.QuickView.Controllers" });

            routes.MapRoute("ShopFast.Plugins.Admin.QuickView.Settings", "Admin/Plugin/QuickView/Settings",
                   new { controller = "QuickViewAdmin", action = "QuickViewSettings" },
                   new[] { "ShopFast.Plugin.Misc.QuickView.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugins.Admin.QuickView.Help", "Admin/Plugin/QuickView/Help",
                   new { controller = "QuickViewAdmin", action = "QuickViewHelp" },
                   new[] { "ShopFast.Plugin.Misc.QuickView.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugins.Admin.QuickView.SaveSettings", "Admin/Plugin/QuickView/Settings/Save",
                   new { controller = "QuickViewAdmin", action = "QuickViewConfigSettings" },
                   new[] { "ShopFast.Plugin.Misc.QuickView.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugins.Admin.QuickView.DefaultSettings", "Admin/Plugin/QuickView/Settings/DefaultSettings",
                new { controller = "QuickViewAdmin", action = "QuickViewConfigSettings" },
               new[] { "ShopFast.Plugin.Misc.QuickView.Controllers" }).DataTokens.Add("area", "admin");
                }

        public int Priority
        {
            get { return 0; }
        }

    }
}
