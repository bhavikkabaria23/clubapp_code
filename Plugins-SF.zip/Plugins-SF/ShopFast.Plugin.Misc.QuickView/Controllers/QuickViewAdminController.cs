﻿using System.Web.Mvc;
using Nop.Admin.Controllers;
using Nop.Services.Configuration;
using Nop.Web.Framework.Controllers;
using ShopFast.Plugin.Misc.QuickView.Models;

namespace ShopFast.Plugin.Misc.QuickView.Controllers
{
    public class QuickViewAdminController : BaseAdminController
    {
        private readonly ISettingService _settingService;

        public QuickViewAdminController(ISettingService settingService)
        {
            this._settingService = settingService;
        }

        private void PrepareModel(QuickViewSettingsModel model)
        {
            var quickViewsettings = _settingService.LoadSetting<QuickViewSettings>();

            model.ButtonContainerName = quickViewsettings.ButtonContainerName;
            model.EnableWidget = quickViewsettings.EnableWidget;
            model.ShowAlsoPurchased = quickViewsettings.ShowAlsoPurchased;
            model.ShowRelatedProducts = quickViewsettings.ShowRelatedProducts;
            model.EnableEnlargePicture = quickViewsettings.EnableEnlargePicture;
            model.ButtonAddToCart = quickViewsettings.ButtonAddToCart;
            model.ApplyForProductsWithProductAtts = quickViewsettings.ApplyForProductsWithProductAtts;
        }
        private void SaveModel(QuickViewSettingsModel model)
        {
            var settings = new QuickViewSettings()
            {
                EnableWidget = model.EnableWidget,
                ShowAlsoPurchased = model.ShowAlsoPurchased,
                ShowRelatedProducts = model.ShowRelatedProducts,
                ButtonContainerName = model.ButtonContainerName,
                EnableEnlargePicture = model.EnableEnlargePicture,
                ApplyForProductsWithProductAtts = model.ApplyForProductsWithProductAtts,
                ButtonAddToCart = model.ButtonAddToCart
            };

            _settingService.SaveSetting(settings);
        }



        #region Configure Action
        [AdminAuthorize]
        public ActionResult QuickViewSettings()
        {
            var model = new QuickViewSettingsModel();
            PrepareModel(model);
            return View("~/Plugins/ShopFast.Misc.QuickView/Views/QuickViewSettings.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult QuickViewSettings(QuickViewSettingsModel model)
        {
            SaveModel(model);

            return View("~/Plugins/ShopFast.Misc.QuickView/Views/QuickViewSettings.cshtml", model);
        }

        [AdminAuthorize]
        public ActionResult QuickViewConfigSettings()
        {
            QuickViewPlugin.SetDefaultSettings();
            QuickViewSettingsModel model = new QuickViewSettingsModel();
            PrepareModel(model);
            return View("~/Plugins/ShopFast.Misc.QuickView/Views/QuickViewConfigSettings.cshtml", model);
        }


        [HttpPost]
        [AdminAuthorize]
        public ActionResult QuickViewConfigSettings(QuickViewSettingsModel model)
        {
            SaveModel(model);
            return View("~/Plugins/ShopFast.Misc.QuickView/Views/QuickViewConfigSettings.cshtml", model);
        }

        [AdminAuthorize]
        public ActionResult QuickViewHelp()
        {

            return View("QuickViewHelp");
        }
        #endregion

    }
}