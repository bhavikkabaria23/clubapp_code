﻿using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;

namespace ShopFast.Plugin.Misc.QuickView
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        //nop3.7 upgrade begin
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 1; }
        }

    }
}
