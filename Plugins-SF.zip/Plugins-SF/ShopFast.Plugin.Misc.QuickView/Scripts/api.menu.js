﻿


var quickViewApi = function () {
};


quickViewApi.prototype.viewProductDetails = function (options) {
    var config = $.extend({
        data: {},
        success: function () {
        },
        error: function () {
        }
    }, options);
    AjaxCart.setLoadWaiting(true);
    $.apiCall({
        type: 'POST',
        data: config.data,
        url: '/product_details',
        success: function (html) {

            $("#quick-view-modal").html(html);

            $("#quick-view-modal").dialog({
                dialogClass: "quickview",
                modal: true,
                /*open: function() {
                    $('.ui-widget-overlay').addClass('custom-overlay');
                },
                close: function() {
                    $('.ui-widget-overlay').removeClass('custom-overlay');
                },    */
                Cancel: function () {
                    $(this).dialog("close");
                }
            });
        }
    });

};






var api = new quickViewApi();