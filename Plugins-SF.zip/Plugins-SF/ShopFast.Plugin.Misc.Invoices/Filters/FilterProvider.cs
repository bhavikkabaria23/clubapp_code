﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Nop.Web.Controllers;

namespace ShopFast.Plugin.Misc.Invoices.Filters
{
    public class FilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            var filters = new List<Filter>()
            {

            };

            //My account / Order details page
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(OrderController))
                && (actionDescriptor.ActionName.ToLower().Equals("Details".ToLower())
                    || actionDescriptor.ActionName.ToLower().Equals("PrintOrderDetails".ToLower())
                    )
                && (controllerContext.HttpContext.Request.HttpMethod == "GET")
                )
            {
                filters.Add(new Filter(new OrderDetailsFilter(), FilterScope.Action, null));
            }

            return filters;
        }
    }
}
