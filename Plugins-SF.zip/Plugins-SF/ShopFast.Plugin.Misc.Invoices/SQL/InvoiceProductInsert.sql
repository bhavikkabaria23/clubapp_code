﻿--DELETE FROM [dbo].[Product] WHERE Sku = N'ShopFast.Plugins.Misc.Invoices.NoPriceProduct';

if exists(select * from [dbo].[Product]
	where Sku = N'ShopFast.Plugins.Misc.Invoices.NoPriceProduct')
begin
	UPDATE [dbo].[Product] set [Deleted] = 0 where Sku = N'ShopFast.Plugins.Misc.Invoices.NoPriceProduct';
end
else
begin
	INSERT INTO  [dbo].[Product] ([ProductTypeId], [ParentGroupedProductId], [VisibleIndividually], 
	[Name], [ShortDescription], [FullDescription], [AdminComment], [ProductTemplateId], [VendorId], [ShowOnHomePage], 
	[MetaKeywords], [MetaDescription], [MetaTitle], [AllowCustomerReviews], [ApprovedRatingSum], 
	[NotApprovedRatingSum], [ApprovedTotalReviews], [NotApprovedTotalReviews], [SubjectToAcl], [LimitedToStores], 
	[Sku], [ManufacturerPartNumber], [Gtin], [IsGiftCard], [GiftCardTypeId], [RequireOtherProducts], 
	[RequiredProductIds], [AutomaticallyAddRequiredProducts], [IsDownload], [DownloadId], [UnlimitedDownloads], 
	[MaxNumberOfDownloads], [DownloadExpirationDays], [DownloadActivationTypeId], [HasSampleDownload], 
	[SampleDownloadId], [HasUserAgreement], [UserAgreementText], [IsRecurring], [RecurringCycleLength], 
	[RecurringCyclePeriodId], [RecurringTotalCycles], [IsRental], [RentalPriceLength], [RentalPricePeriodId], 
	[IsShipEnabled], [IsFreeShipping], [ShipSeparately], [AdditionalShippingCharge], [DeliveryDateId], [IsTaxExempt], 
	[TaxCategoryId],[IsTelecommunicationsOrBroadcastingOrElectronicServices], [ManageInventoryMethodId], 
	[UseMultipleWarehouses], [WarehouseId], [StockQuantity], [DisplayStockAvailability], [DisplayStockQuantity], 
	[MinStockQuantity], [LowStockActivityId], [NotifyAdminForQuantityBelow], [BackorderModeId], 
	[AllowBackInStockSubscriptions], [OrderMinimumQuantity], [OrderMaximumQuantity], [AllowedQuantities], 
	[AllowAddingOnlyExistingAttributeCombinations], [DisableBuyButton], [DisableWishlistButton], 
	[AvailableForPreOrder], [PreOrderAvailabilityStartDateTimeUtc], [CallForPrice], [Price], [OldPrice], 
	[ProductCost],[SpecialPrice], [SpecialPriceStartDateTimeUtc], [SpecialPriceEndDateTimeUtc],[CustomerEntersPrice], 
	[MinimumCustomerEnteredPrice], [MaximumCustomerEnteredPrice],[HasTierPrices], [HasDiscountsApplied], [Weight], 
	[Length], [Width], [Height], [AvailableStartDateTimeUtc], [AvailableEndDateTimeUtc], [DisplayOrder], [Published], 
	[Deleted], [CreatedOnUtc], [UpdatedOnUtc]

-- nop3.7 upgrade begin
	,[BasepriceEnabled]
	,[BasepriceAmount]
	,[BasepriceUnitId]
	,[BasepriceBaseAmount]
	,[BasepriceBaseUnitId]
	,[MarkAsNew]
	,[MarkAsNewStartDateTimeUtc]
	,[MarkAsNewEndDateTimeUtc]
-- nop3.7 upgrade end

-- nop3.8 upgrade begin
	,[NotReturnable]
-- nop3.8 upgrade end

	--, [ShowOnPointOfSale]

	)
VALUES (5,--ProductTypeId
 0, --ParentGroupedProductId
 1, --VisibleIndividually
 N'ShopFast.Plugins.Misc.Invoices.NoPriceProduct', --Name
 N'',--ShortDescription
 N'', --FullDescription
 NULL,-- AdminComment
 1, --ProductTemplateId
 0, --VendorId
 0, --ShowOnHomePage
 NULL, --MetaKeywords
 NULL, --MetaDescription
 NULL, --MetaTitle
1, --AllowCustomerReviews
4, --ApprovedRatingSum
0, --NotApprovedRatingSum
1, --ApprovedTotalReviews
0, --NotApprovedTotalReviews
0, --SubjectToAcl 
0, --LimitedToStores
N'ShopFast.Plugins.Misc.Invoices.NoPriceProduct', --Sku
NULL,--ManufacturerPartNumber
NULL, --Gtin
0, --IsGiftCard
0, --GiftCardTypeId 
0, --RequireOtherProducts
NULL, --RequiredProductIds
0, --AutomaticallyAddRequiredProducts 
0, --IsDownload
0,  --DownloadId
0, -- UnlimitedDownloads
0, --MaxNumberOfDownloads
NULL, --DownloadExpirationDays
0, --DownloadActivationTypeId  
0, --HasSampleDownload
0, --SampleDownloadId
0,  --SampleDownloadId
NULL,--HasUserAgreement
0, --UserAgreementText
0, --IsRecurring
0, --RecurringCycleLength
0, --RecurringCyclePeriodId
0, --RecurringTotalCycles
0,--RecurringTotalCycles 
0, --IsRental
1, -- RentalPriceLength
0, --RentalPricePeriodId
0, --IsShipEnabled
CAST(0.0000 AS Decimal(18, 4)), --IsFreeShipping
0, --ShipSeparately
0, --AdditionalShippingCharge
2, --DeliveryDateId
0, --IsTaxExempt
1, --TaxCategoryId
0, --IsTelecommunicationsOrBroadcastingOrElectronicServices
0, --ManageInventoryMethodId 
10000, --UseMultipleWarehouses
1, --WarehouseId
0, --StockQuantity
0, --DisplayStockAvailability
1, --DisplayStockQuantity
1, --MinStockQuantity
0, --LowStockActivityId
0, --NotifyAdminForQuantityBelow
1,--BackorderModeId
10000, --AllowBackInStockSubscriptions 
NULL, --OrderMinimumQuantity 
0,  --OrderMaximumQuantity
0, --AllowedQuantities
0,  --AllowAddingOnlyExistingAttributeCombinations
0, --DisableBuyButton  
NULL, --DisableWishlistButton
0, --AvailableForPreOrder
CAST(75.0000 AS Decimal(18, 4)), --PreOrderAvailabilityStartDateTimeUtc
CAST(0.0000 AS Decimal(18, 4)),  --CallForPrice
CAST(0.0000 AS Decimal(18, 4)),  --Price
NULL, --OldPrice
NULL, --ProductCost
NULL, --SpecialPrice
0, --SpecialPriceStartDateTimeUtc
CAST(0.0000 AS Decimal(18, 4)),--SpecialPriceEndDateTimeUtc
1, -- CustomerEntersPrice
0,--MinimumCustomerEnteredPrice
1000000,--MaximumCustomerEnteredPrice
CAST(2.0000 AS Decimal(18, 4)), --HasTierPrices
CAST(2.0000 AS Decimal(18, 4)), --HasDiscountsApplied
CAST(2.0000 AS Decimal(18, 4)), --Weight
CAST(3.0000 AS Decimal(18, 4)), --Length
NULL, --Width
NULL,--Height
0, --AvailableStartDateTimeUtc
1,--AvailableEndDateTimeUtc
0,--DisplayOrder
CAST(0x0000A3F800E51ED2 AS DateTime), --Published
CAST(0x0000A3F800E51ED2 AS DateTime) --Deleted;

-- nop3.7 upgrade begin
, 0 --BasepriceEnabled
, 0 --BasepriceAmount
, 0 --BasepriceUnitId
, 0 --BasepriceBaseAmount
, 0 --BasepriceBaseUnitId
, 0 --MarkAsNew
, CAST(0x0000A3F800E51ED2 AS DateTime) --MarkAsNewStartDateTimeUtc
, CAST(0x0000A3F800E51ED2 AS DateTime) --MarkAsNewEndDateTimeUtc
-- nop3.7 upgrade end

-- nop3.8 upgrade begin
, 0
-- nop3.8 upgrade end

--, 0 --ShowOnPointOfSale

); 

UPDATE [dbo].[Product] SET CustomerEntersPrice = 1, MinimumCustomerEnteredPrice = 0, 
	MaximumCustomerEnteredPrice = 1000000, IsShipEnabled = 0 
	WHERE Sku = 'ShopFast.Plugins.Misc.Invoices.NoPriceProduct';
end

SELECT Id FROM [dbo].[Product] WHERE Sku = 'ShopFast.Plugins.Misc.Invoices.NoPriceProduct';