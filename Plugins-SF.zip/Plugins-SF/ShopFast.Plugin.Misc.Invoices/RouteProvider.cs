﻿using System.Security.Policy;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;
using ShopFast.Plugin.Misc.Core.Domain;

namespace ShopFast.Plugin.Misc.Invoices
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //Create/Edit/View/List
            //routes.MapRoute("ShopFast.Plugin.Misc.Invoices.List", "Plugin/Invoices/{invoiceType}s",
            //   new { controller = "Invoices", action = "List", invoiceType = UrlParameter.Optional },
            //   new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Invoices", "Plugin/Invoices/Invoices",
               new { controller = "Invoices", action = "Invoices" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Estimates", "Plugin/Invoices/Estimates",
               new { controller = "Invoices", action = "Estimates" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", "Plugin/Invoices/RecurringInvoices",
               new { controller = "Invoices", action = "RecurringInvoices" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceList", "Plugin/Invoices/InvoiceList",
               new { controller = "Invoices", action = "InvoiceList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoicePaymentHistory", "Plugin/Invoices/InvoicePaymentHistory/{id}",
                new { controller = "Invoices", action = "InvoicePaymentHistory", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Create", "Plugin/Invoices/Create/{invoiceType}",
               new { controller = "Invoices", action = "Create", invoiceType = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Edit", "Plugin/Invoices/Edit/{id}",
               new { controller = "Invoices", action = "Edit", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.View", "Plugin/Invoices/View/{id}",
               new { controller = "Invoices", action = "View", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            /*routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Invoices", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.Invoice },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Estimates", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.Estimate },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.RecurringInvoice },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");*/
            
            //Estimates
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AcceptEstimate", "Plugin/Invoices/AcceptEstimate/{id}",
                new { controller = "Invoices", action = "AcceptEstimate", id = UrlParameter.Optional },
                new[] {"ShopFast.Plugin.Misc.Invoices.Controllers"});

            //Recurring Invoices            
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.CancelRecurringInvoice", "Plugin/Invoices/CancelRecurringInvoice/{id}",
                new { controller = "Invoices", action = "CancelRecurringInvoice", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ProcessNextRecurringInvoice", "Plugin/Invoices/ProcessNextRecurringInvoice/{id}",
                new { controller = "Invoices", action = "ProcessNextRecurringInvoice", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ChainedInvoicesList", "Plugin/Invoices/ChainedInvoicesList",
               new { controller = "Invoices", action = "ChainedInvoicesList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Payments
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Payments", "Plugin/Invoices/Payments",
               new { controller = "Invoices", action = "Payments" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.PaymentList", "Plugin/Invoices/PaymentList",
               new { controller = "Invoices", action = "PaymentList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            /*routes.MapRoute("ShopFast.Plugin.Misc.Invoices.CreatePayment", "Plugin/Invoices/CreatePayment",
                new { controller = "Invoices", action = "CreatePayment"},
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.PayInvoice", "Plugin/Invoices/PayInvoice/{id}",
                new {controller = "Invoices", action = "CreatePayment", id = UrlParameter.Optional},
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");*/

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.SearchInvoiceToPay", "Plugin/Invoices/SearchInvoiceToPay",
                new { controller = "Invoices", action = "SearchInvoiceToPay" },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.GetInvoiceToPay", "Plugin/Invoices/GetInvoiceToPay/{id}",
                new { controller = "Invoices", action = "SearchInvoiceToPay", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ViewPayment", "Plugin/Invoices/ViewPayment/{id}",
                new { controller = "Invoices", action = "ViewPayment", id = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.DeletePayment", "Plugin/Invoices/DeletePayment/{id}",
               new { controller = "Invoices", action = "DeletePayment", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxLoadInvoices", "Plugin/Invoices/Ajax/Invoices/AjaxLoadInvoices",
                new { controller = "Invoices", action = "AjaxLoadInvoices" },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxGetInvoiceData", "Plugin/Invoices/Ajax/Invoices/AjaxGetInvoiceData",
                new { controller = "Invoices", action = "AjaxGetInvoiceData" },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxPaymentInfo", "Plugin/Invoices/Ajax/Payments/AjaxPaymentInfo",
                new { controller = "Invoices", action = "AjaxPaymentInfo" },
                new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Ajax
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxInvoiceSummary", "Plugin/Invoices/Ajax/Invoices/AjaxInvoiceSummary",
               new { controller = "Invoices", action = "AjaxInvoiceSummary" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxMultiInvoicesSummary",
                "Plugin/Invoices/Ajax/Invoices/AjaxMultiInvoicesSummary",
               new { controller = "Invoices", action = "AjaxMultiInvoicesSummary", invoiceIds = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Kendo Grid
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemsList", "Plugin/Invoices/InvoiceItemsList",
               new { controller = "Invoices", action = "InvoiceItemsList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemAdd", "Plugin/Invoices/InvoiceItemAdd",
               new { controller = "Invoices", action = "InvoiceItemAdd" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemUpdate", "Plugin/Invoices/InvoiceItemUpdate",
               new { controller = "Invoices", action = "InvoiceItemUpdate" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemDelete", "Plugin/Invoices/InvoiceItemDelete",
               new { controller = "Invoices", action = "InvoiceItemDelete" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ProductsList", "Plugin/Invoices/ProductsList",
               new { controller = "Invoices", action = "ProductsList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxInvoiceItemCalculateTotal",
                 "Plugin/Invoices/Ajax/Invoices/AjaxInvoiceItemCalculateTotal",
                 new { controller = "Invoices", action = "AjaxInvoiceItemCalculateTotal" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            //Configuration
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.DefaultSettings",
               "Plugin/Invoices/Settings/DefaultSettings",
               new { controller = "Invoices", action = "DefaultSettings" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Payment
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ProceedPayment",
                 "Plugin/Invoices/ProceedPayment",
                 new { controller = "Invoices", action = "ProceedPayment" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            //Customer List
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxSetCustomerId",
                 "Plugin/Invoices/Ajax/Customer/AjaxSetCustomerId",
                 new { controller = "Invoices", action = "AjaxSetCustomerId" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxCustomersList",
               "Plugin/Invoices/Ajax/Customer/AjaxCustomersList",
               new { controller = "Invoices", action = "AjaxCustomersList" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxLoadCustomers",
               "Plugin/Invoices/Ajax/Customer/AjaxLoadCustomers",
               new { controller = "Invoices", action = "AjaxLoadCustomers" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxCustomerInfo",
               "Plugin/Invoices/Ajax/Customer/AjaxCustomerInfo",
               new { controller = "Invoices", action = "AjaxCustomerInfo" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Discounts
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxGetAppliedDiscount",
                 "Plugin/Invoices/Ajax/Discount/AjaxGetAppliedDiscount",
                 new { controller = "Invoices", action = "AjaxGetAppliedDiscount" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxApplyDiscountCoupon",
                 "Plugin/Invoices/Ajax/Discount/AjaxApplyDiscountCoupon",
                 new { controller = "Invoices", action = "AjaxApplyDiscountCoupon" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxRemoveDiscountCoupon",
                 "Plugin/Invoices/Ajax/Discount/AjaxRemoveDiscountCoupon",
                 new { controller = "Invoices", action = "AjaxRemoveDiscountCoupon" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            //GiftCards
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxApplyGiftCard",
                 "Plugin/Invoices/Ajax/GiftCard/AjaxApplyGiftCard",
                 new { controller = "Invoices", action = "AjaxApplyGiftCard" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.AjaxRemoveGiftCard",
                 "Plugin/Invoices/Ajax/GiftCard/AjaxRemoveGiftCard",
                 new { controller = "Invoices", action = "AjaxRemoveGiftCard" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" });
            
            //Items
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Items",
                 "Plugin/Invoices/Items",
                 new { controller = "Invoices", action = "Items" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.ItemsList",
                 "Plugin/Invoices/ItemsList",
                 new { controller = "Invoices", action = "ItemsList" },
                 new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.CreateItem", "Plugin/Invoices/CreateItem",
               new { controller = "Invoices", action = "CreateItem" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.UpdateItem", "Plugin/Invoices/UpdateItem",
               new { controller = "Invoices", action = "UpdateItem" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.DeleteItem", "Plugin/Invoices/DeleteItem",
               new { controller = "Invoices", action = "DeleteItem" },
               new[] { "ShopFast.Plugin.Misc.Invoices.C                                 ontrollers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.GetItem", "Plugin/Invoices/GetItem",
               new { controller = "Invoices", action = "GetItem" },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");
            
            //Print Details / Get PDF
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.PrintOrderDetails", "Plugin/Invoices/PrintOrderDetails/{id}",
               new { controller = "Invoices", action = "PrintOrderDetails", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.GetPdfInvoice", "Plugin/Invoices/GetPdfInvoice/{id}",
               new { controller = "Invoices", action = "GetPdfInvoice", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            //Invoice Deatails
            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceDetails.CancelOrder", 
                "Plugin/Invoices/InvoiceDetails/CancelOrder/{id}",
               new { controller = "Invoices", action = "CancelOrder", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.Invoices.InvoiceDetails.Edit",
                "Plugin/Invoices/InvoiceDetails/Edit/{id}",
               new { controller = "Invoices", action = "EditInvoiceDetails", id = UrlParameter.Optional },
               new[] { "ShopFast.Plugin.Misc.Invoices.Controllers" }).DataTokens.Add("area", "admin");



            //Base Methods
            //routes.MapRoute("ShopFast.Plugin.Misc.Invoices.Overload.PrintOrder",
            //    "orderdetails/print/{orderId}",
            //    new {controller = "Invoices", action = "PrintOrderDetails", orderId = UrlParameter.Optional},
            //    new[] {"ShopFast.Plugin.Misc.Invoices.Controllers"});
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
