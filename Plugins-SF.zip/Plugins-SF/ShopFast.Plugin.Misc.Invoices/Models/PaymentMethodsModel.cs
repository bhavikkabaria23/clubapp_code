﻿using System.Collections.Generic;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Checkout;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class PaymentMethodsModel : BaseNopModel
    {
        public PaymentMethodsModel()
        {
            Warnings = new List<string>();
        }

        public int InvoiceId { get; set; }

        public IList<CheckoutPaymentMethodModel.PaymentMethodModel> PaymentMethods { get; set; }
        public bool DisplayRewardPoints { get; set; }
        public string RewardPointsAmount { get; set; }
        public int RewardPointsBalance { get; set; }
        public bool IsPaymentWorkflowRequired { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.PaymentMethod")]
        public string PaymentMethod { get; set; }
        public List<string> Warnings { get; set; } 
    }
}
