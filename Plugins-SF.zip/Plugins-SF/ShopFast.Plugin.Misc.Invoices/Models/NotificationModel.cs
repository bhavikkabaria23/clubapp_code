﻿using System.Collections.Generic;
using System.Linq;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class NotificationModel
    {
        public NotificationModel()
        {
            Clear();
        }

        public List<string> SuccessMessages { get; set; }
        public List<string> ErrorMessages { get; set; }

        public void Clear()
        {
            SuccessMessages = new List<string>();
            ErrorMessages = new List<string>();
        }

        public string Error
        {
            get { return ErrorMessages.Any() ? ErrorMessages.First() : null; }
            set { ErrorMessages.Add(value); }
        }

        public string Success
        {
            get { return SuccessMessages.Any() ? SuccessMessages.First() : null; }
            set { SuccessMessages.Add(value); }
        }
    }
}
