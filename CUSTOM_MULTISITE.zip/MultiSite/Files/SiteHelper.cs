﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Hosting;
using System.Xml;
using Nop.Core.Data;
using Nop.Data;
using MultiSite.Data;
using MultiSite.Models;

namespace Nop.Web.Models.SiteRegistration
{
    public class SiteHelper
    {

        #region Fields

        public static readonly string settingsFilename = "Settings.txt";

        public static readonly string dbFilename = "Nop.Db.sdf";

        public static readonly string App_data_path = HostingEnvironment.MapPath("~/App_Data/");

        public static readonly string templateSettingsFilename = Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "TemplateSettings.txt");

        public static readonly string templateDbFilename = Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template.sdf");

        public static readonly string defautTemplateMdf = Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template.mdf");

        public static readonly string defautTemplateLdf = Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), "Template_log.ldf");

        public static readonly string Hostname = "137.116.112.203";

        public static readonly string LocalHostname = "10.0.2.4";

        public static readonly string Login = "admin";

        public static readonly string Password = "hgbFd53Ews4ds$d";

        public static string AgentEntryPoint
        {
            get
            { return "https://" + LocalHostname + ":8443/enterprise/control/agent.php"; }
        }

        #endregion

        #region Utilities

        private static bool RemoteCertificateValidation(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors != SslPolicyErrors.RemoteCertificateNotAvailable)
                return true;

            Console.WriteLine("Certificate error: {0}", sslPolicyErrors);

            // Do not allow this client to communicate with unauthenticated servers.
            return false;
        }

        private static XmlDocument ProcessPleskRequest(XmlDocument packet)
        {
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(RemoteCertificateValidation);

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(AgentEntryPoint);
            var message = packet.OuterXml;

            request.Method = "POST";
            request.Headers.Add("HTTP_AUTH_LOGIN", Login);
            request.Headers.Add("HTTP_AUTH_PASSWD", Password);
            request.ContentType = "text/xml";
            request.ContentLength = message.Length;

            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] buffer = encoding.GetBytes(message);

            using (Stream requsetStream = request.GetRequestStream())
            {
                requsetStream.Write(buffer, 0, message.Length);
            }

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();

            TextReader xml = new StreamReader(stream);
            XmlDocument xmlDocument = new XmlDocument();

            using (XmlReader reader = XmlReader.Create(xml))
            {
                xmlDocument.Load(reader);
            }

            return xmlDocument;
        }

        private static string CreatePleskCustomer(string email, string password)
        {
            var customerId = string.Empty;

            StringBuilder requestXml = new StringBuilder();
            requestXml.AppendLine("<packet>");
            requestXml.AppendLine("<customer>");
            requestXml.AppendLine("<add>");
            requestXml.AppendLine("<gen_info>");
            requestXml.AppendLine(string.Format("<pname>{0}</pname>", email));
            requestXml.AppendLine(string.Format("<login>{0}</login>", email));
            requestXml.AppendLine(string.Format("<passwd>{0}</passwd>", password));
            requestXml.AppendLine("<status>0</status>");
            requestXml.AppendLine(string.Format("<email>{0}</email>", email));
            requestXml.AppendLine("</gen_info>");
            requestXml.AppendLine("</add>");
            requestXml.AppendLine("</customer>");
            requestXml.AppendLine("</packet>");

            XmlDocument xmlDocument = new XmlDocument();
            // Add the content
            xmlDocument.LoadXml(requestXml.ToString());

            var response = ProcessPleskRequest(xmlDocument);
            var result = response.SelectSingleNode("//status").InnerText;
            if (result.Equals("ok"))
            {
                customerId = response.SelectSingleNode("//id").InnerText;
            }

            return customerId;
        }

        private static string CreateWebSpace(string ownerId, string storeName, string ftpUserName, string ftpPassword)
        {
            var webSpaceId = string.Empty;

            StringBuilder requestXml = new StringBuilder();
            requestXml.AppendLine("<packet>");
            requestXml.AppendLine("<webspace>");
            requestXml.AppendLine("<add>");
            requestXml.AppendLine("<gen_setup>");
            requestXml.AppendLine(string.Format("<name>{0}.shopfast.com</name>", storeName));
            requestXml.AppendLine(string.Format("<owner-id>{0}</owner-id>", ownerId));
            requestXml.AppendLine(string.Format("<ip_address>{0}</ip_address>", LocalHostname));
            requestXml.AppendLine("<htype>vrt_hst</htype>");
            requestXml.AppendLine("</gen_setup>");
            requestXml.AppendLine("<hosting>");
            requestXml.AppendLine("<vrt_hst>");
            requestXml.AppendLine("<property>");
            requestXml.AppendLine("<name>ftp_login</name>");
            requestXml.AppendLine(string.Format("<value>{0}</value>", ftpUserName));
            requestXml.AppendLine("</property>");
            requestXml.AppendLine("<property>");
            requestXml.AppendLine("<name>ftp_password</name>");
            requestXml.AppendLine(string.Format("<value>{0}</value>", ftpPassword));
            requestXml.AppendLine("</property>");
            requestXml.AppendLine(string.Format("<ip_address>{0}</ip_address>", LocalHostname));
            requestXml.AppendLine("</vrt_hst>");
            requestXml.AppendLine("</hosting>");
            requestXml.AppendLine("<plan-name>Default Domain</plan-name>");
            requestXml.AppendLine("</add>");
            requestXml.AppendLine("</webspace>");
            requestXml.AppendLine("</packet>");

            XmlDocument xmlDocument = new XmlDocument();
            // Add the content
            xmlDocument.LoadXml(requestXml.ToString());

            var response = ProcessPleskRequest(xmlDocument);
            var resultXmlPath = "/packet/webspace/add/result/";
            var result = response.SelectSingleNode(string.Concat(resultXmlPath, "status")).InnerText;
            if (result.Equals("ok"))
            {
                webSpaceId = response.SelectSingleNode(string.Concat(resultXmlPath, "id")).InnerText;
            }

            return webSpaceId;
        }

        private static string GetWebSpace(string ownerId)
        {
            string webSpaceId = string.Empty;

            StringBuilder requestXml = new StringBuilder();
            requestXml.AppendLine("<packet>");
            requestXml.AppendLine("<webspace>");
            requestXml.AppendLine("<get>");
            requestXml.AppendLine("<filter>");
            requestXml.AppendLine(string.Format("<owner-id>{0}</owner-id>", ownerId));
            requestXml.AppendLine("</filter>");
            requestXml.AppendLine("<dataset>");
            requestXml.AppendLine("</dataset>");
            requestXml.AppendLine("</get>");
            requestXml.AppendLine("</webspace>");
            requestXml.AppendLine("</packet>");

            XmlDocument xmlDocument = new XmlDocument();
            // Add the content
            xmlDocument.LoadXml(requestXml.ToString());

            var response = ProcessPleskRequest(xmlDocument);
            var resultXmlPath = "/packet/webspace/get/result/";
            var result = response.SelectSingleNode(string.Concat(resultXmlPath, "status")).InnerText;
            if (result.Equals("ok"))
            {
                webSpaceId = response.SelectSingleNode(string.Concat(resultXmlPath, "id")).InnerText;
            }

            return webSpaceId;
        }

        private static string UpdateWebSpace(string webSpaceId, string ownerId, string storeName, string ftpUserName, string ftpPassword)
        {
            string updatedWebSpaceId = string.Empty;

            StringBuilder requestXml = new StringBuilder();
            requestXml.AppendLine("<packet>");
            requestXml.AppendLine("<webspace>");
            requestXml.AppendLine("<set>");
            requestXml.AppendLine("<filter>");
            requestXml.AppendLine(string.Format("<id>{0}</id>", webSpaceId));
            requestXml.AppendLine("</filter>");
            requestXml.AppendLine("<values>");
            requestXml.AppendLine("<gen_setup>");
            requestXml.AppendLine(string.Format("<name>{0}.shopfast.com</name>", storeName));
            requestXml.AppendLine(string.Format("<owner-id>{0}</owner-id>", ownerId));
            requestXml.AppendLine("</gen_setup>");
            requestXml.AppendLine("<hosting>");
            requestXml.AppendLine("<vrt_hst>");
            requestXml.AppendLine("<property>");
            requestXml.AppendLine("<name>ftp_login</name>");
            requestXml.AppendLine(string.Format("<value>{0}</value>", ftpUserName));
            requestXml.AppendLine("</property>");
            requestXml.AppendLine("<property>");
            requestXml.AppendLine("<name>ftp_password</name>");
            requestXml.AppendLine(string.Format("<value>{0}</value>", ftpPassword));
            requestXml.AppendLine("</property>");
            requestXml.AppendLine("</vrt_hst>");
            requestXml.AppendLine("</hosting>");
            requestXml.AppendLine("</values>");
            requestXml.AppendLine("</set>");
            requestXml.AppendLine("</webspace>");
            requestXml.AppendLine("</packet>");

            XmlDocument xmlDocument = new XmlDocument();
            // Add the content
            xmlDocument.LoadXml(requestXml.ToString());
            var response = ProcessPleskRequest(xmlDocument);

            var resultXmlPath = "/packet/webspace/set/result/";
            var result = response.SelectSingleNode(string.Concat(resultXmlPath, "status")).InnerText;
            if (result.Equals("ok"))
            {
                updatedWebSpaceId = response.SelectSingleNode(string.Concat(resultXmlPath, "id")).InnerText;
            }

            return updatedWebSpaceId;
        }

        private static string GetPleskCustomer(string userName)
        {
            var ownerId = string.Empty;

            StringBuilder requestXml = new StringBuilder();
            requestXml.AppendLine("<packet>");
            requestXml.AppendLine("<customer>");
            requestXml.AppendLine("<get>");
            requestXml.AppendLine("<filter>");
            requestXml.AppendLine(string.Format("<login>{0}</login>", userName));
            requestXml.AppendLine("</filter>");
            requestXml.AppendLine("<dataset>");
            requestXml.AppendLine("</dataset>");
            requestXml.AppendLine("</get>");
            requestXml.AppendLine("</customer>");
            requestXml.AppendLine("</packet>");

            XmlDocument xmlDocument = new XmlDocument();
            // Add the content
            xmlDocument.LoadXml(requestXml.ToString());
            var response = ProcessPleskRequest(xmlDocument);

            var resultXmlPath = "/packet/customer/get/result/";
            var result = response.SelectSingleNode(string.Concat(resultXmlPath, "status")).InnerText;
            if (result.Equals("ok"))
            {
                ownerId = response.SelectSingleNode(string.Concat(resultXmlPath, "id")).InnerText;
            }

            return ownerId;
        }

        #endregion

        #region Methods

        static string GetTemplateMdf(string templateName)
        {
            return Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), string.Format("{0}.mdf", templateName));
        }

        static string GetTemplateLdf(string templateName)
        {
            return Path.Combine(HostingEnvironment.MapPath("~/App_Data/"), string.Format("{0}_log.ldf", templateName));
        }

        public static void AddToSqlServer(string storeName, string industryType, out string csStoreName)
        {

            if (!string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["templatePath"]) &&
               !string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["newDBPath"]))
            {
                #region New Mehtod of Creasting sub domain DB
                var dbTemplateName = MultisiteHelper.GetDatabaseTemplateName(industryType);
                var templateMdf = GetTemplateMdf(dbTemplateName);
                var templateLdf = GetTemplateLdf(dbTemplateName);
                //if (!File.Exists(templateMdf) || !File.Exists(templateLdf))
                //{
                //    MultiSiteDataProvider.LogToAdminDatabase(string.Format("One of files ({0}) or ({1}) not found. Using default template.", templateMdf, templateLdf));
                //    templateMdf = defautTemplateMdf;
                //    templateLdf = defautTemplateLdf;
                //}

                /* Delete settings file if exists */
                var newStoreSettingsFilename = Path.Combine(App_data_path, string.Format("{0}{1}", storeName, settingsFilename));
                if (File.Exists(newStoreSettingsFilename))
                {
                    File.Delete(newStoreSettingsFilename);
                }

                //var index = 0;
                var backupStoreName = storeName;

                /* Copy template data file (.mdf) */
                //string newMdf;
                //do
                //{
                //    newMdf = Path.Combine(App_data_path, MultisiteHelper.GetDbName(storeName) + ".mdf");
                //    if (File.Exists(newMdf))
                //    {
                //        storeName = string.Format("{0}.{1}", backupStoreName, ++index);
                //    }
                //    else
                //    {
                //        File.Copy(templateMdf, newMdf, true);
                //        break;
                //    }
                //} while (true);

                csStoreName = storeName;

                /* copy template log file (.ldf)*/
                //var newLdf = newMdf.Replace(".mdf", "_log.ldf");
                //File.Copy(templateLdf, newLdf, true);

                using (var dbContext = new Sites4Entities())
                {
                    //var command = dbContext.Database.Connection.CreateCommand();
                    //command.CommandText = "sp_RestoreDatabase_Template";
                    //command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.Add(new SqlParameter("@templatePath", "F:\\websites\\SF_DemoSiteDB\\SF_demo.bak"));
                    //command.Parameters.Add(new SqlParameter("@templateDBLogicalName", "NOP3_70"));
                    //command.Parameters.Add(new SqlParameter("@newDBPath","F:\\websites\\SF_DemoSiteDB"));
                    //command.Parameters.Add(new SqlParameter("@newDBName", "TestDb_db9"));

                    //dbContext.Database.Connection.Open();
                    //var reader = command.ExecuteReader();
                    //string storename = reader[0].ToString();

                    if (!string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["templatePath"]) &&
                       !string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["newDBPath"]))
                    {
                        dbContext.Database.CommandTimeout = 300;
                        var result = dbContext.Database.SqlQuery<string>("sp_RestoreDatabase_Template @templatePath,@templateDBLogicalName,@newDBPath,@newDBName",
                                         new SqlParameter("@templatePath", System.Configuration.ConfigurationManager.AppSettings["templatePath"] + dbTemplateName + ".bak"),
                                    new SqlParameter("@templateDBLogicalName", dbTemplateName),
                                    new SqlParameter("@newDBPath", System.Configuration.ConfigurationManager.AppSettings["newDBPath"]),
                                    new SqlParameter("@newDBName", MultisiteHelper.ApplicationName + "_" + storeName)
                                    ).FirstOrDefault();
                        string[] arr = result.Split(new char[] { '_' }, 2);
                        storeName = arr[1];
                    }
                }

                /* Attach new store database (GRANT CREATE ANY DATABASE to MasterCatalog) */
                //            var masterConnectionString = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                //            using (var dbConnection = new SqlConnection(masterConnectionString))
                //            {
                //                dbConnection.Open();
                //                var dbCommand = new SqlCommand(string.Format(@"CREATE DATABASE [{0}_{1}] ON 
                //                        ( FILENAME = N'{2}' ),
                //                        ( FILENAME = N'{3}' )
                //                         FOR ATTACH", MultisiteHelper.ApplicationName, storeName, newMdf, newLdf), dbConnection);
                //                dbCommand.ExecuteNonQuery();
                //                dbConnection.Close();
                //            }

                var settings = CreateStoreSettings(storeName);

                File.WriteAllText(newStoreSettingsFilename, settings);
                #endregion
            }
            else
            {
                #region Old Mehtod of Creasting sub domain DB
                var dbTemplateName = MultisiteHelper.GetDatabaseTemplateName(industryType);
                var templateMdf = GetTemplateMdf(dbTemplateName);
                var templateLdf = GetTemplateLdf(dbTemplateName);
                if (!File.Exists(templateMdf) || !File.Exists(templateLdf))
                {
                    MultiSiteDataProvider.LogToAdminDatabase(string.Format("One of files ({0}) or ({1}) not found. Using default template.", templateMdf, templateLdf));
                    templateMdf = defautTemplateMdf;
                    templateLdf = defautTemplateLdf;
                }

                /* Delete settings file if exists */
                var newStoreSettingsFilename = Path.Combine(App_data_path, string.Format("{0}{1}", storeName, settingsFilename));
                if (File.Exists(newStoreSettingsFilename))
                {
                    File.Delete(newStoreSettingsFilename);
                }

                var index = 0;
                var backupStoreName = storeName;

                /* Copy template data file (.mdf) */
                string newMdf;
                do
                {
                    newMdf = Path.Combine(App_data_path, MultisiteHelper.GetDbName(storeName) + ".mdf");
                    if (File.Exists(newMdf))
                    {
                        storeName = string.Format("{0}.{1}", backupStoreName, ++index);
                    }
                    else
                    {
                        File.Copy(templateMdf, newMdf, true);
                        break;
                    }
                } while (true);

                csStoreName = storeName;

                /* copy template log file (.ldf)*/
                var newLdf = newMdf.Replace(".mdf", "_log.ldf");
                File.Copy(templateLdf, newLdf, true);

                /* Attach new store database (GRANT CREATE ANY DATABASE to MasterCatalog) */
                var masterConnectionString = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                using (var dbConnection = new SqlConnection(masterConnectionString))
                {
                    dbConnection.Open();
                    var dbCommand = new SqlCommand(string.Format(@"CREATE DATABASE [{0}_{1}] ON 
                        ( FILENAME = N'{2}' ),
                        ( FILENAME = N'{3}' )
                         FOR ATTACH", MultisiteHelper.ApplicationName, storeName, newMdf, newLdf), dbConnection);
                    dbCommand.ExecuteNonQuery();
                    dbConnection.Close();
                }

                var settings = CreateStoreSettings(storeName);

                File.WriteAllText(newStoreSettingsFilename, settings);
                #endregion
            }
        }

        public static string GetConnectionString(string storeName)
        {
            return string.Format(@"Data Source={0}{1}{2}; Persist Security Info=False", App_data_path, storeName, dbFilename);
        }

        public static string GetStoreConnectionString(string storeName)
        {
            return string.Format(WebConfigurationManager.ConnectionStrings["StoreCatalog"].ConnectionString, MultisiteHelper.ApplicationName, storeName);
        }

        static string CreateStoreSettings(string storeName)
        {
            return string.Format("DataProvider: sqlserver{0}DataConnectionString: {1}", Environment.NewLine,
                string.Format(WebConfigurationManager.ConnectionStrings["StoreCatalog"].ConnectionString, MultisiteHelper.ApplicationName, storeName));
        }

        public static int AddCloudFareDNS(string storeName)
        {
            try
            {
                string CloudflareApiUrl = System.Configuration.ConfigurationManager.AppSettings["CloudflareApiUrl"];
                string AuthEmail = System.Configuration.ConfigurationManager.AppSettings["AuthEmail"];
                string AuthKey = System.Configuration.ConfigurationManager.AppSettings["AuthKey"];
                string ZoneId = System.Configuration.ConfigurationManager.AppSettings["ZoneId"];
                string DNSContent = System.Configuration.ConfigurationManager.AppSettings["DNSContent"];
                if (!string.IsNullOrEmpty(CloudflareApiUrl) &&
                    !string.IsNullOrEmpty(AuthEmail) &&
                    !string.IsNullOrEmpty(AuthKey) &&
                    !string.IsNullOrEmpty(ZoneId) &&
                    !string.IsNullOrEmpty(DNSContent))
                {
                    using (var client = new HttpClient())
                    {
                        DNSRecord dns = new DNSRecord { type = "A", name = storeName, content = DNSContent,proxied = true };
                        client.BaseAddress = new Uri(CloudflareApiUrl);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Add("X-Auth-Email", AuthEmail);
                        client.DefaultRequestHeaders.Add("X-Auth-Key", AuthKey);
                        var response = client.PostAsJsonAsync("zones/" + ZoneId + "/dns_records", dns).Result;
                        if (response.IsSuccessStatusCode)
                        {
                            return 1;
                        }
                        else
                            return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Remove sub domain from cloud flare using API
        public static int DeleteCloudFareDNS(string storeName)
        {
            try
            {
                string CloudflareApiUrl = System.Configuration.ConfigurationManager.AppSettings["CloudflareApiUrl"];
                string AuthEmail = System.Configuration.ConfigurationManager.AppSettings["AuthEmail"];
                string AuthKey = System.Configuration.ConfigurationManager.AppSettings["AuthKey"];
                string ZoneId = System.Configuration.ConfigurationManager.AppSettings["ZoneId"];
                string DNSContent = System.Configuration.ConfigurationManager.AppSettings["DNSContent"];
                if (!string.IsNullOrEmpty(CloudflareApiUrl) &&
                    !string.IsNullOrEmpty(AuthEmail) &&
                    !string.IsNullOrEmpty(AuthKey) &&
                    !string.IsNullOrEmpty(ZoneId) &&
                    !string.IsNullOrEmpty(DNSContent))
                {
                    using (var client = new HttpClient())
                    {                        
                        client.BaseAddress = new Uri(CloudflareApiUrl);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Add("X-Auth-Email", AuthEmail);
                        client.DefaultRequestHeaders.Add("X-Auth-Key", AuthKey);
                        var response = client.GetAsync("zones/" + ZoneId + "/dns_records").Result;
                        if (response.IsSuccessStatusCode)
                        {
                            var dnsRecords = response.Content.ReadAsAsync<DNSResult>().Result.result;
                            var dns = dnsRecords.SingleOrDefault(r => r.name.ToLower() == storeName.ToLower()+"."+MultisiteHelper.Domain);
                            if(dns != null)
                            {
                                var response2 = client.DeleteAsync("zones/" + ZoneId + "/dns_records/"+dns.id).Result;
                                if (response.IsSuccessStatusCode)
                                {
                                    return 1;
                                }
                            }
                            return 0;
                        }
                        else
                            return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Plesk Api

        public static bool AddPleskHost(SiteRegistrationModel model)
        {
            var isSiteHosted = false;
            try
            {
                //Create customer in plesk.
                var customerId = CreatePleskCustomer(model.email, model.password);
                
                // Get plesk customer
                var ownerId = GetPleskCustomer("storecopy");

                var webSpaceId = string.Empty;
                var updatedWebSpaceId = string.Empty;
                if (!string.IsNullOrEmpty(ownerId))
                {
                    //Get webspace
                    webSpaceId = GetWebSpace(ownerId);
                    if(string.IsNullOrEmpty(webSpaceId))
                    {
                        webSpaceId = CreateWebSpace(ownerId, "storecopy", "storecopy", "Password@1");
                    }

                    if (!string.IsNullOrEmpty(webSpaceId) && !string.IsNullOrEmpty(customerId))
                    {
                        var ftpUserName = model.email.Split('@')[0].ToString().Length > 15 ? model.email.Split('@')[0].Substring(0, 15) : model.email.Split('@')[0];

                        //Update webspace
                        updatedWebSpaceId = UpdateWebSpace(webSpaceId, customerId, model.storeName, ftpUserName, model.password);
                        if (!string.IsNullOrEmpty(updatedWebSpaceId))
                        {
                            isSiteHosted = true;

                            //Create webspace
                            Task.Factory.StartNew(() =>
                            {
                                CreateWebSpace(ownerId, "storecopy", "storecopy", "Password@1");
                            });
                        }
                    }
                }

                return isSiteHosted;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region Upload Ftp File

        public static void UploadFtpFile(string storeName, string ftpUserName, string ftpPassword)
        {
            var folderPath = "httpdocs/App_Data";
            var filePath = Path.Combine(App_data_path, string.Format("{0}{1}", storeName, settingsFilename));
            var fileName = Path.GetFileName(filePath);
            var uploadPath = string.Format(@"ftp://{0}/{1}/{2}", LocalHostname, folderPath, fileName);

            using (WebClient client = new WebClient())
            {
                client.Credentials = new NetworkCredential(ftpUserName, ftpPassword);
                client.UploadFile(uploadPath, "STOR", filePath);
            }

            File.Delete(filePath);
        }

        #endregion

        #endregion    
    }
}