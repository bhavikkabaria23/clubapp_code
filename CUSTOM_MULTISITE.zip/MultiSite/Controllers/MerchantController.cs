﻿using System;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Authentication;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Models.SiteRegistration;
using MultiSite.Data;
using MultiSite.Hubs;
using MultiSite.Models;
using MultiSite.Services;
using System.Web;
using Nop.Services.Directory;
using System.Xml;
using System.IO;

namespace Nop.Web.Controllers
{
    public class MerchantController : Controller
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IAuthenticationService _authenticationService;
        private readonly IEventPublisher _eventPublisher;
        private readonly IStoreContext _storeContext;
        private readonly ICustomerService _customerService;
        private readonly CustomerSettings _customerSettings;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly ILocalizationService _localizationService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly HttpContextBase _httpContext;

        #endregion

        #region Constructors

        public MerchantController()
        {
            this._workContext = EngineContext.Current.Resolve<IWorkContext>();
            this._authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
            this._eventPublisher = EngineContext.Current.Resolve<IEventPublisher>();
            this._storeContext = EngineContext.Current.Resolve<IStoreContext>();
            this._customerService = EngineContext.Current.Resolve<ICustomerService>();
            this._customerSettings = EngineContext.Current.Resolve<CustomerSettings>();
            this._customerRegistrationService = EngineContext.Current.Resolve<ICustomerRegistrationService>();
            this._localizationService = EngineContext.Current.Resolve<ILocalizationService>();
            this._genericAttributeService = EngineContext.Current.Resolve<IGenericAttributeService>();
            this._httpContext = EngineContext.Current.Resolve<HttpContextBase>();
        }

        #endregion

        #region Utilities

        /// <summary>
        /// Generate passwords
        /// </summary>
        /// <param name="passwordLength"></param>
        /// <param name="strongPassword"> </param>
        /// <returns></returns>
        private string PasswordGenerator(int passwordLength, bool strongPassword)
        {
            Random Random = new Random();
            int seed = Random.Next(1, int.MaxValue);
            const string allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
            const string specialCharacters = @"!#$%()*/^~?@_";

            var chars = new char[passwordLength];
            var rd = new Random(seed);

            for (var i = 0; i < passwordLength; i++)
            {
                // If we are to use special characters
                if (strongPassword && i % Random.Next(3, passwordLength) == 0)
                {
                    chars[i] = specialCharacters[rd.Next(0, specialCharacters.Length)];
                }
                else
                {
                    chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
                }
            }

            return new string(chars);
        }

        #endregion

        #region Methods

        public ActionResult CreateStoreMobile()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            return View("CreateStoreMobile");
        }

        [HttpGet]
        public JsonResult TestStoreName(string storeName)
        {
            if (string.IsNullOrWhiteSpace(storeName))
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            using (var dc = new Sites4Entities())
            {
                bool alreadyRegistred = true;
                if (storeName.Contains('.'))
                { //domain name
                    var subdomain = storeName.SanitazeStoreName();
                    var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var customer = _authenticationService.GetAuthenticatedCustomer();
                    if (customer != null)
                    {
                        var isOwn = dc.Sites.Include("Owner")
                            .Any(s => s.StoreName == subdomain && s.Owner.email == customer.Email && !(s.IsOrder ?? false));
                        alreadyRegistred = !isOwn;
                    }
                }
                else
                {
                    alreadyRegistred = MultisiteHelper.MainStoreName.Equals(storeName, StringComparison.InvariantCultureIgnoreCase)
                        || dc.Sites.Any(s => s.StoreName.ToLower() == storeName.ToLower());
                }
                return Json(!alreadyRegistred, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult CheckEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerByEmail(email.Trim()) != null)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        //Admin menu based on super admin and user - add "adminType" parameter
        public ActionResult TmpAdmin(Guid guid, string adminType = "")
        {
            StringBuilder log = new StringBuilder();
            try
            {
                //anti-forgery
                if (MultisiteHelper.TempLoginGuids.ContainsKey(guid) && MultisiteHelper.TempLoginGuids[guid].StoreName == MultisiteHelper.SubDomain)
                {
                    MultisiteHelper.TempLoginGuids.Remove(guid);
                    var _customerService = new MultisiteCustomerService();
                    var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
                    var adminCustomer = _customerService.GetFirstAdminCustomer();
                    if (adminCustomer == null)
                    {
                        //find superadmin user
                        var username = string.Format("{0}@{1}", "superadmin", MultisiteHelper.Domain);
                        var sadmin = _customerService.GetCustomerByUsername(username);
                        //not found
                        if (sadmin == null)
                        {
                            //register
                            var _customerRegistrationService = EngineContext.Current.Resolve<ICustomerRegistrationService>();
                            sadmin = _customerService.InsertAdminCustomer(username);
                            var registrationRequest = new CustomerRegistrationRequest(sadmin, username,
                                username, Guid.NewGuid().ToString(), PasswordFormat.Hashed, _storeContext.CurrentStore.Id, true);
                            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
                            log.AppendFormat("User {0} registered at {1} with status {2}", username, MultisiteHelper.SubDomain, registrationResult.Success);
                        }
                        //var _logger = EngineContext.Current.Resolve<ILogger>();
                        try
                        {
                            using (var dc = new MultisiteObjectContext(MultisiteHelper.CurrentConnectionString, true))
                            {

                                var affectedRows = dc.Database.ExecuteSqlCommand(string.Format(
                                    "insert into dbo.Customer_CustomerRole_Mapping(CustomerRole_Id, Customer_Id) select 1, Id from dbo.Customer where Email = '{0}'",
                                    username));
                                if (affectedRows == 1)
                                {
                                    log.AppendFormat("User {0} got admin rights OK. ", username);
                                }
                                else
                                {
                                    log.AppendFormat("Unexpected number of rows: {0}", affectedRows);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            log.AppendFormat("User {0} at {1} registration exception: {2}", username, MultisiteHelper.SubDomain, ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");

                        }
                        _authenticationService.SignIn(sadmin, true);
                    }
                    else
                    {
                        _authenticationService.SignIn(adminCustomer, true);
                    }
                    if (!string.IsNullOrWhiteSpace(log.ToString()))
                    {
                        MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                    }

                    //Admin menu based on super admin and user
                    if (!string.IsNullOrEmpty(adminType))
                    {
                        return Redirect("/admin?type=" + adminType);
                    }
                    else
                    {
                        return Redirect("/admin");
                    }
                    //-------------------------------



                    //if (sadmin != null && !sadmin.IsAdmin()) {
                    //    log.AppendLine("TmpAdmin: 'superadmin' is not admin");
                    //    //_customerService.DeleteCustomer(sadmin);
                    //    using (var dc = new MultisiteObjectContext(MultisiteHelper.currentConnStr, true)) {
                    //        var admin = dc.Set<Customer>().Single(c => c.Id == sadmin.Id);
                    //        if (admin != null) {
                    //            dc.Set<Customer>().Remove(admin);
                    //            dc.SaveChanges();
                    //        }
                    //    }
                    //    sadmin = null;
                    //}

                    //var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    //_authenticationService.SignIn(sadmin, true);
                    //MultiSiteDataProvider.LogToAdminDB(log.ToString());
                    //return Redirect("/admin");
                }
                else
                {
                    log.AppendLine("TmpAdmin: Guid not found");
                    MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                }
            }
            catch (Exception ex)
            {
                log.AppendFormat("TmpAdmin: {0} {1}", ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");
                MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
            }

            return HttpNotFound();
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetStatesByCountryName(string countryName, bool addEmptyStateIfRequired)
        {
            //this action method gets called via an ajax request
            if (String.IsNullOrEmpty(countryName))
                throw new ArgumentNullException("countryName");

            var _stateProvinceService = new MultisiteStateProvinceService();

            var states = _stateProvinceService.GetStateProvincesByCountryName(countryName).ToList();
            var result = (from s in states
                          select new { id = s.Id, name = s.GetLocalized(x => x.Name) })
                          .ToList();

            if (addEmptyStateIfRequired && result.Count == 0)
                result.Insert(0, new { id = 0, name = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Address.OtherNonUS") });
            //return result.ToList();

            //});

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #region Store Registration

        public bool StoreCustomerLogin(string email)
        {
            var customer = EngineContext.Current.Resolve<ICustomerService>().GetCustomerByEmail(email);
            if (customer != null)
            {
                var customerPassord = EngineContext.Current.Resolve<ICustomerService>().GetCurrentPassword(customer.Id);
                if (customerPassord != null)
                {
                    var loginResult = EngineContext.Current.Resolve<ICustomerRegistrationService>().ValidateCustomer(email, customerPassord.Password);

                    // We make this condition because here only email is passed, not password. 
                    // so password should not be wrong and do not required to check.
                    if (loginResult == CustomerLoginResults.WrongPassword)
                    {
                        loginResult = CustomerLoginResults.Successful;
                    }
                    switch (loginResult)
                    {
                        case CustomerLoginResults.Successful:
                            {
                                //var customer = _customerService.GetCustomerByEmail(email);
                                //migrate shopping cart
                                EngineContext.Current.Resolve<IShoppingCartService>().MigrateShoppingCart(EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer, customer, true);

                                //sign in new customer
                                EngineContext.Current.Resolve<IAuthenticationService>().SignIn(customer, true);

                                //activity log
                                EngineContext.Current.Resolve<ICustomerActivityService>().InsertActivity("PublicStore.Login", EngineContext.Current.Resolve<ILocalizationService>().GetResource("ActivityLog.PublicStore.Login"), customer);

                                return true;
                            }
                        default:
                            return false;
                    }
                }
            }
            return false;
        }

        public ActionResult CreateStore()
        {
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            return View("CreateStore");
        }

        [HttpPost]
        [CaptchaValidator]
        public ActionResult CreateCustomer(SiteRegistrationModel model)
        {
            if (_workContext.CurrentCustomer.IsRegistered())
            {
                //Already registered customer. 
                _authenticationService.SignOut();

                //raise logged out event       
                _eventPublisher.Publish(new CustomerLoggedOutEvent(_workContext.CurrentCustomer));

                //Save a new record
                _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            }
            var customer = _workContext.CurrentCustomer;
            customer.RegisteredInStoreId = _storeContext.CurrentStore.Id;

            bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
            var registrationRequest = new CustomerRegistrationRequest(customer,
                model.email,
                model.email,
                model.password,
                _customerSettings.DefaultPasswordFormat,
                _storeContext.CurrentStore.Id,
                isApproved);

            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
            if (registrationResult.Success)
            {
                _authenticationService.SignIn(customer, true);
                model.industryType = "Other";
                model.isOrder = true;
                model.storeName = model.storeName.ToLower();
                using (var dbContext = new Sites4Entities())
                {
                    var owner = new Owner
                    {
                        email = model.email,
                        industryType = model.industryType,
                        IsRegistered = false
                    };
                    dbContext.Owners.Add(owner);
                    dbContext.SaveChanges();

                    var site = new Site
                    {
                        StoreName = model.storeName,
                        CreationDate = DateTime.UtcNow,
                        Owner_Id = owner.Id,
                        IsOrder = model.isOrder,
                        deleted = false
                    };
                    dbContext.Sites.Add(site);
                    dbContext.SaveChanges();
                }

                var _workflowMessageService = new MultisiteWorkflowMessageService();

                //raise event       
                _eventPublisher.Publish(new CustomerRegisteredEvent(customer));

                //email validation message
                if (_customerSettings.UserRegistrationType == UserRegistrationType.EmailValidation)
                {
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                    _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id);
                }

                _workContext.CurrentCustomer = customer;
                _httpContext.Session["PlanDetail"] = model.PlanProductId + "," + model.PlanType;
                //return RedirectToAction("RegisterResult", new { customerId = customer.Id });
                return RedirectToAction("RegisterStore");
            }
            else
            {
                //errors
                foreach (var error in registrationResult.Errors)
                    ModelState.AddModelError("", error);

                //return RedirectToAction("CreateStore");
                return Redirect("/store-pricing");
            }
        }

        public ActionResult RegisterResult(int customerId)
        {
            var model = new RegisterResultModel();
            var resultText = "";
            switch (_customerSettings.UserRegistrationType)
            {
                case UserRegistrationType.Disabled:
                    resultText = _localizationService.GetResource("Account.Register.Result.Disabled");
                    break;
                case UserRegistrationType.Standard:
                    resultText = _localizationService.GetResource("Account.Register.Result.Standard");
                    break;
                case UserRegistrationType.AdminApproval:
                    resultText = _localizationService.GetResource("Account.Register.Result.AdminApproval");
                    break;
                case UserRegistrationType.EmailValidation:
                    resultText = _localizationService.GetResource("Account.Register.Result.EmailValidation");
                    break;
                default:
                    break;
            }
            model.Result = resultText;
            model.CustomerId = customerId;

            return View("RegisterResult", model);
        }

        [HttpPost]
        public ActionResult RegisterResult(RegisterResultModel model)
        {
            var customer = _customerService.GetCustomerById(model.CustomerId);
            if (customer != null)
            {
                switch (_customerSettings.UserRegistrationType)
                {
                    case UserRegistrationType.Standard:
                        {
                            // login customer now
                            _authenticationService.SignIn(customer, true);
                            return Json(new { redirectUrl = "RegisterStore" });
                        }
                    case UserRegistrationType.AdminApproval:
                        {
                            return Json(new { errormessage = "Your account is not activated. Please contact administrator." });
                        }
                    case UserRegistrationType.EmailValidation:
                        {
                            if (customer.Active)
                            {
                                // login customer now
                                _authenticationService.SignIn(customer, true);
                                return Json(new { redirectUrl = "RegisterStore" });
                            }
                            else
                            {
                                return Json(new { errormessage = "Your account is not activated. Please check email to activate account." });
                            }
                        }
                    default:
                        break;
                }
            }

            return Json(new { errormessage = "Customer does not exists." });
        }

        public ActionResult RegisterStore()
        {
            if (!_workContext.CurrentCustomer.IsRegistered())
                return new HttpUnauthorizedResult();

            var model = new SiteRegistrationModel();
            var countries = EngineContext.Current.Resolve<ICountryService>().GetAllCountries();
            if (countries != null && countries.Any())
            {
                model.Country = countries.FirstOrDefault().Name;
            }
            var customer = _workContext.CurrentCustomer;

            using (var dbContext = new Sites4Entities())
            {
                var owner = dbContext.Owners.Where(o => o.email == customer.Email).FirstOrDefault();
                if (owner == null)
                    return HttpNotFound();

                var site = dbContext.Sites.Where(s => s.Owner_Id == owner.Id).FirstOrDefault();

                model.OwnerId = owner.Id;
                model.siteId = site.Id;
                model.email = owner.email;
                model.storeName = site.StoreName;
            }

            return View("StoreRegistration", model);
        }

        [HttpPost]
        public ActionResult RegisterStore(SiteRegistrationModel model)
        {
            if (!_workContext.CurrentCustomer.IsRegistered())
                return new HttpUnauthorizedResult();
            if (_httpContext.Session["PlanDetail"] != null)
            {
                string[] arrPlanDetail = Convert.ToString(_httpContext.Session["PlanDetail"]).Split(',');
                if (arrPlanDetail.Any() && arrPlanDetail.Count() > 1)
                {
                    model.PlanProductId = arrPlanDetail[0];
                    model.PlanType = arrPlanDetail[1];
                }
            }
            _httpContext.Session["RegisterStoreModel"] = model;
            return Json(new { checkoutUrl = "/store-checkout/" + model.PlanProductId + "/" + model.PlanType });
        }

        [HttpPost]
        public ActionResult GetStatesByCountry(string countryName, bool addEmptyStateIfRequired)
        {
            if (String.IsNullOrEmpty(countryName))
                throw new ArgumentNullException("countryName");

            var _stateProvinceService = new MultisiteStateProvinceService();

            var states = _stateProvinceService.GetStateProvincesByCountryName(countryName).ToList();
            var result = (from s in states
                          select new { id = s.Id, name = s.GetLocalized(x => x.Name) })
                          .ToList();

            if (addEmptyStateIfRequired && result.Count == 0)
                result.Insert(0, new { id = 0, name = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Address.OtherNonUS") });

            return Json(result);
        }

        //3.1
        //Video popup - Currently it is usedd for video Link at "MerchantSetupFinish.cshtml".
        //[ChildActionOnly]
        public string RenderVideoIcon(string keyword)
        {
            string VideoUrl = GetVideoUrlByPageUrl("", keyword);
            return VideoUrl;
        }
        public string GetVideoUrlByPageUrl(string requestedPageUrl, string keyword)
        {
            var themeDirectory = new DirectoryInfo(Server.MapPath("/"));
            var videoConfigFile = new FileInfo(Path.Combine(themeDirectory.FullName, "Video.config"));
            if (videoConfigFile.Exists)
            {
                var doc = new XmlDocument();
                doc.Load(videoConfigFile.FullName);

                string VideoName = videoConfigFile.Name;
                string FilePath = videoConfigFile.FullName;
                var node = doc.SelectSingleNode("Video");
                if (node != null)
                {
                    if (node.HasChildNodes)
                    {
                        //string pageUrl = string.Empty;
                        //string vidoeUrl = string.Empty;
                        for (int i = 0; i < node.ChildNodes.Count; i++)
                        {
                            var cNode = node.ChildNodes[i];
                            var attributePage = cNode.Attributes["pageUrlOrKeyword"];
                            // for requested page url
                            if (!string.IsNullOrEmpty(requestedPageUrl))
                            {
                                if (requestedPageUrl.Contains(Convert.ToString(attributePage.Value).ToLower().Trim()))
                                {
                                    var attributeVideo = cNode.Attributes["vidoeUrl"];
                                    if (!string.IsNullOrEmpty(attributeVideo.Value))
                                    {
                                        return attributeVideo.Value;
                                    }
                                    return "#";
                                }
                            }
                            // for keyword
                            else if (!string.IsNullOrEmpty(keyword))
                            {
                                if (keyword.ToLower().Equals(Convert.ToString(attributePage.Value).ToLower().Trim()))
                                {
                                    var attributeVideo = cNode.Attributes["vidoeUrl"];
                                    if (!string.IsNullOrEmpty(attributeVideo.Value))
                                    {
                                        return attributeVideo.Value;
                                    }
                                    return "#";
                                }
                            }
                            else
                            {
                                return "#";
                            }
                        }
                    }
                }
            }
            return "#";
        }


        #endregion

        #endregion
    }
}