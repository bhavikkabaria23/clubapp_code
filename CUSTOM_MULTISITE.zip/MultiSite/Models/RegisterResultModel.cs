﻿namespace MultiSite.Models
{
    public class RegisterResultModel
    {
        public string Result { get; set; }

        public int CustomerId { get; set; }
    }
}