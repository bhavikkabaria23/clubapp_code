﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Services.Directory;
using Nop.Core.Domain.Catalog;
using MultiSite.Data;
using System.Data;
using MultiSite.Services;
using Nop.Web.Framework.Themes;

namespace MultiSite.Models
{
    public class SiteRegistrationModel
    {
        public int siteId { get; set; }

        public int OwnerId { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        [Display(Name = "First Name")]
        public string firstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        [Display(Name = "Last Name")]
        public string lastName { get; set; }

        [Required(ErrorMessage = "Phone number is required.")]
        [Display(Name = "Phone number")]
        public string phone { get; set; }

        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", ErrorMessage = "Email does not look as e-mail address")]
        [Required(ErrorMessage = "Email is required.")]
        [Remote("CheckEmail", "Merchant", ErrorMessage = "This email is already registered.")]
        [Display(Name = "Email Address")]
        public string email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [Display(Name = "Choose a password")]
        public string password { get; set; }

        [System.Web.Mvc.Compare("password")]
        [Required]
        [Display(Name = "Re-enter password")]
        public string passwordConfirm { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        [Display(Name = "Which best describes you?")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Starting is required.")]
        [Display(Name = "I'm looking to start")]
        public string Starting { get; set; }

        [Required(ErrorMessage = "Country is required.")]
        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "Website (if you have one)")]
        public string Website { get; set; }

        [Required(ErrorMessage = "Store name is required.")]
        [Display(Name = "Store Name")]
        //[RegularExpression(@"^\w{2,15}$", ErrorMessage = "Store allows 2 to 15 characters and no spacing and punctuation allowed.")]
        [RegularExpression(@"^[a-zA-Z0-9]{2,15}$", ErrorMessage = "Store allows 2 to 15 characters and alphanumeric characters only.")]
        [Remote("TestStoreName", "Merchant", ErrorMessage = "This store name is already registered. Please try another store name.")]
        public string storeName { get; set; }

        [Required]
        [Display(Name = "Default theme")]
        public string defaultTheme { get; set; }
        public IEnumerable<SelectListItem> availableThemes
        {
            get
            {
                var themesDir = HttpContext.Current.Server.MapPath("~/Themes");
                return Directory.GetDirectories(themesDir)
                    .Select(d => Path.GetFileName(d))
                    .Select(d => new SelectListItem { Text = d, Value = d });
            }
        }

        [Required(ErrorMessage = "Theme is required.")]
        [Display(Name = "Theme")]
        public string industryType { get; set; }

        //Multisite_NewField_change
        [Required(ErrorMessage = "Street address is required.")]
        [Display(Name = "Street Address")]
        public string StreetAddress { get; set; }

        [Required(ErrorMessage = "City is required.")]
        [Display(Name = "City")]
        public string City { get; set; }

        [Required(ErrorMessage = "Zip is required.")]
        [Display(Name = "Zip Code")]
        public string ZipPostalCode { get; set; }

        [Required(ErrorMessage = "State is required.")]
        [Display(Name = "State")]
        public string State { get; set; }

        // Free trial integration in new page
        [Display(Name = "Avg Sale Amout(eg $1200)")]
        public string AvgSaleAmout { get; set; }

        [Display(Name = "Processor Name")]
        public string ProcessorName { get; set; }

        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", ErrorMessage = "Processor Email does not look as e-mail address")]
        [Display(Name = "Processor Email")]
        public string ProcessorEmail { get; set; }

        [Display(Name = "Processor Phone Number")]
        public string ProcessorPhoneNumber { get; set; }

        [Required(ErrorMessage = "Category is required.")]
        [Display(Name = "Category")]
        public string SiteCategory { get; set; }

        [Required(ErrorMessage = "Team of people is required.")]
        [Display(Name = "How many people in your team?")]
        public string TeamPeople { get; set; }

        [Required(ErrorMessage = "Reason is required.")]
        [Display(Name = "Reason your are considering")]
        public string Reason { get; set; }

        [Required]
        [Display(Name = "Activation Code")]
        public string ActivationCode { get; set; }
        //------------------------------------

        // For package details         
        // this will hold the current package id to be added in order
        public int PackageProductId { get; set; }

        //--------------------------------------

        //public IEnumerable<SelectListItem> industryTypes
        //    = new[] { "", "Jewelry", "Other" }.Select(d => new SelectListItem { Text = string.IsNullOrEmpty(d) ? "-Select-" : d, Value = d });
        //public IEnumerable<SelectListItem> descriptions = new[] { "", "Newbie", "Expert" }.Select(d => new SelectListItem { Text = string.IsNullOrEmpty(d) ? "-Select-" : d, Value = d });
        //public IEnumerable<SelectListItem> startVariants = new[] { "", "Variant 1", "Variant 2" }.Select(d => new SelectListItem { Text = string.IsNullOrEmpty(d) ? "-Select-" : d, Value = d });

        public string storeLink
        {
            get { return string.Format(@"http://{0}.{1}", storeName, MultisiteHelper.Domain); }
        }
        public string adminLink
        {
            get { return string.Format(@"http://{0}.{1}/admin", storeName, MultisiteHelper.Domain); }
        }

        public IEnumerable<SelectListItem> countries2
        {
            get
            {
                var countries = EngineContext.Current.Resolve<ICountryService>().GetAllCountries();
                if (countries != null && countries.Any())
                {                    
                    return countries.Select(c => new SelectListItem { Text = c.Name, Value = c.Name, Selected = c.NumericIsoCode == 840 });                    
                }
                else
                {
                    return new List<SelectListItem>();
                }
            }
        }
        //Multisite_NewField_change
        public IEnumerable<SelectListItem> statesList
        {
            get
            {
                var _stateProvinceService = new MultisiteStateProvinceService();
                var states = _stateProvinceService.GetStateProvincesByNumericIsoCode(840);
                return states.Select(s => new SelectListItem { Text = s.Name, Value = s.Name });
            }
        }
        //----------------------------------
        public bool isOrder { get; set; }

        //My Account Module
        public int CountryId { get; set; }

        public int StateProvinceId { get; set; }

        public string Company { get; set; }

        public string Geolocation { get; set; }
        //-----------------------------------

        public static SiteRegistrationModel GetFromOrder(Nop.Core.Domain.Orders.Order order)
        {
            var res = new SiteRegistrationModel
            {
                storeName = "",
                password = "",
                firstName = order.BillingAddress.FirstName,
                lastName = order.BillingAddress.LastName,
                phone = order.BillingAddress.PhoneNumber,
                email = order.BillingAddress.Email,
                Country = order.BillingAddress.Country.Name,
                //Multisite_NewField_change
                StreetAddress = order.BillingAddress.Address1 + " " + order.BillingAddress.Address2,
                City = order.BillingAddress.City,
                ZipPostalCode = order.BillingAddress.ZipPostalCode,
                State = order.BillingAddress.StateProvince.Name,
                //--------------
                PackageProductId = order.OrderItems.Select(c => c.ProductId).LastOrDefault()
            };

            var productAttributeParser = EngineContext.Current.Resolve<IProductAttributeParser>();
            //upgrade_2.80_3.1
            foreach (var variant in order.OrderItems)
            //------------------------------------
            {
                var AttributesXml = variant.AttributesXml;
                var AddressAttrib = productAttributeParser.ParseProductAttributeMappings(AttributesXml)
                    .SingleOrDefault(a => a.ProductAttribute.Name.ToLower() == "store address");
                if (AddressAttrib == null) continue;
                var id = AddressAttrib.Id;
                res.storeName = productAttributeParser.ParseValues(AttributesXml, id).FirstOrDefault();

                var UserNameAttrib = productAttributeParser.ParseProductAttributeMappings(AttributesXml)
                    .SingleOrDefault(a => a.ProductAttribute.Name.ToLower() == "enter your email");
                res.email = productAttributeParser.ParseValues(AttributesXml, UserNameAttrib.Id).FirstOrDefault();

                var PasswordAttrib = productAttributeParser.ParseProductAttributeMappings(AttributesXml)
                    .SingleOrDefault(a => a.ProductAttribute.Name.ToLower() == "choose a password");
                res.password = productAttributeParser.ParseValues(AttributesXml, PasswordAttrib.Id).FirstOrDefault();

                var industryTypeAttrib = productAttributeParser.ParseProductAttributeMappings(AttributesXml)
                    .SingleOrDefault(a => a.ProductAttribute.Name.ToLower() == "industry type");
                var industryTypeId = productAttributeParser.ParseValues(AttributesXml, industryTypeAttrib.Id).FirstOrDefault();
                //upgrade_2.80_3.1
                res.industryType = variant.Product.ProductAttributeMappings
                    //--------------------------------------------------------------
                    .SingleOrDefault(a => a.ProductAttribute.Name.Equals("industry type", StringComparison.InvariantCultureIgnoreCase))
                    .ProductAttributeValues.SingleOrDefault(v => v.Id.ToString() == industryTypeId).Name;
                if (!string.IsNullOrEmpty(res.storeName))
                {
                    break;
                }
            }

            return res;
        }

        // For package details         
        public static SiteRegistrationModel GetFromOrderForUpgradePackage(Nop.Core.Domain.Orders.Order order, string storeName)
        {
            var res = new SiteRegistrationModel
            {
                storeName = storeName,
                PackageProductId = order.OrderItems.Select(c => c.ProductId).LastOrDefault()
            };
            return res;
        }

        //public static void SavePackageFromProduct(Product product)
        //{
        //    using (var dbContext = new Sites4Entities())
        //    {
        //        Package package = new Package
        //        {
        //            PackageProductId = product.Id,
        //            PackageName = product.Name,
        //            PackagePeriod = product.PackagePeriod,
        //            PackageIsProductLimit = product.PackageIsProductLimit,
        //            PackageProductLimit = product.PackageProductLimit,
        //            PackageIsStoreLimit = product.PackageIsStoreLimit,
        //            PackageStoreLimit = product.PackageStoreLimit,
        //            PackageDbStorageCapacity = product.PackageDbStorageCapacity,
        //            PackageDbStorageType = product.PackageDbStorageType,
        //            PackageIsPOSApiLimit = product.PackageIsPOSApiLimit,
        //            PackageIsAllowQuickBook = product.PackageIsAllowQuickBook,
        //            PackageIsAllowCustomTheme = product.PackageIsAllowCustomTheme,
        //            PackageIsEmailSupport = product.PackageIsEmailSupport,
        //            PackageIsLiveSupport = product.PackageIsLiveSupport,

        //            PackagePOSApiLimit = product.PackagePOSApiLimit,
        //            PackageIsAllowFrontWebsite = product.PackageIsAllowFrontWebsite,
        //            PackageIsDbStorageCapacity = product.PackageIsDbStorageCapacity,
        //            PackageIsBestSell = product.PackageIsBestSell,
        //            PackageCustomField1 = product.PackageCustomField1,
        //            PackageCustomField2 = product.PackageCustomField2,
        //            PackageCustomField3 = product.PackageCustomField3,
        //            PackageCustomField4 = product.PackageCustomField4,
        //            PackageCustomField5 = product.PackageCustomField5
        //        };
        //        dbContext.Packages.Add(package);
        //        dbContext.SaveChanges();
        //    }
        //}

        //public static void UpdatePackageFromProduct(Product product)
        //{
        //    using (var dbContext = new Sites4Entities())
        //    {
        //        var package = dbContext.Packages.SingleOrDefault(p => p.PackageProductId == product.Id);
        //        if (package == null)
        //        {
        //            SavePackageFromProduct(product);
        //        }
        //        else
        //        {
        //            package.PackageName = product.Name;
        //            package.PackagePeriod = product.PackagePeriod;
        //            package.PackageIsProductLimit = product.PackageIsProductLimit;
        //            package.PackageProductLimit = product.PackageProductLimit;
        //            package.PackageIsStoreLimit = product.PackageIsStoreLimit;
        //            package.PackageStoreLimit = product.PackageStoreLimit;
        //            package.PackageDbStorageCapacity = product.PackageDbStorageCapacity;
        //            package.PackageDbStorageType = product.PackageDbStorageType;
        //            package.PackageIsPOSApiLimit = product.PackageIsPOSApiLimit;
        //            package.PackageIsAllowQuickBook = product.PackageIsAllowQuickBook;
        //            package.PackageIsAllowCustomTheme = product.PackageIsAllowCustomTheme;
        //            package.PackageIsEmailSupport = product.PackageIsEmailSupport;
        //            package.PackageIsLiveSupport = product.PackageIsLiveSupport;

        //            package.PackagePOSApiLimit = product.PackagePOSApiLimit;
        //            package.PackageIsAllowFrontWebsite = product.PackageIsAllowFrontWebsite;
        //            package.PackageIsDbStorageCapacity = product.PackageIsDbStorageCapacity;
        //            package.PackageIsBestSell = product.PackageIsBestSell;
        //            package.PackageCustomField1 = product.PackageCustomField1;
        //            package.PackageCustomField2 = product.PackageCustomField2;
        //            package.PackageCustomField3 = product.PackageCustomField3;
        //            package.PackageCustomField4 = product.PackageCustomField4;
        //            package.PackageCustomField5 = product.PackageCustomField5;
        //            dbContext.SaveChanges();
        //        }
        //    }
        //}

        public static void DeletePackageByProductId(int productId)
        {
            using (var dbContext = new Sites4Entities())
            {
                var package = dbContext.Packages.SingleOrDefault(p => p.PackageProductId == productId);
                if (package != null)
                {
                    dbContext.Entry(package).State = System.Data.Entity.EntityState.Deleted;
                    dbContext.SaveChanges();
                }
            }
        }
        //-------------------

        public IEnumerable<ThemeConfiguration> AvailableStoreThemes { get; set; }

        #region New Store Sign Up Approach - Properties
        public string Selling { get; set; }

        // First - I'm not selling product yet
        public string SomethingToSell { get; set; }

        // I'm just playing around
        public bool HelpBusinessLogo { get; set; }
        public bool HelpBusinessBrainStorm { get; set; }
        public bool HelpBusinessWebinar { get; set; }
        public bool HelpBusinessProduct { get; set; }

        //I sell with a different system
        public string SystemName { get; set; }

        // I'm selling, just not online
        public string LaunchStore { get; set; }
        public string WhatToSell { get; set; }
        public bool SellAtMarket { get; set; }
        public bool SellAtRetailStore { get; set; }      

        public string CurrentRevenue { get; set; }
        public bool StoreForCLient { get; set; }

        public string StreetAddress2 { get; set; }

        public string PlanProductId { get; set; }
        public string PlanType { get; set; } // monthly, yearly
        #endregion
    }
}