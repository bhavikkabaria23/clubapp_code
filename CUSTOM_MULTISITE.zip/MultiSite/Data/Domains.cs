﻿namespace MultiSite.Data
{
    public class Domains
    {
        public int siteid;
        public string dbname;
        public string Hosts;
        public string StoreName;
    }
}
