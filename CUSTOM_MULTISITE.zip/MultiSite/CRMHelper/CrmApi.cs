﻿using Microsoft.Crm.Sdk.Samples.HelperCode;
using MultiSite.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace Shopfast.Plugin.Custom.CRMHelper
{
    public class CrmApi
    {
        //Start with base version and update with actual version later.
        private Version webAPIVersion = new Version(9, 0);

        private string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        //public async Task<bool> MerchantInformationCRMPost(SiteRegistrationModel model)
        //{

        //    Configuration config = null;
        //    config = new FileConfiguration(null);
        //    //Create a helper object to authenticate the user with this connection info.
        //    Authentication auth = new Authentication(config);
        //    //Next use a HttpClient object to connect to specified CRM Web service.
        //    var httpClient = new HttpClient(auth.ClientHandler, true);
        //    //Define the Web API base address, the max period of execute time, the 
        //    // default OData version, and the default response payload format.
        //    httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

        //    // Generate json object from model
        //    var merchantForm = new JObject();
        //    merchantForm.Add("new_faxnumber", model.FaxNumber);
        //    merchantForm.Add("new_cell", model.CellPhone);
        //    merchantForm.Add("new_merchantname", model.MerchantName);
        //    merchantForm.Add("new_locationaddress1", model.LocationAddress);
        //    merchantForm.Add("new_city1", model.City);
        //    merchantForm.Add("new_state1", model.SelectedState1);
        //    merchantForm.Add("new_zipcode1", model.Zip);
        //    if (model.IsMoreLocation)
        //    {
        //        merchantForm.Add("new_locationaddress2", model.LocationAddress2);
        //        merchantForm.Add("new_city2", model.City2);
        //        merchantForm.Add("new_state2", model.SelectedState2);
        //        merchantForm.Add("new_zipcode2", model.Zip2);
        //    }
        //    else
        //    {
        //        merchantForm.Add("new_locationaddress2", null);
        //        merchantForm.Add("new_city2", null);
        //        merchantForm.Add("new_state2", null);
        //        merchantForm.Add("new_zipcode2", null);
        //    }            

        //    HttpRequestMessage createRequest =
        //    new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "new_merchantboardings");
        //    createRequest.Content = new StringContent(merchantForm.ToString(),
        //        Encoding.UTF8, "application/json");

        //    HttpResponseMessage createResponse =
        //        await httpClient.SendAsync(createRequest);
        //    if (createResponse.StatusCode == HttpStatusCode.NoContent) //204
        //    {
        //        return true;
        //    }
        //    else
        //    {                
        //        return false;
        //    }
        //}
    }
}