﻿using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Services.Configuration;
using Nop.Web.Models.Customer;
using Nop.Services.Common;
using Nop.Services.Localization;
using Nop.Core.Data;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CustomerNavigationFilterAttribute : ActionFilterAttribute
    {
        #region Fields        
        private readonly ILocalizationService _localizationService;
        #endregion

        #region Ctor

        public CustomerNavigationFilterAttribute()
        {            
            this._localizationService = EngineContext.Current.Resolve<ILocalizationService>();
        }

        #endregion

        #region Methods
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (MultisiteHelper.IsAdminSite)
            {
                var model = filterContext.Controller.ViewData.Model as CustomerNavigationModel;
                if (model != null)
                {
                    model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                    {
                        RouteName = "PackageOrders",
                        Title = _localizationService.GetResource("Account.MyPlan"),
                        Tab = CustomerNavigationEnum.Orders,
                        ItemClass = "customer-plan"
                    });

                    model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                    {
                        RouteName = "MerchantCards",
                        Title = _localizationService.GetResource("Account.MerchantCards"),
                        Tab = CustomerNavigationEnum.Info,
                        ItemClass = "customer-merchantcards"
                    });
                }
            }
        }
        #endregion
    }
}