﻿using MultiSite.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Tasks;
using Shopfast.Plugin.Custom.Controllers;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

namespace Shopfast.Plugin.Custom.Services
{
    public class RecuringPlansTask : ITask
    {
        private readonly ILogger _logger;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;
        private readonly ISettingService _settingService;
        private readonly IEncryptionService _encryptionService;
        private static string ShopfastAPIBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ShopfastAPIBaseUrl"];

        public RecuringPlansTask(ILogger logger, IProductService productService, ISettingService settingService,
            IOrderService orderService, IEncryptionService encryptionService)
        {
            this._productService = productService;
            this._logger = logger;
            this._orderService = orderService;
            this._settingService = settingService;
            this._encryptionService = encryptionService;
        }

        private void ReOrderChecout(List<Order> orders, AppProductListModel product, int months,List<SiteOrders> siteOrders, List<Owner> owners)
        {
            var productorders = orders.Where(o => o.OrderItems
                           .Any(orderItem => orderItem.Product.Id == product.Id) && o.CreatedOnUtc.Date.AddMonths(months) == DateTime.UtcNow.Date);
            if (productorders != null && productorders.Any())
            {
                _logger.Information("5. Get Product orders found for recuring period - " + months);
                foreach (var pOrder in productorders)
                {
                    string CardNumber = string.Empty;
                    string ExpiryMonth = string.Empty;
                    string ExpiryYear = string.Empty;
                    string VerifyCode = string.Empty;
                    if (siteOrders != null && siteOrders.Any() && owners != null && owners.Any())
                    {
                        var siteOrder = siteOrders.FirstOrDefault(so => so.OrderId == pOrder.Id);
                        if(siteOrder != null)
                        {
                            var owner = owners.FirstOrDefault(o => o.Id == siteOrder.OwnerId);
                            if(owner != null)
                            {
                                _logger.Information("6-1. Owner encrypted crad info - card number : #" + owner.CardNumber + "# month : " + owner.ExpiryMonth + " year : " + owner.ExpiryYear + " CVV : " + owner.VerifyCode);
                                // Need to decrypt this card info
                                if(!string.IsNullOrEmpty(owner.CardNumber))
                                    CardNumber = _encryptionService.DecryptText(owner.CardNumber.Trim());
                                if (!string.IsNullOrEmpty(owner.ExpiryMonth))
                                    ExpiryMonth = _encryptionService.DecryptText(owner.ExpiryMonth.Trim());
                                if (!string.IsNullOrEmpty(owner.ExpiryYear))
                                    ExpiryYear = _encryptionService.DecryptText(owner.ExpiryYear.Trim());
                                if (!string.IsNullOrEmpty(owner.VerifyCode))
                                    VerifyCode = _encryptionService.DecryptText(owner.VerifyCode.Trim());
                                //CardNumber = "4111111111111111";
                                //ExpiryMonth = "12";
                                //ExpiryYear = "2020";
                                //VerifyCode = "999";
                                _logger.Information("6-2. Owner  decrypted crad info - card number : " + CardNumber+" month : "+ExpiryMonth+" year : "+ExpiryYear+" CVV : "+VerifyCode);
                            }
                        }
                    }
                    _logger.Information("7. Recuring for order id - " + pOrder.Id + " period - " + months + " Customer Email"+ pOrder.Customer.Email);
                    string email = (pOrder.Customer != null) ? pOrder.Customer.Email : "";
                    if (!string.IsNullOrEmpty(CardNumber) &&
                        !string.IsNullOrEmpty(ExpiryMonth) &&
                        !string.IsNullOrEmpty(ExpiryYear) &&
                        !string.IsNullOrEmpty(VerifyCode))
                    {
                        _logger.Information("8. Checkout API started. card info found");
                        #region Checkout Transaction by API
                        CheckoutTransaction request = new CheckoutTransaction();
                        request.Products = product.Id.ToString();
                        request.Quantities = "1";
                        request.TotalAmount = Convert.ToDouble(pOrder.OrderTotal);
                        request.Email = email;
                        request.CardType = "Visa";
                        request.CardName = "test";
                        request.CardNumber = CardNumber; 
                        request.ExpiryMonth = ExpiryMonth;
                        request.ExpiryYear = ExpiryYear;
                        request.VerifyCode = VerifyCode;
                        request.TransactionType = "card";
                        request.UseRewardPoints = false;
                        request.Attributes = null; // Need to ask Sanjay for how to pass attribute for reorder
                        request.IsWebOrder = true;

                        var jsonString = JsonConvert.SerializeObject(request);
                        var element = new JObject();
                        element["Data"] = jsonString;
                        byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                        byteData = Encoding.UTF8.GetBytes(element.ToString());

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            var client = new HttpClient();
                            var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                                if (checkoutResponse.CheckoutTransactionResult.Status)
                                {
                                    SiteOrders siteOrder = new SiteOrders();
                                    using (var dbContext = new Sites4Entities())
                                    {
                                        //Add this order to SiteOrders and make other orders IsActive to false for this store.
                                        var existingSiteOrders = dbContext.SiteOrders.FirstOrDefault(so => so.OrderId == pOrder.Id);
                                        _logger.Information("9. Old Site Order - " + JsonConvert.SerializeObject(existingSiteOrders));
                                        if (existingSiteOrders != null)
                                        {
                                            var orderUpdate = existingSiteOrders;
                                            existingSiteOrders.IsActive = false;
                                            dbContext.Entry(existingSiteOrders).CurrentValues.SetValues(orderUpdate);
                                            _logger.Information("10. Old Site Order Updated- " + JsonConvert.SerializeObject(existingSiteOrders));
                                        }

                                        siteOrder.StoreName = existingSiteOrders.StoreName;
                                        siteOrder.PackageId = product.Id;
                                        siteOrder.SiteId = existingSiteOrders.SiteId;
                                        siteOrder.OwnerId = existingSiteOrders.OwnerId;
                                        siteOrder.OwnerEmail = existingSiteOrders.OwnerEmail;
                                        siteOrder.PackageName = existingSiteOrders.PackageName;
                                        siteOrder.OrderId = checkoutResponse.CheckoutTransactionResult.OrderId;
                                        siteOrder.IsActive = true;
                                        siteOrder.CreationDate = DateTime.UtcNow;
                                        siteOrder.PlanExpirationDate = (months == 1) ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1); // this for yearly

                                        dbContext.SiteOrders.Add(siteOrder);
                                        dbContext.SaveChanges();
                                    }
                                    _logger.Information("11. Recuring done successfully for Checkout response - " + JsonConvert.SerializeObject(checkoutResponse.CheckoutTransactionResult) + " at " + DateTime.UtcNow.ToString());
                                    _logger.Information("12. New Site Order added - " + JsonConvert.SerializeObject(siteOrder));
                                    _logger.Information("13. Old Order - " + pOrder.Id + " New Order Id - " + checkoutResponse.CheckoutTransactionResult.OrderId);
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
        }

        /// <summary>
        /// Executes a task
        /// </summary>
        public virtual void Execute()
        {
            try
            {
                // This code is just for testimng purpose
                //using (var dbContext = new Sites4Entities())
                //{
                //    var owner = dbContext.Owners.FirstOrDefault(o => o.Id == 256);
                //    if (owner != null)
                //    {                        
                //        // Need to decrypt this card info
                //        string s1 = _encryptionService.EncryptText("4111111111111111");
                //        _logger.Information("t-1 Testing owner  : #" + owner.CardNumber + "# month : " + owner.ExpiryMonth + " year : " + owner.ExpiryYear + " CVV : " + owner.VerifyCode);
                //        _logger.Information("S1   :   #" + s1+"#");
                //        string CardNumber = _encryptionService.DecryptText(owner.CardNumber.Trim());
                //        string ExpiryMonth = _encryptionService.DecryptText(owner.ExpiryMonth);
                //        string ExpiryYear = _encryptionService.DecryptText(owner.ExpiryYear);
                //        string VerifyCode = _encryptionService.DecryptText(owner.VerifyCode);
                //        _logger.Information("t-2. Testing owner - card number : " + CardNumber + " month : " + ExpiryMonth + " year : " + ExpiryYear + " CVV : " + VerifyCode);
                //    }
                //}


                var recuringOrderTaskSettings = _settingService.LoadSetting<RecuringOrderTaskSettings>();
                DateTime startTime = Convert.ToDateTime(recuringOrderTaskSettings.StartTime);
                DateTime endTime = Convert.ToDateTime(recuringOrderTaskSettings.EndTime);
                if (DateTime.UtcNow.TimeOfDay >= startTime.TimeOfDay && DateTime.UtcNow.TimeOfDay <= endTime.TimeOfDay)
                {
                    _logger.Information("1. Recuring Schedular started");
                    // Get All product Ids of package
                    ProductRespose productRespose = new ProductRespose();
                    var client = new HttpClient();
                    HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var productsString = response.Content.ReadAsStringAsync().Result;
                        JavaScriptSerializer js = new JavaScriptSerializer();
                        var products = js.Deserialize<List<AppProductListModel>>(productsString);
                        _logger.Information("2. Get prodicts from API");
                        if (products != null && products.Any())
                        {
                            products = products.Where(p => p.ProductSpecificationAttributes != null
                            && p.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "ispackage" && ps.ValueRaw.ToLower() == "yes")
                            ).ToList();
                            var siteOrders = new List<SiteOrders>();
                            var owners = new List<Owner>();
                            using (var dbContext = new Sites4Entities())
                            {
                                siteOrders = dbContext.SiteOrders.Where(so => so.IsActive).ToList();
                                owners = dbContext.Owners.ToList();
                                _logger.Information("3. Get Site Orders from SF_Multisite");
                            }
                            var orders = _orderService.SearchOrders(createdFromUtc: DateTime.Now.AddMonths(-15), createdToUtc: DateTime.Now).ToList();
                            if (orders != null && orders.Any())
                            {
                                orders = orders.Where(o => siteOrders.Any(so => so.OrderId == o.Id)).ToList();
                                if (orders != null && orders.Any())
                                {
                                    _logger.Information("4. Get orders and filter with site orders");
                                    foreach (var product in products)
                                    {
                                        if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "monthly"))
                                        {
                                            ReOrderChecout(orders, product, 1, siteOrders, owners);
                                        }
                                        else if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "yearly"))
                                        {
                                            ReOrderChecout(orders, product, 12, siteOrders, owners);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // Get all orders of that product Ids
                    //foreach on product packages
                    // foreach on orders of monthly packages
                    // if check for order date + Add month(1) >= Datetime.Now.Date
                    // re order this order and call checkout API for this order
                    // Update Store site CreationDate based on that new chckout order date
                    // foreach on orders of Yearly packages
                    // Do the same process for year               
                }
            }

            catch (Exception exc)
            {
                _logger.Error(string.Format("Error when running RecuringPlansTask. {0}", exc.Message), exc);
            }
        }
    }
}