﻿using Nop.Core.Infrastructure;
using Shopfast.Plugin.Custom.Models.NopCore.Custom;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.Custom
{
    public class CustomCommonService : ICustomCommonService
    {
        #region Demo site
        public virtual int GetNextRunJobTime(string applicationName)
        {
            var pJobName = EngineContext.Current.Resolve<Nop.Core.Data.IDataProvider>().GetParameter();
            pJobName.ParameterName = "jobname";
            pJobName.Value = applicationName + "_DemoSiteDB";
            pJobName.DbType = DbType.String;

            var jobDetails = EngineContext.Current.Resolve<Nop.Data.IDbContext>().SqlQuery<SQLJobDetails>("sp_job_calculate_next_run_time_min @jobname", pJobName).FirstOrDefault();
            int cntMin = jobDetails.job_next_scheduled_in_min;

            return cntMin;
            //var products2 = _dbContext.ExecuteStoredProcedureList<SQLJobDetails>(
            // "sp_GetSQLJobDetailsForDemoSite",
            // pJobName, pReturnVals);
        }
        #endregion
    }
}