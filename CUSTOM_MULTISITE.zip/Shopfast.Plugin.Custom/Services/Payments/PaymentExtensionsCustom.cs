﻿using Nop.Core.Domain.Payments;
using Nop.Services.Payments;
using Shopfast.Plugin.Custom.Models.NopCore.Domain.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.Payments
{
    public static class PaymentExtensionsCustom
    {
        /// <summary>
        /// Is primary payment method?
        /// </summary>
        /// <param name="paymentMethod">Payment method</param>
        /// <param name="paymentSettings">Payment settings</param>
        /// <returns>Result</returns>
        public static bool IsPrimaryPaymentMethod(this IPaymentMethod paymentMethod, PaymentSettingsCustom paymentSettings)
        {
            if (paymentMethod == null)
                throw new ArgumentNullException("paymentMethod");

            if (paymentSettings == null)
                throw new ArgumentNullException("paymentSettings");

            if (string.IsNullOrEmpty(paymentSettings.PrimaryPaymentMethodSystemName))
                return false;

            if (paymentMethod.PluginDescriptor.SystemName.Equals(paymentSettings.PrimaryPaymentMethodSystemName, StringComparison.InvariantCultureIgnoreCase))
                return true;

            return false;
        }

        // Payment method IsTabletOnly
        public static bool IsPaymentMethodForTabletOnly(this IPaymentMethod paymentMethod,
            PaymentSettingsCustom paymentSettings)
        {
            if (paymentMethod == null)
                throw new ArgumentNullException("paymentMethod");

            if (paymentSettings == null)
                throw new ArgumentNullException("paymentSettings");

            if (paymentSettings.TabletPaymentMethodSystemNames == null)
                return false;
            foreach (string mobileMethodSystemName in paymentSettings.TabletPaymentMethodSystemNames)
                if (paymentMethod.PluginDescriptor.SystemName.Equals(mobileMethodSystemName, StringComparison.InvariantCultureIgnoreCase))
                    return true;
            return false;
        }
    }
}