﻿using Nop.Admin.Controllers;
using Nop.Services.Orders;
using Shopfast.Plugin.Custom.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class GiftCardCustomAdminController : BaseAdminController
    {
        #region Fields
        private readonly IGiftCardService _giftCardService;
        #endregion

        #region Constructors
        public GiftCardCustomAdminController(IGiftCardService giftCardService)
        {
            this._giftCardService = giftCardService;
        }
        #endregion
        [HttpPost]
        public ActionResult GenerateCouponCode(string code = "")
        {
            if (string.IsNullOrEmpty(code))
            {
                code = _giftCardService.GenerateGiftCardCode();
            }
            string QRCodeImageUrl = string.Empty;
            if (!string.IsNullOrEmpty(code))
            {
                QRCodeImageUrl = "/" + CommonHelperCustom.GenerateQRCodeImage(code);
            }
            return Json(new { CouponCode = code, QRCodeUrl = QRCodeImageUrl }, JsonRequestBehavior.AllowGet);            
        }
    }
}