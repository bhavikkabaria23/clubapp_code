﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Catalog
{
    public class DiscountsResponse
    {
        public DiscountsResponse()
        {
            GetDiscountsResult = new List<DiscountsResult>();
        }
        public List<DiscountsResult> GetDiscountsResult { get; set; }
    }
    public class DiscountsResult
    {
        public int DiscountId { get; set; }
        public string Name { get; set; }
        public bool UsePercentag { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal DiscountAmount { get; set; }
        public DateTime? StartDateUtc { get; set; }
        public DateTime? EndDateUtc { get; set; }
    }
}