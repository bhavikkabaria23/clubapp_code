﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.MerchantAdmin
{
    public class MerchantCardInfo
    {
        public string CardNumber { get; set; }
        public string Expires { get; set; }        
        public string CVV { get; set; }
        public string Message { get; set; }
        public string OwnerEmail { get; set; }
    }
}