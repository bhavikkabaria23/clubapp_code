﻿//upgrade_2.80_3.1
// For package details         
namespace Shopfast.Plugin.Custom.Models.NopAdmin.Common
{
    public class UpgradePackageJsonModel
    {
        public string url { get; set; }
        public bool upgradeStatus { get; set; }
    }
}
//------------------------