﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Customer
{
    public class SecretCustomerSettingModel
    {
        public bool IsAllowForCustomer { get; set; }
    }
}