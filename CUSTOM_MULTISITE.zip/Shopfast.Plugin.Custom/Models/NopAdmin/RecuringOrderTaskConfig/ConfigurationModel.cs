﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.RecuringOrderTaskConfig
{
    public class ConfigurationModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.Customl.RecuringOrderTaskConfig.Fields.StartTime")]
        [UIHint("TimePicker")]
        public DateTime? StartTime { get; set; }
        public bool StartTime_OverrideForStore { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.Customl.RecuringOrderTaskConfig.Fields.EndTime")]
        [UIHint("TimePicker")]
        public DateTime? EndTime { get; set; }
        public bool EndTime_OverrideForStore { get; set; }
    }
}