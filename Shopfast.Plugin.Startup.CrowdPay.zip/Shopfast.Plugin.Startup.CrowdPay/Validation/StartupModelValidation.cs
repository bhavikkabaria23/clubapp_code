﻿using FluentValidation;
using FluentValidation.Results;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using Shopfast.Plugin.Startup.CrowdPay.Models;

namespace Shopfast.Plugin.Startup.CrowdPay.Validation
{
    public class StartupModelValidation : BaseNopValidator<StartupModel>
    {
        public StartupModelValidation(ILocalizationService localizationService,
            IStateProvinceService stateProvinceService)
        {
            RuleFor(x => x.CompanyName)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.CompanyName.Required"));
            RuleFor(x => x.RequestingMoney)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.RequestingMoney.Required"));
            RuleFor(x => x.PreviousFunding)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.PreviousFunding.Required"));
            RuleFor(x => x.CompanyDesc)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.CompanyDesc.Required"));
            RuleFor(x => x.ContactName)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.ContactName.Required"));
            RuleFor(x => x.Email)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Email.Required"));
            RuleFor(x => x.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));
            RuleFor(x => x.Traction_Revenue_Partnerships)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Traction_Revenue_Partnerships.Required"));
            RuleFor(x => x.Phone)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Phone.Required"));
            RuleFor(x => x.DevelopmentStage)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.DevelopmentStage.Required"));
            RuleFor(x => x.PressLinks)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.PressLinks.Required"));
            RuleFor(x => x.CompanyUrl)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.CompanyUrl.Required"));
            RuleFor(x => x.Market)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Market.Required"));
            RuleFor(x => x.FinancingRound)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.FinancingRound.Required"));
            RuleFor(x => x.Facebook)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Facebook.Required"));
            RuleFor(x => x.Twitter)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Twitter.Required"));
            RuleFor(x => x.Review)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Review.Required"));
            RuleFor(x => x.GooglePlus)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.GooglePlus.Required"));
            RuleFor(x => x.LinkedIn)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.LinkedIn.Required"));
            RuleFor(x => x.MicroVentures)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.MicroVentures.Required"));
            RuleFor(x => x.Founder)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Founder.Required"));
            RuleFor(x => x.Incubator)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Incubator.Required"));
            RuleFor(x => x.Investor)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.Investor.Required"));
            RuleFor(x => x.PitchDeckFile)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Startup.Fields.PitchDeckFile.Required"));                       
        }
    }
}
