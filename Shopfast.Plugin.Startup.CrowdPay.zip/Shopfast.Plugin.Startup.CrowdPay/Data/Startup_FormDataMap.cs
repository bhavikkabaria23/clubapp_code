using Nop.Data.Mapping;
using Shopfast.Plugin.Startup.CrowdPay.Domain;

namespace Shopfast.Plugin.Startup.CrowdPay.Data
{
    public partial class Startup_FormDataMap : NopEntityTypeConfiguration<Startup_FormData>
    {
        public Startup_FormDataMap()
        {
            this.ToTable("Startup_FormData");
            this.HasKey(tr => tr.Id);            
        }
    }
}