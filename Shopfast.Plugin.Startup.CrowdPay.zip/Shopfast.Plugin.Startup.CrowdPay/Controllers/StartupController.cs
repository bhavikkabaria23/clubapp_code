﻿using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.Startup.CrowdPay.Models;
using System;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Common;
using System.Linq;
using System.Web;
using System.IO;
using Shopfast.Plugin.Startup.CrowdPay.Services;
using Shopfast.Plugin.Startup.CrowdPay.Domain;
using Nop.Web.Framework.Kendoui;
using Nop.Services.Security;
using System.Collections.Generic;
using Nop.Services.Catalog;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Configuration;
using System.Net;
using System.Collections.Specialized;
using System.Text;
using Newtonsoft.Json;
using System.Json;
using System.Security.Cryptography;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Startup.CrowdPay.Controllers
{
    public class StartupController : BaseController
    {
        private readonly ICustomerService _customerService;
        private readonly CustomerSettings _customerSettings;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IStartupFormService _startupFormService;
        private readonly IPermissionService _permissionService;
        private readonly IPriceFormatter _priceFormatter;

        public StartupController(ICustomerService customerService,
            CustomerSettings customerSettings,
            IGenericAttributeService genericAttributeService,
            ICustomerRegistrationService customerRegistrationService,
            IStartupFormService startupFormService,
            IPermissionService permissionService,
            IPriceFormatter priceFormatter)
        {
            this._customerService = customerService;
            this._customerSettings = customerSettings;
            this._genericAttributeService = genericAttributeService;
            this._customerRegistrationService = customerRegistrationService;
            this._startupFormService = startupFormService;
            this._permissionService = permissionService;
            this._priceFormatter = priceFormatter;
        }


        public ActionResult ConfigureStartUp()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");
            return View("~/Plugins/Startup.CrowdPay/Views/Startup/Configure.cshtml");
        }

        [HttpPost]
        public ActionResult Configure(DataSourceRequest command, StartUpListModel searchModel)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");

            var startupFormModels = _startupFormService.GetStartupForms();

            if (!string.IsNullOrEmpty(searchModel.SearchEmail))
            {
                startupFormModels = startupFormModels.Where(p => p.Email.ToLower().Contains(searchModel.SearchEmail.ToLower())).ToList();
            }
            if (!string.IsNullOrEmpty(searchModel.SearchContactName))
            {
                startupFormModels = startupFormModels.Where(p => p.ContactName.ToLower().Contains(searchModel.SearchContactName.ToLower())).ToList();
            }
            if (!string.IsNullOrEmpty(searchModel.SearchCompanyName))
            {
                startupFormModels = startupFormModels.Where(p => p.CompanyName.ToLower().Contains(searchModel.SearchCompanyName.ToLower())).ToList();
            }

            var gridModel = new DataSourceResult
            {
                Data = startupFormModels,
                Total = startupFormModels.Count()
            };
            return Json(gridModel);
        }

        public ActionResult StartupFormDetail(int Id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("Access denied");
            var startUpForm = _startupFormService.GetStartupFormById(Id);
            StartupModel model = new StartupModel();
            model.CompanyName = startUpForm.CompanyName;
            model.RequestingMoneyText = _priceFormatter.FormatPrice(startUpForm.RequestingMoney, true, false);
            model.PreviousFundingText = _priceFormatter.FormatPrice(startUpForm.PreviousFunding, true, false); ;

            model.CompanyDesc = startUpForm.CompanyDesc;
            model.ContactName = startUpForm.ContactName;
            model.Email = startUpForm.Email;
            model.Traction_Revenue_Partnerships = startUpForm.Traction_Revenue_Partnerships;
            model.Phone = startUpForm.Phone;

            model.DevelopmentStage = startUpForm.DevelopmentStage;
            model.PressLinks = startUpForm.PressLinks;
            model.CompanyUrl = startUpForm.CompanyUrl;
            model.Market = startUpForm.Market;
            model.FinancingRound = startUpForm.FinancingRound;

            model.Facebook = startUpForm.Facebook;
            model.Review = startUpForm.Review;
            model.Twitter = startUpForm.Twitter;
            model.GooglePlus = startUpForm.GooglePlus;
            model.LinkedIn = startUpForm.LinkedIn;

            model.MicroVentures = startUpForm.MicroVentures;
            model.Founder = startUpForm.Founder;
            model.Incubator = startUpForm.Incubator;
            model.Investor = startUpForm.Investor;
            model.PitchDeckFileName = startUpForm.PitchDeckFile;
            model.PitchDeckFileUrl = "/Content/PitchDeckFiles/" + startUpForm.PitchDeckFile;

            return View("~/Plugins/Startup.CrowdPay/Views/Startup/StartupFormDetail.cshtml", model);
        }

        public ActionResult StartupForm()
        {
            if (TempData["success"] != null)
            ViewBag.success = Convert.ToBoolean(TempData["success"]);
            var model = new StartupModel();
            return View("~/Plugins/Startup.CrowdPay/Views/Startup/StartupForm.cshtml", model);
        }

        [HttpPost]
        public ActionResult StartupForm(StartupModel model)
        {
            if (ModelState.IsValid)
            {
                if (!String.IsNullOrWhiteSpace(model.Email))
                {
                    var cust2 = _customerService.GetCustomerByEmail(model.Email);
                    if (cust2 != null)
                    {
                        ModelState.AddModelError("", "Email is already registered");
                        ViewBag.success = false;
                        return View("~/Plugins/Startup.CrowdPay/Views/Startup/StartupForm.cshtml", model);
                    }
                }
                // Upload file
                if (model.PitchDeckFile.ContentLength > 0 && model.PitchDeckFile.ContentLength <= 20 * 1024 * 1024)
                {
                    // Do code for create PitchDeckFiles folder if not exist
                    CreateDirectory("~/Content/PitchDeckFiles");
                    string filePath = Path.Combine(HttpContext.Server.MapPath("/Content/PitchDeckFiles"),
                                                  model.Email + "_" + Path.GetFileName(model.PitchDeckFile.FileName.Replace(" ", "_")));
                    model.PitchDeckFile.SaveAs(filePath);
                }
                else
                {
                    ModelState.AddModelError("", "Maximum allowed file size is 20 MB");
                    ViewBag.success = false;
                    return View("~/Plugins/Startup.CrowdPay/Views/Startup/StartupForm.cshtml", model);
                }
                var customer = new Customer
                {
                    CustomerGuid = Guid.NewGuid(),
                    Email = model.Email,
                    Username = model.Email,
                    Active = true,
                    CreatedOnUtc = DateTime.UtcNow,
                    LastActivityDateUtc = DateTime.UtcNow,
                };
                var roles = _customerService.GetAllCustomerRoles(true);
                customer.CustomerRoles.Add(roles.FirstOrDefault(cr => cr.Name == SystemCustomerRoleNames.Registered));
                if (roles.Any(cr => cr.Name.ToLower() == "startup"))
                {
                    customer.CustomerRoles.Add(roles.FirstOrDefault(cr => cr.Name.ToLower() == "startup"));
                }
                _customerService.InsertCustomer(customer);

                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.Phone);

                //password
                model.Password = "admin#1";
                var changePassRequest = new ChangePasswordRequest(model.Email, false, _customerSettings.DefaultPasswordFormat, model.Password);
                var changePassResult = _customerRegistrationService.ChangePassword(changePassRequest);

                InsertStartupFormData(model);

                VTigerCRMIntegration(model);
                TempData["success"] = true;
                return RedirectToRoute("Plugin.StartupForm");
            }
            ViewBag.success = false;
            return View("~/Plugins/Startup.CrowdPay/Views/Startup/StartupForm.cshtml", model);
        }

        [HttpPost]
        public ActionResult DeleteStartUp(int id = 0)
        {
            _startupFormService.DeleteStartUpById(id);
            return new NullJsonResult();
        }

        private void InsertStartupFormData(StartupModel model)
        {
            if (model != null)
            {
                Startup_FormData formData = new Startup_FormData();
                formData.CompanyName = model.CompanyName;
                formData.RequestingMoney = Convert.ToDecimal(model.RequestingMoney);
                formData.PreviousFunding = Convert.ToDecimal(model.PreviousFunding);

                formData.CompanyDesc = model.CompanyDesc;
                formData.ContactName = model.ContactName;
                formData.Email = model.Email;
                formData.Traction_Revenue_Partnerships = model.Traction_Revenue_Partnerships;
                formData.Phone = model.Phone;

                formData.DevelopmentStage = model.DevelopmentStage;
                formData.PressLinks = model.PressLinks;
                formData.CompanyUrl = model.CompanyUrl;
                formData.Market = model.Market;
                formData.FinancingRound = model.FinancingRound;

                formData.Facebook = model.Facebook;
                formData.Review = model.Review;
                formData.Twitter = model.Twitter;
                formData.GooglePlus = model.GooglePlus;
                formData.LinkedIn = model.LinkedIn;

                formData.MicroVentures = model.MicroVentures;
                formData.Founder = model.Founder;
                formData.Incubator = model.Incubator;
                formData.Investor = model.Investor;
                formData.PitchDeckFile = model.Email + "_" + Path.GetFileName(model.PitchDeckFile.FileName.Replace(" ", "_"));

                _startupFormService.InsertStartupForm(formData);
            }
        }

        private void CreateDirectory(string path)
        {
            if (!Directory.Exists(Server.MapPath(path)))
            {
                Directory.CreateDirectory(Server.MapPath(path));
            }
        }

        private void VTigerCRMIntegration(StartupModel model)
        {
            string VtigerCrmApiUrl = System.Configuration.ConfigurationManager.AppSettings["VtigerCrmApiUrl"];
            string CrmUsername = System.Configuration.ConfigurationManager.AppSettings["CrmUsername"];
            string accessKey = System.Configuration.ConfigurationManager.AppSettings["accessKey"];
            if (!string.IsNullOrEmpty(VtigerCrmApiUrl) && !string.IsNullOrEmpty(CrmUsername) && !string.IsNullOrEmpty(accessKey))
            {
                // Get Token
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(VtigerCrmApiUrl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var tokenResponse = client.GetAsync("?operation=getchallenge&username=" + CrmUsername).Result;
                    if (tokenResponse.IsSuccessStatusCode)
                    {
                        var tokenResult = tokenResponse.Content.ReadAsAsync<VtigerCrmResponse>().Result;
                        if (tokenResult.success)
                        {
                            using (var webclient = new WebClient())
                            {
                                webclient.UseDefaultCredentials = true;
                                webclient.Headers.Add("Content-Type:application/x-www-form-urlencoded");
                                webclient.Headers.Add("Accept:application/json");
                                var uri = new Uri(VtigerCrmApiUrl);

                                NameValueCollection loginParams = new NameValueCollection();
                                loginParams.Add("operation", "login");
                                loginParams.Add("username", CrmUsername);
                                loginParams.Add("accessKey", CalculateMD5Hash(tokenResult.result.token + accessKey));
                                var response = webclient.UploadValues(uri, "POST", loginParams);
                                string jsonResponse = string.Empty;
                                jsonResponse = Encoding.ASCII.GetString(response);
                                var loginResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
                                if (loginResult.success)
                                {
                                    // // Create Leads entry                                
                                    var element = new JsonObject();
                                    element.Add("leadstatus", "Pending");
                                    element.Add("company", model.CompanyName);
                                    element.Add("cf_753", model.RequestingMoney);
                                    element.Add("cf_755", model.PreviousFunding);
                                    element.Add("cf_759", model.CompanyDesc);
                                    element.Add("firstname", model.ContactName.Split(' ')[0]);
                                    element.Add("lastname", (model.ContactName.Split(' ').Count() > 1) ? model.ContactName.Split(' ')[1] : model.ContactName);
                                    element.Add("email", model.Email);
                                    element.Add("cf_765", model.Traction_Revenue_Partnerships);
                                    element.Add("phone", model.Phone);
                                    element.Add("cf_767", model.DevelopmentStage);
                                    element.Add("cf_769", model.PressLinks);
                                    element.Add("website", model.CompanyUrl);
                                    element.Add("cf_807", model.Market);
                                    element.Add("cf_805", model.FinancingRound);
                                    element.Add("cf_775", model.Facebook);
                                    element.Add("cf_777", model.Twitter);
                                    element.Add("cf_779", model.Review);
                                    element.Add("cf_803", model.GooglePlus);
                                    element.Add("cf_801", model.LinkedIn);
                                    element.Add("cf_799", model.MicroVentures);
                                    element.Add("cf_797", model.Founder);
                                    element.Add("cf_789", model.Incubator);
                                    element.Add("cf_795", model.Investor);
                                    element.Add("cf_811", EngineContext.Current.Resolve<IWebHelper>().GetStoreLocation() +
                                        "Content/PitchDeckFiles/" + model.PitchDeckFileUrl);
                                    element.Add("assigned_user_id", loginResult.result.userId);

                                    NameValueCollection leadParams = new NameValueCollection();
                                    leadParams.Add("operation", "create");
                                    leadParams.Add("sessionName", loginResult.result.sessionName);
                                    leadParams.Add("elementType", "Leads");
                                    leadParams.Add("element", element.ToString());
                                    var responseLead = webclient.UploadValues(uri, "POST", leadParams);
                                    jsonResponse = Encoding.ASCII.GetString(responseLead);
                                    var leadResult = JsonConvert.DeserializeObject<VtigerCrmResponse>(jsonResponse);
                                }
                            }
                        }
                    }
                }
            }
        }

        private string CalculateMD5Hash(string input)
        {
            // step 1, calculate MD5 hash from input
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString().ToLower();
        }
    }
}