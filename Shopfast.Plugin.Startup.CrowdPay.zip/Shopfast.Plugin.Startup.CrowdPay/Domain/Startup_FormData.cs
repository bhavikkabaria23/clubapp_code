﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.Startup.CrowdPay.Domain
{
    public class Startup_FormData : BaseEntity
    {        
        public string  CompanyName { get; set; }
        public decimal  RequestingMoney { get; set; }
        public decimal  PreviousFunding { get; set; }
        public string  CompanyDesc { get; set; }
        public string  ContactName { get; set; }
        public string  Email { get; set; }
        public string Traction_Revenue_Partnerships { get; set; }
        public string Phone { get; set; }
        public string DevelopmentStage { get; set; }        
        public string PressLinks { get; set; }
        public string CompanyUrl { get; set; }
        public string Market { get; set; }
        public string FinancingRound { get; set; }
        public string Facebook { get; set; }
        public string Twitter { get; set; }
        public string Review { get; set; }
        public string GooglePlus { get; set; }
        public string LinkedIn { get; set; }
        public string MicroVentures { get; set; }
        public string Founder { get; set; }
        public string Incubator { get; set; }
        public string Investor { get; set; }         
        public string PitchDeckFile { get; set; }
        public string Password { get; set; }
    }
}
