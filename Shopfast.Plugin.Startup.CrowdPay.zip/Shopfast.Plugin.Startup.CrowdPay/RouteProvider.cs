﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.Startup.CrowdPay
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //IPN
            routes.MapRoute("Plugin.StartupForm",
                 "start-application",
                 new { controller = "Startup", action = "StartupForm" },
                 new[] { "Shopfast.Plugin.Startup.CrowdPay.Controllers" }
            );
            routes.MapRoute("Plugin.Startup.List",
                 "Plugin/Startup/List",
                 new { controller = "Startup", action = "ConfigureStartUp" },
                 new[] { "Shopfast.Plugin.Startup.CrowdPay.Controllers" }
                 );
            routes.MapRoute("Plugin.StartupFormDetail",
                 "StartupFormDetail/{Id}",
                 new { controller = "Startup", action = "StartupFormDetail",Id= UrlParameter.Optional },
                 new[] { "Shopfast.Plugin.Startup.CrowdPay.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
