﻿using FluentValidation.Attributes;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Startup.CrowdPay.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Startup.CrowdPay.Models
{
    [Validator(typeof(StartupModelValidation))]
    public class StartupModel : BaseNopEntityModel
    {
        public StartupModel()
        {
            this.DevelopmentStages = new List<SelectListItem>();
            this.DevelopmentStages.Add(new SelectListItem
            {
                Text = "Select",
                Value = ""
            });
            this.DevelopmentStages.Add(new SelectListItem
            {
                Text = "Startup / Seed",
                Value = "seed"
            });
            this.DevelopmentStages.Add(new SelectListItem
            {
                Text = "Early Stage",
                Value = "early"
            });
            this.DevelopmentStages.Add(new SelectListItem
            {
                Text = "Expansion",
                Value = "expansion"
            });
            this.DevelopmentStages.Add(new SelectListItem
            {
                Text = "Later Stage",
                Value = "later"
            });

        }        
        // Company
        [NopResourceDisplayName("Startup.Fields.CompanyName")]
        public string CompanyName { get; set; }
        [NopResourceDisplayName("Startup.Fields.RequestingMoney")]
        public decimal? RequestingMoney { get; set; }
        [NopResourceDisplayName("Startup.Fields.RequestingMoney")]
        public string RequestingMoneyText { get; set; }
        [NopResourceDisplayName("Startup.Fields.PreviousFunding")]
        public decimal? PreviousFunding { get; set; }
        [NopResourceDisplayName("Startup.Fields.PreviousFunding")]
        public string PreviousFundingText { get; set; }
        [NopResourceDisplayName("Startup.Fields.CompanyDesc")]
        public string CompanyDesc { get; set; }
        // First Name and Last Name - spliting the contact name by space
        [NopResourceDisplayName("Startup.Fields.ContactName")]
        public string ContactName { get; set; }
        // Primary Email
        [NopResourceDisplayName("Startup.Fields.Email")]
        public string Email { get; set; }
        [NopResourceDisplayName("Startup.Fields.Traction_Revenue_Partnerships")]
        public string Traction_Revenue_Partnerships { get; set; }
        // Primary Phone
        [NopResourceDisplayName("Startup.Fields.Phone")]
        public string Phone { get; set; }
        [NopResourceDisplayName("Startup.Fields.DevelopmentStage")]
        public string DevelopmentStage { get; set; }
        public IList<SelectListItem> DevelopmentStages { get; set; }
        [NopResourceDisplayName("Startup.Fields.PressLinks")]
        public string PressLinks { get; set; }
        // Website
        [NopResourceDisplayName("Startup.Fields.CompanyUrl")]
        public string CompanyUrl { get; set; }
        
        [NopResourceDisplayName("Startup.Fields.Market")]
        public string Market { get; set; }
        [NopResourceDisplayName("Startup.Fields.FinancingRound")]
        public string FinancingRound { get; set; }
        [NopResourceDisplayName("Startup.Fields.Facebook")]
        public string Facebook { get; set; }
        [NopResourceDisplayName("Startup.Fields.Twitter")]
        public string Twitter { get; set; }
        [NopResourceDisplayName("Startup.Fields.Review")]
        public string Review { get; set; }
        [NopResourceDisplayName("Startup.Fields.GooglePlus")]
        public string GooglePlus { get; set; }
        [NopResourceDisplayName("Startup.Fields.LinkedIn")]
        public string LinkedIn { get; set; }
        [NopResourceDisplayName("Startup.Fields.MicroVentures")]
        public string MicroVentures { get; set; }
        [NopResourceDisplayName("Startup.Fields.Founder")]
        public string Founder { get; set; }
        [NopResourceDisplayName("Startup.Fields.Incubator")]
        public string Incubator { get; set; }
        [NopResourceDisplayName("Startup.Fields.Investor")]
        public string Investor { get; set; }
        [NopResourceDisplayName("Startup.Fields.PitchDeckFile")]
        public HttpPostedFileBase PitchDeckFile { get; set; }
        [NopResourceDisplayName("Startup.Fields.PitchDeckFile")]
        public string PitchDeckFileUrl { get; set; }
        public string PitchDeckFileName { get; set; }        
        public string Password { get; set; }
    }
}
