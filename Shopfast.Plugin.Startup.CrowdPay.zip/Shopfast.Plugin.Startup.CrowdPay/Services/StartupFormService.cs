﻿using Nop.Core.Data;
using Nop.Services.Events;
using Shopfast.Plugin.Startup.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Startup.CrowdPay.Services
{
    public class StartupFormService : IStartupFormService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<Startup_FormData> _startupFormRepository;
        #endregion

        public StartupFormService(IEventPublisher eventPublisher,
           IRepository<Startup_FormData> startupFormRepository)
        {
            this._eventPublisher = eventPublisher;
            this._startupFormRepository = startupFormRepository;            
        }

        public virtual IEnumerable<Startup_FormData> GetStartupForms()
        {
            return _startupFormRepository.Table;
        }

        public virtual Startup_FormData GetStartupFormById(int Id)
        {
            return _startupFormRepository.Table.FirstOrDefault(s=> s.Id == Id);
        }

        public virtual void InsertStartupForm(Startup_FormData startupForm)
        {
            if (startupForm == null)
                throw new ArgumentNullException("startupForm");

            _startupFormRepository.Insert(startupForm);

            //event notification
            _eventPublisher.EntityInserted(startupForm);
        }

        public virtual void UpdateStartupForm(Startup_FormData startupForm)
        {
            if (startupForm == null)
                throw new ArgumentNullException("startupForm");

            _startupFormRepository.Update(startupForm);

            //event notification
            _eventPublisher.EntityUpdated(startupForm);
        }

        public virtual void DeleteStartUpById(int Id)
        {
            if (Id > 0)
            {
                var startup = _startupFormRepository.Table.FirstOrDefault(d => d.Id == Id);
                _startupFormRepository.Delete(startup);

                //event notification
                _eventPublisher.EntityDeleted(startup);
            }
        }
    }
}
