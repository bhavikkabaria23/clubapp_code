﻿using Shopfast.Plugin.Startup.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Startup.CrowdPay.Services
{
    public interface IStartupFormService
    {
        IEnumerable<Startup_FormData> GetStartupForms();
        Startup_FormData GetStartupFormById(int Id);
        void InsertStartupForm(Startup_FormData startupForm);
        void UpdateStartupForm(Startup_FormData startupForm);
        void DeleteStartUpById(int Id);

    }
}
