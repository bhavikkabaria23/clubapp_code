﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Shopfast.Plugin.IssuerDocForm.Domain
{
    public class IDF_Customer
    {
        public int CustomerId { get; set; }
        public string Guid { get; set; }
        public int QuestinoId { get; set; }
        public int ControlId { get; set; }
        public string Answer { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
