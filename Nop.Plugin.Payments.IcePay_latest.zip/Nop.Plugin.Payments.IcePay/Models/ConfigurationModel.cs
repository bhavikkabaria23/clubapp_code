﻿using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System.Collections.Generic;

namespace Nop.Plugin.Payments.IcePay.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public ConfigurationModel()
        {
            AvailablePaymentMethods = new List<SelectListItem>();
            AvailableIssuer = new List<SelectListItem>();
        }
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        public bool AdditionalFeePercentage_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFee_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.MerchantID")]
        public int MerchantID { get; set; }
        public bool MerchantID_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.MerchantSecret")]
        public string MerchantSecret { get; set; }
        public bool MerchantSecret_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.Description")]
        public string Description { get; set; }
        public bool Description_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.PaymentMethod")]
        public string PaymentMethod { get; set; }
        public IList<SelectListItem> AvailablePaymentMethods { get; set; }
        public bool PaymentMethod_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Payments.IcePay.Fields.Issuer")]
        public string Issuer { get; set; }
        public IList<SelectListItem> AvailableIssuer { get; set; }
        public bool Issuer_OverrideForStore { get; set; }     
    }
}