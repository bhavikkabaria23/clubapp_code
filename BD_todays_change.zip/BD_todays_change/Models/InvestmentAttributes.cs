﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class InvestmentAttributes
    {
        public bool ShowTotalInvestment { get; set; }
        public bool ShowMaxInvestment { get; set; }
        public bool ShowMinInvestment { get; set; }
        public bool ShowPrice { get; set; }
        public bool ShowDaysLeft { get; set; }
        public bool ShowInvestors { get; set; }
        public bool ShowRaised { get; set; }
    }
}
