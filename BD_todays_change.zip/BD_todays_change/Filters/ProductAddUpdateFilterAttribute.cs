﻿using Nop.Core.Infrastructure;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.UI;
using RestSharp;
using System.Collections.Specialized;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class ProductAddUpdateFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int StockQuantity = Convert.ToInt32(form["StockQuantity"]);
            int offeringType = (Convert.ToInt32(form["OfferingType"]));
            decimal price = Convert.ToDecimal(form["Price"]);
            if (offeringType > 0 && price > 0 &&
                offeringType != Convert.ToInt32(ClientConstants.OfferingType.type_506b) &&
                offeringType != Convert.ToInt32(ClientConstants.OfferingType.type_506c) &&
                offeringType != Convert.ToInt32(ClientConstants.OfferingType.type_S_1_IPO))
            {
                int maximumPerShare = 0;
                if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_title3))
                {
                    maximumPerShare = Convert.ToInt32(Convert.ToDecimal(1000000) / Convert.ToDecimal(form["Price"]));
                }
                else if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_rega_tier1))
                {
                    maximumPerShare = Convert.ToInt32(Convert.ToDecimal(20000000) / Convert.ToDecimal(form["Price"]));
                }
                else if (offeringType == Convert.ToInt32(ClientConstants.OfferingType.type_rega_tier2))
                {
                    maximumPerShare = Convert.ToInt32(Convert.ToDecimal(50000000) / Convert.ToDecimal(form["Price"]));
                }
                Helper helper = new Helper();
                if (StockQuantity > maximumPerShare)
                {
                    string dataKey = string.Format("nop.notifications.{0}", NotifyType.Error);

                    if (filterContext.Controller.TempData[dataKey] == null)
                        filterContext.Controller.TempData[dataKey] = new List<string>();
                    ((List<string>)filterContext.Controller.TempData[dataKey]).Add(EngineContext.Current.Resolve<ILocalizationService>().GetResource("OfferingTypeMessage.MaximumStockOrAmountLimit"));

                    var controller = (ProductController)filterContext.Controller;
                    if (filterContext.ActionDescriptor.ActionName == "Create")
                    {
                        filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { area = "Admin", action = filterContext.ActionDescriptor.ActionName, Controller = "Product" }));
                    }
                    else
                    {
                        filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { area = "Admin", action = filterContext.ActionDescriptor.ActionName, Controller = "Product", id = Convert.ToInt32(form["Id"]) }));
                    }
                }
            }
        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int productId = 0;
            if (filterContext.ActionDescriptor.ActionName == "Create")
            {
                productId = int.Parse(HttpContext.Current.Session["BD_Admin_ProductController_Create_Product_Id"].ToString());
                HttpContext.Current.Session["BD_Admin_ProductController_Create_Product_Id"] = null;
            }
            else
            {
                if (form != null)
                {
                    productId = int.Parse(form["Id"]);
                }
            }

            if (productId > 0)
            {
                SubscriptionTemplateModel model = new SubscriptionTemplateModel();
                BD_SubscriptionTemplate subscriptionTemplate = new BD_SubscriptionTemplate();
                model.SubscriptionTemplateId = int.Parse(form["SubscriptionTemplateId"]);
                model.HTMLTemplate = form["HTMLTemplate"];
                model.HTMLTemplateForProductAgreement = form["HTMLTemplateForProductAgreement"];
                model.PDFUploadId = int.Parse(form["PDFUploadId"]);
                model.PDFUploadIdForProductAgreement = int.Parse(form["PDFUploadIdForProductAgreement"]);
                model.productId = int.Parse(form["productId"]);
                var check = form["IsDocusign"];
                if (form["IsDocusign"] == "false")
                {
                    model.IsDocusign = false;
                }
                else
                {
                    model.IsDocusign = true;
                }
                model.DocusignUsername = form["DocusignUsername"];
                model.DocusignPassword = form["DocusignPassword"];
                model.DocuSignIntegratorKey = form["DocuSignIntegratorKey"];
                model.OfferingType = (Convert.ToInt32(form["OfferingType"]) == 0) ? 1 : Convert.ToInt32(form["OfferingType"]);
                model.AllowInvestment = Convert.ToBoolean(form["AllowInvestment"].Split(',')[0]);
                model.ShowLookingToInvest = Convert.ToBoolean(form["ShowLookingToInvest"].Split(',')[0]);
                if (form["AllowNDA"] == "false")
                {
                    model.AllowNDA = false;
                }
                else
                {
                    model.AllowNDA = true;
                }
                model.NDAHTMLTemplate = form["NDAHTMLTemplate"];

                
                subscriptionTemplate.ShowInSummaryPage = SetInvestmentAttributeJson("ShowInSummaryPage", form);
                subscriptionTemplate.ShowInDeatilPage = SetInvestmentAttributeJson("ShowInDeatilPage", form);
                subscriptionTemplate.ShowInCheckoutPage = SetInvestmentAttributeJson("ShowInCheckoutPage", form);


                //logger.Information("NDAPDFUploadId: " + int.Parse(form["NDAPDFUploadId"]));
                //model.NDAPDFUploadId = int.Parse(form["NDAPDFUploadId"]);
                //logger.Information("PPMPDFUploadId: " + int.Parse(form["PPMPDFUploadId"]));
                //model.PPMPDFUploadId = int.Parse(form["PPMPDFUploadId"]);

                if (model.SubscriptionTemplateId > 0)
                {
                    subscriptionTemplate = EngineContext.Current.Resolve<IBDAddressService>().GetSubscriptionTemplateById(model.SubscriptionTemplateId);
                }
                subscriptionTemplate.productId = model.productId;
                subscriptionTemplate.Id = model.SubscriptionTemplateId;
                subscriptionTemplate.HTMLTemplate = model.HTMLTemplate;
                subscriptionTemplate.HTMLTemplateForProductAgreement = model.HTMLTemplateForProductAgreement;
                subscriptionTemplate.PDFUploadId = model.PDFUploadId;
                subscriptionTemplate.PDFUploadIdForProductAgreement = model.PDFUploadIdForProductAgreement;
                subscriptionTemplate.IsDocusign = model.IsDocusign;
                subscriptionTemplate.DocusignUsername = model.DocusignUsername;
                subscriptionTemplate.DocusignPassword = model.DocusignPassword;
                subscriptionTemplate.DocuSignIntegratorKey = model.DocuSignIntegratorKey;
                subscriptionTemplate.DocuSignMode = model.DocuSignModeId == 0 ? Convert.ToInt32(DocuSignMode.Test) : model.DocuSignModeId;
                subscriptionTemplate.OfferingType = model.OfferingType;
                subscriptionTemplate.AllowInvestment = model.AllowInvestment;
                subscriptionTemplate.ShowLookingToInvest = model.ShowLookingToInvest;
                subscriptionTemplate.AllowNDA = model.AllowNDA;
                subscriptionTemplate.NDAHTMLTemplate = model.NDAHTMLTemplate;
                subscriptionTemplate.NDAPDFUploadId = model.NDAPDFUploadId;
                subscriptionTemplate.PPMPDFUploadId = model.PPMPDFUploadId;
                if (model.SubscriptionTemplateId > 0)
                {
                    EngineContext.Current.Resolve<IBDAddressService>().UpdateSubscriptionTemplate(subscriptionTemplate);
                }
                else
                {
                    EngineContext.Current.Resolve<IBDAddressService>().InsertSubscriptionTemplate(subscriptionTemplate);
                }
            }
        }

        private string SetInvestmentAttributeJson(string page, NameValueCollection form)
        {
            var element = new JsonObject();
            try
            {
                element.Add("ShowTotalInvestment", Convert.ToBoolean(form[page + ".ShowTotalInvestment"]));
                element.Add("ShowMaxInvestment", Convert.ToBoolean(form[page + ".ShowMaxInvestment"]));
                element.Add("ShowMinInvestment", Convert.ToBoolean(form[page + ".ShowMinInvestment"]));
                element.Add("ShowPrice", Convert.ToBoolean(form[page + ".ShowPrice"]));
                element.Add("ShowDaysLeft", Convert.ToBoolean(form[page + ".ShowDaysLeft"]));
                element.Add("ShowInvestors", Convert.ToBoolean(form[page + ".ShowInvestors"]));
                element.Add("ShowRaised", Convert.ToBoolean(form[page + ".ShowRaised"]));
                return element.ToString();
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
    }
}
