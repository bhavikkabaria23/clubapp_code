﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Shopfast.Plugin.Custom.Filters.Admin;
using Shopfast.Plugin.Custom.Services;
using Nop.Data;
using Nop.Core.Data;
using Nop.Services.Security;
using Nop.Core.Caching;
using Autofac.Core;
using Shopfast.Plugin.Custom.Services.Custom;
using Shopfast.Plugin.Custom.Services.Messages;
using Shopfast.Plugin.Custom.Filters.Web;

namespace Shopfast.Plugin.Custom.Infrastructure
{
    // 1) two dependancy register
    // 2) One for custom service
    // 3) second for datalayer, cashing and MultisitePermissionService which e want to override
    // after doing 1,2,3 . May be "Install db" page comming problem and "_databaseIsInstalled" problem will be resolved.
    // for cashing we can register "MultisiteMemoryCacheManager". No need to use "MultisitePerRequestCacheManager" bcs it is just for one request
    public class DependencyRegistrarService : IDependencyRegistrar
    {
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {            
            FilterProviders.Providers.Add(new TopicFilterProvider());
            FilterProviders.Providers.Add(new AffiliateFilterProvider());
            // Custom Services
            builder.RegisterType<CustomerServiceCustom>().As<ICustomerServiceCustom>().InstancePerLifetimeScope();
            builder.RegisterType<ProductServiceCustom>().As<IProductServiceCustom>().InstancePerLifetimeScope();
            builder.RegisterType<NewsServiceCustom>().As<INewsServiceCustom>().InstancePerLifetimeScope();
            builder.RegisterType<CustomCommonService>().As<ICustomCommonService>().InstancePerLifetimeScope();
            builder.RegisterType<CustomerRegistrationServiceCustom>().As<ICustomerRegistrationServiceCustom>().InstancePerLifetimeScope();

            builder.RegisterType<WorkflowMessageServiceCustom>().As<IWorkflowMessageServiceCustom>().InstancePerLifetimeScope();
            builder.RegisterType<MessageTokenProviderCustom>().As<IMessageTokenProviderCustom>().InstancePerLifetimeScope();             
        }

        public int Order
        {
            get { return 1; }
        }
    }
}