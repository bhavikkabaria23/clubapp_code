﻿using Nop.Core.Domain.Vendors;
using Nop.Core.Events;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class VendorInsertedEventConsumer : IConsumer<EntityInserted<Vendor>>
    {
        public void HandleEvent(EntityInserted<Vendor> eventMessage)
        {
            var id = eventMessage.Entity.Id;
            System.Web.HttpContext.Current.Session["Admin_VendorController_Create_Vendor_Id"] = id;
        }
    }
}