﻿using Nop.Core.Domain.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopWeb.Product
{
    public class EquipmentManufacturer
    {
        public EquipmentManufacturer()
        {
            ProductList = new List<ProductInformation>();
            ManufacturerList = new List<Manufacturer>();
        }
        public List<ProductInformation> ProductList { get; set; }
        public int SelectedProductId { get; set; }
        public List<Manufacturer> ManufacturerList { get; set; }
        public int SelectedManufacturerId { get; set; }
        public int Count { get; set; }
    }
    public class ProductInformation
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string ModelNumber { get; set; }
        public decimal? PurchasePrice { get; set; }
        public decimal? RentalPrice { get; set; }
        public decimal? ReprogramPrice { get; set; }
        public string ThumbImageUrl { get; set; }
    }
}