﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Settings
{
    public class GeneralCommonSettingsModelCustom
    {
        [NopResourceDisplayName("Admin.Configuration.Settings.GeneralCommon.DefaultStoreThemeForAdmin")]
        [AllowHtml]
        public string DefaultStoreThemeForAdmin { get; set; }
        public IList<SelectListItem> AvailableStoreThemesForAdmin { get; set; }
    }
}