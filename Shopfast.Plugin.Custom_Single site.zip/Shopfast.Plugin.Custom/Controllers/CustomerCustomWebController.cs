﻿using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Messages;
using Nop.Core.Infrastructure;
using Nop.Services.Authentication;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Events;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Web.Controllers;
using Nop.Web.Framework;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Framework.Themes;
using Nop.Web.Models.Customer;
using Shopfast.Plugin.Custom.Models.NopWeb.Customer;
using Shopfast.Plugin.Custom.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebGrease.Css.Extensions;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class CustomerCustomWebController : BasePublicController
    {
        #region Fields
        private readonly IAuthenticationService _authenticationService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly ICustomerService _customerService;
        private readonly ILocalizationService _localizationService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly CaptchaSettings _captchaSettings;
        private readonly CustomerSettings _customerSettings;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IWorkContext _workContext;
        private readonly IEventPublisher _eventPublisher;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly IWorkflowMessageServiceCustom _workflowMessageServiceCustom;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IStoreContext _storeContext;
        private readonly IWebHelper _webHelper;

        private readonly ICustomerAttributeParser _customerAttributeParser;
        private readonly ICustomerAttributeService _customerAttributeService;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly DateTimeSettings _dateTimeSettings;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly INewsLetterSubscriptionService _newsLetterSubscriptionService;


        #endregion

        #region Ctor
        public CustomerCustomWebController(
        IAuthenticationService authenticationService,
        ICustomerRegistrationService customerRegistrationService,
        ICustomerService customerService,
        ILocalizationService localizationService,
        ICustomerActivityService customerActivityService,
            CaptchaSettings captchaSettings,
            CustomerSettings customerSettings,
            IShoppingCartService shoppingCartService,
            IWorkContext workContext,
            IEventPublisher eventPublisher,
            IGenericAttributeService genericAttributeService,
            IWorkflowMessageService workflowMessageService,
            IWorkflowMessageServiceCustom workflowMessageServiceCustom,
            LocalizationSettings localizationSettings,
            IStoreContext storeContext,
            IWebHelper webHelper,
             ICustomerAttributeParser customerAttributeParser,
        ICustomerAttributeService customerAttributeService,
        IDateTimeHelper dateTimeHelper,
        DateTimeSettings dateTimeSettings,
        ICountryService countryService,
        IStateProvinceService stateProvinceService,
            INewsLetterSubscriptionService newsLetterSubscriptionService
            )
        {
            this._authenticationService = authenticationService;

            this._localizationService = localizationService;

            this._customerService = customerService;

            this._customerRegistrationService = customerRegistrationService;

            this._customerActivityService = customerActivityService;
            this._captchaSettings = captchaSettings;
            this._customerSettings = customerSettings;
            this._shoppingCartService = shoppingCartService;
            this._workContext = workContext;
            this._eventPublisher = eventPublisher;
            this._genericAttributeService = genericAttributeService;
            this._workflowMessageService = workflowMessageService;
            this._workflowMessageServiceCustom = workflowMessageServiceCustom;
            this._localizationSettings = localizationSettings;
            this._storeContext = storeContext;
            this._customerAttributeParser = customerAttributeParser;
            this._customerAttributeService = customerAttributeService;
            this._dateTimeHelper = dateTimeHelper;
            this._dateTimeSettings = dateTimeSettings;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._newsLetterSubscriptionService = newsLetterSubscriptionService;
        }
        #endregion

        #region Utilities
        /// <summary>
        /// Prepare custom customer attribute models
        /// </summary>
        /// <param name="customer">Customer</param>
        /// <param name="overrideAttributesXml">When specified we do not use attributes of a customer</param>
        /// <returns>A list of customer attribute models</returns>
        [NonAction]
        protected virtual IList<CustomerAttributeModel> PrepareCustomCustomerAttributes(Customer customer,
            string overrideAttributesXml = "")
        {
            if (customer == null)
                throw new ArgumentNullException("customer");

            var result = new List<CustomerAttributeModel>();

            var customerAttributes = _customerAttributeService.GetAllCustomerAttributes();
            foreach (var attribute in customerAttributes)
            {
                var attributeModel = new CustomerAttributeModel
                {
                    Id = attribute.Id,
                    Name = attribute.GetLocalized(x => x.Name),
                    IsRequired = attribute.IsRequired,
                    AttributeControlType = attribute.AttributeControlType,
                };

                if (attribute.ShouldHaveValues())
                {
                    //values
                    var attributeValues = _customerAttributeService.GetCustomerAttributeValues(attribute.Id);
                    foreach (var attributeValue in attributeValues)
                    {
                        var valueModel = new CustomerAttributeValueModel
                        {
                            Id = attributeValue.Id,
                            Name = attributeValue.GetLocalized(x => x.Name),
                            IsPreSelected = attributeValue.IsPreSelected
                        };
                        attributeModel.Values.Add(valueModel);
                    }
                }

                //set already selected attributes
                var selectedAttributesXml = !String.IsNullOrEmpty(overrideAttributesXml) ?
                    overrideAttributesXml :
                    customer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                    case AttributeControlType.Checkboxes:
                        {
                            if (!String.IsNullOrEmpty(selectedAttributesXml))
                            {
                                //clear default selection
                                foreach (var item in attributeModel.Values)
                                    item.IsPreSelected = false;

                                //select new values
                                var selectedValues = _customerAttributeParser.ParseCustomerAttributeValues(selectedAttributesXml);
                                foreach (var attributeValue in selectedValues)
                                    foreach (var item in attributeModel.Values)
                                        if (attributeValue.Id == item.Id)
                                            item.IsPreSelected = true;
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //do nothing
                            //values are already pre-set
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            if (!String.IsNullOrEmpty(selectedAttributesXml))
                            {
                                var enteredText = _customerAttributeParser.ParseValues(selectedAttributesXml, attribute.Id);
                                if (enteredText.Any())
                                    attributeModel.DefaultValue = enteredText[0];
                            }
                        }
                        break;
                    case AttributeControlType.ColorSquares:
                    case AttributeControlType.ImageSquares:
                    case AttributeControlType.Datepicker:
                    case AttributeControlType.FileUpload:
                    default:
                        //not supported attribute control types
                        break;
                }

                result.Add(attributeModel);
            }


            return result;
        }

        [NonAction]
        protected virtual void PrepareCustomerRegisterModel(OfferingDocsRegisterModel model)
        {
            if (model == null)
                throw new ArgumentNullException("model");

            //countries and states          
            model.AvailableCountries.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });

            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                model.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.CountryId
                });
            }

            //states
            var states = _stateProvinceService.GetStateProvincesByCountryId(model.CountryId, _workContext.WorkingLanguage.Id).ToList();
            if (states.Any())
            {
                model.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectState"), Value = "0" });

                foreach (var s in states)
                {
                    model.AvailableStates.Add(new SelectListItem { Text = s.GetLocalized(x => x.Name), Value = s.Id.ToString(), Selected = (s.Id == model.StateProvinceId) });
                }
            }
            else
            {
                bool anyCountrySelected = model.AvailableCountries.Any(x => x.Selected);

                model.AvailableStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource(anyCountrySelected ? "Address.OtherNonUS" : "Address.SelectState"),
                    Value = "0"
                });
            }
        }

        [NonAction]
        protected virtual void PrepareCustomerRegisterModel(RegisterModel model, bool excludeProperties,
            string overrideCustomCustomerAttributesXml = "")
        {
            if (model == null)
                throw new ArgumentNullException("model");

            model.AllowCustomersToSetTimeZone = _dateTimeSettings.AllowCustomersToSetTimeZone;
            foreach (var tzi in _dateTimeHelper.GetSystemTimeZones())
                model.AvailableTimeZones.Add(new SelectListItem { Text = tzi.DisplayName, Value = tzi.Id, Selected = (excludeProperties ? tzi.Id == model.TimeZoneId : tzi.Id == _dateTimeHelper.CurrentTimeZone.Id) });

            // Customized***
            //model.DisplayVatNumber = _taxSettings.EuVatEnabled;
            //form fields
            model.GenderEnabled = _customerSettings.GenderEnabled;
            model.DateOfBirthEnabled = _customerSettings.DateOfBirthEnabled;
            model.DateOfBirthRequired = _customerSettings.DateOfBirthRequired;
            model.CompanyEnabled = _customerSettings.CompanyEnabled;
            model.CompanyRequired = _customerSettings.CompanyRequired;
            model.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;
            model.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            model.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;
            model.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            model.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;
            model.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            model.CityEnabled = _customerSettings.CityEnabled;
            model.CityRequired = _customerSettings.CityRequired;
            model.CountryEnabled = _customerSettings.CountryEnabled;
            model.CountryRequired = _customerSettings.CountryRequired;
            model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;
            model.StateProvinceRequired = _customerSettings.StateProvinceRequired;
            model.PhoneEnabled = _customerSettings.PhoneEnabled;
            model.PhoneRequired = _customerSettings.PhoneRequired;
            // Customized***
            //model.FaxEnabled = _customerSettings.FaxEnabled;
            // Customized***
            //model.FaxRequired = _customerSettings.FaxRequired;
            model.NewsletterEnabled = _customerSettings.NewsletterEnabled;
            model.AcceptPrivacyPolicyEnabled = _customerSettings.AcceptPrivacyPolicyEnabled;
            model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            model.CheckUsernameAvailabilityEnabled = _customerSettings.CheckUsernameAvailabilityEnabled;
            // Customized***
            //model.HoneypotEnabled = _securitySettings.HoneypotEnabled;
            // Customized***
            model.DisplayCaptcha = _captchaSettings.Enabled;
            model.EnteringEmailTwice = _customerSettings.EnteringEmailTwice;

            //countries and states
            if (_customerSettings.CountryEnabled)
            {
                model.AvailableCountries.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });

                foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
                {
                    model.AvailableCountries.Add(new SelectListItem
                    {
                        Text = c.GetLocalized(x => x.Name),
                        Value = c.Id.ToString(),
                        Selected = c.Id == model.CountryId
                    });
                }

                if (_customerSettings.StateProvinceEnabled)
                {
                    //states
                    var states = _stateProvinceService.GetStateProvincesByCountryId(model.CountryId, _workContext.WorkingLanguage.Id).ToList();
                    if (states.Any())
                    {
                        model.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectState"), Value = "0" });

                        foreach (var s in states)
                        {
                            model.AvailableStates.Add(new SelectListItem { Text = s.GetLocalized(x => x.Name), Value = s.Id.ToString(), Selected = (s.Id == model.StateProvinceId) });
                        }
                    }
                    else
                    {
                        bool anyCountrySelected = model.AvailableCountries.Any(x => x.Selected);

                        model.AvailableStates.Add(new SelectListItem
                        {
                            Text = _localizationService.GetResource(anyCountrySelected ? "Address.OtherNonUS" : "Address.SelectState"),
                            Value = "0"
                        });
                    }

                }
            }

            //custom customer attributes
            var customAttributes = PrepareCustomCustomerAttributes(_workContext.CurrentCustomer, overrideCustomCustomerAttributesXml);
            customAttributes.ForEach(model.CustomerAttributes.Add);
        }

        [NonAction]
        protected virtual string ParseCustomCustomerAttributes(FormCollection form)
        {
            if (form == null)
                throw new ArgumentNullException("form");

            string attributesXml = "";
            var attributes = _customerAttributeService.GetAllCustomerAttributes();
            foreach (var attribute in attributes)
            {
                string controlId = string.Format("customer_attribute_{0}", attribute.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ctrlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = _customerAttributeParser.AddCustomerAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.Checkboxes:
                        {
                            var cblAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(cblAttributes))
                            {
                                foreach (var item in cblAttributes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                                {
                                    int selectedAttributeId = int.Parse(item);
                                    if (selectedAttributeId > 0)
                                        attributesXml = _customerAttributeParser.AddCustomerAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                                }
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //load read-only (already server-side selected) values
                            var attributeValues = _customerAttributeService.GetCustomerAttributeValues(attribute.Id);
                            foreach (var selectedAttributeId in attributeValues
                                .Where(v => v.IsPreSelected)
                                .Select(v => v.Id)
                                .ToList())
                            {
                                attributesXml = _customerAttributeParser.AddCustomerAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                string enteredText = ctrlAttributes.Trim();
                                attributesXml = _customerAttributeParser.AddCustomerAttribute(attributesXml,
                                    attribute, enteredText);
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                    case AttributeControlType.ColorSquares:
                    case AttributeControlType.ImageSquares:
                    case AttributeControlType.FileUpload:
                    //not supported customer attributes
                    default:
                        break;
                }
            }

            return attributesXml;
        }
        #endregion

        #region Login / logout

        #region Additional Methods

        public ActionResult MobileLogin(string username, string password)
        {
            var loginResult = _customerRegistrationService.ValidateCustomer(username, password);
            if (loginResult == CustomerLoginResults.Successful)
            {
                var customer = _customerService.GetCustomerByEmail(username);

                //sign in new customer
                _authenticationService.SignIn(customer, false);

                //raise event       
                _eventPublisher.Publish(new CustomerLoggedinEvent(customer));

                //activity log
                _customerActivityService.InsertActivity("PublicStore.Login", _localizationService.GetResource("ActivityLog.PublicStore.Login"), customer);

                return Redirect("/Admin");
            }

            return null;
        }

        /// <summary>
        //My Account Module
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        //public ActionResult StoreCustomerLogin(string email)
        //{
        //    var customer = _customerService.GetCustomerByEmail(email);
        //    var loginResult = _customerRegistrationService.ValidateCustomer(email, customer.Password);

        //    // We make this condition because here only email is passed, not password. 
        //    // so password should not be wrong and do not required to check.
        //    if (loginResult == CustomerLoginResults.WrongPassword)
        //    {
        //        loginResult = CustomerLoginResults.Successful;
        //    }
        //    switch (loginResult)
        //    {
        //        case CustomerLoginResults.Successful:
        //            {
        //                //var customer = _customerService.GetCustomerByEmail(email);
        //                //migrate shopping cart
        //                _shoppingCartService.MigrateShoppingCart(_workContext.CurrentCustomer, customer, true);

        //                //sign in new customer
        //                _authenticationService.SignIn(customer, true);

        //                //activity log
        //                _customerActivityService.InsertActivity("PublicStore.Login", _localizationService.GetResource("ActivityLog.PublicStore.Login"), customer);

        //                return RedirectToRoute("CustomerInfo");
        //            }
        //        default:
        //            return RedirectToRoute("HomePage");
        //    }

        //}
        #endregion

        #endregion

        #region Additional Methods
        public ActionResult DemoSiteSignUp()
        {
            var model = new RegisterModel();
            PrepareCustomerRegisterModel(model, false);
            //enable newsletter by default
            model.Newsletter = _customerSettings.NewsletterTickedByDefault;
            return View(model);
        }
        // Demo site sign up form register
        [HttpPost]
        [CaptchaValidator]
        public ActionResult DemoSiteRegister(RegisterModel model, string returnUrl, bool captchaValid, FormCollection form)
        {
            //check whether registration is allowed
            //if (_customerSettings.UserRegistrationType == UserRegistrationType.Disabled)
            //    return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.Disabled });

            //if (_workContext.CurrentCustomer.IsRegistered())
            //{
            //    //Already registered customer. 
            //    _authenticationService.SignOut();

            //    //Save a new record
            //    _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            //}
            var customer = _workContext.CurrentCustomer;

            //custom customer attributes
            var customerAttributesXml = ParseCustomCustomerAttributes(form);
            var customerAttributeWarnings = _customerAttributeParser.GetAttributeWarnings(customerAttributesXml);
            foreach (var error in customerAttributeWarnings)
            {
                ModelState.AddModelError("", error);
            }

            //validate CAPTCHA
            if (_captchaSettings.Enabled && !captchaValid)
            {
                ModelState.AddModelError("", _localizationService.GetResource("Common.WrongCaptcha"));
            }
            ModelState.Where(m => m.Key == "Password").FirstOrDefault().Value.Errors.Clear();
            ModelState.Where(m => m.Key == "ConfirmPassword").FirstOrDefault().Value.Errors.Clear();

            if (ModelState.IsValid)
            {
                model.Password = "password@123";
                //if (ModelState.IsValid)
                //{
                //if (_customerSettings.UsernamesEnabled && model.Username != null)
                //{
                //    model.Username = model.Username.Trim();
                //}

                //3.1
                /* Customer Geolocation  */
                //HttpCookie CountryName = Request.Cookies["countryName"];
                //HttpCookie StateName = Request.Cookies["regionName"];
                //HttpCookie CityName = Request.Cookies["cityName"];
                //HttpCookie ipAddress = Request.Cookies["ipAddress"];
                //HttpCookie countryCode = Request.Cookies["countryCode"];
                //HttpCookie latitude = Request.Cookies["latitude"];
                //HttpCookie longitude = Request.Cookies["longitude"];
                //HttpCookie timeZone = Request.Cookies["timeZone"];

                //string location = "";
                //if (CountryName != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(CountryName.Value) ? CountryName.Value : "-");
                //}
                //if (StateName != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(StateName.Value) ? StateName.Value : "-");
                //}
                //if (CityName != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(CityName.Value) ? CityName.Value : "-");
                //}
                //if (ipAddress != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(ipAddress.Value) ? ipAddress.Value : "-");
                //}
                //if (countryCode != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(countryCode.Value) ? countryCode.Value : "-");
                //}
                //if (latitude != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(latitude.Value) ? latitude.Value : "-");
                //}
                //if (longitude != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(longitude.Value) ? longitude.Value : "-");
                //}
                //if (timeZone != null)
                //{
                //    location = location + "," + (!string.IsNullOrEmpty(timeZone.Value) ? timeZone.Value : "-");
                //}
                //model.Geolocation = location.Trim(',');
                //--------------------------

                bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
                var registrationRequest = new CustomerRegistrationRequest(customer,
                         model.Email,
                         _customerSettings.UsernamesEnabled ? model.Username : model.Email,
                         model.Password,
                         _customerSettings.DefaultPasswordFormat,
                         _storeContext.CurrentStore.Id,
                         isApproved);
                //--------------------------------
                var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
                if (registrationResult.Success)
                {

                    //form fields
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, model.FirstName);
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, model.LastName);

                    //3.1
                    /* Customer Geolocation */
                    //_genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Geolocation, model.Geolocation);
                    //-------------------------------
                    if (_customerSettings.CompanyEnabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, model.Company);
                    if (_customerSettings.StreetAddressEnabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress, model.StreetAddress);
                    if (_customerSettings.StreetAddress2Enabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress2, model.StreetAddress2);

                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.ZipPostalCode, model.ZipPostalCode);

                    if (_customerSettings.CityEnabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.City, model.City);
                    if (_customerSettings.CountryEnabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CountryId, model.CountryId);
                    if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);

                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.Phone);

                    //newsletter
                    if (_customerSettings.NewsletterEnabled)
                    {
                        //save newsletter value
                        var newsletter = _newsLetterSubscriptionService.GetNewsLetterSubscriptionByEmailAndStoreId(model.Email, _storeContext.CurrentStore.Id);
                        if (newsletter != null)
                        {
                            if (model.Newsletter)
                            {
                                newsletter.Active = true;
                                _newsLetterSubscriptionService.UpdateNewsLetterSubscription(newsletter);
                            }
                            //else
                            //{
                            //When registering, not checking the newsletter check box should not take an existing email address off of the subscription list.
                            //_newsLetterSubscriptionService.DeleteNewsLetterSubscription(newsletter);
                            //}
                        }
                        else
                        {
                            if (model.Newsletter)
                            {
                                _newsLetterSubscriptionService.InsertNewsLetterSubscription(new NewsLetterSubscription
                                {
                                    NewsLetterSubscriptionGuid = Guid.NewGuid(),
                                    Email = model.Email,
                                    Active = true,
                                    StoreId = _storeContext.CurrentStore.Id,
                                    CreatedOnUtc = DateTime.UtcNow
                                });
                            }
                        }
                    }

                    //save customer attributes
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CustomCustomerAttributes, customerAttributesXml);

                    //notifications
                    if (_customerSettings.NotifyNewCustomerRegistration)
                        _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                    switch (_customerSettings.UserRegistrationType)
                    {
                        case UserRegistrationType.EmailValidation:
                            {
                                //email validation message
                                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                                // here last parameter is "true" for to show demosite link in activation page.
                                _workflowMessageServiceCustom.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id, true);

                                //result
                                //return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });                            
                                return RedirectToRoute("HomePage", new { ShowDemoSitePopup = "yes" });
                            }
                        case UserRegistrationType.AdminApproval:
                            {
                                //return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                                return RedirectToRoute("HomePage");
                            }
                        case UserRegistrationType.Standard:
                            {
                                //send customer welcome message
                                _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);
                                //3.1
                                if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
                                //-------------------------------
                                var redirectUrl = Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                                if (!String.IsNullOrEmpty(returnUrl))
                                    redirectUrl = _webHelper.ModifyQueryString(redirectUrl, "returnurl=" + HttpUtility.UrlEncode(returnUrl), null);
                                //return Redirect(redirectUrl);
                                return RedirectToRoute("HomePage");
                            }
                        default:
                            {
                                return RedirectToRoute("HomePage");
                            }
                    }
                }
                else
                {
                    foreach (var error in registrationResult.Errors)
                        ModelState.AddModelError("", error);
                }
            }
            model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage;
            return Redirect("/Demositesignup");
        }

        public ActionResult ResellerSignUp()
        {
            var model = new RegisterModel();
            PrepareCustomerRegisterModel(model, false);
            //enable newsletter by default
            model.Newsletter = _customerSettings.NewsletterTickedByDefault;
            return View(model);
        }

        [HttpPost]
        [CaptchaValidator]
        public ActionResult ResellerSignUp(RegisterModel model, string returnUrl, bool captchaValid, FormCollection form)
        {
            //check whether registration is allowed
            //if (_customerSettings.UserRegistrationType == UserRegistrationType.Disabled)
            //    return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.Disabled });

            //if (_workContext.CurrentCustomer.IsRegistered())
            //{
            //    //Already registered customer. 
            //    _authenticationService.SignOut();

            //    //Save a new record
            //    _workContext.CurrentCustomer = _customerService.InsertGuestCustomer();
            //}
            var customer = _workContext.CurrentCustomer;

            //custom customer attributes
            var customerAttributesXml = ParseCustomCustomerAttributes(form);
            var customerAttributeWarnings = _customerAttributeParser.GetAttributeWarnings(customerAttributesXml);
            foreach (var error in customerAttributeWarnings)
            {
                ModelState.AddModelError("", error);
            }

            //validate CAPTCHA
            //if (_captchaSettings.Enabled && _captchaSettings.ShowOnRegistrationPage && !captchaValid)
            //{
            //    ModelState.AddModelError("", _localizationService.GetResource("Common.WrongCaptcha"));
            //}

            if (ModelState.IsValid)
            {
                if (_customerSettings.UsernamesEnabled && model.Username != null)
                {
                    model.Username = model.Username.Trim();
                }

                bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
                var registrationRequest = new CustomerRegistrationRequest(customer,
                    model.Email,
                    _customerSettings.UsernamesEnabled ? model.Username : model.Email,
                    model.Password,
                    _customerSettings.DefaultPasswordFormat,
                    _storeContext.CurrentStore.Id,
                    isApproved);
                var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
                if (registrationResult.Success)
                {
                    //properties
                    if (_dateTimeSettings.AllowCustomersToSetTimeZone)
                    {
                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.TimeZoneId, model.TimeZoneId);
                    }
                    //VAT number
                    //if (_taxSettings.EuVatEnabled)
                    //{
                    //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.VatNumber, model.VatNumber);

                    //    string vatName;
                    //    string vatAddress;
                    //    var vatNumberStatus = _taxService.GetVatNumberStatus(model.VatNumber, out vatName, out vatAddress);
                    //    _genericAttributeService.SaveAttribute(customer,
                    //        SystemCustomerAttributeNames.VatNumberStatusId,
                    //        (int)vatNumberStatus);
                    //    //send VAT number admin notification
                    //    if (!String.IsNullOrEmpty(model.VatNumber) && _taxSettings.EuVatEmailAdminWhenNewVatSubmitted)
                    //        _workflowMessageService.SendNewVatSubmittedStoreOwnerNotification(customer, model.VatNumber, vatAddress, _localizationSettings.DefaultAdminLanguageId);

                    //}

                    //form fields
                    //if (_customerSettings.GenderEnabled)
                    //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Gender, model.Gender);
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, model.FirstName);
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, model.LastName);
                    //if (_customerSettings.DateOfBirthEnabled)
                    //{
                    //    DateTime? dateOfBirth = model.ParseDateOfBirth();
                    //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.DateOfBirth, dateOfBirth);
                    //}
                    //if (_customerSettings.CompanyEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, model.Company);
                    //if (_customerSettings.StreetAddressEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress, model.StreetAddress);
                    //if (_customerSettings.StreetAddress2Enabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StreetAddress2, model.StreetAddress2);
                    //if (_customerSettings.ZipPostalCodeEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.ZipPostalCode, model.ZipPostalCode);
                    //if (_customerSettings.CityEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.City, model.City);
                    //if (_customerSettings.CountryEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CountryId, model.CountryId);
                    //if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);
                    //if (_customerSettings.PhoneEnabled)
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.Phone);
                    //if (_customerSettings.FaxEnabled)
                    //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Fax, model.Fax);

                    //newsletter
                    //if (_customerSettings.NewsletterEnabled)
                    //{
                    //    //save newsletter value
                    //    var newsletter = _newsLetterSubscriptionService.GetNewsLetterSubscriptionByEmailAndStoreId(model.Email, _storeContext.CurrentStore.Id);
                    //    if (newsletter != null)
                    //    {
                    //        if (model.Newsletter)
                    //        {
                    //            newsletter.Active = true;
                    //            _newsLetterSubscriptionService.UpdateNewsLetterSubscription(newsletter);
                    //        }
                    //        //else
                    //        //{
                    //        //When registering, not checking the newsletter check box should not take an existing email address off of the subscription list.
                    //        //_newsLetterSubscriptionService.DeleteNewsLetterSubscription(newsletter);
                    //        //}
                    //    }
                    //    else
                    //    {
                    //        if (model.Newsletter)
                    //        {
                    //            _newsLetterSubscriptionService.InsertNewsLetterSubscription(new NewsLetterSubscription
                    //            {
                    //                NewsLetterSubscriptionGuid = Guid.NewGuid(),
                    //                Email = model.Email,
                    //                Active = true,
                    //                StoreId = _storeContext.CurrentStore.Id,
                    //                CreatedOnUtc = DateTime.UtcNow
                    //            });
                    //        }
                    //    }
                    //}

                    //save customer attributes
                    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CustomCustomerAttributes, customerAttributesXml);

                    //login customer now
                    if (isApproved)
                        _authenticationService.SignIn(customer, true);

                    //associated with external account (if possible)
                    //TryAssociateAccountWithExternalAccount(customer);

                    //insert default address (if possible)
                    //var defaultAddress = new Address
                    //{
                    //    FirstName = customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                    //    LastName = customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName),
                    //    Email = customer.Email,
                    //    Company = customer.GetAttribute<string>(SystemCustomerAttributeNames.Company),
                    //    CountryId = customer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId) > 0 ?
                    //        (int?)customer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId) : null,
                    //    StateProvinceId = customer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId) > 0 ?
                    //        (int?)customer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId) : null,
                    //    City = customer.GetAttribute<string>(SystemCustomerAttributeNames.City),
                    //    Address1 = customer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress),
                    //    Address2 = customer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2),
                    //    ZipPostalCode = customer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode),
                    //    PhoneNumber = customer.GetAttribute<string>(SystemCustomerAttributeNames.Phone),
                    //    FaxNumber = customer.GetAttribute<string>(SystemCustomerAttributeNames.Fax),
                    //    CreatedOnUtc = customer.CreatedOnUtc
                    //};
                    //if (this._addressService.IsAddressValid(defaultAddress))
                    //{
                    //    //some validation
                    //    if (defaultAddress.CountryId == 0)
                    //        defaultAddress.CountryId = null;
                    //    if (defaultAddress.StateProvinceId == 0)
                    //        defaultAddress.StateProvinceId = null;
                    //    //set default address
                    //    customer.Addresses.Add(defaultAddress);
                    //    customer.BillingAddress = defaultAddress;
                    //    customer.ShippingAddress = defaultAddress;
                    //    _customerService.UpdateCustomer(customer);
                    //}

                    //notifications
                    if (_customerSettings.NotifyNewCustomerRegistration)
                        _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                    //raise event       
                    _eventPublisher.Publish(new CustomerRegisteredEvent(customer));

                    switch (_customerSettings.UserRegistrationType)
                    {
                        case UserRegistrationType.EmailValidation:
                            {
                                //email validation message
                                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
                                _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id);

                                //result
                                return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });
                            }
                        case UserRegistrationType.AdminApproval:
                            {
                                return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                            }
                        case UserRegistrationType.Standard:
                            {
                                //send customer welcome message
                                _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);

                                var redirectUrl = Url.RouteUrl("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                                if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                                    redirectUrl = _webHelper.ModifyQueryString(redirectUrl, "returnurl=" + HttpUtility.UrlEncode(returnUrl), null);
                                return Redirect(redirectUrl);
                            }
                        default:
                            {
                                return RedirectToRoute("HomePage");
                            }
                    }
                }

                //errors
                foreach (var error in registrationResult.Errors)
                    ModelState.AddModelError("", error);
            }

            //If we got this far, something failed, redisplay form
            PrepareCustomerRegisterModel(model, true, customerAttributesXml);
            return View(model);
        }

        public ActionResult OfferingDocsRegister()
        {
            var model = new RegisterModel();
            PrepareCustomerRegisterModel(model, false);
            var themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;
            return PartialView("~/Themes/" + themeName + "/Views/Home/OfferingDocsRegister.cshtml", model);
        }
        //[HttpPost]
        //[CaptchaValidator]
        //public ActionResult OfferingDocsRegister2(OfferingDocsRegisterModel model)
        //{
        //    string Errors = string.Empty;
        //    var customer = _workContext.CurrentCustomer;

        //    ////custom customer attributes
        //    //var customerAttributesXml = ParseCustomCustomerAttributes(form);
        //    //var customerAttributeWarnings = _customerAttributeParser.GetAttributeWarnings(customerAttributesXml);
        //    //foreach (var error in customerAttributeWarnings)
        //    //{
        //    //    ModelState.AddModelError("", error);
        //    //}

        //    ////validate CAPTCHA
        //    //if (_captchaSettings.Enabled && !captchaValid)
        //    //{
        //    //    ModelState.AddModelError("", _localizationService.GetResource("Common.WrongCaptcha"));
        //    //}            
        //    if (ModelState.IsValid)
        //    {
        //        model.Password = "admin#1";
        //        if (_customerSettings.UsernamesEnabled && model.Username != null)
        //        {
        //            model.Username = model.Email.Trim();
        //        }

        //        bool isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
        //        var registrationRequest = new CustomerRegistrationRequest(customer,
        //                 model.Email,
        //                 _customerSettings.UsernamesEnabled ? model.Username : model.Email,
        //                 model.Password,
        //                 _customerSettings.DefaultPasswordFormat,
        //                 _storeContext.CurrentStore.Id,
        //                 isApproved);
        //        //--------------------------------
        //        var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
        //        if (registrationResult.Success)
        //        {

        //            //form fields
        //            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, model.FirstName);
        //            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, model.LastName);
        //            //if (_customerSettings.CompanyEnabled)
        //            //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Company, model.Company);                    
        //            //_genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.ZipPostalCode, model.ZipPostalCode);
        //            //if (_customerSettings.CityEnabled)
        //            //    _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.City, model.City);
        //            if (_customerSettings.CountryEnabled)
        //                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CountryId, model.CountryId);
        //            if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
        //                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);
        //            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.Phone);

        //            //save customer attributes
        //            //_genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CustomCustomerAttributes, customerAttributesXml);

        //            //notifications
        //            if (_customerSettings.NotifyNewCustomerRegistration)
        //                _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

        //            switch (_customerSettings.UserRegistrationType)
        //            {
        //                case UserRegistrationType.EmailValidation:
        //                    {
        //                        //email validation message
        //                        _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.AccountActivationToken, Guid.NewGuid().ToString());
        //                        // here last parameter is "true" for to show demosite link in activation page.
        //                        _workflowMessageServiceCustom.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id, true);
        //                        break;
        //                        //result
        //                        //return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });                                                            
        //                    }
        //                case UserRegistrationType.Standard:
        //                    {
        //                        //send customer welcome message
        //                        _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);
        //                        break;
        //                    }
        //                default:
        //                    {
        //                        break;
        //                    }
        //            }
        //            string result = EngineContext.Current.Resolve<ILocalizationService>().GetResource("OfferingDocsRegister.ThankYou");
        //            return Json(new
        //            {
        //                Success = true,
        //                Result = result,
        //            });
        //        }
        //        else
        //        {
        //            foreach (var error in registrationResult.Errors)
        //            {
        //                Errors += error + "\r\n";
        //                ModelState.AddModelError("", error);
        //            }
        //        }
        //    }
        //    //If we got this far, something failed, redisplay form
        //    var themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;
        //    PrepareCustomerRegisterModel(model);
        //    return Json(new
        //          {
        //              Success = false,
        //              Result = Errors,
        //              html = RenderPartialViewToString("~/Themes/" + themeName + "/Views/Home/OfferingDocsRegister.cshtml", model)
        //          });
        //}

        [HttpPost]
        public ActionResult OfferingDocsRegister(OfferingDocsRegisterModel model)
        {
            string Errors = string.Empty;
            //string themeName = string.Empty;
            if (ModelState.IsValid)
            {
                if (!String.IsNullOrWhiteSpace(model.Email))
                {
                    var cust2 = _customerService.GetCustomerByEmail(model.Email);
                    if (cust2 != null)
                    {
                        ModelState.AddModelError("", "Email is already registered");
                        Errors += "Email is already registered" + "\r\n";
                        //themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;
                        //PrepareCustomerRegisterModel(model);
                        return Json(new
                        {
                            Success = false,
                            Result = Errors                            
                        });
                    }
                }
                var customer = new Customer
                {
                    CustomerGuid = Guid.NewGuid(),
                    Email = model.Email,
                    Username = model.Email,
                    Active = true,
                    CreatedOnUtc = DateTime.UtcNow,
                    LastActivityDateUtc = DateTime.UtcNow,
                };
                CustomerRole role = new CustomerRole();

                customer.CustomerRoles.Add(_customerService.GetAllCustomerRoles(true).FirstOrDefault(cr => cr.Name == SystemCustomerRoleNames.Registered));
                _customerService.InsertCustomer(customer);

                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.FirstName, model.FirstName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.LastName, model.LastName);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CountryId, model.CountryId);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.StateProvinceId, model.StateProvinceId);
                _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.Phone, model.Phone);

                //password
                model.Password = "admin#1";
                var changePassRequest = new ChangePasswordRequest(model.Email, false, _customerSettings.DefaultPasswordFormat, model.Password);
                var changePassResult = _customerRegistrationService.ChangePassword(changePassRequest);

                string result = EngineContext.Current.Resolve<ILocalizationService>().GetResource("OfferingDocsRegister.ThankYou");
                return Json(new
                {
                    Success = true,
                    Result = result,
                });
            }
            //themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;
            //PrepareCustomerRegisterModel(model);
            return Json(new
            {
                Success = false,
                Result = Errors                
            });
        }
        #endregion

        //public ActionResult Login(LoginModel model, string returnUrl, bool captchaValid)
        //{
        //    //validate CAPTCHA
        //    if (_captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage && !captchaValid)
        //    {
        //        ModelState.AddModelError("", _localizationService.GetResource("Common.WrongCaptcha"));
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        if (_customerSettings.UsernamesEnabled && model.Username != null)
        //        {
        //            model.Username = model.Username.Trim();
        //        }
        //        var loginResult = _customerRegistrationService.ValidateCustomer(_customerSettings.UsernamesEnabled ? model.Username : model.Email, model.Password);
        //        switch (loginResult)
        //        {
        //            case CustomerLoginResults.Successful:
        //                {
        //                    var customer = _customerSettings.UsernamesEnabled ? _customerService.GetCustomerByUsername(model.Username) : _customerService.GetCustomerByEmail(model.Email);

        //                    //migrate shopping cart
        //                    _shoppingCartService.MigrateShoppingCart(_workContext.CurrentCustomer, customer, true);

        //                    //sign in new customer
        //                    _authenticationService.SignIn(customer, model.RememberMe);

        //                    //raise event       
        //                    _eventPublisher.Publish(new CustomerLoggedinEvent(customer));

        //                    //activity log
        //                    _customerActivityService.InsertActivity("PublicStore.Login", _localizationService.GetResource("ActivityLog.PublicStore.Login"), customer);

        //                    if (String.IsNullOrEmpty(returnUrl) || !Url.IsLocalUrl(returnUrl))
        //                        return Redirect("/Admin");

        //                    return Redirect(returnUrl);
        //                }
        //            case CustomerLoginResults.CustomerNotExist:
        //                ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.CustomerNotExist"));
        //                break;
        //            case CustomerLoginResults.Deleted:
        //                ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.Deleted"));
        //                break;
        //            case CustomerLoginResults.NotActive:
        //                ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotActive"));
        //                break;
        //            case CustomerLoginResults.NotRegistered:
        //                ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotRegistered"));
        //                break;
        //            case CustomerLoginResults.WrongPassword:
        //            default:
        //                ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials"));
        //                break;
        //        }
        //    }

        //    //If we got this far, something failed, redisplay form
        //    model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
        //    model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage;
        //    if (!String.IsNullOrEmpty(returnUrl))
        //        return Redirect(returnUrl);
        //    return Redirect("/login");
        //}
    }
}