﻿//upgrade_2.80_3.1
//MessagingToolkit.Barcode
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

//using MessagingToolkit.Barcode;
//using MessagingToolkit.Barcode.QRCode.Decoder;
using System.Web.Mvc;
using System.Drawing.Imaging;

namespace Shopfast.Plugin.Custom.Helper
{
    public static class NopBarCodeImage
    {
        public static string GenerateBarCode(string Number, string BarcodeSymbology)
        {
            string MakeImage = null;
            BarcodeCatgeories bc = new BarcodeCatgeories();
            //if (!string.IsNullOrEmpty(Number))
            //{
            //    KeepAutomation.Barcode.Bean.BarCode bar = new KeepAutomation.Barcode.Bean.BarCode();
            //    bar.Symbology = KeepAutomation.Barcode.Symbology.Code39;
            //    int barcodesymbologyint = Convert.ToInt32(BarcodeSymbology);
            //    if (barcodesymbologyint == 1)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code39;
            //    }
            //    if (barcodesymbologyint == 2)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code128A;
            //    }
            //    if (barcodesymbologyint == 3)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code128B;
            //    }
            //    if (barcodesymbologyint == 4)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Codabar;
            //    }
            //    if (barcodesymbologyint == 5)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code11;
            //    }
            //    if (barcodesymbologyint == 6)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code128Auto;
            //    }
            //    if (barcodesymbologyint == 7)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code128C;
            //    }
            //    if (barcodesymbologyint == 8)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code2of5;
            //    }
            //    if (barcodesymbologyint == 9)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code39ex;
            //    }
            //    if (barcodesymbologyint == 10)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Code93;
            //    }
            //    if (barcodesymbologyint == 11)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.DataMatrix;
            //    }
            //    if (barcodesymbologyint == 12)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN128;
            //    }
            //    if (barcodesymbologyint == 13)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN13;
            //    }
            //    if (barcodesymbologyint == 14)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN13Sup2;
            //    }
            //    if (barcodesymbologyint == 15)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN13Sup5;
            //    }
            //    if (barcodesymbologyint == 16)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN8;
            //    }
            //    if (barcodesymbologyint == 17)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN8Sup2;
            //    }
            //    if (barcodesymbologyint == 18)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.EAN8Sup5;
            //    }
            //    if (barcodesymbologyint == 19)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Identcode;
            //    }
            //    if (barcodesymbologyint == 20)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.IntelligentMail;
            //    }
            //    if (barcodesymbologyint == 21)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Interleaved2of5;
            //    }
            //    if (barcodesymbologyint == 22)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISBN;
            //    }
            //    if (barcodesymbologyint == 23)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISBNSup2;
            //    }
            //    if (barcodesymbologyint == 24)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISBNSup5;
            //    }
            //    if (barcodesymbologyint == 25)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISSN;
            //    }
            //    if (barcodesymbologyint == 26)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISSNSup2;
            //    }
            //    if (barcodesymbologyint == 27)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ISSNSup5;
            //    }
            //    if (barcodesymbologyint == 28)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.ITF14;
            //    }
            //    if (barcodesymbologyint == 29)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Leitcode;
            //    }
            //    if (barcodesymbologyint == 30)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.MSI;
            //    }
            //    if (barcodesymbologyint == 31)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.MSI10;
            //    }
            //    if (barcodesymbologyint == 32)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.MSI1010;
            //    }
            //    if (barcodesymbologyint == 33)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.MSI11;
            //    }
            //    if (barcodesymbologyint == 34)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.MSI1110;
            //    }
            //    if (barcodesymbologyint == 35)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.PDF417;
            //    }
            //    if (barcodesymbologyint == 36)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Planet;
            //    }
            //    if (barcodesymbologyint == 37)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.Postnet;
            //    }
            //    if (barcodesymbologyint == 38)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.QRCode;
            //    }
            //    if (barcodesymbologyint == 39)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.RM4SCC;
            //    }
            //    if (barcodesymbologyint == 40)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCA;
            //    }
            //    if (barcodesymbologyint == 41)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCASup2;
            //    }
            //    if (barcodesymbologyint == 42)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCASup5;
            //    }
            //    if (barcodesymbologyint == 43)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCE;
            //    }
            //    if (barcodesymbologyint == 44)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCESup2;
            //    }
            //    if (barcodesymbologyint == 45)
            //    {
            //        bar.Symbology = KeepAutomation.Barcode.Symbology.UPCESup5;
            //    }
            //    bar.X = 2;
            //    bar.CodeToEncode = Number;                
            //    MakeImage = System.Web.HttpContext.Current.Server.MapPath("~/Content/BarCode/" + Number.ToString() + ".jpg");                                
            //    bar.generateBarcodeToImageFile(MakeImage);
            //}

            //BarcodeEncoder barcodeEncoder = new BarcodeEncoder();

            ////set default barcode format
            //BarcodeFormat fmt = BarcodeFormat.QRCode;
            //var selectedBarcode = Enum.GetName(typeof(BarcodeFormat), Convert.ToInt32(BarcodeSymbology));
            //if (bc.allowBarcodes.Any(b => b.ToString() == selectedBarcode))
            //{
            //    foreach (BarcodeFormat value in Enum.GetValues(typeof(BarcodeFormat)))
            //    {
            //        if (Convert.ToInt32(BarcodeSymbology) == Convert.ToInt32(value))
            //        {
            //            fmt = value;
            //        }
            //    }
            //}

            //if (!string.IsNullOrEmpty(Number))
            //{
            //    bool IsGenerateBarcode = true;
            //    if (fmt == BarcodeFormat.UPCA)
            //    {
            //        if (Number.Trim().Length < 11 || Number.Trim().Length > 12)
            //        {
            //            IsGenerateBarcode = false;
            //        }
            //    }
            //    if (IsGenerateBarcode)
            //    {
            //        barcodeEncoder.Encode(fmt, Number);
            //        MakeImage = System.Web.HttpContext.Current.Server.MapPath("~/Content/BarCode/" + Number.ToString() + ".png");
            //        CreateDirectory("/Content/Barcode");
            //        barcodeEncoder.SaveImage(MakeImage, SaveOptions.Png);
            //        //image.Save(MakeImage, ImageFormat.Png);
            //        MakeImage = "/Content/BarCode/" + Number.ToString() + ".png";
            //    }
            //    return MakeImage;
            //}
            return MakeImage;
        }

        #region Create Directory
        private static void CreateDirectory(string path)
        {
            if (!Directory.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath(path));
            }
        }
        #endregion

        public static IList<SelectListItem> BarcodeCategories()
        {
            IList<SelectListItem> Barcodecate = new List<SelectListItem>();
            //BarcodeCatgeories bc = new BarcodeCatgeories();
            //List<string> lstBarcodeFormat = new List<string>();

            //// these are not supported and give Error
            ////List<string> lstIgnoreBarcodeFormat = new List<string>();
            ////lstIgnoreBarcodeFormat.Add("EAN13");
            ////lstIgnoreBarcodeFormat.Add("EAN8");
            ////lstIgnoreBarcodeFormat.Add("JAN13");
            ////lstBarcodeFormat = Enum.GetNames(typeof(BarcodeFormat)).Except(lstIgnoreBarcodeFormat).ToList();
            ////List<string> allowBarcodes = new List<string>();            
            //lstBarcodeFormat = Enum.GetNames(typeof(BarcodeFormat)).Where(b => bc.allowBarcodes.Contains(b.ToString())).ToList();
            //// int cntValue = 0;
            //BarcodeFormat barcodeValue;
            //foreach (var item in lstBarcodeFormat)
            //{
            //    if (item != BarcodeFormat.Unknown.ToString())
            //    {
            //        //cntValue++;
            //        int value = GetValueOf(item, out barcodeValue);
            //        Barcodecate.Add(new SelectListItem() { Text = Convert.ToString(item), Value = Convert.ToString(value) });
            //    }
            //}


            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code93.ToString(), Value = "1" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code128A.ToString(), Value = "2" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code128B.ToString(), Value = "3" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Codabar.ToString(), Value = "4" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code11.ToString(), Value = "5" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code128A.ToString(), Value = "6" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code128C.ToString(), Value = "7" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code2of5.ToString(), Value = "8" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code39Extended.ToString(), Value = "9" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Code93.ToString(), Value = "10" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.DataMatrix.ToString(), Value = "11" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN128.ToString(), Value = "12" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN13.ToString(), Value = "13" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN13Sup2.ToString(), Value = "14" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN13Sup5.ToString(), Value = "15" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN8.ToString(), Value = "16" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN8Sup2.ToString(), Value = "17" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.EAN8Sup5.ToString(), Value = "18" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.FIM.ToString(), Value = "18" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Identcode.ToString(), Value = "19" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.IntelligentMail.ToString(), Value = "20" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Interleaved2of5.ToString(), Value = "21" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISBN.ToString(), Value = "22" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISBNSup2.ToString(), Value = "23" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISBNSup5.ToString(), Value = "24" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISSN.ToString(), Value = "25" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISSNSup2.ToString(), Value = "26" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ISSNSup5.ToString(), Value = "27" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ITF14.ToString(), Value = "28" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.LOGMARS.ToString(), Value = "29" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.MSI.ToString(), Value = "30" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.MSI2Mod10.ToString(), Value = "31" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.MSIMod10.ToString(), Value = "32" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.MSIMod11.ToString(), Value = "33" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.MSIMod11Mod10.ToString(), Value = "34" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.ModifiedPlessey.ToString(), Value = "34" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.PDF417.ToString(), Value = "35" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Planet.ToString(), Value = "36" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.Postnet.ToString(), Value = "37" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.QRCode.ToString(), Value = "38" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.RM4SCC.ToString(), Value = "39" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCA.ToString(), Value = "40" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCASup2.ToString(), Value = "41" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCASup5.ToString(), Value = "42" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCE.ToString(), Value = "43" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCESup2.ToString(), Value = "44" });
            //Barcodecate.Add(new SelectListItem() { Text = BarcodeFormat.UPCESup5.ToString(), Value = "45" });
            return Barcodecate;
        }

        //public static int GetValueOf(string enumConst, out BarcodeFormat barcodeValue)
        //{
        //    if (Enum.TryParse(enumConst, out barcodeValue))
        //    {
        //        return Convert.ToInt32(barcodeValue);
        //    }
        //    return 0;
        //}
    }

    public class BarcodeCatgeories
    {
        public BarcodeCatgeories()
        {
            allowBarcodes = new List<string>();
            allowBarcodes.Add("QRCode");
            allowBarcodes.Add("UPCA");
        }
        public List<string> allowBarcodes { get; set; }
    }
}
//----------------------------------------
