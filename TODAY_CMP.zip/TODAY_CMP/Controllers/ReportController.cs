﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Data;
using System.Web.Hosting;
using System.Data.SqlClient;
using System.Web.Configuration;
using Nop.Core.Infrastructure;
using Nop.Services.Authentication;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using System.Threading.Tasks;
using Misc.Plugin.MerchantBoarding.Models;
using Microsoft.Crm.Sdk.Samples.HelperCode;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using Nop.Core;
using Nop.Web.Framework.Kendoui;

namespace Shopfast.Plugin.MerchantManagement.Controllers
{
    public class ReportController : BasePluginController
    {
        #region Fields        
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly ICustomerService _customerService;
        private readonly IWorkContext _workContext;

        #endregion

        public ReportController(IPermissionService permissionService,
            ILocalizationService localizationService,
            ICustomerService customerService,
            IWorkContext workContext)
        {
            _permissionService = permissionService;
            _localizationService = localizationService;
            _customerService = customerService;
            _workContext = workContext;
        }

        #region CRM Methods
        private Version webAPIVersion = new Version(9, 0);
        private string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        public async Task<ReportModel> ResidualReportCRMGet(ReportModel model)
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            var httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            var customer = _workContext.CurrentCustomer;

            // Get merchant details from customer email                
            //string queryOptions = "";
            string StartDate = null;
            string EndDate = null;
            var url = "new_residualmerchants?fetchXml=%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Call-attributes/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E";
            if (!string.IsNullOrEmpty(model.SelectedYear))
            {
                if (!string.IsNullOrEmpty(model.SelectedMonth))
                {
                    StartDate = new DateTime(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth), 01).ToString("yyyy-MM-dd");
                    EndDate = new DateTime(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth),
                        DateTime.DaysInMonth(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth))).ToString("yyyy-MM-dd");
                    //queryOptions = "?$filter=new_reportdate%20ge%20" + StartDate + "%20and%20new_reportdate%20le%20" + EndDate;                    
                    url = "new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%22" + StartDate + "%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%22" + EndDate + "%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E";
                }
            }

            // new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%222019-03-01%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%222019-03-31%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            // working with fiter without merchant and partner entity lookup
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?$filter=new_reportdate%20ge%202019-03-01%20and%20new_reportdate%20le%202019-03-31

            // working without filter with merchant and partner entity lookup
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?fetchXml=%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Call-attributes/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            // working with filter
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%222019-03-01%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%222019-03-31%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            //= "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
            HttpResponseMessage merchantResponse = await httpClient.GetAsync(
           getVersionedWebAPIPath() + url);
            JObject retrievedData = new JObject();
            if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
            {
                retrievedData = JsonConvert.DeserializeObject<JObject>(
                    await merchantResponse.Content.ReadAsStringAsync());
            }
            else
            {
                throw new CrmHttpResponseException(merchantResponse.Content);
            }
            if (retrievedData != null)
            {
                var jvalue = retrievedData.GetValue("value");
                if (jvalue != null && jvalue.Count() > 0)
                {
                    model.ResidualDataList = JsonConvert.DeserializeObject<List<ResidualDataModel>>(jvalue.ToString());

                    if (!string.IsNullOrEmpty(model.SelectedAgent) && model.ResidualDataList.Any())
                    {
                        model.ResidualDataList = model.ResidualDataList.Where(a => a.Agent_Email == model.SelectedAgent).ToList();
                    }
                }
            }

            return model;
        }

        public async Task<ReportModel> ResidualTotalPayoutsReportCRMGet(ReportModel model)
        {
            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            var httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            var customer = _workContext.CurrentCustomer;

            // Get merchant details from customer email                
            //string queryOptions = "";
            string StartDate = null;
            string EndDate = null;
            var url = "new_residualmerchants?fetchXml=%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Call-attributes/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E";
            if (!string.IsNullOrEmpty(model.SelectedYear))
            {
                if (!string.IsNullOrEmpty(model.SelectedMonth))
                {
                    StartDate = new DateTime(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth), 01).ToString("yyyy-MM-dd");
                    EndDate = new DateTime(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth),
                        DateTime.DaysInMonth(Convert.ToInt32(model.SelectedYear), Convert.ToInt32(model.SelectedMonth))).ToString("yyyy-MM-dd");
                    //queryOptions = "?$filter=new_reportdate%20ge%20" + StartDate + "%20and%20new_reportdate%20le%20" + EndDate;                    
                    url = "new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%22" + StartDate + "%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%22" + EndDate + "%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E";
                }
            }

            // new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%222019-03-01%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%222019-03-31%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            // working with fiter without merchant and partner entity lookup
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?$filter=new_reportdate%20ge%202019-03-01%20and%20new_reportdate%20le%202019-03-31

            // working without filter with merchant and partner entity lookup
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?fetchXml=%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Call-attributes/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20visible=%22false%22%20link-type=%22outer%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            // working with filter
            // https://crm365.securepay.com:444/api/data/v9.0/new_residualmerchants?fetchXml=%20%3Cfetch%20version=%221.0%22%20output-format=%22xml-platform%22%20mapping=%22logical%22%20distinct=%22false%22%3E%20%3Centity%20name=%22new_residualmerchant%22%3E%20%3Cattribute%20name=%22new_residualmerchantid%22%20/%3E%20%3Cattribute%20name=%22new_feename%22%20/%3E%20%3Cattribute%20name=%22new_peritemrate%22%20/%3E%20%3Cattribute%20name=%22new_volume%22%20/%3E%20%3Cattribute%20name=%22new_count%22%20/%3E%20%3Cattribute%20name=%22new_income%22%20/%3E%20%3Cattribute%20name=%22new_expense%22%20/%3E%20%3Cattribute%20name=%22new_reportdate%22%20/%3E%20%3Cattribute%20name=%22createdon%22%20/%3E%20%3Corder%20attribute=%22new_feename%22%20descending=%22false%22%20/%3E%20%3Cfilter%20type=%22and%22%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-after%22%20value=%222019-03-01%22%20/%3E%20%3Ccondition%20attribute=%22new_reportdate%22%20operator=%22on-or-before%22%20value=%222019-03-31%22%20/%3E%20%3C/filter%3E%20%3Clink-entity%20name=%22new_merchantboarding%22%20from=%22new_merchantboardingid%22%20to=%22new_merchantboarding%22%20link-type=%22inner%22%20alias=%22merchantboarding%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_mid%22%20/%3E20%3Cattribute%20name=%22new_businessemailaddress%22%20/%3E%20%3C/link-entity%3E%20%3Clink-entity%20name=%22new_merchantpartner%22%20from=%22new_merchantpartnerid%22%20to=%22new_merchantpartner%22%20link-type=%22inner%22%20alias=%22merchantpartner%22%3E%20%3Cattribute%20name=%22new_name%22%20/%3E%20%3Cattribute%20name=%22new_agentid%22/%3E%20%3Cattribute%20name=%22new_emailaddress%22/%3E%20%3C/link-entity%3E%20%3C/entity%3E%20%3C/fetch%3E

            //= "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
            HttpResponseMessage merchantResponse = await httpClient.GetAsync(
           getVersionedWebAPIPath() + url);
            JObject retrievedData = new JObject();
            if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
            {
                retrievedData = JsonConvert.DeserializeObject<JObject>(
                    await merchantResponse.Content.ReadAsStringAsync());
            }
            else
            {
                throw new CrmHttpResponseException(merchantResponse.Content);
            }
            if (retrievedData != null)
            {
                var jvalue = retrievedData.GetValue("value");
                if (jvalue != null && jvalue.Count() > 0)
                {
                    model.ResidualDataList = JsonConvert.DeserializeObject<List<ResidualDataModel>>(jvalue.ToString());

                    if (!string.IsNullOrEmpty(model.SelectedAgent) && model.ResidualDataList.Any())
                    {
                        model.ResidualDataList = model.ResidualDataList.Where(a => a.Agent_Email == model.SelectedAgent).ToList();
                    }
                }
            }

            return model;
        }
        #endregion

        #region Action Methods - Residual Report
        public ActionResult Index()
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            var model = new ReportModel();
            int initialYear = Convert.ToInt32(2019);
            for (int i = initialYear; i <= DateTime.UtcNow.Year; i++)
            {
                model.YearsList.Add(new SelectListItem() { Value = i.ToString(), Text = i.ToString() });
            }
            model.SelectedMonth = Convert.ToString(Convert.ToInt32(DateTime.UtcNow.ToString("MM")) - 1);

            if (_workContext.CurrentCustomer.CustomerRoles.Any(cr => cr.SystemName == "Partner"))
                model.SelectedAgent = _workContext.CurrentCustomer.Email;

            return View("~/Plugins/Misc.Plugin.MerchantBoarding/Views/Report/List.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult ReportList(DataSourceRequest command, ReportModel model)
        {
            if (_workContext.CurrentCustomer.CustomerRoles.Any(cr => cr.SystemName == "Partner"))
                model.SelectedAgent = _workContext.CurrentCustomer.Email;

            Task.WaitAll(Task.Run(async () => { model = await ResidualReportCRMGet(model); }));

            var agents = model.ResidualDataList
    .GroupBy(ac => new
    {
        ac.ISO_AgentId, // required by your view model. should be omited
                        // in most cases because group by primary key
                        // makes no sense.
        ac.ISO_AgentName,
        ac.Agent_Email
    })
    .Select(ac => new ResidualDataModel
    {
        ISO_AgentId = ac.Key.ISO_AgentId,
        ISO_AgentName = ac.Key.ISO_AgentName,
        Agent_Email = ac.Key.Agent_Email,
        MerchantCount = ac.Count(),
        new_peritemrate = ac.Sum(acs => acs.new_peritemrate),
        new_volume = ac.Sum(acs => acs.new_volume),
        new_count = ac.Sum(acs => acs.new_count),
        new_income = ac.Sum(acs => acs.new_income),
        new_expense = ac.Sum(acs => acs.new_expense)
    });

            var gridModel = new DataSourceResult
            {
                Data = agents,
                Total = agents.Count()
            };
            TempData["agents"] = agents;            
            return Json(gridModel);
        }

        public ActionResult AgentDetail(string year, string month, string agent)
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            var model = new ReportModel();

            var agentlist = TempData["agents"] as IEnumerable<ResidualDataModel>;
            TempData.Keep("agents");
            if (agentlist != null && agentlist.Any())
            {
                model.ResidualData = agentlist.FirstOrDefault(a => a.Agent_Email == agent);
            }            

            model.SelectedYear = year;
            model.SelectedMonth = month;
            model.SelectedAgent = agent;

            return View("~/Plugins/Misc.Plugin.MerchantBoarding/Views/Report/AgentDetail.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult MerchantList(DataSourceRequest command, ReportModel model)
        {
            Task.WaitAll(Task.Run(async () => { model = await ResidualReportCRMGet(model); }));

            var gridModel = new DataSourceResult
            {
                Data = model.ResidualDataList,
                Total = model.ResidualDataList.Count()
            };
            return Json(gridModel);
        }
        
        #endregion

        #region Action Methods - Total Payouts Report
        public ActionResult Payouts()
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            var model = new ReportModel();
            int initialYear = Convert.ToInt32(2019);
            for (int i = initialYear; i <= DateTime.UtcNow.Year; i++)
            {
                model.YearsList.Add(new SelectListItem() { Value = i.ToString(), Text = i.ToString() });
            }
            model.SelectedMonth = Convert.ToString(Convert.ToInt32(DateTime.UtcNow.ToString("MM")) - 1);

            if (_workContext.CurrentCustomer.CustomerRoles.Any(cr => cr.SystemName == "Partner"))
                model.SelectedAgent = _workContext.CurrentCustomer.Email;

            return View("~/Plugins/Misc.Plugin.MerchantBoarding/Views/Report/ListPayouts.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult PayoutList(DataSourceRequest command, ReportModel model)
        {
            if (_workContext.CurrentCustomer.CustomerRoles.Any(cr => cr.SystemName == "Partner"))
                model.SelectedAgent = _workContext.CurrentCustomer.Email;

            Task.WaitAll(Task.Run(async () => { model = await ResidualReportCRMGet(model); }));

            var agents = model.ResidualDataList
    .GroupBy(ac => new
    {
        ac.ISO_AgentId, // required by your view model. should be omited
                        // in most cases because group by primary key
                        // makes no sense.
        ac.ISO_AgentName,
        ac.Agent_Email
    })
    .Select(ac => new ResidualDataModel
    {
        ISO_AgentId = ac.Key.ISO_AgentId,
        ISO_AgentName = ac.Key.ISO_AgentName,
        Agent_Email = ac.Key.Agent_Email,
        MerchantCount = ac.Sum(acs => acs.new_merchantcount),
        new_volume = ac.Sum(acs => acs.new_volume),
        new_count = ac.Sum(acs => acs.new_count),
        new_income = ac.Sum(acs => acs.new_income),
        new_expense = ac.Sum(acs => acs.new_expense),
        new_nettotal = ac.Sum(acs => acs.new_nettotal),
        new_payout = ac.Sum(acs => acs.new_payout)
    });

            var gridModel = new DataSourceResult
            {
                Data = agents,
                Total = agents.Count()
            };
            TempData["agentspayouts"] = agents;
            return Json(gridModel);
        }

        public ActionResult AgentPayoutDetail(string year, string month, string agent)
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            var model = new ReportModel();

            var agentlist = TempData["agentspayouts"] as IEnumerable<ResidualDataModel>;
            TempData.Keep("agentspayouts");
            if (agentlist != null && agentlist.Any())
            {
                model.ResidualData = agentlist.FirstOrDefault(a => a.Agent_Email == agent);
            }

            model.SelectedYear = year;
            model.SelectedMonth = month;
            model.SelectedAgent = agent;

            return View("~/Plugins/Misc.Plugin.MerchantBoarding/Views/Report/AgentPayoutDetail.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult PayoutMerchantList(DataSourceRequest command, ReportModel model)
        {
            Task.WaitAll(Task.Run(async () => { model = await ResidualTotalPayoutsReportCRMGet(model); }));

            var gridModel = new DataSourceResult
            {
                Data = model.ResidualDataList,
                Total = model.ResidualDataList.Count()
            };
            return Json(gridModel);
        }
        #endregion

        #region Methods

        protected ActionResult AccessDeniedView()
        {
            return RedirectToAction("Login", "Customer", new { Area = "", ReturnUrl = this.Request.RawUrl });
        }

        bool IsAdminUser()
        {
#if (DEBUG)
            return true;
#else
            var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
            var customer = _authenticationService.GetAuthenticatedCustomer();
            return (customer != null && customer.IsAdmin());
#endif
        }

        #endregion


    }
}