﻿using MVCSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSample.Controllers
{
    public class CRMFormsController : Controller
    {
        // GET: CRMForms
        public ActionResult Index(int group = 1, int steps = 4) // dont include confirm step (last step)
        {
            CRMModel model = new CRMModel();
            model.ControlFieldList = model.ControlFieldList.Where(c => c.Group == group).ToList();
            model.CurrentGroup = group;
            model.Steps = steps;
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(CRMModel model)
        {
            return View(model);
        }
    }
}