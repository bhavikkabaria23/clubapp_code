1. 'Nop.Plugin.Payments.Payu' directory contains source code.
2. 'Payments.Payu' contains binaries. Just drop it into \Plugins directory on your server.