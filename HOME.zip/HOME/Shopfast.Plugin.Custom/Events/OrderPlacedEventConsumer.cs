﻿using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class OrderPlacedEventConsumer : IConsumer<OrderPlacedEvent>
    {
        public void HandleEvent(OrderPlacedEvent eventMessage)
        {
            if (eventMessage.Order.OrderGuid != null)
            {
                //HttpContext.Current.Session["CurrentOrderId"] = eventMessage.Order.Id;
                var dbContext = EngineContext.Current.Resolve<IDbContext>();
                // if OrderFlag = 1 or 2 , it is for "online" and if OrderFlag = 3 , it is for "instore"

                #region OrderFlag - Order receipt chart
                dbContext.ExecuteSqlCommand("UPDATE [Order] SET OrderFlag=@p0  WHERE OrderGuid=@p1", false, null,
                   1, eventMessage.Order.OrderGuid);
                #endregion           
            }
        }
    }
}