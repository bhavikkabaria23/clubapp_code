﻿using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain;
using Nop.Core.Domain.Configuration;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Media;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Authentication;
using Nop.Services.Configuration;
using Nop.Services.Media;
using Nop.Web.Controllers;
using Nop.Web.Framework.Themes;
using Nop.Web.Infrastructure.Cache;
using Shopfast.Plugin.Custom.Models.NopWeb.CustomWeb;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Xml;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class CustomWebController : BasePublicController
    {
        private const string SETTINGS_PATTERN_KEY = "Nop.setting.";
        // GET: CustomWeb
        public ActionResult CustomPolls()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SaveThemeSettings(ThemeSettings model)
        {
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            if (!string.IsNullOrEmpty(model.PresetColor))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".preset") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".preset").Value = model.PresetColor;
                }
            }

            if (!string.IsNullOrEmpty(model.HeaderLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".headerlayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".headerlayout").Value = model.HeaderLayout;
                }
            }

            if (!string.IsNullOrEmpty(model.MegaMenu))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".megamenuwithpictureslayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".megamenuwithpictureslayout").Value = model.MegaMenu;
                }
            }

            if (!string.IsNullOrEmpty(model.CategoriesHoverEffect))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".categorieshovereffect") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".categorieshovereffect").Value = model.CategoriesHoverEffect;
                }
            }

            if (!string.IsNullOrEmpty(model.ProductsPerRow))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".catalogpagesitemboxesperrow") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".catalogpagesitemboxesperrow").Value = model.ProductsPerRow;
                }
            }

            if (!string.IsNullOrEmpty(model.ProductPageLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".productpagelayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".productpagelayout").Value = model.ProductPageLayout;
                }
            }

            if (!string.IsNullOrEmpty(model.FooterLayout))
            {
                if (dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".footerlayout") != null)
                {
                    dbContext.Set<Setting>().Single(s => s.Name == model.ThemeName + ".footerlayout").Value = model.FooterLayout;
                }
            }
            dbContext.SaveChanges();
            //EngineContext.Current.Resolve<ICacheManager>().RemoveByPattern(SETTINGS_PATTERN_KEY);
            EngineContext.Current.Resolve<ISettingService>().ClearCache();
            return Json(new { success = true });
        }

        [HttpPost]
        public ActionResult GetThemeSettings(string ThemeName)
        {
            ThemeSettings model = new ThemeSettings();
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".preset") != null)
            {
                model.PresetColor = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".preset").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".headerlayout") != null)
            {
                model.HeaderLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".headerlayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".megamenuwithpictureslayout") != null)
            {
                model.MegaMenu = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".megamenuwithpictureslayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".categorieshovereffect") != null)
            {
                model.CategoriesHoverEffect = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".categorieshovereffect").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".catalogpagesitemboxesperrow") != null)
            {
                model.ProductsPerRow = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".catalogpagesitemboxesperrow").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".productpagelayout") != null)
            {
                model.ProductPageLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".productpagelayout").Value;
            }
            if (dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".footerlayout") != null)
            {
                model.FooterLayout = dbContext.Set<Setting>().Single(s => s.Name == ThemeName + ".footerlayout").Value;
            }

            return Json(new { model });
        }

        public ActionResult testAPI()
        {
            string responseData = "";
            Random r = new Random();
            int n = r.Next();
            string url = "http://192.168.0.40:8483/cgi.html?TerminalTransaction=<request><PaymentType>Credit</PaymentType><TransType>Sale</TransType><Amount>1.00</Amount><InvNum>687</InvNum><RefId>" + n.ToString() + "</RefId><AuthKey>234123-74653252-663525223</AuthKey><RegisterId>3</RegisterId></request>";
            url = "http://shopfast.com/HtmlPage1.html";

            //WebRequest request = WebRequest.Create(url); //Type url here
            //using (WebResponse response = request.GetResponse())
            //{
            //    using (StreamReader responseReader = new StreamReader(response.GetResponseStream()))
            //    {
            //        responseData = responseReader.ReadToEnd();

            //    }
            //}

            //HttpClient client = new HttpClient();
            //HttpResponseMessage response = client.GetAsync(url).Result;
            //HttpContent content = response.Content;
            //Task<string> result = content.ReadAsStringAsync();

            responseData = "<response> <RefId>777</RefId> <RegisterId>3</RegisterId> <InvNum>687</InvNum> <ResultCode>0</ResultCode> <RespMSG>APPROVED</RespMSG> <Message>Approved</Message> <AuthCode>198208</AuthCode> <PNRef>00000026</PNRef> <PaymentType>Credit</PaymentType> <HostSpecific>TID: 001,</HostSpecific> <ExtData>InvNum=687,CardType=MASTERCARD,BatchNum=189002,Tip=0.00,CashBack=0.00,Fee=0.00,AcntLast4=4111,Name=UL%20Demo%2fCard%2001%20%20%20%20%20%20%20%20%20%20%20,SVC=0.00,TotalAmt=0.63,DISC=0.00,Donation=0.00,SHFee=0.00,RwdPoints=0,RwdBalance=0,RwdIssued=,EBTFSLedgerBalance=,EBTFSAvailBalance=,EBTFSBeginBalance=,EBTCashLedgerBalance=,EBTCashAvailBalance=,EBTCashBeginBalance=,RewardCode=,AcqRefData=,ProcessData=,RefNo=,RewardQR=,Language=English,EntryType=CHIP,table_num=0,clerk_id=,ticket_num=</ExtData> <EMVData>AID=A0000000041010,AppName=MasterCardCredit,TVR=0800008000,TSI=E800</EMVData> <Sign>Qk2aAQAAAAAAAD4AAAAoAAAAYAAAAB0AAAABAAEAAAAAAFwBAADEDgAAxA4AAAAAAAAAAAAAAAAAAP///wD////z//////////////+D//////////////4P//////////////g//////////////+D//////////////4P//////////////g///////////////D//////////////8P//////////////wf//////////////h//////////////+H//////////////4P//////////////w///////////////j///////////////n///////////////H//////////////CP/////////////gCf////////////wAcf///////////4AP8///////////8AH////////////8AD////////////4AB///+f///////gAB////+P//////wAD//////B/////gAP///////gH///AAH////////8Bn/wAP//////////xn/wf/////////8=</Sign> <Token></Token> </response>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(responseData);

            return Content(responseData);
        }

        [HttpPost]
        public ActionResult SaveCustomizedTheme(string themeName, string cssCode, bool overwrite)
        {
            var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
            Customer customer = _authenticationService.GetAuthenticatedCustomer();
            if (customer == null || !customer.IsAdmin())
            {
                return Json(new { success = false, reason = "Please log in as store administrator." });
            }
            try
            {
                SaveTheme(themeName, cssCode, overwrite, storeUrl: MultisiteHelper.ExpandStoreNameToUrl(MultisiteHelper.SubDomain));
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, reason = ex.Message });
            }
        }

        internal static void SaveTheme(string themeName, string cssCode, bool overwrite, string storeUrl)
        {
            //new or edited?
            var themeProvider = EngineContext.Current.Resolve<Nop.Web.Framework.Themes.IThemeProvider>();
            var themeContext = EngineContext.Current.Resolve<Nop.Web.Framework.Themes.IThemeContext>();
            var currentTheme = themeProvider.GetThemeConfiguration(themeContext.WorkingThemeName);
            var possibleSavedTheme = themeProvider.GetThemeConfigurations()
                //do not display themes for mobile devices
                .Where(x => x.Stores.Split(',').Select(s => s.Trim().ToLower()).Contains(MultisiteHelper.CurrentUrl.ToLower()))
                .Where(x => x.ThemeTitle.Equals(themeName, StringComparison.InvariantCultureIgnoreCase));

            var themeIsNew = !possibleSavedTheme.Any();
            //!string.Equals(themeName, currentThemeName, StringComparison.InvariantCultureIgnoreCase);

            //find/create dirs
            var newName = "";
            var dirTheme = themeIsNew ?
                HostingEnvironment.MapPath("~/Themes/" +
                 (newName = CreateUniqueThemeName(themeName, MultisiteHelper.CurrentUrl))
                )
                : possibleSavedTheme.First().Path;
            var dirContent = string.Format("{0}\\Content", dirTheme);
            var dirContentCss = string.Format("{0}\\Content\\css", dirTheme);
            var dirContentImages = string.Format("{0}\\Content\\images", dirTheme);
            var dirViews = string.Format("{0}\\Views", dirTheme);
            var dirViewsShared = string.Format("{0}\\Views\\Shared", dirTheme);

            foreach (var dir in new[] { dirTheme, dirContent, dirContentCss, dirContentImages, dirViews, dirViewsShared })
            {
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
            }

            // Copy all css
            if (System.IO.Directory.Exists(currentTheme.Path + "\\Content\\css"))
            {
                string[] files = System.IO.Directory.GetFiles(currentTheme.Path + "\\Content\\css");
                string fileName = "";
                string destFile = "";
                string targetPath = dirContentCss;
                // Copy the files and overwrite destination files if they already exist.
                foreach (string s in files)
                {
                    // Use static Path methods to extract only the file name from the path.
                    fileName = System.IO.Path.GetFileName(s);
                    destFile = System.IO.Path.Combine(targetPath, fileName);
                    System.IO.File.Copy(s, destFile, true);
                }
            }

            // copy all images
            if (System.IO.Directory.Exists(currentTheme.Path + "\\Content\\images"))
            {
                string[] files = System.IO.Directory.GetFiles(currentTheme.Path + "\\Content\\images");
                string fileName = "";
                string destFile = "";
                string targetPath = dirContentImages;
                // Copy the files and overwrite destination files if they already exist.
                foreach (string s in files)
                {
                    // Use static Path methods to extract only the file name from the path.
                    fileName = System.IO.Path.GetFileName(s);
                    destFile = System.IO.Path.Combine(targetPath, fileName);
                    System.IO.File.Copy(s, destFile, true);
                }
            }

            //write css
            System.IO.File.WriteAllText(dirContentCss + "\\pickerStyles.css", cssCode);

            if (themeIsNew)
            {
                //write theme.config
                var baseTheme = currentTheme.BaseTheme;
                var dirBaseTheme = "";
                if (string.IsNullOrEmpty(baseTheme))
                { //current theme is a base theme
                    baseTheme = Path.GetFileName(currentTheme.Path);
                    dirBaseTheme = string.Format(@"~/Themes/{0}", Path.GetFileName(currentTheme.Path));
                }
                else
                {
                    dirBaseTheme = string.Format(@"~/Themes/{0}", baseTheme);
                }

                System.IO.File.WriteAllText(dirTheme + "\\theme.config", string.Format(@"<?xml version=""1.0"" encoding=""utf-8"" ?>
            <Theme title=""{0}""
            	   supportRTL=""true""            	   
                   previewImageUrl=""~/Themes/{3}/preview.jpg""
                   previewText=""This is the {0} site theme.""
                   stores=""{1}"" baseTheme=""{2}"" > 
            </Theme>", themeName, storeUrl, baseTheme, newName));

                //write Head.cshtml\

                //                System.IO.File.WriteAllText(dirViewsShared + "\\Head.cshtml", string.Format(@"@using Nop.Web.Framework;
                //            @{{
                //                Html.AppendCssFileParts(Url.Content(""~/Themes/{0}/Content/styles.css""));
                //                Html.AppendCssFileParts(Url.Content(""{1}/Content/styles.css""));
                //            }}", newName, dirBaseTheme));

                string head = @"@using Nop.Core;
@using Nop.Core.Infrastructure
@using Nop.Web.Framework.Themes
@using Nop.Web.Framework.UI
@{{  
    var supportRtl = EngineContext.Current.Resolve<IWorkContext>().WorkingLanguage.Rtl;
    var themeName = EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName;

    //add browser specific CSS files
    var browser = Request.Browser;
    if (browser.Browser == ""IE"" && browser.MajorVersion == 8)
    {
        Html.AppendCssFileParts(string.Format(""~/Themes/{0}/Content/css/ie8.css"", themeName));
    }
    // color picker css 
    Html.AppendCssFileParts(string.Format(""~/Themes/{0}/Content/css/pickerStyles.css"", themeName));
    Html.AppendCssFileParts(string.Format(""~/Themes/{0}/Content/css/paymentform.css"", themeName));
    //add main CSS file
    if (supportRtl)
    {
        Html.AppendCssFileParts(string.Format(""~/Themes/{0}/Content/css/styles.rtl.css"", themeName));
    }
    else
    {
        Html.AppendCssFileParts(string.Format(""~/Themes/{0}/Content/css/styles.css"", themeName));
    }
    
    //add jQuery UI css file
    Html.AppendCssFileParts(""~/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css"");

    if (browser.Browser == ""IE"" && browser.MajorVersion == 8)
    {
        Html.AddScriptParts(""~/Scripts/selectivizr.min.js"");
        Html.AddScriptParts(""~/Scripts/respond.min.js"");
    }
}}";
                System.IO.File.WriteAllText(dirViewsShared + "\\Head.cshtml", head);

                //write web.config
                System.IO.File.Copy(Path.Combine(currentTheme.Path, "Views", "web.config"),
                    Path.Combine(dirViews, "web.config"));

                // preview image
                System.IO.File.Copy(Path.Combine(currentTheme.Path, "preview.jpg"),
                    Path.Combine(dirTheme, "preview.jpg"));

                // Save Store Theme
                if (!MultisiteHelper.IsAdminSite)
                {
                    MultisiteHelper.SaveSiteThemeByStoreName(MultisiteHelper.SubDomain, newName);
                }
                //----------------------------
            }

        }

        static string CreateUniqueThemeName(string themeName, string storeNameOrUrl)
        {
            themeName = themeName.Trim();
            string invalidChars = Regex.Escape(new string(Path.GetInvalidFileNameChars()));
            string invalidReStr = string.Format(@"[{0}]+", invalidChars);
            themeName = Regex.Replace(themeName, invalidReStr, "_");

            //themeName = Regex.Replace(themeName, @"[^\w\-]", "");
            var tmpName = themeName;
            int n = 1;
            do
            {
                var tmpDir = string.Format("~/Themes/{0}_{1}", storeNameOrUrl, tmpName);
                if (!Directory.Exists(HostingEnvironment.MapPath(tmpDir)))
                {
                    return string.Format("{0}_{1}", storeNameOrUrl, tmpName);
                }
                tmpName = themeName + n++.ToString();
            } while (true);
        }

        // This is used to render same website logo (CommonController -> Logo) for Native Mobile App.
        // For Native mobile app "/merchant/logo" URL is used strickly bases. 
        // So we have to decide to make a replica of "Logo" action of "Common" controller.
        public ActionResult Logo()
        {
            var cacheKey = string.Format(ModelCacheEventConsumer.STORE_LOGO_PATH, EngineContext.Current.Resolve<IStoreContext>().CurrentStore.Id, EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName, EngineContext.Current.Resolve<IWebHelper>().IsCurrentConnectionSecured());
            Picture logoPicture = new Picture();
            logoPicture = EngineContext.Current.Resolve<ICacheManager>().Get(cacheKey, () =>
            {                
                var logoPictureId = EngineContext.Current.Resolve<StoreInformationSettings>().LogoPictureId;
                if (logoPictureId > 0)
                {
                    logoPicture = EngineContext.Current.Resolve<IPictureService>().GetPictureById(logoPictureId);
                }
                else
                {
                    //use default logo
                    string logo = string.Format(@"~/Themes/{0}/Content/images/logo.png", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName);
                    logoPicture = new Picture
                    {
                        PictureBinary = System.IO.File.ReadAllBytes(Server.MapPath(logo)),
                        MimeType = "image/png"
                    };
                }
                return logoPicture;
            });

            //int logoPictureId;
            //logoPictureId = EngineContext.Current.Resolve<ICacheManager>().Get(cacheKey, () =>
            //{
            //    return EngineContext.Current.Resolve<StoreInformationSettings>().LogoPictureId;
            //});

            //if (logoPictureId > 0)
            //{
            //    logoPicture = EngineContext.Current.Resolve<IPictureService>().GetPictureById(logoPictureId);
            //}
            //else
            //{
            //    //use default logo
            //    string logo = string.Format(@"~/Themes/{0}/Content/images/logo.png", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName);
            //    logoPicture = new Picture
            //    {
            //        //PictureBinary = System.IO.File.ReadAllBytes(logo),
            //        //MimeType = "image/png"
            //        PictureBinary = System.IO.File.ReadAllBytes(Server.MapPath(logo)),
            //        MimeType = "image/png"
            //    };
            //}

            return File(logoPicture.PictureBinary, logoPicture.MimeType);
        }
    }

}