﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.Catalog;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Security;
using Nop.Web.Framework.Kendoui;
using Shopfast.Plugin.Custom.Helper;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Extensions;
using Shopfast.Plugin.Custom.Services;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class ProductCustomAdminController : BaseAdminController
    {
        private readonly IProductService _productService;
        private readonly ICategoryService _categoryService;
        private readonly IDbContext _dbContext;
        private readonly IWorkContext _workContext;
        private readonly IPermissionService _permissionService;        
        private readonly IPictureService _pictureService;
        private readonly ILocalizationService _localizationService;
        // Customized***
        private readonly IProductServiceCustom _productServiceCustom;
        
        public ProductCustomAdminController(
            IProductService productService,
            ICategoryService categoryService, 
            IDbContext dbContext,
            IWorkContext workContext, 
            IPermissionService permissionService,             
            IPictureService pictureService,
            ILocalizationService localizationService,
            // Customized***
            IProductServiceCustom productServiceCustom
            )
        {
            this._productService = productService;
            this._categoryService = categoryService;
            this._workContext = workContext;            
            this._localizationService = localizationService;            
            this._pictureService = pictureService;
            this._permissionService = permissionService;                        
            this._dbContext = dbContext;
            // Customized***
            this._productServiceCustom = productServiceCustom;
        }

        #region Utilities
        [NonAction]
        protected virtual List<int> GetChildCategoryIds(int parentCategoryId)
        {
            var categoriesIds = new List<int>();
            var categories = _categoryService.GetAllCategoriesByParentCategoryId(parentCategoryId, true);
            foreach (var category in categories)
            {
                categoriesIds.Add(category.Id);
                categoriesIds.AddRange(GetChildCategoryIds(category.Id));
            }
            return categoriesIds;
        }
        #endregion

        #region Methods
        #region Product list
        [HttpPost]
        public ActionResult ProductList(DataSourceRequest command, ProductListModel model, string SearchGtin)
        {            
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageProducts))
                return AccessDeniedView();

            //a vendor should have access only to his products
            if (_workContext.CurrentVendor != null)
            {
                model.SearchVendorId = _workContext.CurrentVendor.Id;
            }

            var categoryIds = new List<int> { model.SearchCategoryId };
            //include subcategories
            if (model.SearchIncludeSubCategories && model.SearchCategoryId > 0)
                categoryIds.AddRange(GetChildCategoryIds(model.SearchCategoryId));

            //0 - all (according to "ShowHidden" parameter)
            //1 - published only
            //2 - unpublished only
            bool? overridePublished = null;
            if (model.SearchPublishedId == 1)
                overridePublished = true;
            else if (model.SearchPublishedId == 2)
                overridePublished = false;

            var products = _productServiceCustom.SearchProducts(
                categoryIds: categoryIds,
                manufacturerId: model.SearchManufacturerId,
                storeId: model.SearchStoreId,
                vendorId: model.SearchVendorId,
                warehouseId: model.SearchWarehouseId,
                productType: model.SearchProductTypeId > 0 ? (ProductType?)model.SearchProductTypeId : null,
                keywords: model.SearchProductName,
                pageIndex: command.Page - 1,
                pageSize: command.PageSize,
                showHidden: true,
                overridePublished: overridePublished,
                SearchBarcode: SearchGtin
            );
            var gridModel = new DataSourceResult();
            gridModel.Data = products.Select(x =>
            {
                var productModel = x.ToModel();
                //little hack here:
                //ensure that product full descriptions are not returned
                //otherwise, we can get the following error if products have too long descriptions:
                //"Error during serialization or deserialization using the JSON JavaScriptSerializer. The length of the string exceeds the value set on the maxJsonLength property. "
                //also it improves performance
                productModel.FullDescription = "";

                //picture
                var defaultProductPicture = _pictureService.GetPicturesByProductId(x.Id, 1).FirstOrDefault();
                productModel.PictureThumbnailUrl = _pictureService.GetPictureUrl(defaultProductPicture, 75, true);
                //product type
                productModel.ProductTypeName = x.ProductType.GetLocalizedEnum(_localizationService, _workContext);
                //friendly stock qantity
                //if a simple product AND "manage inventory" is "Track inventory", then display
                if (x.ProductType == ProductType.SimpleProduct && x.ManageInventoryMethod == ManageInventoryMethod.ManageStock)
                    productModel.StockQuantityStr = x.GetTotalStockQuantity().ToString();
                return productModel;
            });
            gridModel.Total = products.TotalCount;

            return Json(gridModel);
        }
        #endregion

        #region Additional Methods
        [ChildActionOnly]
        public ActionResult BarcodeView(int productId)
        {
            var barcodeCategories = NopBarCodeImage.BarcodeCategories();            
            var model =
                    _dbContext.SqlQuery<ProductModelCustom>(
                        "select top 1 BarcodeId,Gtin from Product where id=@p0", productId)
                        .FirstOrDefault() ?? new ProductModelCustom();
            model.ProductId = productId;
            if (model.BarcodeId > 0)
            {
                foreach (var tc in barcodeCategories)
                    model.AvailableBarcodeCategories.Add(new SelectListItem() { Text = tc.Text, Value = tc.Value.ToString(), Selected = tc.Value == model.BarcodeId.ToString() });
            }
            else
            {
                model.BarcodeId = 1;
                foreach (var tc in barcodeCategories)
                    model.AvailableBarcodeCategories.Add(new SelectListItem() { Text = tc.Text, Value = tc.Value.ToString(), Selected = tc.Value == "1" });
            }            
            return View(model);
        }

        [ChildActionOnly]
        public ActionResult ShowOnPointOfSaleView(int productId)
        {
            var model =
                _dbContext.SqlQuery<ProductModelCustom>(
                    "select top 1 ShowOnPointOfSale from Product where id=@p0", productId)
                    .FirstOrDefault() ?? new ProductModelCustom();
            return View(model);
        }

        public ActionResult GetBarcodePath(string number, string barcodeSymbology)
        {
            CreateDirectory("~/Content/BarCode");
            string path = NopBarCodeImage.GenerateBarCode(number, barcodeSymbology);
            return Json(path, JsonRequestBehavior.AllowGet);
        }

        [ChildActionOnly]
        public ActionResult ProductGtinView()
        {
            return View();
        }

        private void CreateDirectory(string path)
        {
            if (!Directory.Exists(Server.MapPath(path)))
            {
                Directory.CreateDirectory(Server.MapPath(path));
            }
        }

        private void DeleteDirectoryInfo(string path)
        {
            System.IO.DirectoryInfo directory = new System.IO.DirectoryInfo(Server.MapPath(path));
            if (Directory.Exists(Server.MapPath(path)))
            {
                foreach (System.IO.FileInfo file in directory.GetFiles()) file.Delete();
                //System.IO.Directory.Delete(Server.MapPath(path), true);
            }
        }

        #endregion
        #endregion
    }
}