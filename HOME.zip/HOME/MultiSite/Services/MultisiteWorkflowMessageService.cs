﻿using System;
using System.Collections.Generic;
using Nop.Services.Messages;
using MultiSite.Models;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Services.Localization;
using Nop.Core.Domain.Messages;
using Nop.Services.Events;
using Nop.Services.Stores;
using Nop.Core.Domain.Stores;
using Nop.Core;
using Nop.Core.Domain.Common;
using System.Web;

namespace MultiSite.Services {
    public class MultisiteWorkflowMessageService : WorkflowMessageService {
        public MultisiteWorkflowMessageService()
            : base(
                EngineContext.Current.Resolve<IMessageTemplateService>(),
                EngineContext.Current.Resolve<IQueuedEmailService>(),
                EngineContext.Current.Resolve<ILanguageService>(),
                EngineContext.Current.Resolve<ITokenizer>(),
                EngineContext.Current.Resolve<IEmailAccountService>(),
                EngineContext.Current.Resolve<IMessageTokenProvider>(),
                EngineContext.Current.Resolve<IStoreService>(),
                EngineContext.Current.Resolve<IStoreContext>(),
                EngineContext.Current.Resolve<CommonSettings>(),
                EngineContext.Current.Resolve<EmailAccountSettings>(),
                EngineContext.Current.Resolve<IEventPublisher>(),
                EngineContext.Current.Resolve<HttpContextBase>()
                ) { }
        
        public int SendTrialStoreCreatedCustomerNotification(SiteModel site, bool isTrial)
        {
            if (site == null)
                throw new ArgumentNullException("site");
            var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
            var store = _storeContext.CurrentStore;
            var languageId = 1; //english

            var messageTemplate = (isTrial) ? GetActiveMessageTemplate("TrialStoreCreated.CustomerNotification", store.Id) :
                GetActiveMessageTemplate("PackagedStoreCreated.CustomerNotification", store.Id);
            //-------------------------------------------------
            if (messageTemplate == null)
                return 0;

            var siteTokens = GenerateTokens(site, languageId, store);

            var emailAccount = GetEmailAccountOfMessageTemplate(messageTemplate, languageId);
            var toEmail = site.customerEmail;
            var toName = string.Format("{0} {1}", site.firstName, site.lastName);
            return SendNotification(messageTemplate, emailAccount,
                languageId, siteTokens,
                toEmail, toName);
        }

        public virtual int SendTrialStoreCreatedAdminNotification(SiteModel site, bool isTrial = false)
        { //
            if (site == null)
                throw new ArgumentNullException("site");

            var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
            var store = _storeContext.CurrentStore;
            //---------------------------------------------------------------
            var languageId = 1; //english

            //upgrade_2.80_3.1 (for 3.1 multistore)            
            var messageTemplate = (isTrial) ? GetActiveMessageTemplate("TrialStoreCreated.AdminNotification", store.Id) :
                GetActiveMessageTemplate("PackagedStoreCreated.AdminNotification", store.Id);
            //----------------------------------------------------------
            if (messageTemplate == null)
                return 0;

            var siteTokens = GenerateTokens(site, languageId, store);

            var emailAccount = GetEmailAccountOfMessageTemplate(messageTemplate, languageId);
            var toEmail = emailAccount.Email;
            var toName = emailAccount.DisplayName;
            return SendNotification(messageTemplate, emailAccount,
                languageId, siteTokens,
                toEmail, toName);
        }
        private IList<Token> GenerateTokens(SiteModel site, int languageId, Store store)
        {
            var tokens = new List<Token>();
            IEmailAccountService _emailAccountService = EngineContext.Current.Resolve<IEmailAccountService>();
            EmailAccountSettings _emailAccountSettings = EngineContext.Current.Resolve<EmailAccountSettings>();
            var emailAccount = _emailAccountService.GetEmailAccountById(_emailAccountSettings.DefaultEmailAccountId);
            var _messageTokenProvider = EngineContext.Current.Resolve<IMessageTokenProvider>();
            _messageTokenProvider.AddStoreTokens(tokens, store, emailAccount);
            AddMultistoreTokens(tokens, site, languageId);

            return tokens;
        }
        //-----------------------------------------------------------------

        void AddMultistoreTokens(List<Token> tokens, SiteModel site, int languageId)
        {
            tokens.Add(new Token("MultiStore.StoreUrl", string.Format(@"{0}.{1}", site.storeName, MultisiteHelper.Domain)));
            tokens.Add(new Token("MultiStore.OwnerName", string.Format("{0} {1}", site.firstName, site.lastName)));
            tokens.Add(new Token("MultiStore.OwnerEmail", site.customerEmail));
            tokens.Add(new Token("MultiStore.Password", site.password));
            tokens.Add(new Token("MultiStore.MainStoreUrl", EngineContext.Current.Resolve<Nop.Core.IWebHelper>().GetStoreLocation()));
            tokens.Add(new Token("MultiStore.MainStoreName", EngineContext.Current.Resolve<Nop.Core.Domain.Seo.SeoSettings>().DefaultTitle));
        }

        public virtual int SendTrialStoreCreatedCustomerNotification(SiteRegistrationModel site, bool isTrial = false) { //
            if (site == null)
                throw new ArgumentNullException("site");
            var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
            var store = _storeContext.CurrentStore;
            //---------------------------------------------
            var languageId = 1; //english

            //upgrade_2.80_3.1 (for 3.1 multistore)

            var messageTemplate = (isTrial) ? GetActiveMessageTemplate("TrialStoreCreated.CustomerNotification", store.Id) :
                GetActiveMessageTemplate("PackagedStoreCreated.CustomerNotification", store.Id);
            //-------------------------------------------------
            if (messageTemplate == null)
                return 0;

            var siteTokens = GenerateTokens(site, languageId, store);

            var emailAccount = GetEmailAccountOfMessageTemplate(messageTemplate, languageId);
            var toEmail = site.email;
            var toName = string.Format("{0} {1}", site.firstName, site.lastName);
            return SendNotification(messageTemplate, emailAccount,
                languageId, siteTokens,
                toEmail, toName);
        }

        public virtual int SendTrialStoreCreatedAdminNotification(SiteRegistrationModel site, bool isTrial = false) { //
            if (site == null)
                throw new ArgumentNullException("site");
            var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
            var store = _storeContext.CurrentStore;
            //---------------------------------------------------------------
            var languageId = 1; //english

            var messageTemplate = (isTrial) ? GetActiveMessageTemplate("TrialStoreCreated.AdminNotification", store.Id) :
                GetActiveMessageTemplate("PackagedStoreCreated.AdminNotification", store.Id);
            //----------------------------------------------------------
            if (messageTemplate == null)
                return 0;

            var siteTokens = GenerateTokens(site, languageId, store);

            var emailAccount = GetEmailAccountOfMessageTemplate(messageTemplate, languageId);
            var toEmail = emailAccount.Email;
            var toName = emailAccount.DisplayName;
            return SendNotification(messageTemplate, emailAccount,
                languageId, siteTokens,
                toEmail, toName);
        }
        
        private IList<Token> GenerateTokens(SiteRegistrationModel site, int languageId, Store store) {
            var tokens = new List<Token>();
            IEmailAccountService _emailAccountService = EngineContext.Current.Resolve<IEmailAccountService>();
            EmailAccountSettings _emailAccountSettings = EngineContext.Current.Resolve<EmailAccountSettings>();
            var emailAccount = _emailAccountService.GetEmailAccountById(_emailAccountSettings.DefaultEmailAccountId);
            var _messageTokenProvider = EngineContext.Current.Resolve<IMessageTokenProvider>();
            _messageTokenProvider.AddStoreTokens(tokens, store, emailAccount);
            AddMultistoreTokens(tokens, site, languageId);

            return tokens;
        }

        void AddMultistoreTokens(List<Token> tokens, SiteRegistrationModel site, int languageId) {
            tokens.Add(new Token("MultiStore.StoreUrl", string.Format(@"{0}.{1}", site.storeName, MultisiteHelper.Domain)));
            tokens.Add(new Token("MultiStore.OwnerName", string.Format("{0} {1}", site.firstName, site.lastName)));
            tokens.Add(new Token("MultiStore.OwnerEmail", site.email));
            tokens.Add(new Token("MultiStore.Password", site.password));
            tokens.Add(new Token("MultiStore.MainStoreUrl", EngineContext.Current.Resolve<Nop.Core.IWebHelper>().GetStoreLocation()));
            tokens.Add(new Token("MultiStore.MainStoreName", EngineContext.Current.Resolve<Nop.Core.Domain.Seo.SeoSettings>().DefaultTitle));
        }
    }
}
