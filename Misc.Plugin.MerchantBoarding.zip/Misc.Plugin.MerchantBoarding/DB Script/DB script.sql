insert into messagetemplate
(Name, BccEmailAddresses, [Subject], Body, IsActive, AttachedDownloadId, EmailAccountId, LimitedToStores,DelayBeforeSend,DelayPeriodId)
values
('BoardingCompleted.MerchantNotification',
	NULL,
		'Boarding Securepay : Merchant Completed',
		'Merchant Boarding forms completed',
		1,0,0,0,null,0)
select * from MessageTemplate

--***************************Tables*********************
--MB_MerchantInformation