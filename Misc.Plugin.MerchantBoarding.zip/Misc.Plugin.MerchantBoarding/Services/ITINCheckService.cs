﻿using Misc.Plugin.MerchantBoarding.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Services
{
    public interface ITINCheckService
    {
        TINCheckResponse TINCheckVerification(TINCheckModel _pModel);
    }
}
