﻿var individual_accordion = {
    individualBasic_info1: '#individualBasic #info1',
    individualBasic_info2: '#individualBasic #info2',
    individualBasic_info3: '#individualBasic #info3',
    individualBasic_info4: '#individualBasic #info4',

    individualBasic_continue1: '#individualBasic #continue1',
    individualBasic_continue2: '#individualBasic #continue2',
    individualBasic_continue3: '#individualBasic #continue3',
    //var individualBasic_continue4 = $('#individualBasic #continue4');

    individualBasic_header1: '#individualBasic #header1',
    individualBasic_header2: '#individualBasic #header2',
    individualBasic_header3: '#individualBasic #header3',
    individualBasic_header4: '#individualBasic #header4',
    showIndividualBasic: function () {
        $(this.individualBasic_info2).removeClass('opened');
        $(this.individualBasic_info2).addClass('disableThree');
        $(this.individualBasic_info3).removeClass('opened');
        $(this.individualBasic_info3).addClass('disableThree');
        $(this.individualBasic_info4).removeClass('opened');
        $(this.individualBasic_info4).addClass('disableThree');
        $(this.individualBasic_info1).addClass('opened');
        $(this.individualBasic_info1).removeClass('opened');
    },

    showIndividualHome: function () {
        $(this.individualBasic_info2).addClass('opened');
        $(this.individualBasic_info2).removeClass('disableThree');
        $(this.individualBasic_info1).removeClass('opened');
        $(this.individualBasic_info1).addClass('disableThree');
        $(this.individualBasic_info3).removeClass('opened');
        $(this.individualBasic_info3).addClass('disableThree');
        $(this.individualBasic_info4).removeClass('opened');
        $(this.individualBasic_info4).addClass('disableThree');
    },

    showIndividualEmployer: function () {
        $(this.individualBasic_info3).addClass('opened');
        $(this.individualBasic_info3).removeClass('disableThree');
        $(this.individualBasic_info1).removeClass('opened');
        $(this.individualBasic_info1).addClass('disableThree');
        $(this.individualBasic_info2).removeClass('opened');
        $(this.individualBasic_info2).addClass('disableThree');
        $(this.individualBasic_info4).removeClass('opened');
        $(this.individualBasic_info4).addClass('disableThree');
    },

    showIndividualIncome: function () {
        $(this.individualBasic_info1).removeClass('opened');
        $(this.individualBasic_info1).addClass('disableThree');
        $(this.individualBasic_info2).removeClass('opened');
        $(this.individualBasic_info2).addClass('disableThree');
        $(this.individualBasic_info3).removeClass('opened');
        $(this.individualBasic_info3).addClass('disableThree');
        $(this.individualBasic_info4).removeClass('disableThree');
        $(this.individualBasic_info4).addClass('opened');
    },

    init: function () {
        $(this.individualBasic_info2).addClass('disableThree');
        $(this.individualBasic_info3).addClass('disableThree');
        $(this.individualBasic_info4).addClass('disableThree');
        $(this.individualBasic_info1).addClass('opened');

        $(document).on('click', this.individualBasic_header1, function () {
            $(individual_accordion.individualBasic_info1).addClass('opened');
            $(individual_accordion.individualBasic_info1).removeClass('disableThree');
            $(individual_accordion.individualBasic_info2).removeClass('opened');
            $(individual_accordion.individualBasic_info2).addClass('disableThree');
            $(individual_accordion.individualBasic_info3).removeClass('opened');
            $(individual_accordion.individualBasic_info3).addClass('disableThree');
            $(individual_accordion.individualBasic_info4).removeClass('opened');
            $(individual_accordion.individualBasic_info4).addClass('disableThree');
        });

        $(document).on('click', this.individualBasic_header2, function () {
            $(individual_accordion.individualBasic_info2).addClass('opened');
            $(individual_accordion.individualBasic_info2).removeClass('disableThree');
            $(individual_accordion.individualBasic_info1).removeClass('opened');
            $(individual_accordion.individualBasic_info3).removeClass('opened');
            $(individual_accordion.individualBasic_info3).addClass('disableThree');
            $(individual_accordion.individualBasic_info4).removeClass('opened');
            $(individual_accordion.individualBasic_info4).addClass('disableThree');
        });

        $(document).on('click', this.individualBasic_header3, function () {
            $(individual_accordion.individualBasic_info3).addClass('opened');
            $(individual_accordion.individualBasic_info3).removeClass('disableThree');
            $(individual_accordion.individualBasic_info1).removeClass('opened');
            $(individual_accordion.individualBasic_info2).removeClass('opened');
            $(individual_accordion.individualBasic_info4).removeClass('opened');
            $(individual_accordion.individualBasic_info4).addClass('disableThree');
        });
    }
};

var company_accordion = {
    companyBasic_info1: '#companyBasic #info1',
    companyBasic_info2: '#companyBasic #info2',

    companyBasic_continue1: '#companyBasic #continue1',
    companyBasic_continue2: '#companyBasic #continue2',

    companyBasic_header1: '#companyBasic #header1',
    companyBasic_header2: '#companyBasic #header2',
    showIndividualBasic: function () {
        $(this.companyBasic_info2).removeClass('opened');
        $(this.companyBasic_info2).addClass('disableThree');
        $(this.companyBasic_info1).removeClass('disableThree');
        $(this.companyBasic_info1).addClass('opened');
    },

    showIndividualBusiness: function () {
        $(this.companyBasic_info1).removeClass('opened');
        $(this.companyBasic_info1).addClass('disableThree');
        $(this.companyBasic_info2).removeClass('disableThree');
        $(this.companyBasic_info2).addClass('opened');
    },

    init: function () {
        $(this.companyBasic_info2).addClass('disableThree');
        $(this.companyBasic_info1).addClass('opened');

        $(document).on('click', this.companyBasic_header1, function () {
            $(company_accordion.companyBasic_info1).addClass('opened');
            $(company_accordion.companyBasic_info1).removeClass('disableThree');
            $(company_accordion.companyBasic_info2).removeClass('opened');
            $(company_accordion.companyBasic_info2).addClass('disableThree');
        });
    }
};

var Common = {
    loadWaiting: false,

    init: function () {
        this.loadWaiting = false;
        Accordion.disallowAccessToNextSections = true;
        //individual_accordion.init();
    },

    ajaxFailure: function (err) {
        alert(err.responseText);
        //location.href = Common.failureUrl;
    },

    _disableEnableAll: function (element, isDisabled) {
        var descendants = element.find('*');
        $(descendants).each(function () {
            if (isDisabled) {
                $(this).attr('disabled', 'disabled');
            } else {
                $(this).removeAttr('disabled');
            }
        });

        if (isDisabled) {
            element.attr('disabled', 'disabled');
        } else {
            element.removeAttr('disabled');
        }
    },

    setLoadWaiting: function (step, keepDisabled) {
        if (step) {
            if (this.loadWaiting) {
                this.setLoadWaiting(false);
            }
            var container = $((step === 'common' ? '.' : '#') + step + '-form-buttons-container');
            container.addClass('disabled');
            container.css('opacity', '.5');
            this._disableEnableAll(container, true);
            $((step === 'common' ? '.' : '#') + step + '-please-wait').show();
        } else {
            if (this.loadWaiting) {
                var container = $('#' + this.loadWaiting + '-form-buttons-container');
                var isDisabled = (keepDisabled ? true : false);
                if (!isDisabled) {
                    container.removeClass('disabled');
                    container.css('opacity', '1');
                }
                this._disableEnableAll(container, isDisabled);
                $('#' + this.loadWaiting + '-please-wait').hide();
            }
        }
        this.loadWaiting = step;
    },

    gotoSection: function (section) {
        section = $('#' + section);
        section.addClass('allow');
        Accordion.openSection(section);
    },

    back: function () {
        if (this.loadWaiting) return;
        Accordion.openPrevSection(true, true);
    },

    setStepResponse: function (response, moveToSection) {
        if (response.error) {
            alert(response.message);
        }

        if (response.section_name) {
            $('#' + response.section_name + '-form-load').html(response.html);
        }
        // for shipping address
        if (response.section_name2) {
            $('#' + response.section_name2 + '-form-load').html(response.html2);
            $('#' + response.section_name2 + '-content').show();
        }
        // for shipping method
        if (response.section_name3) {
            $('#' + response.section_name3 + '-form-load').html(response.html3);
            $('#' + response.section_name3 + '-content').show();
        }
        if (response.selectedOptionContent) {
            $('#' + response.selectedOptionArea).html(response.selectedOptionContent.Data.result_html);
        }
        if (response.validation_error) {
            $('#' + response.validation_span_id).css("display", "block");
        }

        //TODO move it to a new method
        if (moveToSection) {
            if (response.section_name) {
                Common.gotoSection(response.section_name);
                $("html, body").animate({ scrollTop: $("#" + response.section_name).offset().top }, "slow");
                return true;
            }
            if (response.redirect) {
                location.href = response.redirect;
                return true;
            }
        }

        return false;
    },

    setCustomStepResponse: function (response) {
        if (response.error) {
            alert(response.message);
        }
        if (response.section_name && response.html) {
            $('#' + response.section_name + '-form-load').html(response.html);
        }
        if (response.selectedOptionContent) {
            $('#' + response.selectedOptionArea).html(response.selectedOptionContent.Data.result_html);
        }
        if (response.validation_error) {
            $('#' + response.validation_span_id).css("display", "block");
        }
        else {
            if (response.section_name == 'shipping-address') {
                Shipping.save();
            }
            else if (response.section_name == 'shipping-method') {
                ShippingMethod.save();
            }
            else if (response.section_name == 'paymentinfo') {
                PaymentInfo.save();
            }
        }
        return false;
    },

    onKeyPress: function (e) {
        var theEvent = e || window.event;
        if ($.inArray(theEvent.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A, Command+A
           (theEvent.keyCode === 65 && (theEvent.ctrlKey === true || theEvent.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
           (theEvent.keyCode >= 35 && theEvent.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
        var regex = /[0-9]|\./;
        if (!regex.test(key)) {
            theEvent.returnValue = false;
            if (theEvent.preventDefault) theEvent.preventDefault();
        }
    },

    resizeIframe: function () {
        $(".docusign-frame").addClass("small-iframe");
    },

    nextStep: function (e) {
        var nextStep = $(e).parent().parent().parent().data('target');
        if (nextStep) {
            switch (nextStep) {
                case "investor-info":
                    InvestorInformation.save();
                    break;
                case "subagreement":
                    SubscriptionAgreement.save();
                    break;
            }
        }
    },

    reloadSection: function (response, sectionName) {
        if (sectionName) {
            $('#' + sectionName + '-form-load').html(response);
        }
    }
};

var InvestorInformation = {
    form: false,
    saveUrl: false,
    reloadUrl: false,

    init: function (form, saveUrl, reloadUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
        this.reloadUrl = reloadUrl;
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('common');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        Common.setStepResponse(response, true);
    },

    reload: function () {
        $.ajax({
            cache: false,
            url: this.reloadUrl,
            type: 'GET',
            success: this.reloadSection,
            error: Common.ajaxFailure
        });
    },

    reloadSection: function (response) {
        Common.reloadSection(response, 'investor-info');
    }
};

var PersonalInformation = {
    form: false,
    saveUrl: false,
    changeTypeUrl: false,
    sectionType: '',

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    validate: function () {
        return true;
    },

    save: function (sectionType) {
        if (Common.loadWaiting != false) return;
        if (sectionType == 'individual_basic') {
            Common.setLoadWaiting('personal-information-basic');
        } else if (sectionType == 'individual_home') {
            Common.setLoadWaiting('personal-information-home');
        } else if (sectionType == 'individual_employer') {
            Common.setLoadWaiting('personal-information-employer');
        } else if (sectionType == 'individual_income') {
            Common.setLoadWaiting('personal-information-income');
        } else if (sectionType == 'company_basic') {
            Common.setLoadWaiting('personal-information-basic');
        } else if (sectionType == 'company_business') {
            Common.setLoadWaiting('personal-information-business');
        }
        else {
            Common.setLoadWaiting('personal-information');
        }


        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: function (response) {
                PersonalInformation.nextStep(response, sectionType)
            },
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });

    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response, sectionType) {
        if (response.redirect) {
            if (response.redirect.indexOf("verifyinvestor") != -1) {
                window.open(response.redirect, "_blank");
            }
            else {
                location.href = response.redirect;
            }
        }
        else {
            if (sectionType == 'individual_basic') {
                // open accordium            
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    individual_accordion.showIndividualBasic();
                }
                else {                    
                    if (response.goToContinue) {
                        Common.setStepResponse(response, true);
                    }
                    else {
                        individual_accordion.showIndividualHome();
                    }
                }
            } else if (sectionType == 'individual_home') {
                // open accordium            
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    individual_accordion.showIndividualHome();
                }
                else {
                    individual_accordion.showIndividualEmployer();
                }
            } else if (sectionType == 'individual_employer') {
                // open accordium            
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    individual_accordion.showIndividualEmployer();
                }
                else {
                    individual_accordion.showIndividualIncome();
                }
            } else if (sectionType == 'individual_income') {
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    individual_accordion.showIndividualIncome();
                }
                else {
                    Common.setStepResponse(response, true);
                }
            } else if (sectionType == 'company_basic') {
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    company_accordion.showIndividualBasic();
                }
                else {
                    if (response.goToContinue) {
                        Common.setStepResponse(response, true);
                    }
                    else {
                        company_accordion.showIndividualBusiness();
                    }
                }
            } else if (sectionType == 'company_business') {
                if (response.invalidForm) {
                    Common.setStepResponse(response, true);
                    company_accordion.showIndividualBusiness();
                }
                else {
                    Common.setStepResponse(response, true);
                }
            }
            else {

            }
        }
    },

    initChangePersonalType: function (changeTypeUrl) {
        this.changeTypeUrl = changeTypeUrl;
    },

    typeChange: function (obj) {
        $.ajax({
            cache: false,
            url: this.changeTypeUrl + '?investorType=' + $(obj).val() + '&ajaxRequest=true',
            type: 'get',
            success: this.typeChangeComplete,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    typeChangeComplete: function (response) {
        if (response.result_html) {
            $('#personal-type-content').html(response.result_html);
        }
    }
};

var InvestorType = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    validate: function () {
        return true;
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('investor-type');
        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        Common.setStepResponse(response, true);
    }
};

var InfoGathering = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl, uploadUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
        this.uploadUrl = uploadUrl;
    }, 

    save: function () {
        var txtval = $('#InfoGatheringPrefix_AnnualIncome').val().replace(/\,/g, '');
        $('#InfoGatheringPrefix_AnnualIncome').val(txtval);
        txtval = $('#InfoGatheringPrefix_NetWorth').val().replace(/\,/g, '');
        $('#InfoGatheringPrefix_NetWorth').val(txtval);

        if (Common.loadWaiting != false) return;
        Common.setLoadWaiting('info-gathering');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    uploadDocuments: function () {
        $.ajax({
            cache: false,
            url: this.uploadUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.uploadSuccess,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    uploadSuccess: function (response) {
        if (response.html) {
            $("#wrapperUploadDocuments").html(response.html);
            if ($('.div-upload:visible:last').find('input[type=hidden]').val() != '0') {
                $('.div-upload:hidden:first').show();
            }
        }
    },

    nextStep: function (response) {
        if (response.redirect) {
            location.href = response.redirect;
        }
        else {
            Common.setStepResponse(response, true);
        }
    }
};

var individualCompanyVerification = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    save: function () {
        if (Common.loadWaiting != false) return;
        Common.setLoadWaiting('individual-company-verification');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        if (response.redirect) {
            location.href = response.redirect;
        }
        else {
            Common.setStepResponse(response, true);
        }
    }
};

var Billing = {
    form: false,
    //// shiiping address
    //form2: false,
    //// shipping method
    //form3: false,
    saveUrl: false,

    //init: function (form, form2, form3, saveUrl) {
    init: function (form, saveUrl) {
        this.form = form;
        //this.form2 = form2;
        //this.form3 = form3;
        this.saveUrl = saveUrl;
    },

    newAddress: function (isNew) {
        if (isNew) {
            this.resetSelectedAddress();
            $('#billing-new-address-form').show();
        } else {
            $('#billing-new-address-form').hide();
        }
    },

    resetSelectedAddress: function () {
        var selectElement = $('#billing-address-select');
        if (selectElement) {
            selectElement.val('');
        }
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('billing-address');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            //data: { form: $(this.form).serialize(), form2: $(this.form2).serialize(), form3: $(this.form3).serialize() },
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        //ensure that response.wrong_billing_address is set
        //if not set, "true" is the default value
        if (typeof response.wrong_billing_address == 'undefined') {
            response.wrong_billing_address = false;
        }

        if (response.wrong_billing_address) {
            Accordion.showSection('#billing-address');
        }

        if (response.error) {
            if ((typeof response.message) == 'string') {
                alert(response.message);
            } else {
                alert(response.message.join("\n"));
            }

            return false;
        }
        if (response.section_name == 'purchase') {
            Common.setStepResponse(response, true);
        }
        else {
            Common.setCustomStepResponse(response);
        }
    }
};

var Shipping = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    newAddress: function (isNew) {
        if (isNew) {
            this.resetSelectedAddress();
            $('#shipping-new-address-form').show();
        } else {
            $('#shipping-new-address-form').hide();
        }
    },

    togglePickUpInStore: function (pickupInStoreInput) {
        if (pickupInStoreInput.checked) {
            //$('#pickup-points-form').show();
            $('#shipping-addresses-form').hide();
            $('#account-info').show();
        }
        else {
            $('#pickup-points-form').hide();
            $('#shipping-addresses-form').show();
            $('#account-info').hide();
        }
    },

    toggleShippingOption: function (optionInput) {
        if (optionInput.id == "share-info1" || optionInput.id == "share-info3") {
            $("#PickUpInStore").val("True");
        }
        else if (optionInput.id == "share-info2") {
            $("#PickUpInStore").val("False");
        }
    },

    resetSelectedAddress: function () {
        var selectElement = $('#shipping-address-select');
        if (selectElement) {
            selectElement.val('');
        }
    },

    save: function () {

        //if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('shipping-address');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        if (response.error) {
            if ((typeof response.message) == 'string') {
                alert(response.message);
            } else {
                alert(response.message.join("\n"));
            }

            return false;
        }

        if (response.wrong_billing_address) {
            Accordion.showSection('#shipping-addresses');
        }

        if (response.section_name == 'purchase') {
            Common.setStepResponse(response, true);
        }
        else {

            Common.setCustomStepResponse(response);
        }
    }
};

var ShippingMethod = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    validate: function () {
        var methods = document.getElementsByName('shippingoption');
        if (methods.length == 0) {
            alert('Your order cannot be completed at this time as there is no shipping methods available for it. Please make necessary changes in your shipping address.');
            return false;
        }

        for (var i = 0; i < methods.length; i++) {
            if (methods[i].checked) {
                return true;
            }
        }
        alert('Please specify shipping method.');
        return false;
    },

    save: function () {
        //if (Common.loadWaiting != false) return;

        if (this.validate()) {
            Common.setLoadWaiting('shipping-method');

            $.ajax({
                cache: false,
                url: this.saveUrl,
                data: $(this.form).serialize(),
                type: 'post',
                success: this.nextStep,
                complete: this.resetLoadWaiting,
                error: Common.ajaxFailure
            });
        }
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        if (response.error) {
            if ((typeof response.message) == 'string') {
                alert(response.message);
            } else {
                alert(response.message.join("\n"));
            }

            return false;
        }

        Common.setStepResponse(response, true);
    }
};

var Purchase = {
    form: false,
    saveUrl: false,
    loadUrl: false,
    validForm: false,

    init: function (form, saveUrl, loadUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
        this.loadUrl = loadUrl
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('purchase');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            type: 'post',
            data: $(this.form).serialize(),
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });

    },

    LoadPaymentInfo: function () {
        $.ajax({
            cache: false,
            url: this.loadUrl,
            type: 'post',
            data: $(this.form).serialize(),
            success: this.nextStepCustom,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        //Common.setStepResponse(response, true);
        Common.setCustomStepResponse(response);
    },

    nextStepCustom: function (response) {
        if (response.error) {
            alert(response.message);
        }
        if (response.section_name && response.html) {
            $('#' + response.section_name + '-form-load').html(response.html);
        }
    },

    onKeyPress: function (e) {
        var currentValue = $(e.target).val();
        currentValue = currentValue.replace(/,/g, '');
        //if (!currentValue) {
        //    $("#currency").html("");
        //}

        var priceValue = $("#perShare").val();
        var currencySymbol = $("#currencySymb").val();
        $("#ShareAmount").val((parseInt(priceValue * currentValue).toFixed(0).replace(/./g, function (c, i, a) {
            return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
        })));
        //$("#currency").html(currencySymbol + ((priceValue * currentValue).toFixed(2).replace(/./g, function (c, i, a) {
        //    return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
        //})));

        $("#shares-section").css("width", (430 + (currentValue.length * 20)) + "px");
    },

    onKeyPressAmount: function (e) {
        var currentValue = $(e.target).val();
        currentValue = currentValue.replace(/,/g, '');
        //if (!currentValue) {
        //    $("#currency").html("");
        //}

        var priceValue = $("#perShare").val();
        var currencySymbol = $("#currencySymb").val();
        var OrderedSharesCount = parseInt(currentValue / priceValue);
        if (OrderedSharesCount > 0) {            
            $("#PurchasePrefix_OrderedSharesCount").val((OrderedSharesCount.toFixed(0).replace(/./g, function (c, i, a) {
                return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
            })));
            //$("#currency").html(currencySymbol + ((priceValue * OrderedSharesCount).toFixed(2).replace(/./g, function (c, i, a) {
            //    return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
            //})));
            $("#PurchasePrefix_OrderedSharesCount").valid();

            //$("#shares-section").css("width", (430 + (currentValue.length * 20)) + "px");
        }
        else
        {
            $("#PurchasePrefix_OrderedSharesCount").val('');            
        }
    }
};

var PaymentInfo = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    save: function () {
        //if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('paymentinfo');

        if ($('#purchase-terms').length > 0) {
            //terms of service element exists
            if (!$('#purchase-terms').is(':checked')) {
                $("#purchase-termserror").css("display", "block");
                Common.setLoadWaiting(false);
                return;
            } else {
                $("#purchase-termserror").css("display", "none");
            }
        }

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        Common.setStepResponse(response, true);
    }
};

var SubscriptionAgreement = {
    form: false,
    saveUrl: false,
    reloadUrl: false,

    init: function (form, saveUrl, reloadUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
        this.reloadUrl = reloadUrl;
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('common');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        $("#div-confirm-load").html(response.html);
        $("#paydata3").addClass("active");
        $("#paydata3").removeClass("disablepay");
        $("#paydata2").removeClass("active");
        $("#paydata1").removeClass("active");
        $("#pay3").addClass("anc");
        $("#pay3").removeClass("mcn");
        $("#pay2").removeClass("anc");
        $("#pay2").addClass("mcn");
        // Common.setStepResponse(response, true);
    },

    reload: function () {
        $.ajax({
            cache: false,
            url: this.reloadUrl,
            type: 'GET',
            success: this.reloadSection,
            error: Common.ajaxFailure
        });
    },

    reloadSection: function (response) {
        Common.reloadSection(response, 'subagreement');
    }
};

var Confirm = {
    form: false,
    saveUrl: false,
    isSuccess: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    save: function () {
        if (Common.loadWaiting != false) return;

        Common.setLoadWaiting('confirm');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {

        if (response.redirect) {
            Confirm.isSuccess = true;
            location.href = response.redirect;
            return;
        }
        if (response.success) {
            Confirm.isSuccess = true;
            window.location = response.confirmRedirectedUrl;
        }

        Common.setStepResponse(response, true);
    }
};

var individualMain = {
    BasicSaving: function () {
        $("#IndividualPrefix_IniIndividualsModel_IsBasicSaving").val(true);
        $("#IndividualPrefix_IniIndividualsModel_IsHomeSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsEmployerSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsIncomeSaving").val(false);
        PersonalInformation.save('individual_basic');
    },

    HomeSaving: function () {
        $("#IndividualPrefix_IniIndividualsModel_IsBasicSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsHomeSaving").val(true);
        $("#IndividualPrefix_IniIndividualsModel_IsEmployerSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsIncomeSaving").val(false);
        PersonalInformation.save('individual_home');
    },

    EmployeeSaving: function () {
        $("#IndividualPrefix_IniIndividualsModel_IsBasicSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsHomeSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsEmployerSaving").val(true);
        $("#IndividualPrefix_IniIndividualsModel_IsIncomeSaving").val(false);
        PersonalInformation.save('individual_employer');
    },

    IncomeSaving: function () {
        $("#IndividualPrefix_IniIndividualsModel_IsBasicSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsHomeSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsEmployerSaving").val(false);
        $("#IndividualPrefix_IniIndividualsModel_IsIncomeSaving").val(true);
        PersonalInformation.save('individual_income');
    },

    CanJointAccount: function (type) {
        var id = "#IndividualPrefix_IniIndividualsModel_IsJoint" + type + "Saving";
        var divId = "#joint-" + type;
        if ($(id).val() == 'true') {
            $(id).val(false);
            $(divId).hide();
        }
        else {
            $(id).val(true);
            $(divId).show();
        }
    }
};

var companyMain = {
    BasicSaving: function () {
        $("#IndividualPrefix_OtherInfoModel_IsBasicSaving").val(true);
        $("#IndividualPrefix_OtherInfoModel_IsBusinessSaving").val(false);
        PersonalInformation.save('company_basic');
    },

    BusinessSaving: function () {
        $("#IndividualPrefix_OtherInfoModel_IsBasicSaving").val(false);
        $("#IndividualPrefix_OtherInfoModel_IsBusinessSaving").val(true);
        PersonalInformation.save('company_business');
    }
};

var network1Security = {
    form: false,
    saveUrl: false,

    init: function (form, saveUrl) {
        this.form = form;
        this.saveUrl = saveUrl;
    },

    save: function () {
        if (Common.loadWaiting != false) return;
        Common.setLoadWaiting('network1-security');

        $.ajax({
            cache: false,
            url: this.saveUrl,
            data: $(this.form).serialize(),
            type: 'post',
            success: this.nextStep,
            complete: this.resetLoadWaiting,
            error: Common.ajaxFailure
        });
    },

    resetLoadWaiting: function () {
        Common.setLoadWaiting(false);
    },

    nextStep: function (response) {
        //if (response.redirect) {
        //    location.href = response.redirect;
        //}
        //else {
        //    Common.setStepResponse(response, true);
        //}
        Common.setStepResponse(response, true);
    }
};
