﻿using FluentValidation.Attributes;
using Nop.Web.Framework;
using Nop.Web.Models.Common;
using ShopFast.Plugin.BD.CrowdPay.Validation;
using System.Collections.Generic;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels
{
    [Validator(typeof(OtherInfoValidation))]
    public class OtherInfoModel
    {

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.VestingName")]
        public string VestingName { get; set; }

        public bool VestingNameEnabled { get; set; }

        public bool VestingNameRequired { get; set; }

        public string CompanyLabel { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.ContactName")]
        public string ContactName { get; set; }

        public bool ContactNameEnabled { get; set; }

        public bool ContactNameRequired { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.RegionFormed")]
        public string RegionFormed { get; set; }

        public bool RegionFormedEnabled { get; set; }

        public bool RegionFormedRequired { get; set; }

        public AddressModel CompanyInfo { get; set; }

        public bool SelfDirected { get; set; }

        public string InfoType { get; set; }

        #region // All Other address attributes for "Company" (PDF 2)
        public int CompanyBasicId { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Business_City")]
        public string Business_City { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int Business_Country { get; set; }
        public IList<SelectListItem> AvailableBusinessCountries { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Business_State")]        
        public int Business_State { get; set; }
        public IList<SelectListItem> AvailableBusinessStates { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Business_Zip")]
        public string Business_Zip { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Business_Website")]
        public string Business_Website { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.EIN")]
        public string EIN { get; set; }

        public bool IsBasicSaving { get; set; }
        public bool IsBusinessSaved { get; set; }
        public bool IsBasicSaved { get; set; }
        public bool IsBusinessSaving { get; set; }
        public bool invalidForm { get; set; }
        #endregion

        public OtherInfoModel()
        {
            CompanyInfo = new AddressModel();
            AvailableBusinessStates = new List<SelectListItem>();
            AvailableBusinessCountries = new List<SelectListItem>();
        }

    }
}
