﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels
{
    public class IndividualJointInfoModel
    {                
        public int IndividualBasicId { get; set; }        

        [NopResourceDisplayName("Account.Fields.FirstName")]
        public string FirstName { get; set; }
        [NopResourceDisplayName("Account.Fields.LastName")]
        public string LastName { get; set; }
        [NopResourceDisplayName("Account.Fields.StreetAddress")]
        public string Street { get; set; }
        [NopResourceDisplayName("Account.Fields.City")]
        public string City { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int Country { get; set; }
        public IList<SelectListItem> AvailableCountries { get; set; }

        [NopResourceDisplayName("Account.Fields.StateProvince")]
        public int State { get; set; }
        public IList<SelectListItem> AvailableStates { get; set; }

        [NopResourceDisplayName("Account.Fields.ZipPostalCode")]
        public string Zip { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Address_Years")]
        public string Address_Years { get; set; }
        public IList<SelectListItem> AvailableAddressYears { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.SSN")]
        public string SSN { get; set; }




        [NopResourceDisplayName("Account.Fields.StreetAddress")]
        public string Home_Street { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.DateofBirth")]
        public string DateOfBirth { get; set; }
        [NopResourceDisplayName("Account.Fields.Phone")]
        [AllowHtml]
        public string Home_Phone { get; set; }
        [NopResourceDisplayName("Account.Fields.Email")]
        [AllowHtml]
        public string Home_Email { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Home_City")]
        public string Home_City { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int Home_Country { get; set; }
        public IList<SelectListItem> AvailableHomeCountries { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Home_State")]
        public int Home_State { get; set; }
        public IList<SelectListItem> AvailableHomeStates { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Home_Zip")]
        public string Home_Zip { get; set; }
        
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Driver_License")]
        public string Driver_License { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int Driver_Country { get; set; }
        public IList<SelectListItem> AvailableDriverCountries { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Driver_State")]
        public int Driver_State { get; set; }
        public IList<SelectListItem> AvailableDriverStates { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.USA_Citizen")]
        public bool? USA_Citizen { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int USA_Citizen_Country { get; set; }
        public IList<SelectListItem> AvailableUSACitizenCountries { get; set; }
        
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Cell_Phone")]
        public string Cell_Phone { get; set; }        



        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Name")]
        public string Employer_Name { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Street")]
        public string Employer_Street { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_City")]
        public string Employer_City { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int Employer_Country { get; set; }
        public IList<SelectListItem> AvailableEmployerCountries { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_State")]
        public int Employer_State { get; set; }
        public IList<SelectListItem> AvailableEmployerStates { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Zip")]
        public string Employer_Zip { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Business_Type")]
        public string Employer_Business_Type { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Position")]
        public string Employer_Position { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_YRS")]
        public string Employer_YRS { get; set; }
        public IList<SelectListItem> AvailableEmployerYears { get; set; }

        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Phone")]
        public string Employer_Phone { get; set; }
        [NopResourceDisplayName("ShopFast.CrowdPay.Fields.Employer_Email")]
        public string Employer_Email { get; set; }

        public IndividualJointInfoModel()
        {
            AvailableCountries = new List<SelectListItem>();
            AvailableHomeCountries = new List<SelectListItem>();
            AvailableDriverCountries = new List<SelectListItem>();
            AvailableUSACitizenCountries = new List<SelectListItem>();
            AvailableEmployerCountries = new List<SelectListItem>();

            AvailableStates = new List<SelectListItem>();
            AvailableHomeStates = new List<SelectListItem>();
            AvailableDriverStates = new List<SelectListItem>();
            AvailableEmployerStates = new List<SelectListItem>();

            AvailableAddressYears = new List<SelectListItem>();
            AvailableEmployerYears = new List<SelectListItem>();
        }
    }
}
