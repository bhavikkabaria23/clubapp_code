﻿
namespace ShopFast.Plugin.BD.CrowdPay.Models
{

    public abstract class BlockScoreResponse
    {
        public string Id { get; set; }
        public string VerificationId { get; set; }
        public string Status { get; set; }
        public Error Error { get; set; }
    }

    public class BlockScoreCustomerResponse : BlockScoreResponse
    {
        public CustomerDetails Details { get; set; }
    }

    public class BlockScoreCompanyScoreResponse : BlockScoreResponse
    {
        public string Entity_name { get; set; }

        public CompanyDetails Details { get; set; }
    }

    public class BlockScoreAdminDetails
    {
        public BlockScoreCustomerResponse Customer { get; set; }

        public BlockScoreCompanyScoreResponse Company { get; set; }
    }
    #region helpers
    public class Error
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
    }

    public class CustomerDetails
    {
        public string Address { get; set; }
        public string Address_Risk { get; set; }
        public string Identification { get; set; }
        public string Date_Of_Birth { get; set; }
        public string Ofac { get; set; }
        public string Pep { get; set; }
    }

    public class CompanyDetails
    {
        public string Address { get; set; }
        public string State { get; set; }
        public string Tax_Id { get; set; }
        public string Ofac { get; set; }
        public string Country_code { get; set; }

    }
    #endregion
}

