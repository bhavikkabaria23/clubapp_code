﻿using System.Collections.Generic;
using System.Web.Mvc;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class PersonalInformationModel
    {
        public IList<SelectListItem> PersonalInfoType { get; set; }

        public IndividualsModel IniIndividualsModel { get; set; }

        public OtherInfoModel OtherInfoModel { get; set; }

        public string SelectedPersonalInfoType { get; set; }

        public string PersonalInfoContent { get; set; }

        public bool InvestorInfoNotRequired { get; set; }
        public string openSection { get; set; }

        public PersonalInformationModel()
        {
            IniIndividualsModel = new IndividualsModel();
            OtherInfoModel = new OtherInfoModel();
            PersonalInfoType = new List<SelectListItem>();
        }

    }
}
