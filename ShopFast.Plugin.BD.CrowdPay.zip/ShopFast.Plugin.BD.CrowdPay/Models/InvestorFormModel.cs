﻿
using FluentValidation.Attributes;
using Nop.Core.Infrastructure;
using Nop.Services.Localization;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.BD.CrowdPay.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    [Validator(typeof(InvestorFormValidation))]
    public class InvestorFormModel : BaseNopEntityModel
    {
        public InvestorFormModel()
        {
            AvailableCountries = new List<SelectListItem>();
            AvailableStates = new List<SelectListItem>();
            LookingToInvestList = new List<SelectListItem>();
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest"),
                Value = ""
            });
            //LookingToInvestList.Add(new SelectListItem
            //{
            //    Text = "100-1000",
            //    Value = "1"
            //});
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest.1001-5000"),
                Value = "1"
            });
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest.5001-25000"),
                Value = "2"
            });
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest.25001-50000"),
                Value = "3"
            });
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest.50001-100000"),
                Value = "4"
            });
            LookingToInvestList.Add(new SelectListItem
            {
                Text = EngineContext.Current.Resolve<ILocalizationService>().GetResource("InvestorForm.LookingToInvest.100001-and up"),
                Value = "5"
            });            
        }        
        public int productId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.Name")]
        public string ProductName { get; set; }
        [NopResourceDisplayName("Account.Fields.FirstName")]
        public string FirstName { get; set; }
        [NopResourceDisplayName("Account.Fields.LastName")]
        public string LastName { get; set; }
        [NopResourceDisplayName("Account.Fields.Phone")]
        public string Phone { get; set; }
        [NopResourceDisplayName("Account.Fields.Email")]
        public string Email { get; set; }
        public IList<SelectListItem> AvailableCountries { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public int CountryId { get; set; }
        [NopResourceDisplayName("Account.Fields.Country")]
        public string CountryName { get; set; }
        public IList<SelectListItem> AvailableStates { get; set; }
        [NopResourceDisplayName("Account.Fields.StateProvince")]
        public int StateId { get; set; }
        [NopResourceDisplayName("Account.Fields.StateProvince")]
        public string StateName { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.LookingToInvest")]
        public int LookingToInvest { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.LookingToInvest")]
        public string LookingToInvestName { get; set; }
        public IList<SelectListItem> LookingToInvestList { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.PreferedContacts")]
        public string PreferedContacts { get; set; }

        public bool IsEmail { get; set; }
        public bool IsPhone { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.TimeToCall")]
        public string TimeToCall { get; set; }

        [NopResourceDisplayName("Account.Fields.ZipPostalCode")]
        [AllowHtml]
        public string ZipPostalCode { get; set; }

        [NopResourceDisplayName("InvestorForm.FormType")]
        [AllowHtml]
        public string FormType { get; set; }

        [NopResourceDisplayName("Admin.Orders.Fields.CreatedOn")]
        public DateTime CreatedOn { get; set; }

        [NopResourceDisplayName("InvestorForm.Language")]
        public int? LanguageId { get; set; }

        [NopResourceDisplayName("InvestorForm.Language")]
        public string Language { get; set; }

    }
}
