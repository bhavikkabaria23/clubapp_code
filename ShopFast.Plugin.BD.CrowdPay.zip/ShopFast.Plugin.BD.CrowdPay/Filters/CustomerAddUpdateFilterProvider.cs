﻿using Nop.Admin.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class CustomerAddUpdateFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CustomerController)) &&
                (actionDescriptor.ActionName.Equals("Edit") || actionDescriptor.ActionName.Equals("Create")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                return new[]
                    {
                        new Filter(new CustomerAddUpdateFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}
