using Autofac;
using Autofac.Core;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Custom.Services.Messages;
using ShopFast.Plugin.BD.CrowdPay.Data;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Filters;
using ShopFast.Plugin.BD.CrowdPay.Services.Implementations;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System.Web.Mvc;


namespace ShopFast.Plugin.BD.CrowdPay.Infrastructure
{
    /// <summary>
    /// Dependency registrar
    /// </summary>
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            FilterProviders.Providers.Add(new NDAFilterProvider());
            FilterProviders.Providers.Add(new CustomerNavigationFilterProvider());
            FilterProviders.Providers.Add(new ProductAddUpdateFilterProvider());
            FilterProviders.Providers.Add(new CustomerAddUpdateFilterProvider());

            builder.RegisterType<DocusignService>().As<IDocusignService>().InstancePerDependency();
            builder.RegisterType<BlockScoreService>().As<IBlockScoreService>().InstancePerDependency();
            builder.RegisterType<VerifyInvestorService>().As<IVerifyInvestorService>().InstancePerDependency();
            builder.RegisterType<InvestorBankAccountService>().As<IInvestorBankAccountService>().InstancePerDependency();
            builder.RegisterType<InvestorDocumentService>().As<IInvestorDocumentService>().InstancePerDependency();

            builder.RegisterType<CustomCustomerAttributeService>().As<ICustomCustomerAttributeService>().InstancePerDependency();
            builder.RegisterType<CustomAddressAttibuteParser>().As<ICustomAddressAttributeParser>().InstancePerDependency();
            builder.RegisterType<CustomCustomerAttributeParser>().As<ICustomCustomerAttributeParser>().InstancePerDependency();
            builder.RegisterType<CustomOrderProccessingService>().As<ICustomOrderProccessingService>().InstancePerDependency();
            builder.RegisterType<CustomGenericAttributeService>().As<ICustomGenericAttributeService>().InstancePerDependency();
            builder.RegisterType<CustomOrderService>().As<ICustomOrderService>().InstancePerDependency();
            builder.RegisterType<BDAddressService>().As<IBDAddressService>().InstancePerDependency();
            builder.RegisterType<WorkflowMessageServiceBD>().As<IWorkflowMessageServiceBD>().InstancePerDependency();
            builder.RegisterType<MessageTokenProviderBD>().As<IMessageTokenProviderBD>().InstancePerDependency();
            builder.RegisterType<InvestorService>().As<IInvestorService>().InstancePerDependency();

            //data context
            this.RegisterPluginDataContext<BDObjectContext>(builder, "plugin_object_context_tax_country_bd");

            //override required repository with our custom context
            builder.RegisterType<EfRepository<BD_CompanyBasicInfo>>()
                .As<IRepository<BD_CompanyBasicInfo>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
                .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_IndividualBasicInfo>>()
              .As<IRepository<BD_IndividualBasicInfo>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_IndividualJointInfo>>()
              .As<IRepository<BD_IndividualJointInfo>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_investorForm>>()
              .As<IRepository<BD_investorForm>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_SubscriptionTemplate>>()
              .As<IRepository<BD_SubscriptionTemplate>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_Documents>>()
              .As<IRepository<BD_Documents>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_VerificationTemplate>>()
              .As<IRepository<BD_VerificationTemplate>>()
              .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
              .InstancePerLifetimeScope();
            builder.RegisterType<EfRepository<BD_InvestorOrder>>()
            .As<IRepository<BD_InvestorOrder>>()
            .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
            .InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<InvestorBankAccount>>().As<IRepository<InvestorBankAccount>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
                .InstancePerLifetimeScope();

            builder.RegisterType<EfRepository<InvestorDocument>>().As<IRepository<InvestorDocument>>()
                .WithParameter(ResolvedParameter.ForNamed<IDbContext>("plugin_object_context_tax_country_bd"))
                .InstancePerLifetimeScope();
        }

        /// <summary>
        /// Order of this dependency registrar implementation
        /// </summary>
        public int Order
        {
            get { return 2; }
        }
    }
}
