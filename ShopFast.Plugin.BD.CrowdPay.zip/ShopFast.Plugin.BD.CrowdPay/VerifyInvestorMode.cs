﻿namespace ShopFast.Plugin.BD.CrowdPay
{
    /// <summary>
    /// Represents verifyinvestor.com mode
    /// </summary>
    public enum VerifyInvestorMode
    {
        /// <summary>
        /// VerifyInvestor test
        /// </summary>
        Test = 1,

        /// <summary>
        /// VerifyInvestor live 
        /// </summary>
        Live = 2
    }
}
