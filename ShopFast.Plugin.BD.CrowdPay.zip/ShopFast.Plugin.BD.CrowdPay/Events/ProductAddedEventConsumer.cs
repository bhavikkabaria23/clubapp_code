﻿using Nop.Core.Domain.Catalog;
using Nop.Core.Events;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class ProductAddedEventConsumer : IConsumer<EntityInserted<Product>>
    {
        public void HandleEvent(EntityInserted<Product> eventMessage)
        {
            var id = eventMessage.Entity.Id;
            System.Web.HttpContext.Current.Session["BD_Admin_ProductController_Create_Product_Id"] = id;
        }
    }
}