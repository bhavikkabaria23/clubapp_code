
alter table BD_investorForm
add ZipPostalCode nvarchar(max) null

alter table BD_investorForm
add FormType nvarchar(max) not null default 'Reserve Share'

alter table BD_investorForm
add CreatedOn datetime not null default GETDATE()

alter table BD_investorForm
add LanguageId int null 

CREATE TABLE [dbo].[InvestorBankAccount](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[BankName] [nvarchar](30) NULL,
	[BankSwiftCode] [nvarchar](30) NULL,
	[BankAccountType] [nvarchar](30) NULL,
	[AccountType] [nvarchar](30) NULL,
	[RoutingNumber] [nvarchar](50) NULL,
	[NameOnAccount] [nvarchar](30) NULL,
	[AccountNumber] [nvarchar](50) NULL,
	[AccountName1] [nvarchar](50) NULL,
	[AccountNumber1] [nvarchar](50) NULL,
	[ReferenceText] [nvarchar](50) NULL,
	[ContactName] [nvarchar](50) NULL,
	[PhoneNumber] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[InvestorRevenueDocument](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[DocumentId] [int] NULL,
	[DocumentTitle] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

INSERT INTO [dbo].[LocaleStringResource]
           ([LanguageId]
           ,[ResourceName]
           ,[ResourceValue])
     VALUES
           (1
           ,''
           ,'')




