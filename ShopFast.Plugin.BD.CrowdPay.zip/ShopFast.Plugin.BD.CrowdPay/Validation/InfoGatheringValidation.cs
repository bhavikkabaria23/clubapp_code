﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class InfoGatheringValidation : BaseNopValidator<InformationGatheringModel>
    {
        public InfoGatheringValidation(ILocalizationService localizationService)
        {

            RuleFor(x => x.NetWorth)
    .GreaterThan(0)
    .WithMessage(localizationService.GetResource("shopfast.fields.NetWorth.greaterthan"));

            RuleFor(x => x.AnnualIncome)
                .GreaterThan(0)
                .WithMessage(localizationService.GetResource("shopfast.fields.AnnualIncome.greaterthan"));
        }
    }
}
