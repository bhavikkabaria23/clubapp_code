﻿using FluentValidation;
using FluentValidation.Results;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class PersonalInfoValidation : BaseNopValidator<IndividualsModel>
    {
        public PersonalInfoValidation(ILocalizationService localizationService,
            IStateProvinceService stateProvinceService)
        {
            When(customer => customer.IsBasicSaving, () =>
            {
                RuleFor(x => x.DateOfBirth)
              .NotEmpty()
              .WithMessage(localizationService.GetResource("Account.Fields.DateOfBirth.Required"));
                RuleFor(x => x.Phone)
              .NotEmpty()
              .WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));
                RuleFor(x => x.FirstName)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("Account.Fields.FirstName.Required"));
                RuleFor(x => x.LastName)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.LastName.Required"));
                RuleFor(x => x.StreetAddress)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));

                RuleFor(x => x.CountryId)
                .NotEqual(0)
                .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                Custom(x =>
                {
                    //does selected country have states?
                    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.CountryId).Count > 0;
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.StateProvinceId == 0)
                        {
                            return new ValidationFailure("StateProvinceId",
                                localizationService.GetResource("Account.Fields.StateProvince.Required"));
                        }
                    }
                    return null;
                });
                RuleFor(x => x.ZipPostalCode)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));
                RuleFor(x => x.City)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.City.Required"));
                RuleFor(x => x.Address_Years)
                .NotEqual("0")
                .WithMessage(localizationService.GetResource("ShopFast.Fields.Address_Years.Required"));
                RuleFor(x => x.SSN)
                          .NotEmpty()
                          .WithMessage(localizationService.GetResource("ShopFast.Fields.SSN.Required"));
                When(customer => customer.IsJointBasicSaving, () =>
                {
                    RuleFor(x => x.IndividualJointInfoModel.FirstName)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.FirstName.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.LastName)
                  .NotEmpty()
                  .WithMessage(localizationService.GetResource("Account.Fields.LastName.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Street)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Country)
                    .NotEqual(0)
                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                    Custom(x =>
                    {
                        //does selected country have states?
                        var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.IndividualJointInfoModel.Country).Count > 0;
                        if (hasStates)
                        {
                            //if yes, then ensure that a state is selected
                            if (x.IndividualJointInfoModel.State == 0)
                            {
                                return new ValidationFailure("State",
                                    localizationService.GetResource("Account.Fields.StateProvince.Required"));
                            }
                        }
                        return null;
                    });
                    RuleFor(x => x.IndividualJointInfoModel.Zip)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.City)
                        .NotEmpty()
                        .WithMessage(localizationService.GetResource("Account.Fields.City.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Address_Years)
                    .NotEqual("0")
                    .WithMessage(localizationService.GetResource("ShopFast.Fields.Address_Years.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.SSN)
                              .NotEmpty()
                              .WithMessage(localizationService.GetResource("ShopFast.Fields.SSN.Required"));
                });
            });
            When(customer => customer.IsHomeSaving, () =>
            {
                RuleFor(x => x.Email)
               .NotEmpty()
               .WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
                RuleFor(x => x.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));
                RuleFor(x => x.Home_Address)
                          .NotEmpty()
                          .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
                RuleFor(x => x.Home_City)
                          .NotEmpty()
                          .WithMessage(localizationService.GetResource("ShopFast.Fields.Home_City.Required"));
                RuleFor(x => x.Home_Country)
                                .NotEmpty()
                                .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                Custom(x =>
                {
                    //does selected country have states?
                    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.Home_Country).Count > 0;
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.Home_State == 0)
                        {
                            return new ValidationFailure("Home_State",
                                localizationService.GetResource("ShopFast.Fields.Home_State.Required"));
                        }
                    }
                    return null;
                });
                RuleFor(x => x.Home_Zip)
                                .NotEmpty()
                                .WithMessage(localizationService.GetResource("ShopFast.Fields.Home_Zip.Required"));
                RuleFor(x => x.Driver_License)
                          .NotEmpty()
                          .WithMessage(localizationService.GetResource("ShopFast.Fields.Driver_License.Required"));
                RuleFor(x => x.Driver_Country)
                                .NotEmpty()
                                .WithMessage(localizationService.GetResource("ShopFast.CrowdPay.Fields.Driver_Country.Required"));
                Custom(x =>
                {
                    //does selected country have states?
                    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.Driver_Country).Count > 0;
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.Driver_State == 0)
                        {
                            return new ValidationFailure("Driver_State",
                                localizationService.GetResource("ShopFast.Fields.Driver_State.Required"));
                        }
                    }
                    return null;
                });
                RuleFor(x => x.USA_Citizen)
                                .NotEmpty()
                                .WithMessage(localizationService.GetResource("ShopFast.Fields.USA_Citizen.Required"));
                When(customer => !customer.USA_Citizen ?? false, () =>
                {
                    RuleFor(x => x.USA_Citizen_Country)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("ShopFast.CrowdPay.Fields.Citizen_Country.Required"));
                });
                RuleFor(x => x.Cell_Phone)
                                .NotEmpty()
                                .WithMessage(localizationService.GetResource("ShopFast.Fields.Cell_Phone.Required"));

                When(customer => customer.IsJointHomeSaving, () =>
                {
                    RuleFor(x => x.IndividualJointInfoModel.Home_Street)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.DateOfBirth)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.DateOfBirth.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Home_Phone)
                  .NotEmpty()
                  .WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Home_Email)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Home_Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));
                    RuleFor(x => x.IndividualJointInfoModel.Home_City)
                              .NotEmpty()
                              .WithMessage(localizationService.GetResource("ShopFast.Fields.Home_City.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Home_Country)
                                    .NotEmpty()
                                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                    Custom(x =>
                    {
                        //does selected country have states?
                        var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.IndividualJointInfoModel.Home_Country).Count > 0;
                        if (hasStates)
                        {
                            //if yes, then ensure that a state is selected
                            if (x.IndividualJointInfoModel.Home_State == 0)
                            {
                                return new ValidationFailure("Home_State",
                                    localizationService.GetResource("ShopFast.Fields.Home_State.Required"));
                            }
                        }
                        return null;
                    });
                    RuleFor(x => x.IndividualJointInfoModel.Home_Zip)
                                    .NotEmpty()
                                    .WithMessage(localizationService.GetResource("ShopFast.Fields.Home_Zip.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Driver_License)
                              .NotEmpty()
                              .WithMessage(localizationService.GetResource("ShopFast.Fields.Driver_License.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Driver_Country)
                                    .NotEmpty()
                                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                    Custom(x =>
                    {
                        //does selected country have states?
                        var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.IndividualJointInfoModel.Driver_Country).Count > 0;
                        if (hasStates)
                        {
                            //if yes, then ensure that a state is selected
                            if (x.IndividualJointInfoModel.Driver_State == 0)
                            {
                                return new ValidationFailure("Driver_State",
                                    localizationService.GetResource("ShopFast.Fields.Driver_State.Required"));
                            }
                        }
                        return null;
                    });
                    RuleFor(x => x.IndividualJointInfoModel.USA_Citizen)
                                    .NotEmpty()
                                    .WithMessage(localizationService.GetResource("ShopFast.Fields.USA_Citizen.Required"));
                    When(customer => !customer.IndividualJointInfoModel.USA_Citizen ?? false, () =>
                    {
                        RuleFor(x => x.IndividualJointInfoModel.USA_Citizen_Country)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                    });
                    RuleFor(x => x.IndividualJointInfoModel.Cell_Phone)
                                    .NotEmpty()
                                    .WithMessage(localizationService.GetResource("ShopFast.Fields.Cell_Phone.Required"));
                });
            });
            //Employer Information - Swection C of Personal is not required
            When(customer => customer.IsEmployerSaving, () =>
            {
                //RuleFor(x => x.Employer_Name)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Name.Required"));
                //RuleFor(x => x.Employer_Street)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Street.Required"));
                //RuleFor(x => x.Employer_City)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_City.Required"));
                //RuleFor(x => x.Employer_Country)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                //Custom(x =>
                //{
                //    //does selected country have states?
                //    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.Employer_Country).Count > 0;
                //    if (hasStates)
                //    {
                //        //if yes, then ensure that a state is selected
                //        if (x.Employer_State == 0)
                //        {
                //            return new ValidationFailure("Employer_State",
                //                localizationService.GetResource("ShopFast.Fields.Employer_State.Required"));
                //        }
                //    }
                //    return null;
                //});
                //RuleFor(x => x.Employer_Zip)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Zip.Required"));
                //RuleFor(x => x.Employer_Business_Type)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Business_Type.Required"));
                //RuleFor(x => x.Employer_Position)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Position.Required"));
                //RuleFor(x => x.Employer_YRS)
                //                .NotEqual("0")
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_YRS.Required"));
                //RuleFor(x => x.Employer_Phone)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Phone.Required"));
                //RuleFor(x => x.Employer_Email)
                //                .NotEmpty()
                //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Email.Required"));
                RuleFor(x => x.Employer_Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));

                When(customer => customer.IsJointEmployerSaving, () =>
                {
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Name)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Name.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Street)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Street.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_City)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_City.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Country)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                    //Custom(x =>
                    //{
                    //    //does selected country have states?
                    //    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.IndividualJointInfoModel.Employer_Country).Count > 0;
                    //    if (hasStates)
                    //    {
                    //        //if yes, then ensure that a state is selected
                    //        if (x.IndividualJointInfoModel.Employer_State == 0)
                    //        {
                    //            return new ValidationFailure("Employer_State",
                    //                localizationService.GetResource("ShopFast.Fields.Employer_State.Required"));
                    //        }
                    //    }
                    //    return null;
                    //});
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Zip)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Zip.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Business_Type)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Business_Type.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Position)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Position.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_YRS)
                    //                .NotEqual("0")
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_YRS.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Phone)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Phone.Required"));
                    //RuleFor(x => x.IndividualJointInfoModel.Employer_Email)
                    //                .NotEmpty()
                    //                .WithMessage(localizationService.GetResource("ShopFast.Fields.Employer_Email.Required"));
                    RuleFor(x => x.IndividualJointInfoModel.Employer_Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));
                });
            });
            When(customer => customer.IsIncomeSaving, () =>
            {
                Custom(x =>
                {
                    //does selected country have states?
                    if (!x.Income1 && !x.Income2 && !x.Income2)
                    {
                        return new ValidationFailure("Income1",
                            localizationService.GetResource("ShopFast.Fields.Income1.Required"));
                    }
                    return null;
                });
            });
        }
    }
}
