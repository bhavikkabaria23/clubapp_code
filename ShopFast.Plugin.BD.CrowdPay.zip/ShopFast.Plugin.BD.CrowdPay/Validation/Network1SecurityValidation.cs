﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class Network1SecurityValidation : BaseNopValidator<Network1SecurityModel>
    {
        public Network1SecurityValidation(ILocalizationService localizationService)
        {
            When(n => n.IsNetwork1Security ?? false, () =>
            {
                RuleFor(x => x.AccountNumber)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("BD.Network1Security.AccountNumber.Required"));
                RuleFor(x => x.AssociatedBroker)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("BD.Network1Security.AssociatedBroker.Required"));
            });
        }
    }
}
