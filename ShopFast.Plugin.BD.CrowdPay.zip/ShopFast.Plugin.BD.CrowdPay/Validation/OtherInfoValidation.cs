﻿using FluentValidation;
using FluentValidation.Results;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class OtherInfoValidation : BaseNopValidator<OtherInfoModel>
    {
        public OtherInfoValidation(ILocalizationService localizationService,
            IStateProvinceService stateProvinceService)
        {
            When(customer => customer.IsBasicSaving, () =>
            {
                RuleFor(x => x.CompanyInfo.Email)
              .NotEmpty()
              .WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
                RuleFor(x => x.CompanyInfo.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));

                //form fields

                RuleFor(x => x.CompanyInfo.CountryId)
                    .NotEqual(0)
                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));


                Custom(x =>
                {
                    //does selected country have states?
                    var hasStates = x.CompanyInfo.CountryId.HasValue && stateProvinceService.GetStateProvincesByCountryId(x.CompanyInfo.CountryId.Value).Count > 0;
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.CompanyInfo.StateProvinceId == 0)
                        {
                            return new ValidationFailure("StateProvinceId",
                                localizationService.GetResource("Account.Fields.StateProvince.Required"));
                        }
                    }
                    return null;
                });


                RuleFor(x => x.CompanyInfo.Address1)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));


                RuleFor(x => x.CompanyInfo.ZipPostalCode)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));

                RuleFor(x => x.CompanyInfo.City)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.City.Required"));



                RuleFor(x => x.CompanyInfo.Company)
        .NotEmpty()
        .WithMessage(localizationService.GetResource("ShopFast.Fields.Company.Required"));
                RuleFor(x => x.ContactName)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("ShopFast.Fields.ContactName.Required"));

                Custom(x =>
                {
                    if (x.SelfDirected && string.IsNullOrEmpty(x.VestingName))
                    {
                        return new ValidationFailure("VestingName",
                                    localizationService.GetResource("ShopFast.Fields.VestingName.Required"));
                    }
                    return null;
                });

                Custom(x =>
                {
                    if (string.IsNullOrEmpty(x.CompanyInfo.FirstName) || string.IsNullOrEmpty(x.CompanyInfo.LastName))
                    {
                        return null;
                    }
                    return null;
                });


                RuleFor(x => x.RegionFormed)
       .NotEmpty()
       .WithMessage(localizationService.GetResource("ShopFast.Fields.RegionFormed.Required"));
                RuleFor(x => x.CompanyInfo.PhoneNumber)
             .NotEmpty()
             .WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));
                RuleFor(x => x.CompanyInfo.FaxNumber)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.Fax.CompanyInfo.Required"));
            });
            When(customer => customer.IsBusinessSaving, () =>
            {
                RuleFor(x => x.CompanyInfo.Address2)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("Account.Fields.StreetAddress2.Required"));               
                RuleFor(x => x.Business_City)
             .NotEmpty()
             .WithMessage(localizationService.GetResource("ShopFast.Fields.Business_City.Required"));
                RuleFor(x => x.Business_Country)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
                Custom(x =>
                {
                    //does selected country have states?
                    var hasStates = stateProvinceService.GetStateProvincesByCountryId(x.Business_Country).Count > 0;
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.Business_State == 0)
                        {
                            return new ValidationFailure("Business_State",
                                localizationService.GetResource("Account.Fields.Business_State.Required"));
                        }
                    }
                    return null;
                });
                RuleFor(x => x.Business_Zip)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("ShopFast.Fields.Business_Zip.Required"));
                RuleFor(x => x.Business_Website)
                    .NotEmpty()
                   .WithMessage(localizationService.GetResource("ShopFast.Fields.Business_Website.Required"));
                RuleFor(x => x.EIN)
                    .NotEmpty()
                   .WithMessage(localizationService.GetResource("ShopFast.Fields.EIN.Required"));
            });
        }
    }
}
