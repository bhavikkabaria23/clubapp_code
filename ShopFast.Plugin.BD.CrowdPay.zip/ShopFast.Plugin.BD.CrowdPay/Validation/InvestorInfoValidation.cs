﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.Other.CrowdPay.Models;

namespace ShopFast.Plugin.Other.CrowdPay.Validation
{
    public class InvestorInfoValidation : BaseNopValidator<InvestorInformationModel>
    {
        public InvestorInfoValidation(ILocalizationService localizationService)
        {
            RuleFor(x => x.CustomerSignature).NotEmpty().
                WithMessage(localizationService.GetResource("shopfast.fields.customersignature.required")); ;
        }
    }
}
