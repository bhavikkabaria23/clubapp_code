﻿using System.Collections.Generic;
using Nop.Core.Domain.Customers;

namespace ShopFast.Plugin.Other.CrowdPay.Services.Interfaces
{
    public interface ICrowdPayCustomerAttributeService
    {
        IList<CustomerAttributeValue>  GetCustomerAttributeValuesByName(string attrName);

        void SaveCustomAttributeValue(Customer customer, string attrName, string value);

    }
}
