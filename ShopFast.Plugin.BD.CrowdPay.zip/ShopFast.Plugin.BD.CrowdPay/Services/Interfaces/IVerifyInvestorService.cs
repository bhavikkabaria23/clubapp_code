﻿using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public  interface IVerifyInvestorService
    {
        void VerifyCustomer(int viUserId, out string redirectUrl);

        UserVerificationStatus GetUserVerificationStatus(int userId);

        byte[] GetVerificationCertificate(int viUserId);

        string GetRedirectUrlForInvestor(int vi_user_id);
    }
}
