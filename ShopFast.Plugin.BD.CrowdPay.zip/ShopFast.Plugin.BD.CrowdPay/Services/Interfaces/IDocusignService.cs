﻿using ShopFast.Plugin.BD.CrowdPay.Models;
using System.IO;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public interface IDocusignService
    {
        string GenerateSigningSessionUrl(string attributeName, int productId, string pdf);

        Stream GetDocumentFromTemplate(string templateId);
    }
}
