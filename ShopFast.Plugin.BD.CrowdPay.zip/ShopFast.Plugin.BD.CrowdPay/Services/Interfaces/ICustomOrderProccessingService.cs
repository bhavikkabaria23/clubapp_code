﻿using Nop.Services.Orders;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public interface ICustomOrderProccessingService : IOrderProcessingService
    {
        void InitOrderProcessing(int productId, int quantity);
    }
}
