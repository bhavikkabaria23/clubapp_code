﻿using Nop.Core.Domain.Customers;
using Nop.Services.Customers;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public interface ICustomCustomerAttributeParser : ICustomerAttributeParser
    {
        string UpdateCustomerAttribute(string attributesXml, CustomerAttribute ca, string value);

        string ParseCustomCustomerAttributes(string attributesXml, string attrName, string value);

        string ParseCustomCustomerAttributesValues(string attributesXml, string attrName);

    }
}
