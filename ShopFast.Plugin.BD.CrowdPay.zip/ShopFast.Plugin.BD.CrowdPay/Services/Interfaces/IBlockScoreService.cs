﻿using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Models.PersonalInfoModels;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public interface IBlockScoreService
    {
        void VerifyCustomer(IndividualsModel model);

        void VerifyCompany(PersonalInformationModel model);

    }
}
