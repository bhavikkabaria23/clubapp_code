using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using Nop.Core.Data;
using Nop.Services.Events;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class InvestorBankAccountService : IInvestorBankAccountService
    {
        #region Fields

        private readonly IRepository<InvestorBankAccount> _investorBankAccountRepository;
        private readonly IEventPublisher _eventPublisher;

        #endregion

        #region Ctor

        public InvestorBankAccountService(IRepository<InvestorBankAccount> investorBankAccountRepository,
            IEventPublisher eventPublisher)
        {
            this._investorBankAccountRepository = investorBankAccountRepository;
            this._eventPublisher = eventPublisher;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Inserts a InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        public void InsertInvestorBankAccount(InvestorBankAccount investorbankAccount)
        {
            if (investorbankAccount == null)
                throw new ArgumentNullException("investorbankAccount");

            _investorBankAccountRepository.Insert(investorbankAccount);
            _eventPublisher.EntityInserted(investorbankAccount);
        }

        /// <summary>
        /// Updates a InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        public void UpdateInvestorBankAccount(InvestorBankAccount investorbankAccount)
        {
            if (investorbankAccount == null)
                throw new ArgumentNullException("investorbankAccount");

            _investorBankAccountRepository.Update(investorbankAccount);
            _eventPublisher.EntityUpdated(investorbankAccount);
        }

        /// <summary>
        /// Deletes a InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        public void DeleteInvestorBankAccount(InvestorBankAccount investorbankAccount)
        {
            if (investorbankAccount == null)
                throw new ArgumentNullException("investorbankAccount");

            _investorBankAccountRepository.Delete(investorbankAccount);
            _eventPublisher.EntityDeleted(investorbankAccount);
        }

        public InvestorBankAccount GetInvestorBankAccountById(int customerId)
        {
            if (customerId == 0)
                return null;

            var query = from iba in _investorBankAccountRepository.Table
                        where iba.CustomerId == customerId
                        select iba;

            return query.FirstOrDefault();
        }

        #endregion
    }
}
