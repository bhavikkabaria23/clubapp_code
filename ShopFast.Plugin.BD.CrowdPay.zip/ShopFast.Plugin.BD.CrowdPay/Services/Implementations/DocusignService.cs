﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Models;
using Nop.Services.Logging;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    /// <summary>
    /// DocuSign Integration
    /// </summary>
    public class DocusignService : IDocusignService
    {
        private readonly ISettingService _settingService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IProductService _productService;
        private readonly ILocalizationService _localizationService;
        private readonly IWebHelper _webHelper;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly IBDAddressService _bDAddressService;
        private readonly ILogger _logger;

        public DocusignService(ISettingService settingService, IWorkContext workContext,
            IStoreContext storeContext, IProductService productService, ILocalizationService localizationService,
            IWebHelper webHelper, ICustomGenericAttributeService customGenericAttributeService,
            IBDAddressService bDAddressService,
            ILogger logger)
        {
            _settingService = settingService;
            _workContext = workContext;
            _storeContext = storeContext;
            _productService = productService;
            _localizationService = localizationService;
            _webHelper = webHelper;
            _customGenericAttributeService = customGenericAttributeService;
            _bDAddressService = bDAddressService;
            this._logger = logger;
        }

        /// <summary>
        /// Generates special url for the Signing Ceremony beginning
        /// </summary>
        /// <param name="attributeName">Attribute that contains docusign template Id</param>
        /// <param name="productId">Product that associated with attribute</param>
        /// <returns>Url session</returns>
        public string GenerateSigningSessionUrl(string attributeName, int productId, string pdf)
        {
            try
            {
                var product = _productService.GetProductById(productId);
                if (product != null)
                {
                    //var docuSignSettings = _settingService.LoadSetting<CrowdPaySettings>();
                    var docuSignSettings = _bDAddressService.GetSubscriptionTemplateByProduct(productId);

                    // initialize client for desired environment (for production change to www)
                    ApiClient apiClient = new ApiClient(docuSignSettings.DocuSignMode == Convert.ToInt32(DocuSignMode.Test) ? ClientConstants.ExternalApi.DocuSignApiTest
                        : ClientConstants.ExternalApi.DocuSignApi);
                    var baseUrl = docuSignSettings.DocuSignMode == Convert.ToInt32(DocuSignMode.Test) ? ClientConstants.ExternalApi.DocuSignApiTest
                        : ClientConstants.ExternalApi.DocuSignApi;
                    _logger.Information("ApiClient BaseUrl: " + baseUrl);
                    Configuration.Default.ApiClient = apiClient;

                    // configure 'X-DocuSign-Authentication' header
                    string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                        docuSignSettings.DocusignUsername, docuSignSettings.DocusignPassword, docuSignSettings.DocuSignIntegratorKey), "}");
                    if (!Configuration.Default.DefaultHeader.Any())
                        Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);


                    /* ---------- Step 1: Login API ----------  */
                    // login call is available in the authentication api 
                    AuthenticationApi authApi = new AuthenticationApi();
                    LoginInformation loginInfo = authApi.Login();

                    // parse the first account ID that is returned (user might belong to multiple accounts)
                    var accountId = loginInfo.LoginAccounts[0].AccountId;

                    // Update ApiClient with the new base url from login call
                    _logger.Information("ApiClient NewBaseUrl: " + loginInfo.LoginAccounts[0].BaseUrl);
                    apiClient = new ApiClient(loginInfo.LoginAccounts[0].BaseUrl);


                    /* ---------- Step 2: Create Envelope API ---------- */
                    // create a new envelope which we will use to send the signature request
                    var notification = _localizationService.GetLocaleStringResourceByName("shopfast.titles.docusignemailnotification");
                    EnvelopeDefinition envDef = new EnvelopeDefinition();
                    envDef.EmailSubject = String.Format("{0} - {1} - {2}", _storeContext.CurrentStore.Name, notification != null ? notification.ResourceValue : String.Empty, product.Name);

                    // Add a document to the envelope
                    byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(pdf);
                    var investorPdfDocument = new Document();
                    investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
                    investorPdfDocument.Name = "Subscription Agreement.pdf";
                    investorPdfDocument.DocumentId = "1";
                    envDef.Documents = new List<Document>();
                    envDef.Documents.Add(investorPdfDocument);

                    // Add a recipient to sign the documeent
                    Signer signer = new Signer();
                    signer.Email = _workContext.CurrentCustomer.Email;
                    signer.Name = String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName), _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName));
                    signer.RecipientId = "1";
                    signer.ClientUserId = _workContext.CurrentCustomer.Id.ToString();

                    // Create a |SignHere| tab somewhere on the document for the recipient to sign
                    signer.Tabs = new Tabs();
                    signer.Tabs.SignHereTabs = new List<SignHere>();
                    SignHere signHere = new SignHere();
                    signHere.DocumentId = "1";
                    signHere.PageNumber = "11";
                    signHere.RecipientId = "1";
                    signHere.XPosition = "120";
                    signHere.YPosition = "250";
                    signer.Tabs.SignHereTabs.Add(signHere);

                    signer.Tabs.TitleTabs = new List<Title>();
                    Title title = new Title();
                    title.DocumentId = "1";
                    title.PageNumber = "11";
                    title.RecipientId = "1";
                    title.XPosition = "115";
                    title.YPosition = "409";
                    title.Width = 210;
                    title.Font = "TimesNewRoman";
                    title.FontSize = "Size12";
                    title.FontColor = "BrightBlue";
                    title.Required = "false";
                    signer.Tabs.TitleTabs.Add(title);


                    signer.Tabs.RadioGroupTabs = new List<RadioGroup>();
                    RadioGroup radioGroup1 = new RadioGroup { DocumentId = "1", RecipientId = "1", GroupName = "USPerson" };
                    radioGroup1.Radios = new List<Radio>();
                    radioGroup1.Radios.Add(new Radio { PageNumber = "11", XPosition = "70", YPosition = "478", Required = "false" });
                    radioGroup1.Radios.Add(new Radio { PageNumber = "11", XPosition = "70", YPosition = "492", Required = "false" });

                    RadioGroup radioGroup2 = new RadioGroup { DocumentId = "1", RecipientId = "1", GroupName = "InvestorType" };
                    radioGroup2.Radios = new List<Radio>();
                    radioGroup2.Radios.Add(new Radio { PageNumber = "11", XPosition = "70", YPosition = "518", Required = "false" });
                    radioGroup2.Radios.Add(new Radio { PageNumber = "11", XPosition = "70", YPosition = "532", Required = "false" });

                    signer.Tabs.RadioGroupTabs.Add(radioGroup1);
                    signer.Tabs.RadioGroupTabs.Add(radioGroup2);

                    signer.Tabs.CheckboxTabs = new List<Checkbox>();
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "11", XPosition = "70", YPosition = "573", TabLabel = "ch1" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "11", XPosition = "70", YPosition = "613", TabLabel = "ch2" });


                    RadioGroup radioGropup3 = new RadioGroup { DocumentId = "1", RecipientId = "1", GroupName = "Schedule K-1" };
                    radioGropup3.Radios = new List<Radio>();
                    radioGropup3.Radios.Add(new Radio { PageNumber = "13", XPosition = "85", YPosition = "187", Required = "false" });
                    radioGropup3.Radios.Add(new Radio { PageNumber = "13", XPosition = "85", YPosition = "251", Required = "false" });
                    signer.Tabs.RadioGroupTabs.Add(radioGropup3);

                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "165", TabLabel = "ch3" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "217", TabLabel = "ch4" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "257", TabLabel = "ch5" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "365", TabLabel = "ch6" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "460", TabLabel = "ch7" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "500", TabLabel = "ch8" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "14", XPosition = "80", YPosition = "553", TabLabel = "ch9" });

                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "15", XPosition = "80", YPosition = "69", TabLabel = "ch10" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "15", XPosition = "80", YPosition = "177", TabLabel = "ch11" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "15", XPosition = "80", YPosition = "299", TabLabel = "ch12" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "15", XPosition = "80", YPosition = "408", TabLabel = "ch13" });
                    signer.Tabs.CheckboxTabs.Add(new Checkbox { DocumentId = "1", RecipientId = "1", PageNumber = "15", XPosition = "80", YPosition = "557", TabLabel = "ch14" });

                    RadioGroup radioGropup4 = new RadioGroup { DocumentId = "1", RecipientId = "1", GroupName = "Undersigned" };
                    radioGropup4.Radios = new List<Radio>();
                    radioGropup4.Radios.Add(new Radio { PageNumber = "16", XPosition = "345", YPosition = "200", Required = "false" });
                    radioGropup4.Radios.Add(new Radio { PageNumber = "16", XPosition = "333", YPosition = "305", Required = "false" });
                    signer.Tabs.RadioGroupTabs.Add(radioGropup4);


                    var specAttr = product.ProductSpecificationAttributes.SingleOrDefault(x => x.SpecificationAttributeOption.SpecificationAttribute.Name == attributeName);
                    if (specAttr != null)
                    {
                        envDef.Recipients = new Recipients();
                        envDef.Recipients.Signers = new List<Signer>();
                        envDef.Recipients.Signers.Add(signer);

                        // set envelope status to "sent" to immediately send the signature request
                        envDef.Status = "sent";
                        // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
                        EnvelopesApi envelopesApi = new EnvelopesApi();
                        EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);

                        RecipientViewRequest viewOptions = new RecipientViewRequest()
                        {
                            ReturnUrl = String.Format("{0}/crowdpay/SigningResult?documentType={1}&productId={2}", _webHelper.GetStoreLocation(), attributeName, productId),
                            ClientUserId = _workContext.CurrentCustomer.Id.ToString(),  // must match clientUserId set in step #2!
                            AuthenticationMethod = "email",
                            UserName = String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName), _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName)),
                            Email = _workContext.CurrentCustomer.Email,
                        };

                        // create the recipient view(aka signing URL)
                        ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

                        return recipientView.Url;
                    }
                    else
                    {
                        throw new Exception("Can't find docusign template by provided id");
                    }
                }

                return String.Empty;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }

        // This is not in use
        /// <summary>
        /// Old logic...
        /// </summary>
        /// <param name="templateId"></param>
        /// <returns></returns>
        public Stream GetDocumentFromTemplate(string templateId)
        {
            try
            {
                ApiClient apiClient = new ApiClient(ClientConstants.ExternalApi.DocuSignApi);
                Configuration.Default.ApiClient = apiClient;

                var settings = _settingService.LoadSetting<CrowdPaySettings>();                

                string authHeader = "{\"Username\":\"" + settings.DocuSignUserName + "\", \"Password\":\"" + settings.DocuSignPassword + "\", \"IntegratorKey\":\"" + settings.IntegratorKey + "\"}";
                if (!Configuration.Default.DefaultHeader.ContainsKey("X-DocuSign-Authentication"))
                {
                    Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);
                }

                string accountId = null;

                AuthenticationApi authApi = new AuthenticationApi();
                LoginInformation loginInfo = authApi.Login();

                accountId = loginInfo.LoginAccounts[0].AccountId;

                EnvelopesApi envelopesApi = new EnvelopesApi();

                EnvelopeDocumentsResult docsList = envelopesApi.ListDocuments(accountId, templateId);

                if (docsList.EnvelopeDocuments.Any())
                {
                    var document = envelopesApi.GetDocument(accountId, templateId, docsList.EnvelopeDocuments[0].DocumentId);
                    return document;
                }

                return Stream.Null;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
    }
}
