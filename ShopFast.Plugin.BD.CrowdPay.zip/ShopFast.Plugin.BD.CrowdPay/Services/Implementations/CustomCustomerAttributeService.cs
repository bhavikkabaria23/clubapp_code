﻿using System.Collections.Generic;
using System.Linq;
using Nop.Core.Domain.Customers;
using Nop.Services.Common;
using Nop.Services.Customers;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class CustomCustomerAttributeService : ICustomCustomerAttributeService
    {
        private readonly ICustomerAttributeService _customerAttributeService;
        private readonly ICustomerAttributeParser _customerAttributeParser;
        private readonly IGenericAttributeService _genericAttributeService;

        public CustomCustomerAttributeService(ICustomerAttributeService customerAttributeService, ICustomerAttributeParser customerAttributeParser, IGenericAttributeService genericAttributeService)
        {
            _customerAttributeService = customerAttributeService;
            _customerAttributeParser = customerAttributeParser;
            _genericAttributeService = genericAttributeService;
        }

        public IList<CustomerAttributeValue> GetCustomerAttributeValuesByName(string attrName)
        {
            var attribute = _customerAttributeService.GetAllCustomerAttributes().FirstOrDefault(x => x.Name == attrName);

            return attribute != null ? _customerAttributeService.GetCustomerAttributeValues(attribute.Id) : new List<CustomerAttributeValue>();
        }

        public IDictionary<CustomerAttribute, IList<CustomerAttributeValue>> GetCustomerAttributeByName(string attrName)
        {
            var attribute = _customerAttributeService.GetAllCustomerAttributes().FirstOrDefault(x => x.Name == attrName);
            var resultDictionary = new Dictionary<CustomerAttribute, IList<CustomerAttributeValue>>();
            if (attribute != null)
            {
                var attributeValues = _customerAttributeService.GetCustomerAttributeValues(attribute.Id);
                if (attributeValues.Any())
                {
                    resultDictionary.Add(attribute, attributeValues);
                }
            }
            return resultDictionary;
        }

        public void SaveCustomAttributeValue(Customer customer, string attrName, string value)
        {
            var customAttrsXml = ParseCustomCustomerAttributes(attrName, value);
            _genericAttributeService.SaveAttribute(customer, SystemCustomerAttributeNames.CustomCustomerAttributes,
                customAttrsXml);
        }

        private string ParseCustomCustomerAttributes(string attrName, string value)
        {

            string attributesXml = "";
            var attributes = _customerAttributeService.GetAllCustomerAttributes();
            foreach (var attribute in attributes)
            {
                if (attribute.Name == attrName)
                {
                    attributesXml = _customerAttributeParser.AddCustomerAttribute(attributesXml,
               attribute, value);
                }
            }

            return attributesXml;
        }
    }
}
