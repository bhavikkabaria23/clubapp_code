using System;
using System.Linq;
using Nop.Core.Data;
using Nop.Services.Events;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class InvestorDocumentService : IInvestorDocumentService
    {
        #region Fields

        private readonly IRepository<InvestorDocument> _investorDocumentRepository;
        private readonly IEventPublisher _eventPublisher;

        #endregion

        #region Ctor

        public InvestorDocumentService(IRepository<InvestorDocument> investorDocumentRepository,
                        IEventPublisher eventPublisher)
        {
            this._investorDocumentRepository = investorDocumentRepository;
            this._eventPublisher = eventPublisher;
        }


        #endregion

        #region Methods

        /// <summary>
        /// Inserts an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        public void InsertInvestorDocument(InvestorDocument investorDocument)
        {
            if (investorDocument == null)
                throw new ArgumentNullException("investorDocument");

            _investorDocumentRepository.Insert(investorDocument);
            _eventPublisher.EntityInserted(investorDocument);
        }

        /// <summary>
        /// Updates an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        public void UpdateInvestorDocument(InvestorDocument investorDocument)
        {
            if (investorDocument == null)
                throw new ArgumentNullException("investorDocument");

            _investorDocumentRepository.Update(investorDocument);
            _eventPublisher.EntityUpdated(investorDocument);
        }

        /// <summary>
        /// Deletes an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        public void DeleteInvestorDocument(InvestorDocument investorDocument)
        {
            if (investorDocument == null)
                throw new ArgumentNullException("investorDocument");

            _investorDocumentRepository.Delete(investorDocument);
            _eventPublisher.EntityDeleted(investorDocument);
        }

        /// <summary>
        /// Gets an InvestorDocument by customer identifier
        /// </summary>
        /// <param name="customerId">customer identifier</param>
        /// <returns>investor documents by customer identifier</returns>
        public InvestorDocument GetInvestorDocumentByCustomerId(int customerId)
        {
            if (customerId == 0)
                return null;

            var query = from idoc in _investorDocumentRepository.Table
                        where idoc.CustomerId == customerId
                        select idoc;

            return query.FirstOrDefault();
        }

    #endregion
    }
}
