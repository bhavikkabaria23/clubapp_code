﻿namespace ShopFast.Plugin.BD.CrowdPay
{
    /// <summary>
    /// Represents docusign mode
    /// </summary>
    public enum DocuSignMode
    {
        /// <summary>
        /// DocuSign test mode
        /// </summary>
        Test = 5,

        /// <summary>
        /// DocuSign live mode
        /// </summary>
        Live = 10
    }
}
