﻿namespace ShopFast.Plugin.BD.CrowdPay.Common
{
    public static class ClientConstants
    {
        public class CustomAttributes
        {
            public const string PersonalInfoType = "PersonalInfo type";
            public const string TaxId = "Tax Id";
            public const string InvestorType = "Investor type";
            public const string AccreditedQualify = "Accredited Qualify";
            public const string BackUpWithholding = "BackUp Withholding";
            public const string AnnualIncome = "Annual Income";
            public const string NetWorth = "Net Worth";
            public const string VestingName = "Vesting Name";
            public const string ContactName = "Contact Name";
            public const string RegionFormedIn = "Region Formed";
            public const string CompanyAddress = "Company Address";
            //public const string EIN = "Employer Identification Number (EIN)";

            // All Other customer attributes for "Individual" (PDF 1)
            //public const string Address_Years = "Address_Years";
            //public const string Home_City = "Home_City";
            ////public const string Home_Country = "Home_Country";
            //public const string Home_Country = "Home_Country"; // DropdownList
            //public const string Home_State = "Home_State"; // DropdownList
            //public const string Home_Zip = "Home_Zip";
            //public const string SSN = "SSN";
            //public const string Driver_License = "Driver_License";
            //public const string Driver_State = "Driver_State";
            //public const string USA_Citizen = "USA_Citizen";
            //public const string Cell_Phone = "Cell_Phone";
            //public const string Employer_Name = "Employer_Name";
            //public const string Employer_Street = "Employer_Street";
            //public const string Employer_City = "Employer_City";
            //public const string Employer_Country = "Employer_Country"; // DropdownList
            //public const string Employer_State = "Employer_State"; // DropdownList
            //public const string Employer_Zip = "Employer_Zip";
            //public const string Employer_Business_Type = "Employer_Business_Type";
            //public const string Employer_Position = "Employer_Position";
            //public const string Employer_YRS = "Employer_YRS";
            //public const string Employer_Phone = "Employer_Phone";
            //public const string Employer_Email = "Employer_Email";
            //public const string Income1 = "Income1";
            //public const string Income2 = "Income2";
            //public const string Income3 = "Income3";

            // All Other address attributes for "Company" (PDF 2)
            //public const string Business_City = "Business_City";
            //public const string Business_Country = "Business_Country"; // DropdownList
            //public const string Business_State = "Business_State"; // DropdownList
            //public const string Business_Zip = "Business_Zip";
            //public const string Business_Website = "Business_Website";

            //Block score customer attributes
            public const string BlockScoreAdressMatch = "BlockScore_AddressMatch";
            public const string BlockScoreAdressRisk = "BlockScore_AddressRisk";
            public const string BlockScorePassportMatch = "BlockScore_CustomerPassportMatch";
            public const string BlockScoreDateOfBirthMath = "BlockScore_CustomerBirthMatch";
            public const string BlockScoreOfacMath = "BlockScore_OfacMatch";
            public const string BlockScorePepMatch = "BlockScore_PepMatch";
            public const string BlockScoreObjectId = "BlockScore_ObjectId";
            public const string BlockScoreStatus = "BlockScore_ObjectStatus";

            //Block score company attributes
            public const string BlockScoreCompanyNameMatch = "BlockScore_CompanyNameMatch";
            public const string BlockScoreStateMatch = "BlockScore_CompanyStateMatch";
            public const string BlockScoreTaxIdMatch = "BlockScore_CompanyTaxIdMatch";
            public const string BlockScoreCompanyCountryCodeMatch = "BlockScore_CompanyCountryCodeMatch";
        }

        public class OfferingType
        {
            public const int type_506b = 1;//"506 b"
            public const int type_506c = 2;//"506 c"
            public const int type_title3 = 3;//"Title III";           
            public const int type_rega_tier1 = 4;// "Reg A+ Tier 1"
            public const int type_rega_tier2 = 5;//"Reg A+ Tier 2"
            public const int type_S_1_IPO = 6;//"S-1 (IPO - Initial Public Offering)"
        }

        public class PersonalInfoType
        {
            public const string Individual = "Individual(s)";
            public const string Company = "Company";
            public const string Trust = "Trust";
            public const string SelfDirectedIRA = "Self-Directed IRA";
        }

        public class InvestorType
        {
            public const string NonAccreditted = "Non-Accredited";
            public const string Accreddited = "Accredited";
        }

        public class QualiflyOptions
        {
            public const string IndividualNetworth = "Individual net worth";
            public const string IndividualWithIncome = "Individual with income";
            public const string Business = "Business";
            public const string Bank = "Bank";
            public const string Corporation = "Corporation";
            public const string Employee = "Employee";
            public const string TrustWithAsset = "TrustWithAsset";
        }

        public class BackupWithholdingOptions
        {
            public const string Exempt = "Exempt";
            public const string NotExempt = "Not exempt";
        }

        public class Localization
        {
            public class LocalizationKey
            {
                public const string ShopFastPrefix = "ShopFast.CrowdPay.{0}.{1}";
            }

            public class KeyTypes
            {
                public const string Fields = "Fields";
                public const string WizardStep = "wizardstep";
                public const string Tip = "Tip";
            }
        }

        public class FormPrefix
        {
            public const string IndividualPrefix = "IndividualPrefix";
            public const string InfoGatheringPrefix = "InfoGatheringPrefix";
            public const string PurchasePrefix = "PurchasePrefix";
            public const string PaymentInfoPrefix = "PaymentInfoPrefix";
            public const string SubscriptionAgreementPrefix = "SubscriptionAgreementPrefix";
            public const string ConfirmPrefix = "ConfirmPrefix";
        }

        public class SpecificationAttributeName
        {
            public const string InvestorInfoTemplateId = "InvestorInfoTemplateId";
            public const string SubscriptionAgreementTemplateId = "SubscriptionAgreementTemplateId";
        }



        public class ExternalApi
        {
            public const string DocuSignApi = "https://www.docusign.net/restapi";
            public const string DocuSignApiTest = "https://demo.docusign.net/restapi";
            public const string BlackScoreApi = "https://api.blockscore.com/";
            public const string VerifyInvestor = "https://verifyinvestor.com/api/v1";
            public const string VerifyInvestorTest = "https://verifyinvestor-api-staging.herokuapp.com/";
        }

        public class DocuSign
        {
            public class SigningResult
            {
                public const string Cancel = "cancel";
                public const string Decline = "decline";
                public const string Exception = "exception";
                public const string SessionExpired = "session_timeout";
                public const string Complete = "signing_complete";
                public const string TtlExpired = "ttl_expired";
            }

            public class RoleNameTemplate
            {
                public const string Customer = "Customer";
            }
        }

        public class VerifyInvestor
        {
            public class CustomerFormAttributes
            {
                public const string Email = "issuer_email";
                public const string CompanyName = "deal_name";
                public const string PortalName = "portal_name";
                public const string RedirectUrl = "redirect_url";
            }

            public class StatusCode
            {
                public const string PendingVerification = "422";
            }

            public class InvestorValidationStatus
            {
                public const string Unverified = "unverified";
                public const string Verified = "verified";
                public const string PendingVerification = "pending_verification";
                public const string WaitingForInvestorAcceptance = "waiting_for_investor_acceptance";
                public const string WaitingForReview = "waiting_for_review";
                public const string NoRequest = "no_verification_request";
                public const string WaitingForInfoFromInvestor = "waiting_for_information_from_investor";
                public const string DeclinedByInvestor = "declined_by_investor";
                public const string DeclinedExpire = "declined_expire";
                public const string AcceptedExpire = "accepted_expire";
            }

            public class ErrorMessages
            {
                public const string OkError = "A pending verification request already exists.";
            }
        }

        public class BlockScore
        {
            public class CustomerFormAttributes
            {
                public const string FirstName = "name_first";
                public const string LastName = "name_last";
                public const string BirthDay = "birth_day";
                public const string BirthMonth = "birth_month";
                public const string BirthYear = "birth_year";
                public const string DocumentType = "document_type";
                public const string DocumentValue = "document_value";
                public const string Street1 = "address_street1";
                public const string Street2 = "address_street2";
                public const string City = "address_city";
                public const string State = "address_subdivision";
                public const string PostalCode = "address_postal_code";
                public const string CountryCode = "address_country_code";
                public const string Phone = "phone_number";
                public const string CustomerId = "id";
            }

            public class CompanyFormAttributes
            {
                public const string CompanyName = "entity_name";
                public const string TaxId = "tax_id";
                public const string CorporationCountryCode = "incorporation_country_code";
                public const string StateCode = "incorporation_state";
                public const string CorporationType = "incorporation_type";
                public const string Email = "email";
                public const string Phone = "phone_number";
                public const string Street1 = "address_street1";
                public const string Street2 = "address_street2";
                public const string City = "address_city";
                public const string State = "address_subdivision";
                public const string PostalCode = "address_postal_code";
                public const string CountryCode = "address_country_code";
                public const string CompanyId = "id";
            }

            public class VerificationType
            {
                public const string Customer = "people";
                public const string Company = "companies";
            }

            public class PassportTypes
            {
                public const string SSN = "ssn";
                public const string PASSPORT = "passport";
            }

            public class CorporationTypes
            {
                public const string Corporation = "corporation";
                public const string Other = "other";
            }


            public class OptionsValues
            {
                public const string Valid = "valid";
                public const string Invalid = "invalid";

                public const string NoMatch = "no_match";
                public const string Match = "match";
                public const string PartialMatch = "partial_match";
                public const string MisMatch = "mismatch";
                public const string InsufficientData = "insufficient_data";

                public const string Low = "low";
                public const string High = "high";
            }
        }
        public class MessageTemplates
        {
            public class BlockScoreTemplate
            {
                public const string TemplateName = "BlockScore.Verification";
                public const string TemplateSubject = "%Store.Name%. Customer validation";
                public const string TemplateBody = "%Customer.Email% did not pass validation in service";
            }
        }

        public class CssClasses
        {
            public const string Valid = "valid";
            public const string Invalid = "invalid";
            public const string Pending = "pending";
        }

        public class GerenicAttributeKeyGroup
        {
            public const string CustomerGroup = "Customer";
            public const string CompanyGroup = "Company";
        }

        public class TempCheckOutGenericAttirubutes
        {
            public const string ProductId = "Temp_ProductId";
            public const string DeliveredQuantity = "Temp_DeliveredQuantity";
            public const string TemporaryEnvelopId = "Temp_EnvelopeId_ProductId_{0}_ForAttr_{1}";
            public const string SuccesfulyEnvelopId = "Succesfuly_EnvelopeId_ProductId_{0}_ForAttr_{1}";
            public const string OldTemplateId = "Old_TemplateId_ProductId_{0}_ForAttr_{1}";
            public const string VerifyInvestorApiIdentityId = "VerifyInvestorApiIdentityId";
            public const string VerifyInvestorViUserId = "VerifyInvestorViUserId";
            public const string VerifyInvestorId = "VerifyInvestorId_ForUser_{0}";
        }

    }
}
