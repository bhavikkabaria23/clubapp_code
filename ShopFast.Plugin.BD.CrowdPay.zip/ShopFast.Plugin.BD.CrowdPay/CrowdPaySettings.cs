﻿
using Nop.Core.Configuration;

namespace ShopFast.Plugin.BD.CrowdPay
{
    public class CrowdPaySettings : ISettings
    {
        public string DocuSignUserName { get; set; }

        public string DocuSignPassword { get; set; }

        public string IntegratorKey { get; set; }

        public string BlockScoreKey { get; set; }

        public bool VerifyInvestorValidationEnabled { get; set; }

        public bool SelfAccredited { get; set; }

        public bool InternalAccreditation { get; set; }

        public string VerifyInvestorApiKey { get; set; }

        public string VerifyInvestorUserKey { get; set; }

        public VerifyInvestorMode VerifyInvestorMode { get; set; }

        public string OfferingType { get; set; }

        public int SingleOfferProductId { get; set; }

        public bool ShowLogoInPeoductBox { get; set; }

        // Post to net1 CRM - http://net1crm.crowdpay.us

        public string Net1CrmApiUrl { get; set; }
        public string Net1CrmUsername { get; set; }
        public string Net1AccessKey { get; set; }
        public string Net1AssignedUserId { get; set; }

    }
}