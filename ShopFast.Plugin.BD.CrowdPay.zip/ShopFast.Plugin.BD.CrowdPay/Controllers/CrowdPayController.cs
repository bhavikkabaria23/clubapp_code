﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Seo;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Web.Controllers;
using Nop.Web.Extensions;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using Nop.Web.Models.Common;
using ShopFast.Plugin.Other.CrowdPay.Common;
using ShopFast.Plugin.Other.CrowdPay.Models;
using ShopFast.Plugin.Other.CrowdPay.Models.PersonalInfoModels;
using ShopFast.Plugin.Other.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.Other.CrowdPay.Controllers
{
    public class CrowdPayController : CheckoutController
    {
        #region Properties
        private readonly IDocusignService _docusignService;
        private readonly ICustomCustomerAttributeService _crowdPayCustomerAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ILocalizationService _localizationService;
        private readonly IWorkContext _workContext;
        private readonly CustomerSettings _customerSettings;
        private readonly Customer _currentCustomer;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;
        private readonly AddressSettings _addressSettings;
        private readonly ICustomAddressAttributeParser _customAddressAttributeParser;
        private readonly ICustomCustomerAttributeParser _customCustomerAttributeParser;
        private readonly ICurrencyService _currencyService;
        private readonly IPaymentService _paymentService;
        private readonly IStoreContext _storeContext;
        private readonly ITaxService _taxService;
        private readonly IWebHelper _webHelper;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IProductService _productService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly PaymentSettings _paymentSettings;
        private readonly IPluginFinder _pluginFinder;
        private readonly HttpContextBase _httpContext;
        private readonly ICustomOrderProccessingService _customOrderProccessingService;
        private readonly ISettingService _settingsService;
        private readonly ILogger _logger;
        private readonly ShippingSettings _shippingSettings;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IShippingService _shippingService;
        //      private readonly IShi
        #endregion

        #region Ctors
        public CrowdPayController(IWorkContext workContext,
             IStoreContext storeContext,
             IStoreMappingService storeMappingService,
             IShoppingCartService shoppingCartService,
             ILocalizationService localizationService,
             ITaxService taxService,
             ICurrencyService currencyService,
             IPriceFormatter priceFormatter,
             IOrderProcessingService orderProcessingService,
             ICustomerService customerService,
             IGenericAttributeService genericAttributeService,
             ICountryService countryService,
             IStateProvinceService stateProvinceService,
             IPaymentService paymentService,
             IPluginFinder pluginFinder,
             IOrderTotalCalculationService orderTotalCalculationService,
             IRewardPointService rewardPointService,
             ILogger logger,
             IOrderService orderService,
             IWebHelper webHelper,
             HttpContextBase httpContext,
             IAddressAttributeParser addressAttributeParser,
             IAddressAttributeService addressAttributeService,
             IAddressAttributeFormatter addressAttributeFormatter,
             OrderSettings orderSettings,
             RewardPointsSettings rewardPointsSettings,
             PaymentSettings paymentSettings,
             ShippingSettings shippingSettings,
             AddressSettings addressSettings, IDocusignService docusignService, ICustomCustomerAttributeService crowdPayCustomerAttributeService, CustomerSettings customerSettings, ICustomAddressAttributeParser customAddressAttributeParser, ICustomCustomerAttributeParser customCustomerAttributeParser, IAddressService addressService, IProductService productService, IPriceCalculationService priceCalculationService, ICustomOrderProccessingService customOrderProccessingService, ISettingService settingsService, IShippingService shippingService)
            : base(workContext, storeContext, storeMappingService, shoppingCartService,
                localizationService, taxService, currencyService, priceFormatter, orderProcessingService, customerService, genericAttributeService,
                countryService, stateProvinceService, shippingService, paymentService, pluginFinder, orderTotalCalculationService, rewardPointService,
                logger, orderService, webHelper, httpContext, addressAttributeParser, addressAttributeService, addressAttributeFormatter, orderSettings,
                rewardPointsSettings, paymentSettings, shippingSettings, addressSettings)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _taxService = taxService;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _paymentService = paymentService;
            _pluginFinder = pluginFinder;
            _logger = logger;
            _webHelper = webHelper;
            _httpContext = httpContext;
            _addressAttributeParser = addressAttributeParser;
            _addressAttributeService = addressAttributeService;
            _paymentSettings = paymentSettings;
            _shippingSettings = shippingSettings;
            _addressSettings = addressSettings;
            _docusignService = docusignService;
            _crowdPayCustomerAttributeService = crowdPayCustomerAttributeService;
            _customerSettings = customerSettings;
            _currentCustomer = _workContext.CurrentCustomer;
            _customAddressAttributeParser = customAddressAttributeParser;
            _customCustomerAttributeParser = customCustomerAttributeParser;
            _addressService = addressService;
            _productService = productService;
            _priceCalculationService = priceCalculationService;
            _customOrderProccessingService = customOrderProccessingService;
            _settingsService = settingsService;
            _shippingService = shippingService;
        }
        #endregion

        [Nop.Web.Framework.Controllers.AdminAuthorize]
        public ActionResult Configure()
        {
            var settingsEntity = _settingsService.LoadSetting<CrowdPaySettings>();

            var configurationModel = new ConfigurationModel()
            {
                DocuSignUserName = settingsEntity.DocuSignUserName,
                DocuSignPassword = settingsEntity.DocuSignPassword,
                DocuSignIntegratorKey = settingsEntity.IntegratorKey
            };

            return View("~/Plugins/Other.CrowdPay/Views/CrowdPay/Configure.cshtml", configurationModel);
        }

        [HttpPost]
        [Nop.Web.Framework.Controllers.AdminAuthorize]
        public ActionResult Configure(ConfigurationModel model)
        {
            var settingsEntity = _settingsService.LoadSetting<CrowdPaySettings>();
            settingsEntity.DocuSignUserName = model.DocuSignUserName;
            settingsEntity.DocuSignPassword = model.DocuSignPassword;
            settingsEntity.IntegratorKey = model.DocuSignIntegratorKey;

            _settingsService.SaveSetting(settingsEntity);

            return Configure();
        }

        [Authorize]
        public ActionResult PublicInfo(int? productId)
        {
            var model = new PublicInfoModel();

            var investorInfoModel = new InvestorInformationModel
            {
                CustomerSignature = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Signature)
            };
            model.InvestorInformationModel = investorInfoModel;
            model.ProductId = productId ?? 0;

            if (model.ProductId != 0)
            {
                var product = _productService.GetProductById(model.ProductId);
                if (product != null)
                {
                    var specAttr =
                        product.ProductSpecificationAttributes.SingleOrDefault(
                            x =>
                                x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                                ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId);

                    if (specAttr != null)
                    {
                        investorInfoModel.PdfFileExists = true;
                        investorInfoModel.InvestorInformationFilePath = _webHelper.GetStoreLocation() + Url.Action("DownloadFile", "CrowdPay", new { templateId = specAttr.CustomValue });
                    }

                    var subAgreementAttr = product.ProductSpecificationAttributes.SingleOrDefault(
                            x =>
                                x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                                ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId);

                    if (subAgreementAttr != null)
                    {
                        investorInfoModel.SubscriptionExists = true;
                    }

                    investorInfoModel.ProductId = model.ProductId;
                }

            }

            return View("~/Plugins/Other.CrowdPay/Views/CrowdPay/PublicInfo.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInvestorInformation(InvestorInformationModel model)
        {
            if (ModelState.IsValid)
            {
                var product = _productService.GetProductById(model.ProductId);

                _docusignService.SendDocumentForSignature(model.CustomerSignature,
                    ClientConstants.SpecificationAttributeName.InvestorInfoTemplateId,
                    product.Id);
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.Signature, model.CustomerSignature);
            }
            else
            {
                var repeatStepHtml =
                    RenderPartialViewToString(
                        "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_InvestorInformation.cshtml", model);

                var errorMessage =
                    _localizationService.GetLocaleStringResourceByName("shopfast.fields.customersignature.required");

                return Json(new
                {
                    section_name = "investor-info",
                    html = repeatStepHtml,
                    validation_span_id = "signature-validation",
                    validation_error = errorMessage != null ? errorMessage.ResourceValue : "shopfast.fields.customersignature.required"
                });
            }

            var resultModel = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType);

            resultModel.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;

            PreparePersonalInformationModel(resultModel);

            var stepHtml =
                RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml",
                    resultModel);

            var firstSelectedTypeContent = (JsonResult)InvestorInfoTypeChange(resultModel.SelectedPersonalInfoType, true);

            return Json(new
            {
                section_name = "personal-information",
                html = stepHtml,
                selectedOptionContent = firstSelectedTypeContent,
                selectedOptionArea = "personal-type-content"
            });
        }

        //call when investor information is not required     
        public ActionResult PesonalInformation()
        {
            var resultModel = new PersonalInformationModel();

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType);

            resultModel.SelectedPersonalInfoType = String.IsNullOrEmpty(personalInfoType) ? ClientConstants.PersonalInfoType.Individual : personalInfoType;

            PreparePersonalInformationModel(resultModel);

            resultModel.InvestorInfoNotRequired = true;
            resultModel.PersonalInfoContent = (string)InvestorInfoTypeChange(resultModel.SelectedPersonalInfoType, false);

            return View("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml", resultModel);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePersonalInformation()
        {
            var model = new PersonalInformationModel();
            TryUpdateModel(model, ClientConstants.FormPrefix.IndividualPrefix);
            switch (model.SelectedPersonalInfoType)
            {
                case ClientConstants.PersonalInfoType.Individual:
                    {

                        TryValidateModel(model.IniIndividualsModel);
                        if (ModelState.IsValid)
                        {
                            SaveIndividualInfo(model.IniIndividualsModel, model.SelectedPersonalInfoType);
                        }
                    }
                    break;
                case ClientConstants.PersonalInfoType.Company:
                case ClientConstants.PersonalInfoType.SelfDirectedIRA:
                case ClientConstants.PersonalInfoType.Trust:
                    {
                        TryValidateModel(model);

                        if (ModelState.IsValid)
                        {
                            SaveOtherInfo(model.OtherInfoModel);
                            SaveIndividualInfo(model.IniIndividualsModel, model.SelectedPersonalInfoType);
                        }

                        break;
                    }
            }
            if (!ModelState.IsValid)
            {
                PreparePersonalInformationModel(model);

                var stepHtml =
                    RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Personal.cshtml",
                        model);
                var firstSelectedTypeContent = (JsonResult)InvestorInfoTypeChange(model.SelectedPersonalInfoType, true);

                return Json(new
                {
                    section_name = "personal-information",
                    html = stepHtml,
                    selectedOptionContent = firstSelectedTypeContent,
                    selectedOptionArea = "personal-type-content"
                });
            }

            var investorTypeAttrubute =
              _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                  ClientConstants.CustomAttributes.InvestorType);
            var investorTypeModel = new InvestorTypeModel
            {
                InvestorTypeList = GetSelectListItemsModel(investorTypeAttrubute)
            };

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var investorType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.InvestorType);

            investorTypeModel.SelectedInvestorType = investorType ?? ClientConstants.InvestorType.NonAccreditted;

            var resultHtml =
                RenderPartialViewToString(
                    "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_InvestorType.cshtml", investorTypeModel);

            return Json(new
            {
                section_name = "investor-type",
                html = resultHtml
            });
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInvestorType(InvestorTypeModel model)
        {
            if (!string.IsNullOrEmpty(model.SelectedInvestorType))
            {
                var existCustomAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

                var customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml,
               ClientConstants.CustomAttributes.InvestorType, model.SelectedInvestorType);

                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);
            }

            var resultModel = new InformationGatheringModel();
            PrepareInformationGatheringModel(resultModel, model.SelectedInvestorType);

            var resultHtml =
                RenderPartialViewToString(
                    "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_InformationGathering.cshtml", resultModel);
            return Json(new
            {
                section_name = "info-gathering",
                html = resultHtml
            });
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveInfoGathering()
        {
            var model = new InformationGatheringModel();
            TryUpdateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);
            TryValidateModel(model, ClientConstants.FormPrefix.InfoGatheringPrefix);

            if (ModelState.IsValid)
            {
                var existCustomAttributesXml =
                    _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes,
                        _genericAttributeService);

                string customAttributesXml = String.Empty;
                if (model.AccreditedInvestor)
                {
                    customAttributesXml =
                        _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml,
                            ClientConstants.CustomAttributes.AccreditedQualify, model.SelectedQualify);
                }

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(model.AccreditedInvestor ? customAttributesXml : existCustomAttributesXml,
                    ClientConstants.CustomAttributes.AnnualIncome,
                    model.AnnualIncome.ToString(CultureInfo.InvariantCulture));

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(customAttributesXml,
                    ClientConstants.CustomAttributes.NetWorth, model.NetWorth.ToString(CultureInfo.InvariantCulture));

                customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(customAttributesXml,
                    ClientConstants.CustomAttributes.BackUpWithholding, model.SelectedBackupWithholding);

                _genericAttributeService.SaveAttribute(_currentCustomer,
                    SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);
            }
            else
            {
                PrepareInformationGatheringModel(model, model.InvestorType);
                var repeatHtml =
                RenderPartialViewToString(
                    "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_InformationGathering.cshtml", model);
                return Json(new
                {
                    section_name = "info-gathering",
                    html = repeatHtml
                });
            }

            //var resultModel = new PurchaseModel();
            //PreparePurchaseModel(resultModel);

            var billingAddressModel = PrepareBillingAddressModel(prePopulateNewAddressWithCustomerFields: true);

            var resultHtml =
                RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_BillingAddress.cshtml",
                    billingAddressModel);

            return Json(new
            {
                section_name = "billing-address",
                html = resultHtml
            });
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveBilling(FormCollection form)
        {
            try
            {
                Product product;
                if (Request.UrlReferrer != null)
                {
                    var uri = new Uri(Request.UrlReferrer.AbsoluteUri);
                    var productId = HttpUtility.ParseQueryString(uri.Query).Get("productId");

                    if (String.IsNullOrEmpty(productId))
                    {
                        return Json(new {error = 1, message = "Can't parse product id from url"});
                    }

                    product = _productService.GetProductById(int.Parse(productId));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't parse product id from url" });
                }
                //validation
                    var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                    int billingAddressId;
                    int.TryParse(form["billing_address_id"], out billingAddressId);

                    if (billingAddressId > 0)
                    {
                        //existing address
                        var address = _workContext.CurrentCustomer.Addresses.FirstOrDefault(a => a.Id == billingAddressId);
                        if (address == null)
                            throw new Exception("Address can't be loaded");

                        _workContext.CurrentCustomer.BillingAddress = address;
                        _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                    }
                    else
                    {
                        //new address
                        var model = new CheckoutBillingAddressModel();
                        TryUpdateModel(model.NewAddress, "BillingNewAddress");

                        //custom address attributes
                        var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                        var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                        foreach (var error in customAttributeWarnings)
                        {
                            ModelState.AddModelError("", error);
                        }

                        //validate model
                        TryValidateModel(model.NewAddress);
                        if (!ModelState.IsValid)
                        {
                            //model is not valid. redisplay the form with errors
                            var billingAddressModel = PrepareBillingAddressModel(
                                selectedCountryId: model.NewAddress.CountryId,
                                overrideAttributesXml: customAttributes);
                            billingAddressModel.NewAddressPreselected = true;

                            var resultHtml =
                                RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_BillingAddress.cshtml",
                                    billingAddressModel);

                            return Json(new
                            {
                                section_name = "billing-address",
                                html = resultHtml,
                                wrong_billing_address = true
                            });
                        }

                        //try to find an address with the same values (don't duplicate records)
                        var address = _workContext.CurrentCustomer.Addresses.ToList().FindAddress(
                            model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                            model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                            model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                            model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                            model.NewAddress.CountryId, customAttributes);
                        if (address == null)
                        {
                            //address is not found. let's create a new one
                            address = model.NewAddress.ToEntity();
                            address.CustomAttributes = customAttributes;
                            address.CreatedOnUtc = DateTime.UtcNow;
                            //some validation
                            if (address.CountryId == 0)
                                address.CountryId = null;
                            if (address.StateProvinceId == 0)
                                address.StateProvinceId = null;
                            if (address.CountryId.HasValue && address.CountryId.Value > 0)
                            {
                                address.Country = _countryService.GetCountryById(address.CountryId.Value);
                            }
                            _workContext.CurrentCustomer.Addresses.Add(address);
                        }
                        _workContext.CurrentCustomer.BillingAddress = address;
                        _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                    }

                    if (cart.RequiresShipping())
                    {
                        //shipping is required
                        var shippingAddressModel = PrepareShippingAddressModel(prePopulateNewAddressWithCustomerFields: true);
                        return Json(new
                        {
                            section_name = "shipping-address",
                            html = this.RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_ShippingAddress.cshtml", shippingAddressModel)
                        });
                    }
                

                //shipping is not required
                _genericAttributeService.SaveAttribute<ShippingOption>(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, null, _storeContext.CurrentStore.Id);

                //load next step

                var purchaseModel = new PurchaseModel();
                PreparePurchaseModel(purchaseModel);

                return Json(new
                {
                    section_name = "purchase",
                    html = this.RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_ShippingAddress.cshtml", purchaseModel)
                });
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveShipping(FormCollection form)
        {
            try
            {
                Product product;
                if (Request.UrlReferrer != null)
                {
                    var uri = new Uri(Request.UrlReferrer.AbsoluteUri);
                    var productId = HttpUtility.ParseQueryString(uri.Query).Get("productId");

                    if (String.IsNullOrEmpty(productId))
                    {
                        return Json(new { error = 1, message = "Can't parse product id from url" });
                    }

                    product = _productService.GetProductById(int.Parse(productId));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't parse product id from url" });
                }
                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                //Pick up in store?
                if (_shippingSettings.AllowPickUpInStore)
                {
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model);

                    if (model.PickUpInStore)
                    {
                        //customer decided to pick up in store

                        //no shipping address selected
                        _workContext.CurrentCustomer.ShippingAddress = null;
                        _customerService.UpdateCustomer(_workContext.CurrentCustomer);

                        //set value indicating that "pick up in store" option has been chosen
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickUpInStore, true, _storeContext.CurrentStore.Id);

                        //save "pick up in store" shipping method
                        var pickUpInStoreShippingOption = new ShippingOption
                        {
                            Name = _localizationService.GetResource("Checkout.PickUpInStore.MethodName"),
                            Rate = _shippingSettings.PickUpInStoreFee,
                            Description = null,
                            ShippingRateComputationMethodSystemName = null
                        };
                        _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                            SystemCustomerAttributeNames.SelectedShippingOption,
                            pickUpInStoreShippingOption,
                            _storeContext.CurrentStore.Id);

                        //load next step
                        return OpcLoadStepAfterShippingMethod(cart);
                    }

                    //set value indicating that "pick up in store" option has not been chosen
                    _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedPickUpInStore, false, _storeContext.CurrentStore.Id);
                }

                int shippingAddressId;
                int.TryParse(form["shipping_address_id"], out shippingAddressId);

                if (shippingAddressId > 0)
                {
                    //existing address
                    var address = _workContext.CurrentCustomer.Addresses.FirstOrDefault(a => a.Id == shippingAddressId);
                    if (address == null)
                        throw new Exception("Address can't be loaded");

                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }
                else
                {
                    //new address
                    var model = new CheckoutShippingAddressModel();
                    TryUpdateModel(model.NewAddress, "ShippingNewAddress");

                    //custom address attributes
                    var customAttributes = form.ParseCustomAddressAttributes(_addressAttributeParser, _addressAttributeService);
                    var customAttributeWarnings = _addressAttributeParser.GetAttributeWarnings(customAttributes);
                    foreach (var error in customAttributeWarnings)
                    {
                        ModelState.AddModelError("", error);
                    }

                    //validate model
                    TryValidateModel(model.NewAddress);
                    if (!ModelState.IsValid)
                    {
                        //model is not valid. redisplay the form with errors
                        var shippingAddressModel = PrepareShippingAddressModel(
                            selectedCountryId: model.NewAddress.CountryId,
                            overrideAttributesXml: customAttributes);
                        shippingAddressModel.NewAddressPreselected = true;
                        return Json(new
                        {
                            section_name = "shipping-address",
                            html = RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_ShippingAddress.cshtml", shippingAddressModel)
                        });
                    }

                    //try to find an address with the same values (don't duplicate records)
                    var address = _workContext.CurrentCustomer.Addresses.ToList().FindAddress(
                        model.NewAddress.FirstName, model.NewAddress.LastName, model.NewAddress.PhoneNumber,
                        model.NewAddress.Email, model.NewAddress.FaxNumber, model.NewAddress.Company,
                        model.NewAddress.Address1, model.NewAddress.Address2, model.NewAddress.City,
                        model.NewAddress.StateProvinceId, model.NewAddress.ZipPostalCode,
                        model.NewAddress.CountryId, customAttributes);
                    if (address == null)
                    {
                        address = model.NewAddress.ToEntity();
                        address.CustomAttributes = customAttributes;
                        address.CreatedOnUtc = DateTime.UtcNow;
                        //little hack here (TODO: find a better solution)
                        //EF does not load navigation properties for newly created entities (such as this "Address").
                        //we have to load them manually 
                        //otherwise, "Country" property of "Address" entity will be null in shipping rate computation methods
                        if (address.CountryId.HasValue)
                            address.Country = _countryService.GetCountryById(address.CountryId.Value);
                        if (address.StateProvinceId.HasValue)
                            address.StateProvince = _stateProvinceService.GetStateProvinceById(address.StateProvinceId.Value);

                        //other null validations
                        if (address.CountryId == 0)
                            address.CountryId = null;
                        if (address.StateProvinceId == 0)
                            address.StateProvinceId = null;
                        _workContext.CurrentCustomer.Addresses.Add(address);
                    }
                    _workContext.CurrentCustomer.ShippingAddress = address;
                    _customerService.UpdateCustomer(_workContext.CurrentCustomer);
                }

                var shippingMethodModel = PrepareShippingMethodModel(cart, _workContext.CurrentCustomer.ShippingAddress);

                if (_shippingSettings.BypassShippingMethodSelectionIfOnlyOne &&
                    shippingMethodModel.ShippingMethods.Count == 1)
                {
                    //if we have only one shipping method, then a customer doesn't have to choose a shipping method
                    _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                        SystemCustomerAttributeNames.SelectedShippingOption,
                        shippingMethodModel.ShippingMethods.First().ShippingOption,
                        _storeContext.CurrentStore.Id);

                    //load next step
                    return null;
                }

                return Json(new
                {
                    section_name = "shipping-method",
                    html = this.RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_ShippingMethods.cshtml", shippingMethodModel)
                });

            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }


        [ValidateInput(false)]
        [HttpPost]
        public ActionResult SaveShippingMethod(FormCollection form)
        {
            try
            {
                Product product;
                //validation
                if (Request.UrlReferrer != null)
                {
                    var uri = new Uri(Request.UrlReferrer.AbsoluteUri);
                    var productId = HttpUtility.ParseQueryString(uri.Query).Get("productId");

                    if (String.IsNullOrEmpty(productId))
                    {
                        return Json(new { error = 1, message = "Can't parse product id from url" });
                    }

                    product = _productService.GetProductById(int.Parse(productId));
                }
                else
                {
                    return Json(new { error = 1, message = "Can't parse product id from url" });
                }



                //validation
                var cart = new List<ShoppingCartItem>()
                    {
                        new ShoppingCartItem()
                        {
                            CreatedOnUtc = DateTime.UtcNow,
                            Customer = _currentCustomer,
                            CustomerId = _currentCustomer.Id,
                            Product = product,
                            ProductId = product.Id,
                            Quantity = 1,
                            AttributesXml = string.Empty,
                            StoreId = _storeContext.CurrentStore.Id,
                            ShoppingCartType = ShoppingCartType.ShoppingCart
                        }
                    };

                if (cart.Count == 0)
                    throw new Exception("Your cart is empty");

                if (!cart.RequiresShipping())
                    throw new Exception("Shipping is not required");

                //parse selected method 
                string shippingoption = form["shippingoption"];
                if (String.IsNullOrEmpty(shippingoption))
                    throw new Exception("Selected shipping method can't be parsed");
                var splittedOption = shippingoption.Split(new[] { "___" }, StringSplitOptions.RemoveEmptyEntries);
                if (splittedOption.Length != 2)
                    throw new Exception("Selected shipping method can't be parsed");
                string selectedName = splittedOption[0];
                string shippingRateComputationMethodSystemName = splittedOption[1];

                //find it
                //performance optimization. try cache first
                var shippingOptions = _workContext.CurrentCustomer.GetAttribute<List<ShippingOption>>(SystemCustomerAttributeNames.OfferedShippingOptions, _storeContext.CurrentStore.Id);
                if (shippingOptions == null || shippingOptions.Count == 0)
                {
                    //not found? let's load them using shipping service
                    shippingOptions = _shippingService
                        .GetShippingOptions(cart, _workContext.CurrentCustomer.ShippingAddress, shippingRateComputationMethodSystemName, _storeContext.CurrentStore.Id)
                        .ShippingOptions
                        .ToList();
                }
                else
                {
                    //loaded cached results. let's filter result by a chosen shipping rate computation method
                    shippingOptions = shippingOptions.Where(so => so.ShippingRateComputationMethodSystemName.Equals(shippingRateComputationMethodSystemName, StringComparison.InvariantCultureIgnoreCase))
                        .ToList();
                }

                var shippingOption = shippingOptions
                    .Find(so => !String.IsNullOrEmpty(so.Name) && so.Name.Equals(selectedName, StringComparison.InvariantCultureIgnoreCase));
                if (shippingOption == null)
                    throw new Exception("Selected shipping method can't be loaded");

                //save
                _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, SystemCustomerAttributeNames.SelectedShippingOption, shippingOption, _storeContext.CurrentStore.Id);

                //load next step
                return OpcLoadStepAfterShippingMethod(cart);
            }
            catch (Exception exc)
            {
                _logger.Warning(exc.Message, exc, _workContext.CurrentCustomer);
                return Json(new { error = 1, message = exc.Message });
            }
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePurchase(FormCollection form)
        {
            string paymentmethod = form["paymentmethod"];
            //payment method 
            if (String.IsNullOrEmpty(paymentmethod))
                throw new Exception("Selected payment method can't be parsed");

            var purchaseModel = new PurchaseModel();
            TryUpdateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);
            TryValidateModel(purchaseModel, ClientConstants.FormPrefix.PurchasePrefix);

            if (!ModelState.IsValid)
            {
                PreparePurchaseModel(purchaseModel);

                var repeatHtml =
                    RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Purchase.cshtml",
                        purchaseModel);
                return Json(new
                {
                    section_name = "purchase",
                    html = repeatHtml
                });
            }

            var paymentMethodInst = _paymentService.LoadPaymentMethodBySystemName(paymentmethod);
            if (paymentMethodInst == null ||
                !paymentMethodInst.IsPaymentMethodActive(_paymentSettings) ||
                !_pluginFinder.AuthenticateStore(paymentMethodInst.PluginDescriptor, _storeContext.CurrentStore.Id))
                throw new Exception("Selected payment method can't be parsed");

            //save
            _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer,
                SystemCustomerAttributeNames.SelectedPaymentMethod, paymentmethod, _storeContext.CurrentStore.Id);

            var paymentInfoModel = PreparePaymentInfoModel(paymentMethodInst);

            var resultModel = new CustomPaymentInfoModel()
            {
                CheckoutPaymentInfoModel = paymentInfoModel,
                DeliveredQuantity = purchaseModel.OrderedSharesCount,
                ProductId = purchaseModel.ProductId
            };

            var resultHtml =
                RenderPartialViewToString(
                    "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", resultModel);
            return Json(new
            {
                section_name = "paymentinfo",
                html = resultHtml
            });
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SavePaymentInfo(FormCollection form)
        {
            try
            {
                var customPaymentInfoModel = new CustomPaymentInfoModel();
                TryUpdateModel(customPaymentInfoModel, ClientConstants.FormPrefix.PaymentInfoPrefix);

                //validation
                var paymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                    SystemCustomerAttributeNames.SelectedPaymentMethod,
                    _genericAttributeService, _storeContext.CurrentStore.Id);
                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(paymentMethodSystemName);
                if (paymentMethod == null)
                    throw new Exception("Payment method is not selected");

                var paymentControllerType = paymentMethod.GetControllerType();
                var paymentController = DependencyResolver.Current.GetService(paymentControllerType) as Nop.Web.Framework.Controllers.BasePaymentController;
                if (paymentController == null)
                    throw new Exception("Payment controller cannot be loaded");

                var warnings = paymentController.ValidatePaymentForm(form);
                foreach (var warning in warnings)
                    ModelState.AddModelError("", warning);
                if (ModelState.IsValid)
                {
                    //get payment info
                    var paymentInfo = paymentController.GetPaymentInfo(form);
                    //session save
                    _httpContext.Session["CrowdPayOrderPaymentInfo"] = paymentInfo;

                    var subscriptionAgreementModel = PrepareSubscriptionAgreementModel(customPaymentInfoModel);

                    if (subscriptionAgreementModel.SubscriptionAgreementExists)
                    {
                        var resultHtml =
                             RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_SubscriptionAgreement.cshtml",
                                 subscriptionAgreementModel);
                        return Json(new
                        {
                            section_name = "subagreement",
                            html = resultHtml
                        });
                    }
                    else
                    {
                        var confirmOrderModel = PrepareConfirmOrderModel(customPaymentInfoModel);

                        var resultHtml =
                             RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                                 confirmOrderModel);
                        return Json(new
                        {
                            section_name = "confirm",
                            html = resultHtml
                        });
                    }
                }

                var paymentInfoModel = PreparePaymentInfoModel(paymentMethod);

                var resultModel = new CustomPaymentInfoModel()
                {
                    CheckoutPaymentInfoModel = paymentInfoModel,
                    DeliveredQuantity = customPaymentInfoModel.DeliveredQuantity,
                    ProductId = customPaymentInfoModel.ProductId
                };

                var repeatHtml =
                    RenderPartialViewToString(
                        "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_PaymentInfo.cshtml", resultModel);
                return Json(new
                {
                    section_name = "paymentinfo",
                    html = repeatHtml
                });
            }
            catch (Exception exc)
            {
                return Json(new { error = 1, message = exc.Message });
            }

        }

        [HttpPost]
        public ActionResult SaveSubscriptionAgreement()
        {
            var subscriptionAgreementModel = new SubscriptionAgreementModel();
            TryUpdateModel(subscriptionAgreementModel, ClientConstants.FormPrefix.SubscriptionAgreementPrefix);

            if (ModelState.IsValid)
            {
                var product = _productService.GetProductById(subscriptionAgreementModel.ProductId);

                _docusignService.SendDocumentForSignature(subscriptionAgreementModel.CustomerSignature,
                    ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId,
                    product.Id);

                var confirmOrderModel = PrepareConfirmOrderModel(subscriptionAgreementModel);

                var resultHtml =
                     RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                         confirmOrderModel);
                return Json(new
                {
                    section_name = "confirm",
                    html = resultHtml
                });
            }

            var repeateHtml =
                              RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_SubscriptionAgreement.cshtml",
                                  subscriptionAgreementModel);

            var errorMessage =
    _localizationService.GetLocaleStringResourceByName("shopfast.fields.customersignature.required");

            return Json(new
            {
                section_name = "investor-info",
                html = repeateHtml,
                validation_span_id = "signature-validation",
                validation_error = errorMessage != null ? errorMessage.ResourceValue : "shopfast.fields.customersignature.required"
            });
        }

        [HttpPost]
        public new ActionResult Confirm()
        {
            var confirmModel = new ConfirmOrderModel();
            TryUpdateModel(confirmModel, ClientConstants.FormPrefix.ConfirmPrefix);

            var processPaymentRequest = _httpContext.Session["CrowdPayOrderPaymentInfo"] as ProcessPaymentRequest;
            if (processPaymentRequest == null)
            {
                throw new Exception("Payment information is not entered");
            }

            _customOrderProccessingService.InitOrderProcessing(confirmModel.ProductId, confirmModel.DeliveredQuantity);
            processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
            processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
            processPaymentRequest.PaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            var placeOrderResult = _customOrderProccessingService.PlaceOrder(processPaymentRequest);

            if (placeOrderResult.Success)
            {
                _httpContext.Session["CrowdPayOrderPaymentInfo"] = null;
                var postProcessPaymentRequest = new PostProcessPaymentRequest
                {
                    Order = placeOrderResult.PlacedOrder
                };

                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(placeOrderResult.PlacedOrder.PaymentMethodSystemName);
                if (paymentMethod == null)
                    //payment method could be null if order total is 0
                    //success
                    return Json(new { success = 1 });

                if (paymentMethod.PaymentMethodType == PaymentMethodType.Redirection)
                {
                    //Redirection will not work because it's AJAX request.
                    //That's why we don't process it here (we redirect a user to another page where he'll be redirected)

                    //redirect
                    return Json(new
                    {
                        redirect = string.Format("{0}checkout/OpcCompleteRedirectionPayment", _webHelper.GetStoreLocation())
                    });
                }

                _paymentService.PostProcessPayment(postProcessPaymentRequest);
                //success
                return Json(new { success = 1 });
            }

            //error

            if (confirmModel.ProductId != 0)
            {
                var product = _productService.GetProductById(confirmModel.ProductId);
                var productModel = PrepareSimpleProductDetailsModel(product);

                confirmModel.DeliveredProduct = productModel;
            }

            foreach (var error in placeOrderResult.Errors)
                confirmModel.Warnings.Add(error);

            var resultHtml =
                           RenderPartialViewToString("~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/_Confirm.cshtml",
                               confirmModel);
            return Json(new
            {
                section_name = "confirm",
                html = resultHtml
            });
        }

        #region Other Actions

        public ActionResult DownloadFile(string templateId)
        {
            var docusignDocument = _docusignService.GetDocumentFromTemplate(templateId);

            if (docusignDocument != Stream.Null)
            {
                var byteBuffer = new byte[docusignDocument.Length];
                docusignDocument.Read(byteBuffer, 0, (int)docusignDocument.Length);

                return File(byteBuffer, "application/pdf");
            }

            return null;
        }

        public object InvestorInfoTypeChange(string investorType, bool ajaxRequest)
        {
            string resultHtml = string.Empty;

            switch (investorType)
            {
                case ClientConstants.PersonalInfoType.Individual:
                    {

                        var individualInfoModel = new IndividualsModel();
                        PrepareIndividualsInformationModel(individualInfoModel);

                        var resulInfoModel = new PersonalInformationModel()
                        {
                            IniIndividualsModel = individualInfoModel
                        };

                        resultHtml =
                             RenderPartialViewToString(
                                 "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/PersonalInvoViews/_IndividualInfo.cshtml",
                                 resulInfoModel);
                        break;
                    }
                case ClientConstants.PersonalInfoType.Company:
                case ClientConstants.PersonalInfoType.Trust:
                case ClientConstants.PersonalInfoType.SelfDirectedIRA:
                    {
                        var otherInfoModel = new OtherInfoModel();

                        if (investorType.Equals(ClientConstants.PersonalInfoType.SelfDirectedIRA))
                        {
                            otherInfoModel.SelfDirected = true;
                        }

                        var individualInfo = new IndividualsModel();
                        PrepareOtherTypeInformationModel(otherInfoModel, individualInfo, investorType);

                        var resulInfoModel = new PersonalInformationModel()
                        {
                            OtherInfoModel = otherInfoModel,
                            IniIndividualsModel = individualInfo
                        };

                        resultHtml =
                            RenderPartialViewToString(
                                "~/Plugins/Other.CrowdPay/Views/CrowdPay/PartialViews/PersonalInvoViews/_OtherInfo.cshtml",
                                resulInfoModel);
                        break;
                    }
            }

            if (!String.IsNullOrEmpty(resultHtml))
            {
                if (!ajaxRequest)
                {
                    return resultHtml;
                }
                return Json(new
                {
                    result_html = resultHtml
                }, JsonRequestBehavior.AllowGet);
            }
            return Json(new
            {
                error = "This investor type is not implemented"
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SuccesfulInvestment()
        {
            return View("~/Plugins/Other.CrowdPay/Views/CrowdPay/SuccesfulInvestment.cshtml");
        }
        #endregion

        #region Utils

        #region Prepare models
        [NonAction]
        private void PreparePersonalInformationModel(PersonalInformationModel model)
        {
            var personalInfoTypesAttribute =
                _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                    ClientConstants.CustomAttributes.PersonalInfoType);
            model.PersonalInfoType = GetSelectListItemsModel(personalInfoTypesAttribute);
        }

        [NonAction]
        private void PrepareIndividualsInformationModel(IndividualsModel model)
        {

            model.Email = _currentCustomer.Email;
            model.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
            model.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);

            var dateOfBirth = _currentCustomer.GetAttribute<DateTime?>(SystemCustomerAttributeNames.DateOfBirth);
            if (dateOfBirth.HasValue)
            {
                model.DateOfBirth = dateOfBirth.Value.ToShortDateString();
            }
            model.DateOfBirthEnabled = _customerSettings.DateOfBirthEnabled;
            model.DateOfBirthRequired = _customerSettings.DateOfBirthEnabled;

            model.StreetAddress = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress);
            model.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            model.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;

            model.StreetAddress2 = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.StreetAddress2);
            model.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            model.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;

            model.ZipPostalCode = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode);
            model.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            model.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;


            model.City = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.City);
            model.CityRequired = _customerSettings.CityRequired;
            model.CityEnabled = _customerSettings.CityEnabled;

            model.CountryId = _currentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.CountryId);
            model.CountryRequired = _customerSettings.CountryRequired;
            model.CountryEnabled = _customerSettings.CountryEnabled;

            model.StateProvinceId = _currentCustomer.GetAttribute<int>(SystemCustomerAttributeNames.StateProvinceId);
            model.StateProvinceRequired = _customerSettings.StateProvinceRequired;
            model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;

            model.Phone = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Phone);
            model.PhoneEnabled = _customerSettings.PhoneEnabled;
            model.PhoneRequired = _customerSettings.PhoneRequired;

            model.Fax = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Fax);
            model.FaxEnabled = _customerSettings.FaxEnabled;
            model.FaxRequired = _customerSettings.FaxRequired;

            var customAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            model.TaxIdNumber = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.TaxId);

            #region Countries and states

            //countries and states
            model.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            model.CountryRequired = _customerSettings.CountryRequired;
            model.CountryEnabled = _customerSettings.CountryEnabled;

            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                model.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == model.CountryId
                });
            }


            model.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;
            model.StateProvinceRequired = _customerSettings.StateProvinceRequired;
            //states
            var states =
                _stateProvinceService.GetStateProvincesByCountryId(model.CountryId,
                    _workContext.WorkingLanguage.Id).ToList();
            if (states.Count > 0)
            {
                model.AvailableStates.Add(new SelectListItem
                {
                    Text = _localizationService.GetResource("Address.SelectState"),
                    Value = "0"
                });

                foreach (var s in states)
                {
                    model.AvailableStates.Add(new SelectListItem
                    {
                        Text = s.GetLocalized(x => x.Name),
                        Value = s.Id.ToString(),
                        Selected = (s.Id == model.StateProvinceId)
                    });
                }
            }
            else
            {
                bool anyCountrySelected = model.AvailableCountries.Any(x => x.Selected);

                model.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            #endregion
        }

        [NonAction]
        private void PrepareOtherTypeInformationModel(OtherInfoModel otherInfoModel, IndividualsModel individualsModel,
            string infoType)
        {
            otherInfoModel.InfoType = infoType;

            var langId = _workContext.WorkingLanguage.Id;
            otherInfoModel.CompanyLabel =
                _localizationService.GetResource(
                    string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                        ClientConstants.Localization.KeyTypes.Fields, infoType.Replace(
                            " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty) + "Name"), langId);

            var companyAddress = new Address();
            foreach (var address in _currentCustomer.Addresses)
            {
                var addressAttributes = _addressAttributeParser.ParseAddressAttributeValues(address.CustomAttributes);
                foreach (var addressAttribute in addressAttributes)
                {
                    if (addressAttribute.AddressAttribute.Name == ClientConstants.CustomAttributes.CompanyAddress)
                    {
                        companyAddress = address;
                        break;
                    }
                }
            }
            otherInfoModel.CompanyInfo.Company = companyAddress.Company;
            otherInfoModel.CompanyInfo.CompanyRequired = _addressSettings.CompanyRequired;
            otherInfoModel.CompanyInfo.CompanyEnabled = _addressSettings.CompanyEnabled;

            otherInfoModel.CompanyInfo.Address1 = companyAddress.Address1;
            otherInfoModel.CompanyInfo.StreetAddressRequired = _customerSettings.StreetAddressRequired;
            otherInfoModel.CompanyInfo.StreetAddressEnabled = _customerSettings.StreetAddressEnabled;

            otherInfoModel.CompanyInfo.Address2 = companyAddress.Address2;
            otherInfoModel.CompanyInfo.StreetAddress2Required = _customerSettings.StreetAddress2Required;
            otherInfoModel.CompanyInfo.StreetAddress2Enabled = _customerSettings.StreetAddress2Enabled;

            otherInfoModel.CompanyInfo.ZipPostalCode = companyAddress.ZipPostalCode;
            otherInfoModel.CompanyInfo.ZipPostalCodeRequired = _customerSettings.ZipPostalCodeRequired;
            otherInfoModel.CompanyInfo.ZipPostalCodeEnabled = _customerSettings.ZipPostalCodeEnabled;

            otherInfoModel.CompanyInfo.City = companyAddress.City;
            otherInfoModel.CompanyInfo.CityRequired = _customerSettings.CityRequired;
            otherInfoModel.CompanyInfo.CityEnabled = _customerSettings.CityEnabled;

            otherInfoModel.CompanyInfo.CountryId = companyAddress.CountryId;
            otherInfoModel.CompanyInfo.CountryEnabled = _customerSettings.CountryEnabled;

            otherInfoModel.CompanyInfo.StateProvinceId = companyAddress.StateProvinceId;
            otherInfoModel.CompanyInfo.StateProvinceEnabled = _customerSettings.StateProvinceEnabled;

            otherInfoModel.CompanyInfo.PhoneNumber = companyAddress.PhoneNumber;
            otherInfoModel.CompanyInfo.PhoneEnabled = _customerSettings.PhoneEnabled;
            otherInfoModel.CompanyInfo.PhoneRequired = _customerSettings.PhoneRequired;


            otherInfoModel.CompanyInfo.FaxNumber = companyAddress.FaxNumber;
            otherInfoModel.CompanyInfo.FaxEnabled = _customerSettings.FaxEnabled;
            otherInfoModel.CompanyInfo.FaxRequired = _customerSettings.FaxRequired;

            otherInfoModel.CompanyInfo.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
            otherInfoModel.CompanyInfo.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);

            #region Countries and states

            //countries and states


            otherInfoModel.CompanyInfo.AvailableCountries.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("Address.SelectCountry"),
                Value = "0"
            });
            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                otherInfoModel.CompanyInfo.AvailableCountries.Add(new SelectListItem
                {
                    Text = c.GetLocalized(x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.Id == otherInfoModel.CompanyInfo.CountryId
                });
            }

            //states

            if (otherInfoModel.CompanyInfo.CountryId.HasValue)
            {
                var states =
                    _stateProvinceService.GetStateProvincesByCountryId(otherInfoModel.CompanyInfo.CountryId.Value,
                        _workContext.WorkingLanguage.Id).ToList();
                if (states.Count > 0)
                {
                    otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                    {
                        Text = _localizationService.GetResource("Address.SelectState"),
                        Value = "0"
                    });

                    foreach (var s in states)
                    {
                        otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                        {
                            Text = s.GetLocalized(x => x.Name),
                            Value = s.Id.ToString(),
                            Selected = (s.Id == otherInfoModel.CompanyInfo.StateProvinceId)
                        });
                    }
                }
            }
            else
            {
                bool anyCountrySelected = otherInfoModel.CompanyInfo.AvailableCountries.Any(x => x.Selected);

                otherInfoModel.CompanyInfo.AvailableStates.Add(new SelectListItem
                {
                    Text =
                        _localizationService.GetResource(anyCountrySelected
                            ? "Address.OtherNonUS"
                            : "Address.SelectState"),
                    Value = "0"
                });
            }

            #endregion

            otherInfoModel.CompanyInfo.Email = companyAddress.Email;
            otherInfoModel.RegionFormed =
                _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.RegionFormedIn);

            otherInfoModel.ContactName =
                _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.ContactName);

            otherInfoModel.VestingName =
               _customAddressAttributeParser.ParseCustomAddressAttributesValues(companyAddress.CustomAttributes,
                   ClientConstants.CustomAttributes.VestingName);

            PrepareIndividualsInformationModel(individualsModel);
        }

        [NonAction]
        private void PrepareInformationGatheringModel(InformationGatheringModel informationGatheringModel, string investorType)
        {
            if (investorType == ClientConstants.InvestorType.Accreddited)
            {
                informationGatheringModel.AccreditedInvestor = true;
                var accreditedQualifyList = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                  ClientConstants.CustomAttributes.AccreditedQualify);

                informationGatheringModel.AccreditedInvestorQualifyList = GetSelectListItemsModel(accreditedQualifyList);
            }
            var existAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            var annualIncome = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.AnnualIncome);
            var netWorth = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.NetWorth);

            var selectedQualifyValue = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.AccreditedQualify);

            var backUpWithholdingList = _crowdPayCustomerAttributeService.GetCustomerAttributeValuesByName(
                  ClientConstants.CustomAttributes.BackUpWithholding);

            informationGatheringModel.BackupWithholdingList = GetSelectListItemsModel(backUpWithholdingList);

            var selectedBackupWithholdingValue = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(existAttributesXml,
                ClientConstants.CustomAttributes.BackUpWithholding);

            informationGatheringModel.AnnualIncome = !String.IsNullOrEmpty(annualIncome) ? Convert.ToDecimal(annualIncome) : 0;
            informationGatheringModel.NetWorth = !String.IsNullOrEmpty(netWorth) ? Convert.ToDecimal(netWorth) : 0;
            informationGatheringModel.SelectedQualify = selectedQualifyValue;
            informationGatheringModel.SelectedBackupWithholding = selectedBackupWithholdingValue;
            informationGatheringModel.InvestorType = investorType;

            var currentCurrency = _currencyService.GetCurrencyById(_workContext.WorkingCurrency.Id);
            if (currentCurrency != null)
            {
                informationGatheringModel.CurrencySymbol = !String.IsNullOrEmpty(currentCurrency.DisplayLocale)
                    ? new RegionInfo(currentCurrency.DisplayLocale).CurrencySymbol
                    : String.Empty;
                informationGatheringModel.CurrencyName = currentCurrency.CurrencyCode.ToUpper();
            }
        }

        [NonAction]
        private void PreparePurchaseModel(PurchaseModel purchaseModel)
        {
            var productIdFromRequest = Request["productId"];

            int productIdParsed;
            if (int.TryParse(productIdFromRequest, out productIdParsed) || purchaseModel.ProductId != 0)
            {
                var product = _productService.GetProductById(productIdParsed != 0 ? productIdParsed : purchaseModel.ProductId);
                if (product != null)
                {
                    var currentCurrency = _currencyService.GetCurrencyById(_workContext.WorkingCurrency.Id);
                    if (currentCurrency != null)
                    {
                        purchaseModel.CurrencySymbol = !String.IsNullOrEmpty(currentCurrency.DisplayLocale)
                            ? new RegionInfo(currentCurrency.DisplayLocale).CurrencySymbol
                            : String.Empty;
                    }
                    purchaseModel.MaximumSharesCount = product.StockQuantity;
                    purchaseModel.MinimumSharesCount = product.OrderMinimumQuantity;

                    decimal taxRate;
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    purchaseModel.PerShare = finalPriceWithoutDiscount;

                    purchaseModel.MinimumInvest = finalPriceWithoutDiscount * product.OrderMinimumQuantity;
                    purchaseModel.MaximumInvest = (finalPriceWithoutDiscount * product.StockQuantity);
                    purchaseModel.ProductId = productIdParsed;
                }
            }

            //add payment methods
            var paymentMethods = _paymentService
                .LoadActivePaymentMethods(_workContext.CurrentCustomer.Id, _storeContext.CurrentStore.Id)
                .Where(pm => pm.PaymentMethodType == PaymentMethodType.Standard || pm.PaymentMethodType == PaymentMethodType.Redirection)
               .ToList();
            foreach (var pm in paymentMethods)
            {

                var pmModel = new CheckoutPaymentMethodModel.PaymentMethodModel
                {
                    Name = pm.GetLocalizedFriendlyName(_localizationService, _workContext.WorkingLanguage.Id),
                    PaymentMethodSystemName = pm.PluginDescriptor.SystemName,
                    LogoUrl = pm.PluginDescriptor.GetLogoUrl(_webHelper)
                };

                purchaseModel.PaymentMethods.Add(pmModel);
            }

            //find a selected (previously) payment method
            var selectedPaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
                SystemCustomerAttributeNames.SelectedPaymentMethod,
                _genericAttributeService, _storeContext.CurrentStore.Id);
            if (!String.IsNullOrEmpty(selectedPaymentMethodSystemName))
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.ToList()
                    .Find(pm => pm.PaymentMethodSystemName.Equals(selectedPaymentMethodSystemName, StringComparison.InvariantCultureIgnoreCase));
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }
            //if no option has been selected, let's do it for the first one
            if (purchaseModel.PaymentMethods.FirstOrDefault(so => so.Selected) == null)
            {
                var paymentMethodToSelect = purchaseModel.PaymentMethods.FirstOrDefault();
                if (paymentMethodToSelect != null)
                    paymentMethodToSelect.Selected = true;
            }

        }

        private ProductDetailsModel PrepareSimpleProductDetailsModel(Product product)
        {
            if (product == null)
                throw new ArgumentNullException("product");

            var model = new ProductDetailsModel
            {
                Id = product.Id,
                Name = product.GetLocalized(x => x.Name),
                SeName = product.GetSeName(),
            };

            model.ProductPrice.ProductId = product.Id;

            model.ProductPrice.HidePrices = false;
            if (product.CustomerEntersPrice)
            {
                model.ProductPrice.CustomerEntersPrice = true;
            }
            else
            {
                if (product.CallForPrice)
                {
                    model.ProductPrice.CallForPrice = true;
                }
                else
                {
                    decimal taxRate;
                    decimal oldPriceBase = _taxService.GetProductPrice(product, product.OldPrice, out taxRate);
                    decimal finalPriceWithoutDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: false), out taxRate);
                    decimal finalPriceWithDiscountBase = _taxService.GetProductPrice(product, _priceCalculationService.GetFinalPrice(product, _workContext.CurrentCustomer, includeDiscounts: true), out taxRate);

                    decimal oldPrice = _currencyService.ConvertFromPrimaryStoreCurrency(oldPriceBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithoutDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithoutDiscountBase, _workContext.WorkingCurrency);
                    decimal finalPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(finalPriceWithDiscountBase, _workContext.WorkingCurrency);

                    if (finalPriceWithoutDiscountBase != oldPriceBase && oldPriceBase > decimal.Zero)
                        model.ProductPrice.OldPrice = _priceFormatter.FormatPrice(oldPrice);

                    model.ProductPrice.Price = _priceFormatter.FormatPrice(finalPriceWithoutDiscount);

                    if (finalPriceWithoutDiscountBase != finalPriceWithDiscountBase)
                        model.ProductPrice.PriceWithDiscount = _priceFormatter.FormatPrice(finalPriceWithDiscount);

                    model.ProductPrice.PriceValue = finalPriceWithDiscount;
                }
            }

            return model;
        }


        protected SubscriptionAgreementModel PrepareSubscriptionAgreementModel(
            CustomPaymentInfoModel customPaymentInfoModel)
        {

            var product = _productService.GetProductById(customPaymentInfoModel.ProductId);

            var model = new SubscriptionAgreementModel()
            {
                CustomerSignature = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.Signature),
                DeliveredQuantity = customPaymentInfoModel.DeliveredQuantity,
                ProductId = customPaymentInfoModel.ProductId
            };

            var subAgreementAttr = product.ProductSpecificationAttributes.SingleOrDefault(
                    x =>
                        x.SpecificationAttributeOption.SpecificationAttribute.Name ==
                        ClientConstants.SpecificationAttributeName.SubscriptionAgreementTemplateId);

            if (subAgreementAttr != null)
            {
                model.SubscriptionAgreementExists = true;
                model.SubscriptionAgreementFile = _webHelper.GetStoreLocation() + Url.Action("DownloadFile", "CrowdPay", new { templateId = subAgreementAttr.CustomValue });
            }

            return model;
        }

        [NonAction]
        protected ConfirmOrderModel PrepareConfirmOrderModel(CustomPaymentInfoModel customPaymentInfoModel)
        {
            var product = _productService.GetProductById(customPaymentInfoModel.ProductId);
            var productModel = PrepareSimpleProductDetailsModel(product);

            var model = new ConfirmOrderModel
            {
                DeliveredQuantity = customPaymentInfoModel.DeliveredQuantity,
                ProductId = customPaymentInfoModel.ProductId,
                DeliveredProduct = productModel,
                Warnings = new List<string>()
            };

            return model;
        }


        [NonAction]
        protected ConfirmOrderModel PrepareConfirmOrderModel(SubscriptionAgreementModel subscriptionAgreementModel)
        {
            var product = _productService.GetProductById(subscriptionAgreementModel.ProductId);
            var productModel = PrepareSimpleProductDetailsModel(product);

            var model = new ConfirmOrderModel
            {
                DeliveredQuantity = subscriptionAgreementModel.DeliveredQuantity,
                ProductId = subscriptionAgreementModel.ProductId,
                DeliveredProduct = productModel
            };

            return model;
        }

        [NonAction]
        private IList<SelectListItem> GetSelectListItemsModel(IList<CustomerAttributeValue> attributeValues)
        {
            var langId = _workContext.WorkingLanguage.Id;

            return attributeValues.Select(x => new SelectListItem()
            {
                Text = _localizationService.GetResource(
                        string.Format(ClientConstants.Localization.LocalizationKey.ShopFastPrefix,
                            ClientConstants.Localization.KeyTypes.Fields, x.Name.Replace(
                                " ", string.Empty).Replace(")", String.Empty).Replace("(", String.Empty).Replace("-", String.Empty)), langId),
                Selected = x.IsPreSelected,
                Value = x.Name
            }).ToList();
        }

        #endregion

        #region Save models
        [NonAction]
        private void SaveIndividualInfo(IndividualsModel model, string infoType)
        {

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.LastName,
                model.LastName);
            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.FirstName,
                model.FirstName);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StreetAddress,
                model.StreetAddress);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StreetAddress2,
                model.StreetAddress2);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CountryId,
                model.CountryId);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.StateProvinceId,
                model.StateProvinceId);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.ZipPostalCode,
                model.ZipPostalCode);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.City, model.City);

            DateTime dateofbirth;
            if (DateTime.TryParse(model.DateOfBirth, out dateofbirth))
            {
                _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.DateOfBirth,
                    dateofbirth);
            }

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.Phone, model.Phone);

            var existCustomAttributesXml = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);

            var customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(existCustomAttributesXml,
                ClientConstants.CustomAttributes.TaxId, model.TaxIdNumber);

            customAttributesXml = _customCustomerAttributeParser.ParseCustomCustomerAttributes(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType, infoType);

            _genericAttributeService.SaveAttribute(_currentCustomer, SystemCustomerAttributeNames.CustomCustomerAttributes, customAttributesXml);

        }

        [NonAction]
        private void SaveOtherInfo(OtherInfoModel model)
        {

            var companyAddress = new Address();
            var existingAddress = false;
            foreach (var address in _currentCustomer.Addresses)
            {
                var addressAttributes = _addressAttributeParser.ParseAddressAttributeValues(address.CustomAttributes);
                foreach (var addressAttribute in addressAttributes)
                {
                    if (addressAttribute.AddressAttribute.Name == ClientConstants.CustomAttributes.CompanyAddress)
                    {
                        companyAddress = address;
                        existingAddress = true;
                        break;
                    }
                }
            }
            companyAddress.LastName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName);
            companyAddress.FirstName = _currentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName);
            companyAddress.Company = model.CompanyInfo.Company;
            companyAddress.Address1 = model.CompanyInfo.Address1;
            companyAddress.Address2 = model.CompanyInfo.Address2;
            companyAddress.City = model.CompanyInfo.City;
            companyAddress.CountryId = model.CompanyInfo.CountryId;
            companyAddress.StateProvinceId = model.CompanyInfo.StateProvinceId;
            companyAddress.ZipPostalCode = model.CompanyInfo.ZipPostalCode;
            companyAddress.Email = model.CompanyInfo.Email;
            companyAddress.PhoneNumber = model.CompanyInfo.PhoneNumber;
            companyAddress.FaxNumber = model.CompanyInfo.FaxNumber;


            if (!existingAddress)
            {
                companyAddress.CustomAttributes =
                    _customAddressAttributeParser.ParseCustomAddressAttributes(companyAddress.CustomAttributes,
                        ClientConstants.CustomAttributes.CompanyAddress, "1");
                _addressService.InsertAddress(companyAddress);

                _currentCustomer.Addresses.Add(companyAddress);
            }

            companyAddress.CustomAttributes =
                _customAddressAttributeParser.ParseCustomAddressAttributes(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.RegionFormedIn, model.RegionFormed);
            companyAddress.CustomAttributes =
                _customAddressAttributeParser.ParseCustomAddressAttributes(companyAddress.CustomAttributes,
                    ClientConstants.CustomAttributes.ContactName, model.ContactName);

            if (model.SelfDirected)
            {
                companyAddress.CustomAttributes =
                    _customAddressAttributeParser.ParseCustomAddressAttributes(companyAddress.CustomAttributes,
                        ClientConstants.CustomAttributes.VestingName, model.VestingName);
            }

            _customerService.UpdateCustomer(_currentCustomer);
        }
        #endregion
        #endregion
    }
}


