﻿using System;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Nop.Web.Framework.Controllers;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdPayInvestorVerifyApiController : BasePluginController
    {
        private readonly IWorkContext _workContext;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly IVerifyInvestorService _verifyInvestorService;

        public CrowdPayInvestorVerifyApiController(IWorkContext workContext, ICustomGenericAttributeService customGenericAttributeService, IVerifyInvestorService verifyInvestorService)
        {
            _workContext = workContext;
            _customGenericAttributeService = customGenericAttributeService;
            _verifyInvestorService = verifyInvestorService;
        }

        [Authorize]
        public ActionResult VerifyInvestor(int vi_user_id)
        {
            _customGenericAttributeService.SaveGenericAttirubteValue(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId, vi_user_id.ToString());

            string redirectUrl = String.Empty;

            var productId =
                       _customGenericAttributeService.GetAttributeByNameForCurrentCustomer(
                           ClientConstants.TempCheckOutGenericAttirubutes.ProductId);

            var verifyStatus = _verifyInvestorService.GetUserVerificationStatus(vi_user_id);
            if (verifyStatus != null)
            {
                switch (verifyStatus.verification_status)
                {
                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.PendingVerification:
                        {
                            if (verifyStatus.verification_request_step != ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForReview)
                            {
                                redirectUrl = _verifyInvestorService.GetRedirectUrlForInvestor(vi_user_id);
                            }
                            if (productId != null)
                            {
                                return RedirectToAction("PublicInfo", "CrowdPayCheckOut", new { productId = productId.Value, goToInformationGatheringSection = true });
                            }
                        }
                        break;
                    case ClientConstants.VerifyInvestor.InvestorValidationStatus.Unverified:
                        if (verifyStatus.verification_request_step ==
                            ClientConstants.VerifyInvestor.InvestorValidationStatus.WaitingForInvestorAcceptance)
                        {
                            redirectUrl = _verifyInvestorService.GetRedirectUrlForInvestor(vi_user_id);
                            if (String.IsNullOrEmpty(redirectUrl))
                            {
                                _verifyInvestorService.VerifyCustomer(vi_user_id, out redirectUrl);
                            }
                        }
                        else
                        {
                            _verifyInvestorService.VerifyCustomer(vi_user_id, out redirectUrl);
                        }
                        break;
                    default:
                        {
                            if (productId != null)
                            {
                                return RedirectToAction("PublicInfo", "CrowdPayCheckOut", new { productId = productId.Value, goToInformationGatheringSection = true });
                            }
                        }
                        break;
                }
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

            if (!String.IsNullOrEmpty(redirectUrl))
            {
                return Redirect(redirectUrl);
            }

            return RedirectToAction("Index", "Home");
        }

    }
}
