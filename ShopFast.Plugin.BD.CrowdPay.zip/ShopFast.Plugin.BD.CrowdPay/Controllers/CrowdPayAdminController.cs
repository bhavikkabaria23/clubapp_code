﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Nop.Admin.Controllers;
using Nop.Admin.Models.Customers;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using Nop.Services.Logging;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdPayAdminController : BaseAdminController
    {
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomerService _customerService;
        private readonly ICustomCustomerAttributeParser _customCustomerAttributeParser;
        private readonly IVerifyInvestorService _verifyInvestorService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly ILocalizationService _localizationService;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly IPermissionService _permissionService;
        private readonly IWorkContext _workContext;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IInvestorService _investorService;
        private readonly ILogger _logger;

        public CrowdPayAdminController(IGenericAttributeService genericAttributeService, ICustomerService customerService,
            ICustomCustomerAttributeParser customCustomerAttributeParser, IVerifyInvestorService verifyInvestorService, ICustomGenericAttributeService customGenericAttributeService,
            ILocalizationService localizationService, IDateTimeHelper dateTimeHelper, IPermissionService permissionService, IWorkContext workContext,
            IPriceFormatter priceFormatter,
            IInvestorService investorService,
            ILogger logger)
        {
            _genericAttributeService = genericAttributeService;
            _customerService = customerService;
            _customCustomerAttributeParser = customCustomerAttributeParser;
            _verifyInvestorService = verifyInvestorService;
            _customGenericAttributeService = customGenericAttributeService;
            _localizationService = localizationService;
            _dateTimeHelper = dateTimeHelper;
            _permissionService = permissionService;
            _workContext = workContext;
            this._priceFormatter = priceFormatter;
            this._investorService = investorService;
            this._logger = logger;
        }

        [NonAction]
        protected virtual string GetCustomerRolesNames(IList<CustomerRole> customerRoles, string separator = ",")
        {
            var sb = new StringBuilder();
            for (int i = 0; i < customerRoles.Count; i++)
            {
                sb.Append(customerRoles[i].Name);
                if (i != customerRoles.Count - 1)
                {
                    sb.Append(separator);
                    sb.Append(" ");
                }
            }
            return sb.ToString();
        }

        [NonAction]
        protected virtual CustomerModel PrepareCustomerModelForList(Customer customer)
        {
		  var blockScoreStatusValid = false;
            var blockScoreStatus = _genericAttributeService.GetAttributesForEntity(customer.Id,
                ClientConstants.GerenicAttributeKeyGroup.CustomerGroup).FirstOrDefault(x => x.Key == ClientConstants.CustomAttributes.BlockScoreStatus);
            if (blockScoreStatus != null && blockScoreStatus.Value == "valid")
                blockScoreStatusValid = true;
				
            return new CustomerModel
            {
                Id = customer.Id,
                Email = customer.IsRegistered() ? customer.Email : _localizationService.GetResource("Admin.Customers.Guest"),
                Username = customer.Username,
                FullName = customer.GetFullName(),
                Company = customer.GetAttribute<string>(SystemCustomerAttributeNames.Company),
                Phone = customer.GetAttribute<string>(SystemCustomerAttributeNames.Phone),
                ZipPostalCode = customer.GetAttribute<string>(SystemCustomerAttributeNames.ZipPostalCode),
                CustomerRoleNames = GetCustomerRolesNames(customer.CustomerRoles.ToList()),
                Active = customer.Active,
                CreatedOn = _dateTimeHelper.ConvertToUserTime(customer.CreatedOnUtc, DateTimeKind.Utc),
                LastActivityDate = _dateTimeHelper.ConvertToUserTime(customer.LastActivityDateUtc, DateTimeKind.Utc),
				DisplayRewardPointsHistory = blockScoreStatusValid
            };
        }

        /// <summary>
        /// This action renders blockScore validation results
        /// </summary>
        /// <param name="customerId">Customer which associated with blockScore results</param>
        /// <returns></returns>
        public ActionResult BlockScoreValidationDetails(int customerId)
        {
            _logger.Information("BlockScoreValidationDetails Invoke");
            var customer = _customerService.GetCustomerById(customerId);
            var customAttributesXml = customer.GetAttribute<string>(SystemCustomerAttributeNames.CustomCustomerAttributes, _genericAttributeService);
            var personalInfoType = _customCustomerAttributeParser.ParseCustomCustomerAttributesValues(customAttributesXml,
                ClientConstants.CustomAttributes.PersonalInfoType);
            _logger.Information("PersonalInfoType: " + personalInfoType);

            var model = new List<BlockScoreAdminModel>();

            switch (personalInfoType)
            {
                case ClientConstants.PersonalInfoType.Individual:
                    PrepareBlockScoreDetails(model, customerId, ClientConstants.GerenicAttributeKeyGroup.CustomerGroup);
                    break;
                case ClientConstants.PersonalInfoType.Company:
                case ClientConstants.PersonalInfoType.SelfDirectedIRA:
                case ClientConstants.PersonalInfoType.Trust:
                    PrepareBlockScoreDetails(model, customerId, ClientConstants.GerenicAttributeKeyGroup.CustomerGroup);
                    PrepareBlockScoreDetails(model, customerId, ClientConstants.GerenicAttributeKeyGroup.CompanyGroup);
                    break;
            }

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/BlockScoreValidationDetails.cshtml", model);
        }

        /// <summary>
        /// This action renders verifyInvestor validation results
        /// </summary>
        /// <param name="customerId">Customer which associated with VI results</param>
        /// <returns></returns>
        public ActionResult VerifyInvestorDetails(int customerId)
        {
            var model = new VerifyInvestorAdminModel();

            var viUserId = _genericAttributeService.GetAttributesForEntity(customerId,
              ClientConstants.GerenicAttributeKeyGroup.CustomerGroup).SingleOrDefault(x => x.Key == ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);

            var customer = _customerService.GetCustomerById(customerId);

            if (customer != null)
            {
                model.Company = customer.GetAttribute<string>(SystemCustomerAttributeNames.Company);
            }

            if (viUserId != null)
            {
                var verifyStatus = _verifyInvestorService.GetUserVerificationStatus(int.Parse(viUserId.Value));
                if (verifyStatus != null)
                {
                    model.Id = verifyStatus.id;
                    if (!String.IsNullOrEmpty(verifyStatus.verified_on))
                    {
                        model.VerifiedOn = DateTime.Parse(verifyStatus.verified_on);
                    }

                    switch (verifyStatus.verification_status)
                    {
                        case ClientConstants.VerifyInvestor.InvestorValidationStatus.Verified:
                            {
                                model.VerifiedDocumentUrl = Url.Action("DownloadFile", "CrowdPayAdmin",
                                    new { vi_UserId = int.Parse(viUserId.Value) });

                                model.CssClass = "verified";
                            }
                            break;
                        default:
                            {
                                model.CssClass = verifyStatus.verification_status;
                            }
                            break;
                    }
                    model.VerifiedStatus =
                        new CultureInfo("en-US", false).TextInfo.ToTitleCase(
                            verifyStatus.verification_status.Replace("_", " "));
                    model.FirstName = verifyStatus.first_name;
                    model.LastName = verifyStatus.last_name;
                    model.Email = verifyStatus.email;
                    model.UserExists = true;
                }
            }

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/VerifyInvestorValidationDetails.cshtml", model);
        }

        /// <summary>
        /// This action returns certificate from verify api
        /// </summary>
        /// <param name="vi_UserId">verification info user id</param>
        /// <returns></returns>
        [Authorize]
        public ActionResult DownloadFile(int vi_UserId)
        {
            var fileContent = _verifyInvestorService.GetVerificationCertificate(vi_UserId);

            if (fileContent != null)
            {
                return File(fileContent, "application/pdf");
            }

            return null;
        }

        #region Admin > Customers

        [NonAction]
        protected virtual IList<RegisteredCustomerReportLineModel> GetReportRegisteredCustomersModel()
        {
            var report = new List<RegisteredCustomerReportLineModel>();

            var vendorId = _workContext.CurrentVendor != null ? _workContext.CurrentVendor.Id : 0;
            report.Add(new RegisteredCustomerReportLineModel
            {
                Period = _localizationService.GetResource("Admin.Customers.Reports.RegisteredCustomers.Fields.Period.7days"),
                Customers = _investorService.GetRegisteredCustomersReport(7, vendorId)
            });

            report.Add(new RegisteredCustomerReportLineModel
            {
                Period = _localizationService.GetResource("Admin.Customers.Reports.RegisteredCustomers.Fields.Period.14days"),
                Customers = _investorService.GetRegisteredCustomersReport(14, vendorId)
            });
            report.Add(new RegisteredCustomerReportLineModel
            {
                Period = _localizationService.GetResource("Admin.Customers.Reports.RegisteredCustomers.Fields.Period.month"),
                Customers = _investorService.GetRegisteredCustomersReport(30, vendorId)
            });
            report.Add(new RegisteredCustomerReportLineModel
            {
                Period = _localizationService.GetResource("Admin.Customers.Reports.RegisteredCustomers.Fields.Period.year"),
                Customers = _investorService.GetRegisteredCustomersReport(365, vendorId)
            });

            return report;
        }

        [HttpPost]
        public ActionResult CustomerList(DataSourceRequest command, CustomerListModel model,
            [ModelBinder(typeof(CommaSeparatedModelBinder))] int[] searchCustomerRoleIds)
        {
            //we use own own binder for searchCustomerRoleIds property 
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return AccessDeniedView();

            var searchDayOfBirth = 0;
            int searchMonthOfBirth = 0;
            if (!String.IsNullOrWhiteSpace(model.SearchDayOfBirth))
                searchDayOfBirth = Convert.ToInt32(model.SearchDayOfBirth);
            if (!String.IsNullOrWhiteSpace(model.SearchMonthOfBirth))
                searchMonthOfBirth = Convert.ToInt32(model.SearchMonthOfBirth);
            var vendorId = _workContext.CurrentVendor != null ? _workContext.CurrentVendor.Id : 0;

            var customers = _investorService.GetAllCustomers(
                vendorId: vendorId,
                customerRoleIds: searchCustomerRoleIds,
                email: model.SearchEmail,
                username: model.SearchUsername,
                firstName: model.SearchFirstName,
                lastName: model.SearchLastName,
                dayOfBirth: searchDayOfBirth,
                monthOfBirth: searchMonthOfBirth,
                company: model.SearchCompany,
                phone: model.SearchPhone,
                zipPostalCode: model.SearchZipPostalCode,
                ipAddress: model.SearchIpAddress,
                loadOnlyWithShoppingCart: false,
                pageIndex: command.Page - 1,
                pageSize: command.PageSize);
            var gridModel = new DataSourceResult
            {
                Data = customers.Select(PrepareCustomerModelForList),
                Total = customers.TotalCount
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult ReportBestCustomersByOrderTotalList(DataSourceRequest command, BestCustomersReportModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("");

            DateTime? startDateValue = (model.StartDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.StartDate.Value, _dateTimeHelper.CurrentTimeZone);

            DateTime? endDateValue = (model.EndDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.EndDate.Value, _dateTimeHelper.CurrentTimeZone).AddDays(1);

            OrderStatus? orderStatus = model.OrderStatusId > 0 ? (OrderStatus?)(model.OrderStatusId) : null;
            PaymentStatus? paymentStatus = model.PaymentStatusId > 0 ? (PaymentStatus?)(model.PaymentStatusId) : null;
            ShippingStatus? shippingStatus = model.ShippingStatusId > 0 ? (ShippingStatus?)(model.ShippingStatusId) : null;
            var vendorId = _workContext.CurrentVendor != null ? _workContext.CurrentVendor.Id : 0;

            var items = _investorService.GetBestCustomersReport(startDateValue, endDateValue,
                orderStatus, paymentStatus, shippingStatus, 1, vendorId, command.Page - 1, command.PageSize);
            var gridModel = new DataSourceResult
            {
                Data = items.Select(x =>
                {
                    var m = new BestCustomerReportLineModel
                    {
                        CustomerId = x.CustomerId,
                        OrderTotal = _priceFormatter.FormatPrice(x.OrderTotal, true, false),
                        OrderCount = x.OrderCount,
                    };
                    var customer = _customerService.GetCustomerById(x.CustomerId);
                    if (customer != null)
                    {
                        m.CustomerName = customer.IsRegistered() ? customer.Email : _localizationService.GetResource("Admin.Customers.Guest");
                    }
                    return m;
                }),
                Total = items.TotalCount
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult ReportBestCustomersByNumberOfOrdersList(DataSourceRequest command, BestCustomersReportModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("");

            DateTime? startDateValue = (model.StartDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.StartDate.Value, _dateTimeHelper.CurrentTimeZone);

            DateTime? endDateValue = (model.EndDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.EndDate.Value, _dateTimeHelper.CurrentTimeZone).AddDays(1);

            OrderStatus? orderStatus = model.OrderStatusId > 0 ? (OrderStatus?)(model.OrderStatusId) : null;
            PaymentStatus? paymentStatus = model.PaymentStatusId > 0 ? (PaymentStatus?)(model.PaymentStatusId) : null;
            ShippingStatus? shippingStatus = model.ShippingStatusId > 0 ? (ShippingStatus?)(model.ShippingStatusId) : null;
            var vendorId = _workContext.CurrentVendor != null ? _workContext.CurrentVendor.Id : 0;

            var items = _investorService.GetBestCustomersReport(startDateValue, endDateValue,
                orderStatus, paymentStatus, shippingStatus, 2, vendorId, command.Page - 1, command.PageSize);
            var gridModel = new DataSourceResult
            {
                Data = items.Select(x =>
                {
                    var m = new BestCustomerReportLineModel
                    {
                        CustomerId = x.CustomerId,
                        OrderTotal = _priceFormatter.FormatPrice(x.OrderTotal, true, false),
                        OrderCount = x.OrderCount,
                    };
                    var customer = _customerService.GetCustomerById(x.CustomerId);
                    if (customer != null)
                    {
                        m.CustomerName = customer.IsRegistered() ? customer.Email : _localizationService.GetResource("Admin.Customers.Guest");
                    }
                    return m;
                }),
                Total = items.TotalCount
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult ReportRegisteredCustomersList(DataSourceRequest command)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return Content("");

            var model = GetReportRegisteredCustomersModel();
            var gridModel = new DataSourceResult
            {
                Data = model,
                Total = model.Count
            };

            return Json(gridModel);
        }

        #endregion

        #region Helpers
        private void PrepareBlockScoreDetails(IList<BlockScoreAdminModel> model, int customerId, string key)
        {
            _logger.Information("PrepareBlockScoreDetails Invoke");
            var customerBlockScoreAttributes = _genericAttributeService.GetAttributesForEntity(customerId,
                key).Where(x => x.Key.Contains("BlockScore")).ToList();

            if (customerBlockScoreAttributes.Any())
            {
                var modelItem = new BlockScoreAdminModel { ItemType = key };

                foreach (var blockScoreAttribute in customerBlockScoreAttributes)
                {
                    if (blockScoreAttribute.Key == ClientConstants.CustomAttributes.BlockScoreStatus)
                    {
                        modelItem.Valid = blockScoreAttribute.Value == ClientConstants.BlockScore.OptionsValues.Valid;
                    }
                    else
                    {
                        if (blockScoreAttribute.Key == ClientConstants.CustomAttributes.BlockScoreObjectId)
                        {
                            modelItem.Details.Insert(0, new BlockScoreItem
                            {
                                Title = String.Format("Shopfast.Admin.BlockScore.{0}", blockScoreAttribute.Key),
                                Value = new CultureInfo("en-US", false).TextInfo.ToTitleCase(blockScoreAttribute.Value.Replace("_", " "))
                            });
                        }
                        else
                        {
                            modelItem.Details.Add(new BlockScoreItem
                            {
                                CssClass = GetCssClassByBlockScoreValue(blockScoreAttribute.Key, blockScoreAttribute.Value),
                                Title = String.Format("Shopfast.Admin.BlockScore.{0}", blockScoreAttribute.Key),
                                Value = new CultureInfo("en-US", false).TextInfo.ToTitleCase(blockScoreAttribute.Value.Replace("_", " "))
                            });
                        }

                    }
                }
                _logger.Information("BlockScoreAdminModel: " + modelItem);
                model.Add(modelItem);
            }
        }

        private string GetCssClassByBlockScoreValue(string optionName, string value)
        {
            if (optionName == ClientConstants.CustomAttributes.BlockScoreOfacMath)
            {
                switch (value)
                {
                    case ClientConstants.BlockScore.OptionsValues.Match:
                        return ClientConstants.CssClasses.Invalid;
                    case ClientConstants.BlockScore.OptionsValues.PartialMatch:
                        return ClientConstants.CssClasses.Pending;
                    case ClientConstants.BlockScore.OptionsValues.NoMatch:
                        return ClientConstants.CssClasses.Valid;
                    default:
                        return String.Empty;
                }
            }
            switch (value)
            {
                case ClientConstants.BlockScore.OptionsValues.Valid:
                case ClientConstants.BlockScore.OptionsValues.Low:
                case ClientConstants.BlockScore.OptionsValues.Match:
                    return ClientConstants.CssClasses.Valid;
                case ClientConstants.BlockScore.OptionsValues.MisMatch:
                case ClientConstants.BlockScore.OptionsValues.PartialMatch:
                case ClientConstants.BlockScore.OptionsValues.InsufficientData:
                    return ClientConstants.CssClasses.Pending;
                case ClientConstants.BlockScore.OptionsValues.High:
                case ClientConstants.BlockScore.OptionsValues.Invalid:
                case ClientConstants.BlockScore.OptionsValues.NoMatch:
                    return ClientConstants.CssClasses.Invalid;
                default:
                    return String.Empty;
            }
        }      

        #endregion
    }
}
