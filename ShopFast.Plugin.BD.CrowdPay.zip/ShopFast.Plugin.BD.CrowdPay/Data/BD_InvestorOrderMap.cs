﻿using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public class BD_InvestorOrderMap : NopEntityTypeConfiguration<BD_InvestorOrder>
    {
        public BD_InvestorOrderMap()
        {
            this.ToTable("BD_InvestorOrder");
            this.HasKey(tr => tr.Id);            
        }
    }
}
