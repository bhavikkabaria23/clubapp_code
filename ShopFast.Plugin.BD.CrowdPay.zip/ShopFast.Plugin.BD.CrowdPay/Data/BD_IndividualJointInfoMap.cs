using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public partial class BD_IndividualJointInfoMap : NopEntityTypeConfiguration<BD_IndividualJointInfo>
    {
        public BD_IndividualJointInfoMap()
        {
            this.ToTable("BD_IndividualJointInfo");
            this.HasKey(tr => tr.Id);            
        }
    }
}