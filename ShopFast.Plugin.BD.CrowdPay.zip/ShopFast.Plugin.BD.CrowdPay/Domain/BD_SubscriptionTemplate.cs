﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class BD_SubscriptionTemplate : BaseEntity
    {
        public int productId { get; set; }
        public string HTMLTemplate { get; set; }
        public int PDFUploadId { get; set; }
        public string HTMLTemplateForProductAgreement { get; set; }
        public int? PDFUploadIdForProductAgreement { get; set; }
        public bool IsDocusign { get; set; }
        public string DocusignUsername { get; set; }
        public string DocusignPassword { get; set; }
        public string DocuSignIntegratorKey { get; set; }
        public int DocuSignMode { get; set; }
        public int? OfferingType { get; set; }
        public bool AllowInvestment { get; set; }
        public bool ShowLookingToInvest { get; set; }
        public bool AllowNDA { get; set; }
        public string NDAHTMLTemplate { get; set; }        
        public int? NDAPDFUploadId { get; set; }
        public int? PPMPDFUploadId { get; set; }

    }
}
