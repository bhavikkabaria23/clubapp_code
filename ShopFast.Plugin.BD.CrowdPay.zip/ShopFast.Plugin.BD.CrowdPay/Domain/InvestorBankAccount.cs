using Nop.Core;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public partial class InvestorBankAccount : BaseEntity
    {
        public int CustomerId { get; set; }

        #region BankInfo

        public string BankName { get; set; }

        public string BankSwiftCode { get; set; }

        #endregion

        #region AccountInfo

        public string BankAccountType { get; set; }

        public string AccountType { get; set; }

        public string RoutingNumber { get; set; }

        public string NameOnAccount { get; set; }

        public string AccountNumber { get; set; }

        #endregion

        #region AddtionalInfo

        public string AccountName1 { get; set; }

        public string AccountNumber1 { get; set; }

        public string ReferenceText { get; set; }

        public string ContactName { get; set; }

        public string PhoneNumber { get; set; }

        #endregion
    }
}
