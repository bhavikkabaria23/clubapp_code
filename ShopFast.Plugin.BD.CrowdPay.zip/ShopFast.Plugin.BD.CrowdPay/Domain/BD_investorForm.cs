﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class BD_investorForm : BaseEntity
    {        
        public int productId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public int CountryId { get; set; }
        public int StateId { get; set; }
        public int LookingToInvest { get; set; }
        public string PreferedContacts { get; set; }
        public DateTime? TimeToCall { get; set; }
        public string ZipPostalCode { get; set; }

        public string FormType { get; set; }

        public DateTime CreatedOn { get; set; }

        public int? LanguageId { get; set; }

    }
}
