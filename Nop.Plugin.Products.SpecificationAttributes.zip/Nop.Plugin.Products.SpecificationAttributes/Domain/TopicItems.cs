using Nop.Core;

namespace Nop.Plugin.Products.SpecificationAttributes.Domain
{
    /// <summary>
    /// Represents a pickup point of store
    /// </summary>
    public partial class TopicItems : BaseEntity
    {
        /// <summary>
        /// Gets or sets a TopicName
        /// </summary>
        public string TopicName { get; set; }

        /// <summary>
        /// Gets or sets a TopicUrl
        /// </summary>
        public string TopicUrl { get; set; }        
    }
}