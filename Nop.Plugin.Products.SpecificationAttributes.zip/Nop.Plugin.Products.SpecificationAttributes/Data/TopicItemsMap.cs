using Nop.Data.Mapping;
using Nop.Plugin.Products.SpecificationAttributes.Domain;

namespace Nop.Plugin.Products.SpecificationAttributes.Data
{
    public partial class TopicItemsMap : NopEntityTypeConfiguration<TopicItems>
    {
        public TopicItemsMap()
        {
            this.ToTable("TopicItems");
            this.HasKey(topic => topic.Id);            
        }
    }
}