using Nop.Core;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Nop.Plugin.Products.SpecificationAttributes.Models
{
    /// <summary>
    /// Represents a pickup point of store
    /// </summary>
    public partial class TopicItemsModel : BaseNopEntityModel
    {
        public TopicItemsModel()
        {
            AvailableTopics = new List<SelectListItem>();
        }
        [NopResourceDisplayName("Plugin.TopicItem.TopicName")]
        public string TopicName { get; set; }

        [NopResourceDisplayName("Plugin.TopicItem.TopicUrl")]
        public string TopicUrl { get; set; }

        public IList<SelectListItem> AvailableTopics { get; set; }
    }
}