﻿namespace Nop.Plugin.Products.SpecificationAttributes
{
    public static partial class ProductSpecificationAttributeNames
    {        
        public static string ArtistName { get { return "ArtistName"; } }
    }
}
