﻿using Nop.Plugin.Products.SpecificationAttributes.Models;
using Nop.Plugin.Products.SpecificationAttributes.Services;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Nop.Plugin.Products.SpecificationAttributes.Controllers
{
    public class TopicItemsController : BasePluginController
    {
        private readonly ITopicItemsService _topicItemsService;
        private readonly IPermissionService _permissionService;
        public TopicItemsController(ITopicItemsService topicItemsService,
            IPermissionService permissionService)
        {
            _topicItemsService = topicItemsService;
            _permissionService = permissionService;
        }

        [AdminAuthorize]
        public ActionResult Create()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageShippingSettings))
                return Content("Access denied");

            var model = new TopicItemsModel();
        }
    }
}
