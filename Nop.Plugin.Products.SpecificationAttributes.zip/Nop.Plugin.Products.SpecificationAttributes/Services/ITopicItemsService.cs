using Nop.Core;
using Nop.Core.Domain.Topics;
using Nop.Plugin.Products.SpecificationAttributes.Domain;
using System.Collections.Generic;

namespace Nop.Plugin.Products.SpecificationAttributes.Services
{
    public partial interface ITopicItemsService
    {
        IEnumerable<TopicItems> GetAllTopicItems();
        TopicItems GetTopicItemById(int topicItemId);
        void InsertTopicItem(TopicItems topicItem);
        void UpdateTopicItem(TopicItems topicItem);
        void DeleteTopicItem(TopicItems topicItem);
        IEnumerable<Topic> GetAllTopicPages();

    }
}
