using System;
using System.Linq;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Topics;
using System.Collections.Generic;
using Nop.Plugin.Products.SpecificationAttributes.Domain;

namespace Nop.Plugin.Products.SpecificationAttributes.Services
{
    /// <summary>
    /// Store pickup point service
    /// </summary>
    public partial class TopicItemsService : ITopicItemsService
    {       
        #region Fields
        
        private readonly IRepository<Topic> _topicRepository;
        private readonly IRepository<TopicItems> _topicItemRepository;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="cacheManager">Cache manager</param>
        /// <param name="storePickupPointRepository">Store pickup point repository</param>
        public TopicItemsService(IRepository<Topic> topicRepository, IRepository<TopicItems> topicItemRepository)
        {
            this._topicRepository = topicRepository;
            this._topicItemRepository = topicItemRepository;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets all pickup points
        /// </summary>
        /// <param name="storeId">The store identifier; pass 0 to load all records</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <returns>Pickup points</returns>
        public virtual IEnumerable<TopicItems> GetAllTopicItems()
        {
            return _topicItemRepository.Table;  
        }

        /// <summary>
        /// Gets a pickup point
        /// </summary>
        /// <param name="topicItemId">Pickup point identifier</param>
        /// <returns>Pickup point</returns>
        public virtual TopicItems GetTopicItemById(int topicItemId)
        {
            if (topicItemId == 0)
                return null;

           return _topicItemRepository.GetById(topicItemId);
        }

        /// <summary>
        /// Inserts a pickup point
        /// </summary>
        /// <param name="topicItem">Pickup point</param>
        public virtual void InsertTopicItem(TopicItems topicItem)
        {
            if (topicItem == null)
                throw new ArgumentNullException("topicItem");

            _topicItemRepository.Insert(topicItem);            
        }

        /// <summary>
        /// Updates the pickup point
        /// </summary>
        /// <param name="topicItem">Pickup point</param>
        public virtual void UpdateTopicItem(TopicItems topicItem)
        {
            if (topicItem == null)
                throw new ArgumentNullException("topicItem");

            _topicItemRepository.Update(topicItem);            
        }

        /// <summary>
        /// Deletes a pickup point
        /// </summary>
        /// <param name="topicItem">Pickup point</param>
        public virtual void DeleteTopicItem(TopicItems topicItem)
        {
            if (topicItem == null)
                throw new ArgumentNullException("topicItem");

            _topicItemRepository.Delete(topicItem);            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual IEnumerable<Topic> GetAllTopicPages()
        {
            return _topicRepository.Table.Where(t => t.Published == true);
        }

        #endregion
    }
}
