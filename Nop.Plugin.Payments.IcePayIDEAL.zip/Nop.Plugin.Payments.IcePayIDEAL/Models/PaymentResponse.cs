﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.IcePayIDEAL.Models
{
    public class PaymentResponse
    {
        public string orderId { get; set; }
        public string merchantSerialNumber { get; set; }
        public TransactionInfo transactionInfo { get; set; }
        public string errorCode { get; set; }
        public string errorGroup { get; set; }
        public string errorMessage { get; set; }
    }

    public class TransactionInfo
    {
        public string amount { get; set; }
        public string status { get; set; }
        public string transactionId { get; set; }
        public string timeStamp { get; set; }
        public string message { get; set; }
    }

    public class TokenResult
    {
        public string access_token { get; set; }
    }
}
