﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.Payments.IcePayIDEAL
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            //routes.MapRoute("Plugin.Payments.IcePay.GetIssuersByPaymentMethod",
            //     "Plugins/IcePay/GetIssuersByPaymentMethod",
            //     new { controller = "PaymentsIcePay", action = "GetIssuersByPaymentMethod" },
            //     new[] { "Nop.Plugin.Payments.IcePayIDEAL.Controllers" }
            //);           
            routes.MapRoute("Plugin.Payments.IcePayIdeal.CallbackHander",
                 "Plugins/PaymentIcePayIdeal/CallbackHander",
                 new { controller = "PaymentsIcePayIdeal", action = "SetCallbackHander" },
                 new[] { "Nop.Plugin.Payments.IcePayIDEAL.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
