﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Nop.Plugin.Payments.IcePayIDEAL.Models;
using Nop.Plugin.Payments.IcePayIDEAL.Validators;
using Nop.Services;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Plugin.Payments.IcePayIDEAL;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Orders;
using Nop.Services.Orders;
using System.Text;

namespace Nop.Plugin.Payments.IcePayIDEAL.Controllers
{
    public class PaymentsIcePayIdealController : BasePaymentController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;
        private readonly IWebHelper _webHelper;
        private readonly IPaymentService _paymentService;
        private readonly PaymentSettings _paymentSettings;
        private readonly IOrderService _orderService;
        private readonly IOrderProcessingService _orderProcessingService;

        public PaymentsIcePayIdealController(IWorkContext workContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService,
            IWebHelper webHelper,
            IPaymentService paymentService,
            PaymentSettings paymentSettings,
            IOrderService orderService,
            IOrderProcessingService orderProcessingService)
        {
            this._workContext = workContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._localizationService = localizationService;
            this._webHelper = webHelper;
            this._paymentService = paymentService;
            this._paymentSettings = paymentSettings;
            this._orderService = orderService;
            this._orderProcessingService = orderProcessingService;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayIdealPaymentSettings = _settingService.LoadSetting<IcePayIdealPaymentSettings>(storeScope);

            var model = new ConfigurationModel();
            model.MerchantID = IcePayIdealPaymentSettings.MerchantID;
            model.MerchantSecret = IcePayIdealPaymentSettings.MerchantSecret;
            //model.PaymentMethod = IcePayIdealPaymentSettings.PaymentMethod;
            model.Description = IcePayIdealPaymentSettings.Description;
            //model.Issuer = IcePayIdealPaymentSettings.Issuer;
            model.AdditionalFee = IcePayIdealPaymentSettings.AdditionalFee;
            model.AdditionalFeePercentage = IcePayIdealPaymentSettings.AdditionalFeePercentage;
            //    if (IcePayIdealPaymentSettings.MerchantID > 0 && !string.IsNullOrEmpty(IcePayIdealPaymentSettings.MerchantSecret))
            //    {
            //        IcepayRestClient.Payment restPayment =
            //new IcepayRestClient.Payment(IcePayIdealPaymentSettings.MerchantID, IcePayIdealPaymentSettings.MerchantSecret);

            //        if (restPayment != null)
            //        {
            //            IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
            //                restPayment.GetMyPaymentMethods();
            //            if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
            //            {
            //                foreach (var p in getMyPaymentMethodsResponse.PaymentMethods)
            //                {
            //                    model.AvailablePaymentMethods.Add(new SelectListItem { Text = p.PaymentMethodCode, Value = p.PaymentMethodCode });

            //                    var issuers = p.Issuers;
            //                    if (issuers != null && issuers.Any())
            //                    {
            //                        foreach (var item in p.Issuers)
            //                        {
            //                            model.AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }

            //    if (!model.AvailablePaymentMethods.Any())
            //    {
            //        model.AvailablePaymentMethods.Add(new SelectListItem { Text = "N/A", Value = "" });
            //    }
            //    if (!model.AvailableIssuer.Any())
            //    {
            //        model.AvailableIssuer.Add(new SelectListItem { Text = "N/A", Value = "" });
            //    }

            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.MerchantID_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.MerchantID, storeScope);
                model.MerchantSecret_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.MerchantSecret, storeScope);
                //model.PaymentMethod_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.PaymentMethod, storeScope);
                model.Description_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.Description, storeScope);
                //model.Issuer_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.Issuer, storeScope);

                model.AdditionalFee_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = _settingService.SettingExists(IcePayIdealPaymentSettings, x => x.AdditionalFeePercentage, storeScope);
            }

            return View("~/Plugins/Payments.IcePayIDEAL/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayIdealPaymentSettings = _settingService.LoadSetting<IcePayIdealPaymentSettings>(storeScope);

            //save settings
            IcePayIdealPaymentSettings.MerchantID = model.MerchantID;
            IcePayIdealPaymentSettings.MerchantSecret = model.MerchantSecret;
            //IcePayIdealPaymentSettings.PaymentMethod = model.PaymentMethod;
            IcePayIdealPaymentSettings.Description = model.Description;
            //IcePayIdealPaymentSettings.Issuer = model.Issuer;

            IcePayIdealPaymentSettings.AdditionalFee = model.AdditionalFee;
            IcePayIdealPaymentSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */

            _settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.MerchantID, model.MerchantID_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.MerchantSecret, model.MerchantSecret_OverrideForStore, storeScope, false);
            //_settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.PaymentMethod, model.PaymentMethod_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.Description, model.Description_OverrideForStore, storeScope, false);
            //_settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.Issuer, model.Issuer_OverrideForStore, storeScope, false);

            _settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.AdditionalFee, model.AdditionalFee_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayIdealPaymentSettings, x => x.AdditionalFeePercentage, model.AdditionalFeePercentage_OverrideForStore, storeScope, false);

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }

        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();

            //CC types
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Visa",
                Value = "Visa",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Master card",
                Value = "MasterCard",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Discover",
                Value = "Discover",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Amex",
                Value = "Amex",
            });

            //years
            for (int i = 0; i < 15; i++)
            {
                string year = Convert.ToString(DateTime.Now.Year + i);
                model.ExpireYears.Add(new SelectListItem
                {
                    Text = year,
                    Value = year,
                });
            }

            //months
            for (int i = 1; i <= 12; i++)
            {
                string text = (i < 10) ? "0" + i : i.ToString();
                model.ExpireMonths.Add(new SelectListItem
                {
                    Text = text,
                    Value = i.ToString(),
                });
            }

            //set postback values
            var form = this.Request.Form;
            model.CardholderName = form["CardholderName"];
            model.CardNumber = form["CardNumber"];
            model.CardCode = form["CardCode"];
            var selectedCcType = model.CreditCardTypes.FirstOrDefault(x => x.Value.Equals(form["CreditCardType"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedCcType != null)
                selectedCcType.Selected = true;
            var selectedMonth = model.ExpireMonths.FirstOrDefault(x => x.Value.Equals(form["ExpireMonth"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedMonth != null)
                selectedMonth.Selected = true;
            var selectedYear = model.ExpireYears.FirstOrDefault(x => x.Value.Equals(form["ExpireYear"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedYear != null)
                selectedYear.Selected = true;

            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayIdealPaymentSettings = _settingService.LoadSetting<IcePayIdealPaymentSettings>(storeScope);

            if (IcePayIdealPaymentSettings.MerchantID > 0 && !string.IsNullOrEmpty(IcePayIdealPaymentSettings.MerchantSecret))
            {
                IcepayRestClient.Payment restPayment =
        new IcepayRestClient.Payment(IcePayIdealPaymentSettings.MerchantID, IcePayIdealPaymentSettings.MerchantSecret);

                if (restPayment != null)
                {
                    IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
                        restPayment.GetMyPaymentMethods();
                    if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
                    {
                        foreach (var method in getMyPaymentMethodsResponse.PaymentMethods.Where(p => p.PaymentMethodCode.ToLower() == "ideal"))
                        {
                            var issuers = method.Issuers;
                            if (issuers != null && issuers.Any())
                            {
                                foreach (var item in method.Issuers)
                                {
                                    model.AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
                                }
                            }
                        }
                    }
                }
            }

            return View("~/Plugins/Payments.IcePayIDEAL/Views/PaymentInfo.cshtml", model);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();

            //validate
            var validator = new PaymentInfoValidator(_localizationService);
            var model = new PaymentInfoModel
            {
                CardholderName = form["CardholderName"],
                CardNumber = form["CardNumber"],
                CardCode = form["CardCode"],
                ExpireMonth = form["ExpireMonth"],
                ExpireYear = form["ExpireYear"]
            };
            var validationResult = validator.Validate(model);
            if (!validationResult.IsValid)
                foreach (var error in validationResult.Errors)
                    warnings.Add(error.ErrorMessage);
            return warnings;
        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
            paymentInfo.CreditCardType = form["CreditCardType"];
            paymentInfo.CreditCardName = form["CardholderName"];
            paymentInfo.CreditCardNumber = form["CardNumber"];
            paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            paymentInfo.CreditCardCvv2 = form["CardCode"];
            paymentInfo.CustomValues.Add("Issuer", form["Issuer"]);
            return paymentInfo;
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public virtual ActionResult GetIssuersByPaymentMethod(string paymentMethodCode)
        {
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayIdealPaymentSettings = _settingService.LoadSetting<IcePayIdealPaymentSettings>(storeScope);
            IcepayRestClient.Payment restPayment =
  new IcepayRestClient.Payment(IcePayIdealPaymentSettings.MerchantID, IcePayIdealPaymentSettings.MerchantSecret);
            var AvailableIssuer = new List<SelectListItem>();
            if (restPayment != null)
            {
                IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
                    restPayment.GetMyPaymentMethods();
                if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
                {
                    var paymentMethod = getMyPaymentMethodsResponse.PaymentMethods.FirstOrDefault(pm => pm.PaymentMethodCode == paymentMethodCode);
                    if (paymentMethod != null)
                    {
                        if (paymentMethod.Issuers != null && paymentMethod.Issuers.Any())
                        {
                            foreach (var item in paymentMethod.Issuers)
                            {
                                AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
                            }
                        }
                    }
                }
            }
            if (!AvailableIssuer.Any())
            {
                AvailableIssuer.Add(new SelectListItem { Text = "N/A", Value = "" });
            }
            return Json(AvailableIssuer, JsonRequestBehavior.AllowGet);
        }

        [ValidateInput(false)]
        public ActionResult SetCallbackHander()
        {
            //http://nopguru-001-site48.etempurl.com/
            //?Status=OK&
            //StatusCode=Payment+Completed+simulation+via+Test+Mode&
            //Merchant=31299&
            //OrderID=1018&
            //PaymentID=29524922&
            //Reference=&
            //TransactionID=29524922&
            //Checksum=b564548e63230ab935f0e4595df3f80d8b56ab9b&
            //PaymentMethod =IDEAL

            var processor = _paymentService.LoadPaymentMethodBySystemName("Payments.IcePayIDEAL") as IcePayIdealProcessor;
            if (processor == null ||
                !processor.IsPaymentMethodActive(_paymentSettings) || !processor.PluginDescriptor.Installed)
                throw new NopException("IcePay IDEAL module cannot be loaded");

            var Status = _webHelper.QueryString<string>("Status");
            var StatusCode = _webHelper.QueryString<string>("StatusCode");
            var Merchant = _webHelper.QueryString<string>("Merchant");
            var OrderID = _webHelper.QueryString<string>("OrderID");
            var PaymentID = _webHelper.QueryString<string>("PaymentID");
            var Reference = _webHelper.QueryString<string>("Reference");
            var TransactionID = _webHelper.QueryString<string>("TransactionID");
            var Checksum = _webHelper.QueryString<string>("Checksum");
            var PaymentMethod = _webHelper.QueryString<string>("PaymentMethod");

            if (!string.IsNullOrEmpty(OrderID) && !string.IsNullOrEmpty(OrderID) && !string.IsNullOrEmpty(Merchant) && !string.IsNullOrEmpty(TransactionID))
            {
                Guid orderNumberGuid = Guid.Empty;
                try
                {
                    orderNumberGuid = new Guid(OrderID);
                }
                catch { }
                Order order = _orderService.GetOrderByGuid(orderNumberGuid);
                if (order != null)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("Payment status: " + Status);
                    sb.AppendLine("Payment description: " + StatusCode);
                    sb.AppendLine("Merchant : " + Merchant);
                    sb.AppendLine("Order ID : " + OrderID);
                    sb.AppendLine("Payment ID : " + PaymentID);
                    sb.AppendLine("Reference : " + Reference);
                    sb.AppendLine("Transaction ID : " + TransactionID);
                    sb.AppendLine("Checksum : " + Checksum);
                    sb.AppendLine("Payment Method : " + PaymentMethod);

                    var newPaymentStatus = GetPaymentStatus(Status);
                    sb.AppendLine("New payment status: " + newPaymentStatus);

                    //order note
                    order.OrderNotes.Add(new OrderNote
                    {
                        Note = sb.ToString(),
                        DisplayToCustomer = false,
                        CreatedOnUtc = DateTime.UtcNow
                    });
                    _orderService.UpdateOrder(order);

                    //mark order as paid
                    if (newPaymentStatus == PaymentStatus.Paid)
                    {
                        if (_orderProcessingService.CanMarkOrderAsPaid(order))
                        {
                            order.AuthorizationTransactionId = TransactionID;
                            order.SubscriptionTransactionId = TransactionID;
                            order.CaptureTransactionResult = Status + " - " + " - "+ PaymentMethod+" - "+StatusCode;
                            order.CaptureTransactionId = PaymentID;

                            _orderService.UpdateOrder(order);

                            _orderProcessingService.MarkOrderAsPaid(order);
                        }
                    }
                }
                return RedirectToRoute("CheckoutCompleted", new { orderId = 0 });
            }
            else
            {
                Guid orderNumberGuid = Guid.Empty;
                try
                {
                    orderNumberGuid = new Guid(OrderID);
                }
                catch { }
                Order order = _orderService.GetOrderByGuid(orderNumberGuid);
                if (order != null)
                {
                    //order note
                    order.OrderNotes.Add(new OrderNote
                    {
                        Note = "IcePay IDEAL failed. ",
                        DisplayToCustomer = false,
                        CreatedOnUtc = DateTime.UtcNow
                    });
                    _orderService.UpdateOrder(order);
                }
                return RedirectToAction("Index", "Home", new { area = "" });
            }            
        }

        private PaymentStatus GetPaymentStatus(string paymentStatus)
        {
            var result = PaymentStatus.Pending;
            // Stutus can be "OK" or "OPEN" or "ERR"
            if (paymentStatus.ToLower() == "ok")
            {
                result = PaymentStatus.Paid;
            }
            else if (paymentStatus.ToLower() == "open")
            {
                result = PaymentStatus.Pending;
            }
            else // Status = "ERR"
            {
                result = PaymentStatus.Voided;
            }
            return result;
        }
    }
}