﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CheckoutFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CheckoutController)) &&
                (actionDescriptor.ActionName.ToLower().Equals("completed")))
                //(actionDescriptor.ActionName.Equals("OpcConfirmOrder") || actionDescriptor.ActionName.Equals("ConfirmOrder")))
            {
                return new[]
                    {
                        new Filter(new CheckoutFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}