﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class TopicFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(TopicController)) &&
                (actionDescriptor.ActionName.Equals("TopicBlock") || actionDescriptor.ActionName.Equals("TopicDetails")
                || actionDescriptor.ActionName.Equals("TopicDetailsPopup")
                ))
            {
                return new[]
                    {
                        new Filter(new TopicFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}