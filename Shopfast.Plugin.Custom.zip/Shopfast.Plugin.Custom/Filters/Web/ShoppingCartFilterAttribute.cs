﻿using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Orders;
using Shopfast.Plugin.Custom.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class ShoppingCartFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.ActionDescriptor.ActionName.ToLower() == "addproducttocart_details")
            {
                if (filterContext.HttpContext.Request.Form["hdnPackage"] != null)
                {
                    if (filterContext.HttpContext.Request.Form["hdnPackage"] == "packagePage")
                    {
                        var formCollection = new FormCollection(filterContext.HttpContext.Request.Form);
                        string attributes = ParseProductAttributes(Convert.ToInt32(filterContext.Controller.ValueProvider.GetValue("productId").AttemptedValue), formCollection);
                        var UserNameAttrib = EngineContext.Current.Resolve<IProductAttributeParser>().ParseProductAttributeMappings(attributes)
                                               .SingleOrDefault(a => a.ProductAttribute.Name.ToLower() == "enter your email");
                        if (UserNameAttrib != null)
                        {
                            string email = EngineContext.Current.Resolve<IProductAttributeParser>().ParseValues(attributes, UserNameAttrib.Id).FirstOrDefault();
                            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerByEmail(email) != null)
                            {
                                var result = new JsonResult();
                                result.Data = new
                                {
                                    success = false,
                                    message = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Account.Register.Errors.EmailAlreadyExists")
                                };
                                filterContext.Result = result;
                                return;
                            }
                        }
                    }
                }
            }
        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            
            if (filterContext.ActionDescriptor.ActionName.ToLower() == "cart")
            {
                //if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
                //{
                //    ProductHelper.ProcessSpecialAttributes(model);
                //    if (HttpContext.Current.Request["type"] == "upgrade")
                //    {
                //        filterContext.Result = new RedirectResult("/checkout");
                //        return;
                //    }
                //}               
            }
            else if (filterContext.ActionDescriptor.ActionName.ToLower() == "updatecart")
            {

            }
            else if (filterContext.ActionDescriptor.ActionName.ToLower() == "ordersummary")
            {

                    //message = _localizationService.GetResource("Account.Register.Errors.EmailAlreadyExists")                
            }
        }

        protected virtual string ParseProductAttributes(int productId, FormCollection form)
        {   
            string attributesXml = "";

            #region Product attributes
            var productAttributes = EngineContext.Current.Resolve<IProductAttributeService>().GetProductAttributeMappingsByProductId(productId);
            foreach (var attribute in productAttributes)
            {
                string controlId = string.Format("product_attribute_{0}", attribute.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                        // Customized***
                        {
                            var ddlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ddlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ddlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    //------------
                    case AttributeControlType.RadioList:
                        // Customized***
                        {
                            var rblAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(rblAttributes))
                            {
                                int selectedAttributeId = int.Parse(rblAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    //------------
                    case AttributeControlType.ColorSquares:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ctrlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.ImageSquares:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ctrlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.Checkboxes:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                foreach (var item in ctrlAttributes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                                {
                                    int selectedAttributeId = int.Parse(item);
                                    if (selectedAttributeId > 0)
                                        attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                                }
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //load read-only (already server-side selected) values
                            var attributeValues = EngineContext.Current.Resolve<IProductAttributeService>().GetProductAttributeValues(attribute.Id);
                            foreach (var selectedAttributeId in attributeValues
                                .Where(v => v.IsPreSelected)
                                .Select(v => v.Id)
                                .ToList())
                            {
                                attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                    attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.TextBox:
                        // Customized***
                        {
                            var txtAttribute = form[controlId];
                            if (!String.IsNullOrEmpty(txtAttribute))
                            {
                                string enteredText = txtAttribute.Trim();
                                attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                    attribute, enteredText);
                            }
                        }
                        break;
                    //------------
                    case AttributeControlType.MultilineTextbox:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                string enteredText = ctrlAttributes.Trim();
                                attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                    attribute, enteredText);
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                        {
                            var day = form[controlId + "_day"];
                            var month = form[controlId + "_month"];
                            var year = form[controlId + "_year"];
                            DateTime? selectedDate = null;
                            try
                            {
                                selectedDate = new DateTime(Int32.Parse(year), Int32.Parse(month), Int32.Parse(day));
                            }
                            catch { }
                            if (selectedDate.HasValue)
                            {
                                attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                    attribute, selectedDate.Value.ToString("D"));
                            }
                        }
                        break;
                    case AttributeControlType.FileUpload:
                        {
                            Guid downloadGuid;
                            Guid.TryParse(form[controlId], out downloadGuid);
                            var download = EngineContext.Current.Resolve<IDownloadService>().GetDownloadByGuid(downloadGuid);
                            if (download != null)
                            {
                                attributesXml = EngineContext.Current.Resolve<IProductAttributeParser>().AddProductAttribute(attributesXml,
                                        attribute, download.DownloadGuid.ToString());
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            #endregion            

            return attributesXml;
        }
    }
}