﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class ReportModel
    {
        public ReportModel()
        {
            ResidualDataList = new List<ResidualDataModel>();
            MonthsList = new List<SelectListItem>();
            //MonthsList.Add(new SelectListItem() { Value = "", Text = "All" });
            MonthsList.Add(new SelectListItem() { Value = "1", Text = "January" });
            MonthsList.Add(new SelectListItem() { Value = "2", Text = "February" });
            MonthsList.Add(new SelectListItem() { Value = "3", Text = "March" });
            MonthsList.Add(new SelectListItem() { Value = "4", Text = "April" });
            MonthsList.Add(new SelectListItem() { Value = "5", Text = "May" });
            MonthsList.Add(new SelectListItem() { Value = "6", Text = "June" });
            MonthsList.Add(new SelectListItem() { Value = "7", Text = "July" });
            MonthsList.Add(new SelectListItem() { Value = "8", Text = "August" });
            MonthsList.Add(new SelectListItem() { Value = "9", Text = "September" });
            MonthsList.Add(new SelectListItem() { Value = "10", Text = "October" });
            MonthsList.Add(new SelectListItem() { Value = "11", Text = "November" });
            MonthsList.Add(new SelectListItem() { Value = "12", Text = "December" });
            YearsList = new List<SelectListItem>();

            AgentList = new List<SelectListItem>();
            AgentList.Add(new SelectListItem() { Value = "", Text = "All" });
            AgentList.Add(new SelectListItem() { Value = "partnerbhavik@olb.com", Text = "Bhavik Kabariya - 100001" });
            AgentList.Add(new SelectListItem() { Value = "jmartin@olb.com", Text = "Jason Martin - 981900" });
        }
        public List<SelectListItem> MonthsList { get; set; }
        public string SelectedMonth { get; set; }
        public List<SelectListItem> YearsList { get; set; }
        public string SelectedYear { get; set; }

        public List<SelectListItem> AgentList { get; set; }
        public string SelectedAgent { get; set; }

        public List<ResidualDataModel> ResidualDataList { get; set; }
    }

    public class ResidualDataModel
    {
        public int new_id { get; set; } // ID
        public string _new_merchantboarding_value { get; set; } // MERCHANT BOARDING
        public string _new_merchantpartner_value { get; set; } // MERCHANT PARTNER
        public string new_feename { get; set; } // FEE NAME
        public decimal new_peritemrate { get; set; } // PERITEM RATE
        public decimal new_volume { get; set; } // VOLUME
        public int new_count { get; set; }// COUNT
        public decimal new_income { get; set; }// INCOME
        public decimal new_expense { get; set; }// EXPENSE
        public DateTime new_reportdate { get; set; } // REPORT DATE
        public DateTime createdon { get; set; } // Created On


        // Need to tell Vaishali to give in API
        [JsonProperty(PropertyName = "merchantboarding.new_name")]
        public string MerchantName { get; set; }
        [JsonProperty(PropertyName = "merchantpartner.new_name")]
        public string ISO_AgentName { get; set; } // Partner name
        [JsonProperty(PropertyName = "merchantboarding.new_mid")]
        public string MerchantId { get; set; }
        [JsonProperty(PropertyName = "merchantboarding.new_businessemailaddress")]
        public string MerchantEmail { get; set; }
        [JsonProperty(PropertyName = "merchantpartner.new_agentid")]
        public string ISO_AgentId { get; set; } // Partner Id
        [JsonProperty(PropertyName = "merchantpartner.new_emailaddress")]
        public string Agent_Email { get; set; } // Partner Email

        public int MerchantCount { get; set; }

    }
}
