﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Nop.Plugin.Payments.IcePay.Models;
using Nop.Plugin.Payments.IcePay.Validators;
using Nop.Services;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Plugin.Payments.IcePay;

namespace Nop.Plugin.Payments.IcePay.Controllers
{
    public class PaymentsIcePayController : BasePaymentController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        public PaymentsIcePayController(IWorkContext workContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService)
        {
            this._workContext = workContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._localizationService = localizationService;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayPaymentSettings = _settingService.LoadSetting<IcePayPaymentSettings>(storeScope);

            var model = new ConfigurationModel();
            model.MerchantID = IcePayPaymentSettings.MerchantID;
            model.MerchantSecret = IcePayPaymentSettings.MerchantSecret;
            //model.PaymentMethod = IcePayPaymentSettings.PaymentMethod;
            model.Description = IcePayPaymentSettings.Description;
            //model.Issuer = IcePayPaymentSettings.Issuer;
            model.AdditionalFee = IcePayPaymentSettings.AdditionalFee;
            model.AdditionalFeePercentage = IcePayPaymentSettings.AdditionalFeePercentage;
        //    if (IcePayPaymentSettings.MerchantID > 0 && !string.IsNullOrEmpty(IcePayPaymentSettings.MerchantSecret))
        //    {
        //        IcepayRestClient.Payment restPayment =
        //new IcepayRestClient.Payment(IcePayPaymentSettings.MerchantID, IcePayPaymentSettings.MerchantSecret);

        //        if (restPayment != null)
        //        {
        //            IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
        //                restPayment.GetMyPaymentMethods();
        //            if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
        //            {
        //                foreach (var p in getMyPaymentMethodsResponse.PaymentMethods)
        //                {
        //                    model.AvailablePaymentMethods.Add(new SelectListItem { Text = p.PaymentMethodCode, Value = p.PaymentMethodCode });

        //                    var issuers = p.Issuers;
        //                    if (issuers != null && issuers.Any())
        //                    {
        //                        foreach (var item in p.Issuers)
        //                        {
        //                            model.AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }

        //    if (!model.AvailablePaymentMethods.Any())
        //    {
        //        model.AvailablePaymentMethods.Add(new SelectListItem { Text = "N/A", Value = "" });
        //    }
        //    if (!model.AvailableIssuer.Any())
        //    {
        //        model.AvailableIssuer.Add(new SelectListItem { Text = "N/A", Value = "" });
        //    }

            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.MerchantID_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.MerchantID, storeScope);
                model.MerchantSecret_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.MerchantSecret, storeScope);
                //model.PaymentMethod_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.PaymentMethod, storeScope);
                model.Description_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.Description, storeScope);
                //model.Issuer_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.Issuer, storeScope);

                model.AdditionalFee_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = _settingService.SettingExists(IcePayPaymentSettings, x => x.AdditionalFeePercentage, storeScope);
            }

            return View("~/Plugins/Payments.IcePay/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayPaymentSettings = _settingService.LoadSetting<IcePayPaymentSettings>(storeScope);

            //save settings
            IcePayPaymentSettings.MerchantID = model.MerchantID;
            IcePayPaymentSettings.MerchantSecret = model.MerchantSecret;
            //IcePayPaymentSettings.PaymentMethod = model.PaymentMethod;
            IcePayPaymentSettings.Description = model.Description;
            //IcePayPaymentSettings.Issuer = model.Issuer;

            IcePayPaymentSettings.AdditionalFee = model.AdditionalFee;
            IcePayPaymentSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */

            _settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.MerchantID, model.MerchantID_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.MerchantSecret, model.MerchantSecret_OverrideForStore, storeScope, false);
            //_settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.PaymentMethod, model.PaymentMethod_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.Description, model.Description_OverrideForStore, storeScope, false);
            //_settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.Issuer, model.Issuer_OverrideForStore, storeScope, false);

            _settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.AdditionalFee, model.AdditionalFee_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(IcePayPaymentSettings, x => x.AdditionalFeePercentage, model.AdditionalFeePercentage_OverrideForStore, storeScope, false);

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }

        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();

            //CC types
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Visa",
                Value = "Visa",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Master card",
                Value = "MasterCard",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Discover",
                Value = "Discover",
            });
            model.CreditCardTypes.Add(new SelectListItem
            {
                Text = "Amex",
                Value = "Amex",
            });

            //years
            for (int i = 0; i < 15; i++)
            {
                string year = Convert.ToString(DateTime.Now.Year + i);
                model.ExpireYears.Add(new SelectListItem
                {
                    Text = year,
                    Value = year,
                });
            }

            //months
            for (int i = 1; i <= 12; i++)
            {
                string text = (i < 10) ? "0" + i : i.ToString();
                model.ExpireMonths.Add(new SelectListItem
                {
                    Text = text,
                    Value = i.ToString(),
                });
            }

            //set postback values
            var form = this.Request.Form;
            model.CardholderName = form["CardholderName"];
            model.CardNumber = form["CardNumber"];
            model.CardCode = form["CardCode"];
            var selectedCcType = model.CreditCardTypes.FirstOrDefault(x => x.Value.Equals(form["CreditCardType"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedCcType != null)
                selectedCcType.Selected = true;
            var selectedMonth = model.ExpireMonths.FirstOrDefault(x => x.Value.Equals(form["ExpireMonth"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedMonth != null)
                selectedMonth.Selected = true;
            var selectedYear = model.ExpireYears.FirstOrDefault(x => x.Value.Equals(form["ExpireYear"], StringComparison.InvariantCultureIgnoreCase));
            if (selectedYear != null)
                selectedYear.Selected = true;
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayPaymentSettings = _settingService.LoadSetting<IcePayPaymentSettings>(storeScope);

            if (IcePayPaymentSettings.MerchantID > 0 && !string.IsNullOrEmpty(IcePayPaymentSettings.MerchantSecret))
            {
                IcepayRestClient.Payment restPayment =
        new IcepayRestClient.Payment(IcePayPaymentSettings.MerchantID, IcePayPaymentSettings.MerchantSecret);

                if (restPayment != null)
                {
                    IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
                        restPayment.GetMyPaymentMethods();
                    if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
                    {
                        foreach (var p in getMyPaymentMethodsResponse.PaymentMethods)
                        {
                            model.AvailablePaymentMethods.Add(new SelectListItem { Text = p.PaymentMethodCode, Value = p.PaymentMethodCode });

                            var issuers = p.Issuers;
                            if (issuers != null && issuers.Any())
                            {
                                foreach (var item in p.Issuers)
                                {
                                    model.AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
                                }
                            }
                        }
                    }
                }
            }

            if (!model.AvailablePaymentMethods.Any())
            {
                model.AvailablePaymentMethods.Add(new SelectListItem { Text = "N/A", Value = "" });
            }
            if (!model.AvailableIssuer.Any())
            {
                model.AvailableIssuer.Add(new SelectListItem { Text = "N/A", Value = "" });
            }

            return View("~/Plugins/Payments.IcePay/Views/PaymentInfo.cshtml", model);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();

            //validate
            var validator = new PaymentInfoValidator(_localizationService);
            var model = new PaymentInfoModel
            {
                CardholderName = form["CardholderName"],
                CardNumber = form["CardNumber"],
                CardCode = form["CardCode"],
                ExpireMonth = form["ExpireMonth"],
                ExpireYear = form["ExpireYear"]
            };
            var validationResult = validator.Validate(model);
            if (!validationResult.IsValid)
                foreach (var error in validationResult.Errors)
                    warnings.Add(error.ErrorMessage);
            return warnings;
        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
            paymentInfo.CreditCardType = form["CreditCardType"];
            paymentInfo.CreditCardName = form["CardholderName"];
            paymentInfo.CreditCardNumber = form["CardNumber"];
            paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            paymentInfo.CreditCardCvv2 = form["CardCode"];
            paymentInfo.CustomValues.Add("PaymentMethod", form["PaymentMethod"]);
            paymentInfo.CustomValues.Add("Issuer", form["Issuer"]);
            return paymentInfo;
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public virtual ActionResult GetIssuersByPaymentMethod(string paymentMethodCode)
        {
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var IcePayPaymentSettings = _settingService.LoadSetting<IcePayPaymentSettings>(storeScope);
            IcepayRestClient.Payment restPayment =
  new IcepayRestClient.Payment(IcePayPaymentSettings.MerchantID, IcePayPaymentSettings.MerchantSecret);
            var AvailableIssuer = new List<SelectListItem>();
            if (restPayment != null)
            {
                IcepayRestClient.Classes.Payment.GetMyPaymentMethodsResponse getMyPaymentMethodsResponse =
                    restPayment.GetMyPaymentMethods();
                if (getMyPaymentMethodsResponse != null && getMyPaymentMethodsResponse.PaymentMethods.Any())
                {
                    var paymentMethod = getMyPaymentMethodsResponse.PaymentMethods.FirstOrDefault(pm => pm.PaymentMethodCode == paymentMethodCode);
                    if (paymentMethod != null)
                    {
                        if (paymentMethod.Issuers != null && paymentMethod.Issuers.Any())
                        {
                            foreach (var item in paymentMethod.Issuers)
                            {
                                AvailableIssuer.Add(new SelectListItem { Text = item.IssuerKeyword, Value = item.IssuerKeyword });
                            }
                        }
                    }
                }
            }
            if (!AvailableIssuer.Any())
            {
                AvailableIssuer.Add(new SelectListItem { Text = "N/A", Value = "" });
            }
            return Json(AvailableIssuer, JsonRequestBehavior.AllowGet);
        }
    }
}