using System;
using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Plugins;
using NopGuru.Nop.Plugins.Payments.Vipps.Controllers;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using System.Net;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Web;
using System.Net.Http.Headers;
using NopGuru.Nop.Plugins.Payments.Vipps.Models;
using System.Globalization;
using Nop.Services.Customers;
using Nop.Core;
using System.Linq;

namespace NopGuru.Nop.Plugins.Payments.Vipps
{
    /// <summary>
    /// Manual payment processor
    /// </summary>
    public class VippsPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly ILocalizationService _localizationService;
        private readonly VippsPaymentSettings _VippsPaymentSettings;
        private readonly ISettingService _settingService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ICustomerService _customerService;
        private readonly IOrderService _orderService;

        #endregion

        #region Ctor

        public VippsPaymentProcessor(ILocalizationService localizationService,
            VippsPaymentSettings VippsPaymentSettings,
            ISettingService settingService, IOrderTotalCalculationService orderTotalCalculationService,
            ICustomerService customerService,
            IOrderService orderService)
        {
            this._localizationService = localizationService;
            this._VippsPaymentSettings = VippsPaymentSettings;
            this._settingService = settingService;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._customerService = customerService;
            this._orderService = orderService;
        }

        #endregion

        #region Utilities
        private PaymentResponse VippsAPI(ProcessPaymentRequest request, out string error)
        {
            error = "";
          
            var paymentResponse = new PaymentResponse();
            if (Convert.ToInt32(request.OrderTotal) < 100 || Convert.ToInt32(request.OrderTotal) > 9999999)
            {
                error = _localizationService.GetResource("Plugins.Payments.Vipps.Fields.InvalidAmount");
                return paymentResponse;
            }
            try
            {
                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);

                // Request headers
                client.DefaultRequestHeaders.Add("client_id", _VippsPaymentSettings.ClientId);
                client.DefaultRequestHeaders.Add("client_secret", _VippsPaymentSettings.ClientSecret);
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyToken);

                var uriToken = _VippsPaymentSettings.BaseAPIUrl + "/accessToken/get";

                HttpResponseMessage responseToken;

                // Request body
                byte[] byteData = Encoding.UTF8.GetBytes("{body}");

                using (var content = new ByteArrayContent(byteData))
                {
                    //content.Headers.ContentType = new MediaTypeHeaderValue("application/json; charset=utf-8");
                    responseToken = client.PostAsync(uriToken, content).Result;
                    if (responseToken.IsSuccessStatusCode)
                    {
                        var tokenResult = responseToken.Content.ReadAsAsync<TokenResult>().Result;
                        client = new HttpClient();

                        //var date = new DateTimeOffset(2016, 3, 29, 12, 20, 35, 93, TimeSpan.FromHours(-5));
                        var date = new DateTimeOffset(DateTime.Now);

                        // Request headers
                        client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenResult.access_token);
                        client.DefaultRequestHeaders.Add("X-Request-Id", _VippsPaymentSettings.RequestId);
                        client.DefaultRequestHeaders.Add("X-TimeStamp", FormatIso8601(date));
                        //client.DefaultRequestHeaders.Add("X-TimeStamp", "2014-06-24T08:34:25-07:00");
                        client.DefaultRequestHeaders.Add("X-Source-Address", _VippsPaymentSettings.SourceAddress);
                        client.DefaultRequestHeaders.Add("X-App-Id", _VippsPaymentSettings.ClientId);
                        client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyPayment);
                        //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                        var uriPayment = _VippsPaymentSettings.BaseAPIUrl + "/Ecomm/v1/payments";

                        HttpResponseMessage responsePayment;

                        // Request body

                        Random ran = new Random();
                        int orderId = ran.Next();
                        string mobileNumber = Convert.ToString(request.CustomValues.FirstOrDefault(c => c.Key == "MobileNumber").Value);

                        string bodyContent = "{{" +
         "\"merchantInfo\": {{" +
         "\"merchantSerialNumber\": \"{0}\"," +
         "\"callBack\": \"{1}\"" +
         "}}," +
         "\"customerInfo\": {{" +
         "\"mobileNumber\":\"{2}\"" +
         "}}," +
         "\"transaction\": {{" +
         "\"orderId\": \"{3}\"," +
              //"\"refOrderId\": \"{4}\"," +
         "\"amount\": {4}," +
         "\"transactionText\": \"{5}\"," +
         "\"timeStamp\":\"{6}\"" +
         "}}" +
         "}}";


                        //            string bodyContent = "{" +
                        //"\"merchantInfo\": {" +
                        //"\"merchantSerialNumber\": \"" + _VippsPaymentSettings.MerchantSerialNumber + "\"," +
                        //"\"callBack\": \"" + _VippsPaymentSettings.PaymentCallBackUrl + "\"" +
                        //"}," +
                        //"\"customerInfo\": {" +
                        //"\"mobileNumber\":\"" + mobileNumber + "\"" +
                        //"}," +
                        //"\"transaction\": {" +
                        //"\"orderId\": \"" + request.InitialOrderId + "\"," +
                        //     "\"refOrderId\": \"" + request.OrderGuid + "\"," +
                        //"\"amount\": " + request.OrderTotal + "," +
                        //"\"transactionText\": \"" + _VippsPaymentSettings.TransactionText + "\"," +
                        //"\"timeStamp\":\"" + FormatIso8601(date) + "\"" +
                        //"}" +
                        //"}";

                        // bodyContent = string.Format(bodyContent,
                        //_VippsPaymentSettings.MerchantSerialNumber,
                        //_VippsPaymentSettings.PaymentCallBackUrl,
                        //mobileNumber,
                        //    "878798",
                        // "119930211",
                        ////request.OrderGuid.ToString(),
                        ////request.OrderGuid.ToString(),
                        //Convert.ToInt32(request.OrderTotal),
                        //_VippsPaymentSettings.TransactionText,
                        //"2014-06-24T08:34:25-07:00"
                        ////FormatIso8601(date)
                        //);

                        bodyContent = string.Format(bodyContent,
                            _VippsPaymentSettings.MerchantSerialNumber,
                      _VippsPaymentSettings.PaymentCallBackUrl,
                        mobileNumber,
                            orderId.ToString(),
                            //request.OrderGuid.ToString(),
                            Convert.ToInt32(request.OrderTotal * 100),
                            _VippsPaymentSettings.TransactionText,
                            "2014-06-24T08:34:25-07:00");

                        byteData = Encoding.UTF8.GetBytes(bodyContent);

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            responsePayment = client.PostAsync(uriPayment, contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                paymentResponse = responsePayment.Content.ReadAsAsync<PaymentResponse>().Result;
                                if (!string.IsNullOrEmpty(paymentResponse.errorCode))
                                {
                                    error = "errorCode = " + paymentResponse.errorCode + " ,errorGroup = " + paymentResponse.errorGroup + " ,errorMessage = " + paymentResponse.errorMessage;
                                }                          
                            }
                            else
                            {
                                error += " ,Status Code = " + responsePayment.StatusCode + " ,Request = " + responsePayment.RequestMessage;
                            }
                        }
                    }
                }
                return paymentResponse;
            }
            catch (Exception ex)
            {
                // Something else went wrong, e.g. invalid arguments passed to the order object.
                error = ex.Message;
                return paymentResponse;
            }
        }

        public static string FormatIso8601(DateTimeOffset dto)
        {
            string format = dto.Offset == TimeSpan.Zero
                ? "yyyy-MM-ddTHH:mm:ss.fffZ"
                : "yyyy-MM-ddTHH:mm:ss.fffzzz";

            return dto.ToString(format, CultureInfo.InvariantCulture);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            string error = "";
            var paymentResponse = VippsAPI(processPaymentRequest, out error);
            if (string.IsNullOrEmpty(error))
            {
                // Stutus can be "checkout_incomplete" or "created" or "checkout_complete"
                if (paymentResponse.transactionInfo.status.ToLower() == "cancel" ||
                    paymentResponse.transactionInfo.status.ToLower() == "autocancel" ||
                    paymentResponse.transactionInfo.status.ToLower() == "failed")
                {
                    result.NewPaymentStatus = PaymentStatus.Pending;
                }
                else if (paymentResponse.transactionInfo.status.ToLower() == "void")
                {
                    result.NewPaymentStatus = PaymentStatus.Voided;
                }

                else
                {
                    result.NewPaymentStatus = PaymentStatus.Paid;
                }
                result.CaptureTransactionResult = paymentResponse.transactionInfo.status;
                result.SubscriptionTransactionId = paymentResponse.transactionInfo.transactionId;
                result.CaptureTransactionId = paymentResponse.transactionInfo.transactionId;
            }
            else
            {
                result.AddError(error);
            }
            return result;
        }

        protected string GetRequestData(string url, out string error)
        {
            string responseData = "";
            error = "";
            try
            {
                WebRequest request = WebRequest.Create(url); //Type url here
                using (WebResponse response = request.GetResponse())
                {
                    using (StreamReader responseReader = new StreamReader(response.GetResponseStream()))
                    {
                        responseData = responseReader.ReadToEnd();
                    }
                }
            }
            catch (WebException wex)
            {
                error = wex.Message;
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return responseData;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            var result = this.CalculateAdditionalFee(_orderTotalCalculationService, cart,
                _VippsPaymentSettings.AdditionalFee, _VippsPaymentSettings.AdditionalFeePercentage);
            return result;
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();
            result.AddError("Capture method not supported");
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();
            result.AddError("Refund method not supported");
            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();
            result.AddError("Void method not supported");
            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            //always success
            return new CancelRecurringPaymentResult();
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "PaymentsVipps";
            routeValues = new RouteValueDictionary { { "Namespaces", "NopGuru.Nop.Plugins.Payments.Vipps.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "PaymentsVipps";
            routeValues = new RouteValueDictionary { { "Namespaces", "NopGuru.Nop.Plugins.Payments.Vipps.Controllers" }, { "area", null } };
        }

        public Type GetControllerType()
        {
            return typeof(PaymentsVippsController);
        }

        public override void Install()
        {
            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee", "Additional fee");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl", "Base API Url");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrlHelp", "Don't include / at the end of URL");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl.Hint", "Base API Url.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId", "Client Id");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId.Hint", "Client Id.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret", "Client Secret");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret.Hint", "Client Secret.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken", "Subscription Key for Token");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken.Hint", "Subscription Key for Token.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId", "Request Id");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId.Hint", "Request Id.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress", "Source Address (IP Address)");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress.Hint", "Source Address (IP Address).");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment", "Subscription Key for Payment");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment.Hint", "Subscription Key for Payment.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber", "Merchant Serial Number");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber.Hint", "Merchant Serial Number.");
            //this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber", "Mobile Number");
            //this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber.Hint", "Mobile Number.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText", "Transaction Text");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText.Hint", "Transaction Text.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl", "Payment Call Back Url");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl.Hint", "Payment Call Back Url.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.PaymentMethodDescription", "Pay by credit / debit card");
            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.InvalidAmount", "Amount is invalid. Minimum amount value should be 100 and maximum amount value should be 9999999.");
            

            this.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber.Required", "Mobile Number is required");


            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<VippsPaymentSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl.Hint");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentMethodDescription");
            this.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.InvalidAmount");

            base.Uninstall();
        }


        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Manual;
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a payment method description that will be displayed on checkout pages in the public store
        /// </summary>
        public string PaymentMethodDescription
        {
            //return description of this payment method to be display on "payment method" checkout step. good practice is to make it localizable
            //for example, for a redirection payment method, description may be like this: "You will be redirected to PayPal site to complete the payment"
            get { return _localizationService.GetResource("Plugins.Payments.Vipps.Fields.PaymentMethodDescription"); }
        }

        #endregion

    }
}
