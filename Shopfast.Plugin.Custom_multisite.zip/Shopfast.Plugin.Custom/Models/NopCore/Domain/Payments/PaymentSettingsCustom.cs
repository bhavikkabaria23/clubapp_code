﻿using Nop.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopCore.Domain.Payments
{
    public class PaymentSettingsCustom : ISettings
    {
        public PaymentSettingsCustom()
        {            
            // Payment method IsTabletOnly
            TabletPaymentMethodSystemNames = new List<string>();
        }

        

        //primary payment method - new added
        /// <summary>
        /// Gets or sets a system name of primary payment method for mobile application.
        /// </summary>
        public string PrimaryPaymentMethodSystemName { get; set; }

        // Payment method IsTabletOnly - new added
        /// <summary>
        /// Gets or sets a system name of mobile payment method for mobile application.
        /// </summary>
        public List<string> TabletPaymentMethodSystemNames { get; set; }
       
    }
}