﻿using Nop.Admin.Controllers;
using Shopfast.Plugin.Custom.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class DiscountCustomAdminController : BaseAdminController
    {
        [HttpPost]
        public ActionResult GenerateQRCodeDiscount(string code)
        {
            string QRCodeImageUrl = string.Empty;
            if (!string.IsNullOrEmpty(code))
            {
                QRCodeImageUrl = "/" + CommonHelperCustom.GenerateQRCodeImage(code);
            }
            return Json(new { QRCodeUrl = QRCodeImageUrl }, JsonRequestBehavior.AllowGet);
        }
    }
}